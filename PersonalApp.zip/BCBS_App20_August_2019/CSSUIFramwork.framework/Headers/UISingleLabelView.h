//
//  UISingleLabelView.h
//  CSSUIFramwork
//
//  Created by CSS Admin on 6/22/18.
//  Copyright © 2018 csscorp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ValidatorLabel.h"

IB_DESIGNABLE

@interface UISingleLabelView : UIView

@property (strong, nonatomic) IBOutlet ValidatorLabel *contentLabel;

@property (strong, nonatomic) IBOutlet UISingleLabelView *singleLabelView;

@property (nonatomic,strong) NSString *xPath;

-(void)setEnabled:(BOOL)enabled;
-(void)setUserInteractionEnabled:(BOOL)userInteractionEnabled;

@end
