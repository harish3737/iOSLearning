//
//  DBHelper.h
//  BcBs
//
//  Created by CSS Admin on 6/20/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>



@interface DBHelper : NSObject{
    
    sqlite3 *sqlite3Database;
}

@property (nonatomic,strong) NSString *documentsDirectory;
@property (nonatomic,strong) NSString *databaseFilename;
@property (nonatomic,strong) NSString *databasePathDir; 
@property (nonatomic,strong) NSMutableArray *arrResults;
@property (nonatomic,strong) NSMutableArray *arrColumnNames;
@property (nonatomic)int affectedRows;
@property (nonatomic)long long lastInsertedRowID;

-(void)copyDatabaseIntoDocumentsDirectory;
-(instancetype)initWithDatabaseFilename:(NSString *)dbFilename;

-(void)runQuery:(const char *)query isQueryExecutable:(BOOL)queryExecutable;
-(NSArray *)loadDataFromDB:(NSString *)query;
-(void)executeQuery:(NSString *)query;

-(void)createQuery:(NSString *)query;
-(void)createDatabase;

-(void)executeQuery:(NSString *)jsonString queryTemplate:(NSString*)query;

@end
