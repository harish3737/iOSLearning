//
//  UIDropDown.h
//  SampleBCBSPOC
//
//  Created by CSS Admin on 5/20/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIPopOverContentViewController.h"
#import "Validator.h"
#import "UICallback.h"
#import "UIConfirmImageView.h"


IB_DESIGNABLE

typedef void(^ActionBlock)(id selectedDate, id parent);


//vr
@protocol DropDownDelegate <NSObject>

@optional
-(void)dropDownLabelText:(NSString *)selectedString tag:(long)tag;

@end

@interface UIDropDown : UIView <UIPopOverDisplayDelegate,DropDownDelegate>
@property (strong, nonatomic) IBOutlet UIDropDown *dropDownView;

@property (strong, nonatomic) IBOutlet UILabel *dropDownTextLabel;
@property (strong, nonatomic) IBOutlet UIImageView *dropDownImageView;
@property (nonatomic) BOOL isDatePickerShow;
@property (nonatomic) BOOL isMultipleSelection;
@property (nonatomic,strong) NSMutableArray *contentArray;
@property (strong, nonatomic) IBOutlet UIButton *dropDownButton;

@property (nonatomic,strong) IBOutlet UIConfirmImageView *confirmImgView;

@property (strong,nonatomic)NSString *titleString;

@property (strong,nonatomic)NSString *xPath;

@property (nonatomic,assign)id<DropDownDelegate> delegate;

@property (nonatomic,strong) ActionBlock actionBlock;
@property (nonatomic,weak) DataValidator dataValidator;
@property (nonatomic,strong) id nextField;
@property (nonatomic,strong) NSString *validatorString;
@property (copy) UICallback *callback;

@property (nonatomic,strong) NSString *selectedString;
@property (nonatomic) BOOL isBirthDate;

@property (nonatomic,strong) UIPopOverContentViewController *popoverVC;


@property (nonatomic, strong) id parent;

@property (nonatomic) BOOL isPlanDropDown;

@property (nonatomic) BOOL isAutoEnableWRTData; // for UICheckGrouped class only used


+(NSString*)ageCalculation : (NSString*)dateOfBirth;

-(void)setdisabled;
-(void)setenabled;

- (IBAction)DropDownAction:(id)sender;
-(id)getNextField;

-(BOOL)validate;

-(NSString *)getValueString;

-(NSString *)xPath;

-(void)setValueString:(NSString *)valueString;

-(void)resetTitle;


@end
