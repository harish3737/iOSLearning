//
//  UICustomProgressView.h
//  CSSUIFramwork
//
//  Created by CSS Admin on 6/14/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UICustomProgressView : UIView

@end
