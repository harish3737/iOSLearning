//
//  UIRadioButtonWithOptions.h
//  CSSUIFramwork
//
//  Created by CSS Admin on 7/26/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIRadioButton.h"
#import "UILabeledButton.h"
#import "UIMultiLingualButton.h"

@interface UIRadioButtonWithOptions : UIView<UIRadioButtonDelegate>

@property (strong, nonatomic) IBOutlet UIRadioButtonWithOptions *radioBtnOptionsView;

@property (strong, nonatomic) IBOutlet UIRadioButton *radioButton;
@property (strong, nonatomic) IBOutlet UIMultiLingualButton *contentButton;
@property (strong, nonatomic) IBOutlet UILabeledButton *labelDropDownView;

@property (strong,nonatomic) NSString *xPath;



- (IBAction)contentTapAction:(id)sender;


@end
