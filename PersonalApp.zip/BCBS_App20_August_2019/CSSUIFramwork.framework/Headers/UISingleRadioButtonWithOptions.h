//
//  UISingleRadioButtonWithOptions.h
//  SampleBCBSPOC
//
//  Created by CSS Admin on 6/2/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UIRadioButton.h"
#import "UILabelContentWithDropDown.h"
#import "UICGSizeConstraints.h"



@interface UISingleRadioButtonWithOptions : UIView <UIRadioButtonDelegate>

@property (strong, nonatomic) IBOutlet UISingleRadioButtonWithOptions *radioButtonView;

@property (strong, nonatomic) IBOutlet UIRadioButton *radioButton;

@property (strong, nonatomic) IBOutlet UILabelContentWithDropDown *contentView;
@property (strong,nonatomic) UICGSizeConstraints *sizeConstraints;

@property (strong,nonatomic) NSString *xPath;

-(NSString *)getValueString;

@end
