//
//  LanguageCentral.h
//  CSSUIFramwork
//
//  Created by CSS Admin on 4/6/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


@interface LanguageCentral : NSObject{
    
    
}
+(NSString *)internalizeString;
+(void)setInternalizeString:(NSString*)languageString;
+(NSString *)languageSelectedString:(NSString *)key;
+(NSString *)pathForLanguageSelected:(NSString*)languageName;


@end
