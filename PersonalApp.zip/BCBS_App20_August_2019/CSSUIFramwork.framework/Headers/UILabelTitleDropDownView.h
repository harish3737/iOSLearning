//
//  UILabelTitleDropDownView.h
//  SampleBCBSPOC
//
//  Created by CSS Admin on 5/10/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIDropDown.h"
#import "ValidatorLabel.h"

IB_DESIGNABLE

@interface UILabelTitleDropDownView : UIView



@property (strong, nonatomic) IBOutlet UILabelTitleDropDownView *labeledButtonView;

@property (weak,nonatomic) IBOutlet ValidatorLabel *titleLabel;
@property (strong,nonatomic)IBOutlet UIDropDown *dropDownCustomView;


@property (strong,nonatomic) NSString *xPath;

+(BOOL)isDatePicker;
+(void)setBooleanDatePicker:(BOOL)isDatePickerShow;

-(void)enableDropDownView;
-(void)disableDropDownView;

-(NSString *)getValueString;
-(NSString *)xPath;


-(void)setEnabled:(BOOL)enabled;
-(void)setUserInteractionEnabled:(BOOL)userInteractionEnabled;

-(void)resetDropDownTitle;

@end
