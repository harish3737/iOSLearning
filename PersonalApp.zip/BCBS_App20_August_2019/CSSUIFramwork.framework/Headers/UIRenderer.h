//
//  UIRenderer.h
//  CSSUIFramwork
//
//  Created by CSS Admin on 6/9/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface UIRenderer : NSObject

+(void)renderPlist:(id)classObject plist:(NSString *)plistName;

+(id)getComponentAtIndex:(NSUInteger)index;

+ (void) stretchToSuperView:(UIView*) view;

//vrl added
+(void)renderPlistToView:(id)classObject plist:(NSString *)plistName viewObject:(id)viewObject appConfig:(NSMutableDictionary *)appConfig extraData:(id)extraData;

@end
