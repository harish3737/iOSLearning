//
//  UISingleLabelLeftImageView.h
//  CSSUIFramwork
//
//  Created by CSS Admin on 6/22/18.
//  Copyright © 2018 csscorp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ValidatorLabel.h"


IB_DESIGNABLE

@interface UISingleLabelLeftImageView : UIView

@property (strong, nonatomic) IBOutlet UISingleLabelLeftImageView *singleLabelImageView;

@property (strong, nonatomic) IBOutlet ValidatorLabel *contentLabel;

@property (nonatomic,strong) NSString *xPath;
@property (weak, nonatomic) IBOutlet UIImageView *leftImageView;


@end
