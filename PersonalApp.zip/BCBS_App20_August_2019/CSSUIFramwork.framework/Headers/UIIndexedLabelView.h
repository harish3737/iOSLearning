//
//  UIIndexedLabelView.h
//  CSSUIFramwork
//
//  Created by CSS Admin on 8/4/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ValidatorLabel.h"
@interface UIIndexedLabelView : UIView
@property (strong, nonatomic) IBOutlet UIIndexedLabelView *indexLabelView;
@property (strong, nonatomic) IBOutlet ValidatorLabel *indexTitle;
@property (strong, nonatomic) IBOutlet ValidatorLabel *indexContentLabel;

@end
