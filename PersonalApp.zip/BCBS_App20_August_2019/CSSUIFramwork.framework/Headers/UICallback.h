//
//  UICallback.h
//  CSSUIFramwork
//
//  Created by CSS Corp on 05/04/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ServiceCallbackProtocol.h"

@interface UICallback : NSObject <ServiceCallbackProtocol>

+ (instancetype) getDummyUICallback;
- (instancetype) initWithUICallbacks : (callbackBlock) successBlock : (callbackBlock) failedBlock;

@end
