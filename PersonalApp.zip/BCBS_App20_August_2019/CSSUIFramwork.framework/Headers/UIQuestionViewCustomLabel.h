//
//  UIQuestionViewCustomLabel.h
//  CSSUIFramwork
//
//  Created by CSS Corp on 04/08/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ValidatorLabel.h"
#import "UICheckBox.h"
#import "UIRadioButton.h"

IB_DESIGNABLE

@interface UIQuestionViewCustomLabel : UIView<UIRadioButtonDelegate>

@property (strong, nonatomic) IBOutlet UIQuestionViewCustomLabel *questionView;

@property (strong, nonatomic) IBOutlet ValidatorLabel *titleLabel;
@property (strong, nonatomic) IBOutlet ValidatorLabel *subTitleLabel;
@property (strong, nonatomic) IBOutlet ValidatorLabel *headingLabel;
@property (strong, nonatomic) IBOutlet ValidatorLabel *detailLabel;
@property (strong, nonatomic) IBOutlet UIRadioButton *yesButton;
@property (strong, nonatomic) IBOutlet UIRadioButton *noButton;



@property (strong,nonatomic) NSString *childViewString;
@property (strong,nonatomic) UIView *childView;

@property (strong,nonatomic) NSString *xPath;

- (IBAction)YesActionClicked:(id)sender;

- (IBAction)NoActionClicked:(id)sender;

- (void)enableSecondView :(BOOL)enable;

@end
