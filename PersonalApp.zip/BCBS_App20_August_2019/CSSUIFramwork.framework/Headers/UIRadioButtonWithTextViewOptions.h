//
//  UIRadioButtonWithTextViewOptions.h
//  CSSUIFramwork
//
//  Created by Ganesh on 08/08/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIRadioButton.h"
#import "UICGSizeConstraints.h"
#import "UIMultiLingualButton.h"
#import "ValidatorTextView.h"


@interface UIRadioButtonWithTextViewOptions : UIView <UIRadioButtonDelegate>

@property (strong, nonatomic) IBOutlet UIRadioButtonWithTextViewOptions *radioBtnView;

@property (strong, nonatomic) IBOutlet UIRadioButton *radioButton;

@property (strong, nonatomic) IBOutlet UIMultiLingualButton *contentButton;

@property (nonatomic,strong) NSString *xPath;
@property (strong, nonatomic) IBOutlet ValidatorTextView *textView;

- (IBAction)contentTapAction:(id)sender;


//radioBtnView
@end
