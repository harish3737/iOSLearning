//
//  UIRadioButtonWithLabel.h
//  CSSUIFramwork
//
//  Created by CSS Admin on 6/15/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIRadioButton.h"
#import "ValidatorLabel.h"
#import "UICGSizeConstraints.h"

@interface UIRadioButtonWithLabel : UIView <UIRadioButtonDelegate>

@property (strong, nonatomic) IBOutlet UIRadioButtonWithLabel *radioBtnLabelView;
@property (strong, nonatomic) IBOutlet UIRadioButton *radioButton;
@property (strong, nonatomic) IBOutlet ValidatorLabel *contentLabel;
@property (strong,nonatomic) UICGSizeConstraints *sizeConstraints;

@property (nonatomic,strong) NSString *xPath;


@end
