//
//  UICGSizeConstraints.h
//  BcBs
//
//  Created by CSS Admin on 6/17/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UICGSizeConstraints : NSObject

@property (nonatomic) NSNumber *width;
@property (nonatomic) NSNumber *height;
@property (nonatomic) NSNumber *leadingSpace;
@property (nonatomic) NSNumber *trailingSpace;
@property (nonatomic) NSNumber *topSpace;
@property (nonatomic) NSNumber *bottomSpace;
@property (nonatomic) NSNumber *verticalSpace;
@property (nonatomic) NSNumber *horizontalSpace;

@end
