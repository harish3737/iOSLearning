//
//  UICheckBox.h
//  SampleBCBSPOC
//
//  Created by CSS Admin on 5/20/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Validator.h"
#import "UICallback.h"

IB_DESIGNABLE

typedef void(^ActionBlock)(id sender, id parent);

@interface UICheckBox : UIButton

@property(nonatomic)BOOL checkboxState;

@property (nonatomic,strong) IBInspectable UIImage *checkedImage;
@property (nonatomic,strong) IBInspectable UIImage *unCheckedImage;

@property (nonatomic) IBInspectable BOOL isMandatory;
@property (nonatomic,weak) DataValidator dataValidator;
@property (nonatomic,strong) id nextField;
@property (nonatomic,strong) NSString *validatorString;

@property (nonatomic) UICallback *callback;

@property (nonatomic,strong) NSString *xPath;

@property (nonatomic,strong)ActionBlock actionblock;

@property (nonatomic, strong) id parent;

-(BOOL)ischecked;
-(void)setChecked:(BOOL)checked;

-(id)getNextField;

-(BOOL)validate;

-(NSString *)getValueString;

-(NSString *)xPath;

-(void)updateUI;
-(void)setValueString:(NSString *)valueString;

@end
