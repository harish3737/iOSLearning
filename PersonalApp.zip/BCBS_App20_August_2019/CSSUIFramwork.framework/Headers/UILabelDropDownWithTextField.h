//
//  UILabelDropDownWithTextField.h
//  CSSUIFramwork
//
//  Created by CSS Admin on 6/17/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ValidatorLabel.h"
#import "UIDropDown.h"
#import "ValidatorTextField.h"
#import "UIConfirmImageView.h"
#import "UIMultiLingualButton.h"



IB_DESIGNABLE


@interface UILabelDropDownWithTextField : UIView


@property (strong, nonatomic) IBOutlet UILabelDropDownWithTextField *dropDownTextFieldView;
@property (strong, nonatomic) IBOutlet ValidatorLabel *headingLabel;

@property (strong,nonatomic) UIDropDown *dropDownBtnView;
@property (strong,nonatomic) ValidatorTextField *userTextField;

@property (strong,nonatomic) IBOutlet UIConfirmImageView *confirmImageView;

@property (strong,nonatomic) IBOutlet UIMultiLingualButton *optionalButton;

@property (strong,nonatomic) NSString *xPath;

-(NSString *)getValueString;

-(NSString *)xPath;



-(void)setEnabled:(BOOL)enabled;
-(void)setUserInteractionEnabled:(BOOL)userInteractionEnabled;




@end
