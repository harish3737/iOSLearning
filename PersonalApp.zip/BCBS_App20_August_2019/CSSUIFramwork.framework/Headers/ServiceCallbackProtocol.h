//
//  ServiceCallbackProtocol.h
//  CSSUIFramwork
//
//  Created by CSS Corp on 05/04/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#ifndef ServiceCallbackProtocol_h
#define ServiceCallbackProtocol_h

@protocol ServiceCallbackProtocol <NSObject>

typedef void (^callbackBlock) (id, id, id);

@property (assign) callbackBlock onSuccess;
@property (assign) callbackBlock onFailed;

@required
- (void) setSuccessBlock: (callbackBlock) mySuccessBlock;
- (void) setFailedBlock: (callbackBlock) myFailedBlock;

@end

#endif /* ServiceCallbackProtocol_h */
