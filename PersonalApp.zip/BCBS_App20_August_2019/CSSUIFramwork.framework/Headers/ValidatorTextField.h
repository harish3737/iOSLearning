//
//  ValidatorTextField.h
//  SampleBCBSPOC
//
//  Created by CSS Admin on 4/4/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Validator.h"
#import "UICallback.h"

IB_DESIGNABLE

@interface ValidatorTextField : UITextField<UITextFieldDelegate>
@property (nonatomic) IBInspectable NSInteger maxLength;
@property (nonatomic) IBInspectable NSInteger minLength;
@property(nonatomic) IBInspectable NSString *localizationKey;

@property (strong, nonatomic) id nextField;
@property(nonatomic,strong)DataValidator dataValidator;
@property(nonatomic,strong) NSString *validatorString;

@property (nonatomic,strong) NSString *xPath;
@property (nonatomic) NSInteger keyboardTypeName; 

@property(copy)UICallback *callback;

-(void)setSubmitHandler:(callbackBlock)submitHandler;
-(BOOL)validate;
-(void)linkChain;

-(id)getNextField;

-(NSString *)getValueString;
-(NSString *)xPath;

-(void)setEnableTextField:(BOOL)isEnable;
-(void)showConfirmImage:(id)textField hidden:(BOOL)isHiddenConfirmImage;

-(void)setValueString:(NSString *)valueString;

@end
