//
//  SupplementPaymentOptionViewController.h
//  BCBS Medicare Enrolment App
//
//  Created by Ganesh on 09/08/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//
#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>

@interface SupplementPaymentOptionViewController : UIBaseContainerViewController



@property (strong, nonatomic) IBOutlet UIRadioButton *semiAnnualButton;
@property (strong, nonatomic) IBOutlet UIRadioButton *quarterlyButton;
@property (strong, nonatomic) IBOutlet UIRadioButton *monthlyButton;

@property (strong, nonatomic) IBOutlet UIView *contentView;


@property (strong, nonatomic) IBOutlet ValidatorLabel *titleString;
@property (strong, nonatomic) IBOutlet ValidatorLabel *SubTitle;
@property (weak, nonatomic) IBOutlet ValidatorLabel *headTitleLabel;

@end
