//
//  CustomValidatorLabel.h
//  BCBS Medicare Enrolment App
//
//  Created by CSS CORP on 02/07/18.
//  Copyright © 2018 CSS Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>

@interface CustomValidatorLabel : ValidatorLabel

@end
