//
//  CountyViewController.m
//  BCBS Medicare Enrolment App
//
//  Created by CSS Corp on 01/06/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "CountyViewController.h"
#import "AppDelegate.h"
#import "AppConfig.h"

static BOOL isBackButtonPressed;
@interface CountyViewController () {
	
	UIAlertController *alertController;
	NSString *countyCache;
	NSMutableArray *effectiveDateArray;
}
@property (nonatomic,strong)NSMutableArray *popoverListArray;
@property (nonatomic,strong)DBHelper *dbHelper;
@property (nonatomic,strong) UITextField *activeField;
@property (nonatomic,strong) NSMutableArray *getPlanArray;
@end

@implementation CountyViewController
@synthesize popoverListArray;
@synthesize countyView;
@synthesize planEnrollView,zipCodeTextField,effectiveDateView;
@synthesize countyLabel,planEnrollLabel,effectiveDateLabel,zipCodeLabel;
@synthesize getPlanArray;

- (void)viewDidLoad {
	[super viewDidLoad];
	// Do any additional setup after loading the view.
	
	isBackButtonPressed = NO;
	effectiveDateArray = [[NSMutableArray alloc]init];
	[effectiveDateArray removeAllObjects];
	[effectiveDateArray addObject:@""];
	_titleString.text = [NSString stringWithFormat:@"%@ %@ - \n%@",[AppConfig enrollYear],[LanguageCentral languageSelectedString:[[AppConfig currentPlanDictionary] objectForKey:@"PlanTitle"]],[LanguageCentral languageSelectedString:[[[AppConfig currentPlanDictionary] objectForKey:NSStringFromClass([self class])]objectForKey:@"title"]]];
	
	getPlanArray = [[NSMutableArray alloc]init];
	
	
    //svk added
    if([[AppConfig currentPlan]isEqualToString:@"DSNP"])
    {
        zipCodeTextField.validatorString = @"NoValidation";
        countyView.validatorString = @"NoValidation";
        planEnrollView.validatorString=@"MandatoryValidator";
        effectiveDateView.validatorString=@"MandatoryValidator";
        zipCodeLabel.hidden = YES;
        zipCodeTextField.hidden = YES;
        countyLabel.hidden = YES;
        countyView.hidden = YES;
        _planSelectLabel.localizationKey = @"PLAN_YOU_WISH_TO_ENROLL_IN_2020";
        
        [self.view addConstraint:[NSLayoutConstraint constraintWithItem:_planSelectLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:_titleString attribute:NSLayoutAttributeBottom multiplier:1 constant:10]];
        
        [self.view addConstraint:[NSLayoutConstraint constraintWithItem:zipCodeLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:_planSelectLabel attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
        [self.view addConstraint:[NSLayoutConstraint constraintWithItem:planEnrollLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:_planSelectLabel attribute:NSLayoutAttributeBottom multiplier:1 constant:20]];
        [self.view updateConstraints];
        
    }//
    else
    {
        zipCodeTextField.validatorString=@"NumberValidator";
        zipCodeTextField.maxLength = 5;
        countyView.validatorString=@"MandatoryValidator";
        planEnrollView.validatorString=@"MandatoryValidator";
        effectiveDateView.validatorString=@"MandatoryValidator";
    }
    
	
	planEnrollView.isPlanDropDown = YES;
	zipCodeTextField.keyboardTypeName = UIKeyboardTypeNumberPad;
	
	
	if([[AppConfig currentPlan] isEqualToString:@"DSNP"]){
		[self.sharedataObj setForwardNextButtonTitle:@"Continue_to_health"];
		[self.sharedataObj setNextProgressIndex:1];
	}else {
		[self.sharedataObj setForwardNextButtonTitle:@"Continue_to_billing_active"];
		[self.sharedataObj setNextProgressIndex:1];
	}
	
	[self.sharedataObj setPreviousNextButtonTitle:@"Next"];
	[self.sharedataObj setBackProgressIndex:1];
	
    
    
	[countyView setTitleString:@"Select a county"];
	[planEnrollView setTitleString:@"Select a Plan"];
	[effectiveDateView setTitleString:@"Select a Date"];
	
	AppDelegate *appDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
	self.dbHelper = appDelegate.appDelegateDBHelper;
	zipCodeTextField.delegate =self;
	
	self.countyView.tag = 0;
	self.countyView.delegate = self;
	
	
	//setting xPath
	
	countyView.xPath = @"data:plan_details:county";
	planEnrollView.xPath = @"data:plan_details:csv_plan_name";
	effectiveDateView.xPath = @"data:plan_details:effective_date";
	
	
	CountyViewController *weakSelf = self;
	
	self.willLoadNext = ^(id object){
		
		[weakSelf addCustomJsonValue];
		
	};
	
	self.willBackPage = ^(id object){
		
		[weakSelf backButtonBlockAction];
	};
	
}

-(void)viewWillAppear:(BOOL)animated {
	
    
	[ScopeBaseViewController populateCurrentItemValue];
	[self loadBackData];
    if([[AppConfig currentPlan]isEqualToString:@"DSNP"])
    {
    [self enrollArrayMethod];
    }
        [super viewWillAppear:animated];
    
	
	
}

-(void)enrollArrayMethod
{
//    [self.view updateConstraintsIfNeeded];
//    [planEnrollView setTranslatesAutoresizingMaskIntoConstraints:NO];
//    [effectiveDateView setTranslatesAutoresizingMaskIntoConstraints:NO];
    AppDelegate *appDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    NSString *queryString = [NSString stringWithFormat:@"select Plan_Name, Monthly_Premium,CSV_Plan_Name from bcbs_dsnp_plan where Plan_Year like '%@%%'", [AppConfig enrollYear]];
    NSArray *valueArray = [[NSArray alloc]initWithArray:[appDelegate.appDelegateDBHelper loadDataFromDB:queryString]];
    
    PRINTLOG(@"Fetch ::%@",valueArray);
    
    NSMutableArray *dsnpArray =[[NSMutableArray alloc]init];
    
    if (valueArray.count>0) {
        
        for(NSArray *arrayValues in valueArray){
            
            NSString *planString = [NSString stringWithFormat:@"%@ -- %@",[arrayValues objectAtIndex:0],[arrayValues objectAtIndex:1]];
            
            [dsnpArray addObject:planString];
            //            [getPlanArray addObject:arrayValues];
            
        }
        getPlanArray = [valueArray copy];
        [AppConfig setPlanEnrollArray:getPlanArray];
    }else{
        
        [dsnpArray addObject:@""];
        [getPlanArray removeAllObjects];
        [planEnrollView setTitleString:@"Select a Plan"];
        [AppConfig setPlanEnrollArray:nil];
    }
    planEnrollView.contentArray = dsnpArray;
    [self effectiveDateArrayCalculation];
    
}

-(void)effectiveDateArrayCalculation{
	
	NSNumberFormatter * numberFormatter = [[NSNumberFormatter alloc] init];
	NSDateComponents *components = [[NSCalendar currentCalendar] components:NSCalendarUnitMonth | NSCalendarUnitYear fromDate:[NSDate date]];
	effectiveDateArray = [[NSMutableArray alloc]init];
	NSString *month = [numberFormatter stringFromNumber:[NSNumber numberWithInteger:[components month]]]; 
	NSInteger currentMonth = [components month];
	NSInteger currentYear = [components year];
	
	
	NSString *planYear = [AppConfig enrollYear];
	NSInteger year = [planYear intValue];
	if(year > currentYear){
		currentYear = year;
		currentMonth = 0;
		month = @"0";
	}
	for(int iteration = 1; iteration <= 3; iteration ++){
		currentMonth += 1;
		int monthInt = [month intValue];// I assume you need it as an integer.
		month= [NSString stringWithFormat:@"%d",++monthInt];
        PRINTLOG(@"month:%@",month);
		if(currentMonth < 13)
		{
			if(month.length == 1){
				[effectiveDateArray addObject:[NSString stringWithFormat:@"0%ld/01/%ld",(long)currentMonth,(long)currentYear]];
			}else{
				[effectiveDateArray addObject:[NSString stringWithFormat:@"%ld/01/%ld",(long)currentMonth,(long)currentYear]];
				
			}
			
		}
		effectiveDateView.contentArray =effectiveDateArray;
	}
	if([AppConfig planEnrollArray]!=nil){
		effectiveDateView.contentArray =effectiveDateArray;
		[AppConfig setmedigapEffectiveArray:effectiveDateArray];
	}else {
		
		[effectiveDateArray removeAllObjects];
		[effectiveDateArray addObject:@""];
		effectiveDateView.contentArray =effectiveDateArray;
		
		[AppConfig setmedigapEffectiveArray:nil];
	}
	
	
}

-(void)backButtonBlockAction {
	
	isBackButtonPressed = YES;
}


-(BOOL)validateVC {
	
	BOOL hasError = NO;
    
	if(zipCodeTextField.text.length>0){
		
		zipCodeLabel.textColor = [UIColor colorWithRed:(153/255.f) green:(153/255.f) blue:(153/255.f) alpha:1.0];
	}else {
		zipCodeLabel.textColor = [UIColor colorWithRed:(240/255.f) green:(108/255.f) blue:(108/255.f) alpha:1.0];
		
	}
	if(countyView.selectedString.length>0){
		countyLabel.textColor = [UIColor colorWithRed:(153/255.f) green:(153/255.f) blue:(153/255.f) alpha:1.0];
		countyView.layer.borderColor = [UIColor colorWithRed:(204.0/255.0) green:(204.0/255.0) blue:(204.0/255.0) alpha:1.0f].CGColor;
	}else {
		countyLabel.textColor = [UIColor colorWithRed:(240/255.f) green:(108/255.f) blue:(108/255.f) alpha:1.0];
		countyView.layer.borderColor = [UIColor colorWithRed:(240/255.f) green:(108/255.f) blue:(108/255.f) alpha:1.0].CGColor;
		countyView.confirmImgView.hidden = YES;
	}
	if(planEnrollView.selectedString.length>0){
		planEnrollLabel.textColor = [UIColor colorWithRed:(153/255.f) green:(153/255.f) blue:(153/255.f) alpha:1.0];
		planEnrollView.layer.borderColor = [UIColor colorWithRed:(204.0/255.0) green:(204.0/255.0) blue:(204.0/255.0) alpha:1.0f].CGColor;
	}else {
		planEnrollLabel.textColor = [UIColor colorWithRed:(240/255.f) green:(108/255.f) blue:(108/255.f) alpha:1.0];
		planEnrollView.layer.borderColor = [UIColor colorWithRed:(240/255.f) green:(108/255.f) blue:(108/255.f) alpha:1.0].CGColor;
		planEnrollView.confirmImgView.hidden = YES;
	}
	if(effectiveDateView.selectedString.length>0){
		effectiveDateLabel.textColor = [UIColor colorWithRed:(153/255.f) green:(153/255.f) blue:(153/255.f) alpha:1.0];
		effectiveDateView.layer.borderColor = [UIColor colorWithRed:(204.0/255.0) green:(204.0/255.0) blue:(204.0/255.0) alpha:1.0f].CGColor;
	}else {
		effectiveDateLabel.textColor = [UIColor colorWithRed:(240/255.f) green:(108/255.f) blue:(108/255.f) alpha:1.0];
		effectiveDateView.layer.borderColor = [UIColor colorWithRed:(240/255.f) green:(108/255.f) blue:(108/255.f) alpha:1.0].CGColor;
		effectiveDateView.confirmImgView.hidden = YES;
	}
	if([[AppConfig currentPlan]isEqualToString:@"DSNP"])
    {
        if(planEnrollView.selectedString.length>0&&effectiveDateView.selectedString.length>0)
        {
            hasError = NO;
        }
        else
        {
            hasError = NO;
        }
    }
    else
        {
	if(zipCodeTextField.text.length>0&&countyView.selectedString.length>0 && planEnrollView.selectedString.length>0&&effectiveDateView.selectedString.length>0){
		hasError = NO;
	}else {
        hasError = YES;
        //        hasError = NO;  // development purpose only , don't enable this when release IPA
        
	}
        }
	return hasError;
}

-(void)loadBackData {
	
	NSString *zipValue = [AppConfig countyZipcode];
	if([zipValue length] > 0){
		
		zipCodeTextField.text = zipValue;
	}
	
	if([AppConfig county].length>0){
		
		[countyView setValueString:[AppConfig county]];
		
		countyView.contentArray = [AppConfig countyArray];
		
	}else {
		countyView.contentArray =[NSMutableArray arrayWithObject:@""];
		[countyView setTitleString:@"Select a county"];
		
	}
    PRINTLOG(@"CountyArray ::%@",countyView.contentArray);
	
	if(![[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:plan_details:csv_plan_name"] isEqualToString:@""]){
		
		for(NSArray *planArray in [AppConfig planEnrollArray]){
			
			if([planArray containsObject:[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:plan_details:csv_plan_name"]]){
				NSString *planEnrollString = [NSString stringWithFormat:@"%@ -- %@",[planArray objectAtIndex:0],[planArray objectAtIndex:1]];
				
				
				[self.planEnrollView setValueString:planEnrollString];
			}
		}
		
		NSMutableArray *planEnrollArray =[[NSMutableArray alloc]init];
		if([AppConfig planEnrollArray].count>0){
			for(NSArray *arrayValues in [AppConfig planEnrollArray]){
				
				NSString *planString = [NSString stringWithFormat:@"%@ -- %@",[arrayValues objectAtIndex:0],[arrayValues objectAtIndex:1]];
				
				[planEnrollArray addObject:planString];
				
			}
			getPlanArray = [AppConfig planEnrollArray];
		}else {
			[planEnrollArray addObject: @""];
			[planEnrollView setTitleString:@"Select a Plan"];
			[countyView setTitleString:@"Select a county"];
			countyView.selectedString = @"";
			planEnrollView.selectedString = @"";
			[AppConfig setPlanEnrollArray:nil];
			[self errorMessageAlert:@"Selected county not allowed to enroll for this plan" message:@""];
		}
		
		planEnrollView.contentArray = planEnrollArray;
	}else {
		planEnrollView.contentArray =[NSMutableArray arrayWithObject:@""];
		[planEnrollView setTitleString:@"Select a Plan"];
	}
    PRINTLOG(@"wow ::%@",self.planEnrollView.contentArray);
	
	if(![[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:plan_details:effective_date"] isEqualToString:@""]){
		
		[effectiveDateView setValueString:[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:plan_details:effective_date"]];
		
		if([AppConfig medigapEffectiveArray]!=nil){
			effectiveDateView.contentArray = [AppConfig medigapEffectiveArray];
		}else {
			effectiveDateView.contentArray = [NSMutableArray new];
		}
	}else {
		[effectiveDateView setTitleString:@"Select a Date"];
		effectiveDateView.selectedString = @"";
		effectiveDateView.contentArray = [NSMutableArray new];
	}
	
}

-(void)addCustomJsonValue {
	
	isBackButtonPressed = NO;
	
	[AppConfig fillJSONDictionary:@"data:plan_details:plan_year" value:[AppConfig enrollYear]];
	
	int index=0;
	
	if([self.planEnrollView.contentArray containsObject:self.planEnrollView.selectedString]) {
		index = [self.planEnrollView.contentArray indexOfObject: self.planEnrollView.selectedString];
        PRINTLOG(@"index ::%d",index);
		if(getPlanArray.count>0){
			[AppConfig fillJSONDictionary:@"data:plan_details:csv_plan_name" value:[[getPlanArray objectAtIndex:index]objectAtIndex:2]];
			if(![[AppConfig currentPlan] isEqualToString:@"DSNP"]){
				[AppConfig fillJSONDictionary:@"data:plan_details:region" value:[[getPlanArray objectAtIndex:index]objectAtIndex:3]];
			}
		}
	} else {
        PRINTLOG(@"not found");
		[AppConfig fillJSONDictionary:@"data:plan_details:csv_plan_name" value:@""];
	}
	
	[AppConfig fillJSONDictionary:@"data:plan_details:effective_date" value:effectiveDateView.selectedString];
	
	[AppConfig setcounty:countyView.selectedString];
	[AppConfig setCountyZipcode:zipCodeTextField.text];
	
    PRINTLOG(@"county ::%@",[AppConfig countyArray]);
    PRINTLOG(@"Plan Enroll ::%@",[AppConfig planEnrollArray]);
	
}


- (void)didReceiveMemoryWarning {
	[super didReceiveMemoryWarning];
	// Dispose of any resources that can be recreated.
}


-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
	
	[self registerForKeyboardNotifications];
	return YES;
}

-(BOOL)textFieldShouldEndEditing:(UITextField *)textField {
	
	
	return YES;
}


-(BOOL) textFieldShouldReturn:(UITextField *)textField {
	
	[zipCodeTextField resignFirstResponder];
	return YES;
	
}



- (void)textFieldDidBeginEditing:(UITextField *)textField {
	
	self.activeField = textField;
	
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
	
	countyView.confirmImgView.hidden = YES;
	planEnrollView.confirmImgView.hidden = YES;
	effectiveDateView.confirmImgView.hidden = YES;
	
	[self unregisterForKeyboardNotification];
	self.activeField = nil;
	
	if(!isBackButtonPressed){
		
		isBackButtonPressed = NO;
		if (zipCodeTextField.text.length == 5) {
			
            NSString *currentPlanYear = [AppConfig enrollYear];

            
			NSString *queryString = [NSString stringWithFormat:@"Select distinct County from bcbs_zip_county_region_map where Zip_Code like '%%%@%%' and Enroll_Year like '%@%%'",textField.text,currentPlanYear];
			
			
			NSMutableArray *valueArray = [[NSMutableArray alloc]initWithArray:[self.dbHelper loadDataFromDB:queryString]];
			
			
			NSMutableArray *countyArray =[[NSMutableArray alloc]init];
			NSMutableArray *planEnrollArray =[[NSMutableArray alloc]init];
			
			NSString *planString = @"";
			
			if (valueArray.count > 0) {
				[self effectiveDateView];
				for(NSArray *arrayValues in valueArray){
					
					planString  = [NSString stringWithFormat:@"%@",[arrayValues objectAtIndex:0]];
					[countyArray addObject:planString];
				}
				[AppConfig setCountyArray:countyArray];
			}else if(zipCodeTextField.text.length > 0){
				[countyArray addObject: @""];
				
				[self errorMessageAlert:@"Alert" message:@"Please Enter Valid Zip Code"];
				self.countyView.selectedString = @"";
				self.planEnrollView.selectedString = @"";
				[AppConfig setCountyArray:nil];
				[AppConfig setPlanEnrollArray:nil];
			}else{
				[countyArray addObject: @""];
				self.countyView.selectedString = @"";
				self.planEnrollView.selectedString = @"";
				[AppConfig setCountyArray:nil];
				[AppConfig setPlanEnrollArray:nil];
			}
			
			[countyView setTitleString:@"Select a county"];
			[planEnrollArray addObject: @""];
			[planEnrollView setTitleString:@"Select a Plan"];
			[effectiveDateView setTitleString:@"Select a Date"];
			
			planEnrollView.selectedString = @"";
			countyView.selectedString = @"";
			effectiveDateView.selectedString = @"";
			
			effectiveDateView.contentArray = [NSMutableArray arrayWithObject:@""];
			
			self.countyView.contentArray = countyArray;
			self.planEnrollView.contentArray=planEnrollArray;
			
			
			
		}else if(zipCodeTextField.text.length > 0){
			
			[self errorMessageAlert:@"Alert" message:@"Please Enter Valid Zip Code"];
			self.countyView.selectedString = @"";
			self.planEnrollView.selectedString = @"";
			self.effectiveDateView.selectedString = @"";
			
			[countyView setTitleString:@"Select a county"];
			[planEnrollView setTitleString:@"Select a Plan"];
			[effectiveDateView setTitleString:@"Select a Date"];
			[self.countyView.contentArray removeAllObjects];
			[self.planEnrollView.contentArray removeAllObjects];
			[self.countyView.contentArray addObject:@""];
			[self.planEnrollView.contentArray addObject:@""];
			[AppConfig setCountyArray:nil];
			[AppConfig setPlanEnrollArray:nil];
			effectiveDateView.contentArray = [NSMutableArray arrayWithObject:@""];
		}else{
			self.countyView.selectedString = @"";
			self.planEnrollView.selectedString = @"";
			self.effectiveDateView.selectedString = @"";
			[countyView setTitleString:@"Select a county"];
			[planEnrollView setTitleString:@"Select a Plan"];
			[effectiveDateView setTitleString:@"Select a Date"];
			[self.countyView.contentArray removeAllObjects];
			[self.planEnrollView.contentArray removeAllObjects];
			[self.countyView.contentArray addObject:@""];
			[self.planEnrollView.contentArray addObject:@""];
			effectiveDateView.contentArray = [NSMutableArray arrayWithObject:@""];
			[AppConfig setCountyArray:nil];
			[AppConfig setPlanEnrollArray:nil];
			
		}
	}else {
		isBackButtonPressed = NO;
	}
}

-(void)dropDownLabelText:(NSString *)selectedString tag:(long)tag{
	
	
	if (tag == 0) {
        PRINTLOG(@"%@SelectedString",selectedString);
		NSString *queryString = @"";
		NSMutableArray *planEnrollArray =[[NSMutableArray alloc]init];
		NSString *planYear = [AppConfig enrollYear];
		
		if (selectedString.length == 0) {
			[planEnrollArray addObject: @""];
			[planEnrollView setTitleString:@"Select a Plan"];
			planEnrollView.selectedString = @"";
			[effectiveDateView setTitleString:@"Select a Date"];
			effectiveDateView.selectedString = @"";
			effectiveDateView.contentArray = [NSMutableArray arrayWithObject:@""];
			[AppConfig setPlanEnrollArray:nil];
		}else{
			
			if(![countyCache isEqualToString:selectedString]){
                PRINTLOG(@"not same county");
				[planEnrollView setTitleString:@"Select a Plan"];
				planEnrollView.selectedString = @"";
				effectiveDateView.selectedString = @"";
				[effectiveDateView setTitleString:@"Select a Date"];
			}
			if([[AppConfig currentPlan] isEqualToString:@"DSNP"]){
				queryString = [NSString stringWithFormat:@"select Plan_Name, Monthly_Premium,CSV_Plan_Name from bcbs_dsnp_plan where County like '%%%@%%' and Plan_Year like '%@%%'",selectedString, planYear];
			}else{
                  NSString *currentYear = [AppConfig enrollYear];
                
                PRINTLOG(@"Plan Year - %@",planYear);
				queryString = [NSString stringWithFormat:@"select Plan_Name, Monthly_Premium,CSV_Plan_Name,Region from bcbs_mapd_plan where Region in (select Region from bcbs_zip_county_region_map where county like '%%%@%%' and Enroll_Year like '%@%%') and Plan_Year like '%@%%'", selectedString,currentYear,planYear];
			}
			
			
			NSMutableArray *valueArray = [[NSMutableArray alloc]initWithArray:[self.dbHelper loadDataFromDB:queryString]];
			
			
			if(valueArray.count>0){
				
				for(NSArray *arrayValues in valueArray){
					
					NSString *planString = [NSString stringWithFormat:@"%@ -- %@",[arrayValues objectAtIndex:0],[arrayValues objectAtIndex:1]];
					
					[planEnrollArray addObject:planString];
					
				}
				
				getPlanArray = [valueArray copy];
				[AppConfig setPlanEnrollArray:getPlanArray];
				
				[self effectiveDateArrayCalculation]; 
				
			}else {
				
				id basevc = [[[UIApplication sharedApplication]keyWindow]rootViewController];
				id vc = [basevc visibleViewController];
				if([vc isKindOfClass:[UIPopOverContentViewController class]]){
					[vc dismissViewControllerAnimated:YES completion:nil];
				}
				
                if([[AppConfig currentPlan] isEqualToString:@"DSNP"]){
                    [self errorMessageAlert:@"Alert" message:@"Horizon HMO SNP Plan is not available for individuals living in this county."];
                }else {
                    [self errorMessageAlert:@"Alert" message:@"Horizon Medicare Advantage Plan is not available for individuals living in this county."];
                }
				
				
				[planEnrollArray addObject: @""];
				
				[planEnrollView setTitleString:@"Select a Plan"];
				[countyView setTitleString:@"Select a county"];
				countyView.selectedString = @"";
				planEnrollView.selectedString = @"";
				effectiveDateView.selectedString = @"";
				[effectiveDateView setTitleString:@"Select a Date"];
				[AppConfig setPlanEnrollArray:nil];
				// [self errorMessageAlert:@"Selected county not allowed to enroll for this plan" message:@""];
			}
			
			countyCache = nil;
			countyCache = [NSString stringWithFormat:@"%@",selectedString];
            PRINTLOG(@"cache %@",countyCache);
			self.planEnrollView.contentArray=planEnrollArray;
			
		}
	}
}

-(void)registerForKeyboardNotifications{
	
	
	[[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(keyboardDidShow:)
												 name:UIKeyboardDidShowNotification
											   object:nil];
	
	[[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(keyboardWillBeHidden:)
												 name:UIKeyboardWillHideNotification
											   object:nil];
}


-(void)unregisterForKeyboardNotification {
	[[NSNotificationCenter defaultCenter] removeObserver:self
													name:UIKeyboardWillShowNotification
												  object:nil];
	
	[[NSNotificationCenter defaultCenter] removeObserver:self
													name:UIKeyboardWillHideNotification
												  object:nil];
	
}


- (void)keyboardDidShow:(NSNotification *)notification
{
	NSDictionary* info = [notification userInfo];
//    CGRect kbRect = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue];
    CGRect kbRect = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue];  //ios 11 keyboard issue

	// If you are using Xcode 6 or iOS 7.0, you may need this line of code. There was a bug when you
	// rotated the device to landscape. It reported the keyboard as the wrong size as if it was still in portrait mode.
	//kbRect = [self.view convertRect:kbRect fromView:nil];
	
	UIEdgeInsets contentInsets = UIEdgeInsetsMake(0.0, 0.0, kbRect.size.height+20, 0.0);
	[AppConfig getBaseScrollView].contentInset = contentInsets;
	[AppConfig getBaseScrollView].scrollIndicatorInsets = contentInsets;
	
	CGRect aRect = [AppConfig getBaseMainView].frame;
	aRect.size.height -= kbRect.size.height;
	//    if (!CGRectContainsPoint(aRect, self.activeField.frame.origin) ) {
	//        [_currentScrollView scrollRectToVisible:self.activeField.frame animated:YES];
	//    }
	
	if (!CGRectContainsPoint(aRect, self.activeField.frame.origin) ) {
		CGPoint scrollPoint = CGPointMake(0.0, self.activeField.frame.origin.y-kbRect.size.height);
		//        CGPoint moveScrollPoint = CGPointMake(scrollPoint.x, scrollPoint.y+200);
//        PRINTLOG(@"move ::%f",moveScrollPoint.y);
		[[AppConfig getBaseScrollView] setContentOffset:scrollPoint animated:YES];
		//        [_currentScrollView setContentOffset:moveScrollPoint animated:YES];
	}
}

- (void)keyboardWillBeHidden:(NSNotification *)notification
{
	UIEdgeInsets contentInsets = UIEdgeInsetsZero;
	[AppConfig getBaseScrollView].contentInset = contentInsets;
	[AppConfig getBaseScrollView].scrollIndicatorInsets = contentInsets;
}


-(void)errorMessageAlert:(NSString *)title message:(NSString *)message {
	
	if([title isEqualToString:@"Please Enter Valid Zip Code"]){
		zipCodeTextField.text = @"";
	}
	[zipCodeTextField resignFirstResponder];
	
	
	NSString *localizeTitle = [LanguageCentral languageSelectedString:title];
	NSString *titleString = (localizeTitle.length>0)?localizeTitle:title;
	
	
	NSString *localizeMessage = [LanguageCentral languageSelectedString:message];
	NSString *msgString = (localizeMessage.length>0)?localizeMessage:message;
	
	
	alertController = [UIAlertController alertControllerWithTitle:titleString
														  message:msgString preferredStyle:UIAlertControllerStyleAlert];
	
	
	UIAlertAction *okAction = [UIAlertAction
							   actionWithTitle:NSLocalizedString(@"OK", @"OK action")
							   style:UIAlertActionStyleDefault
							   handler:^(UIAlertAction *action)
							   {
                                   PRINTLOG(@"OK action");
							   }];
	
	
	[alertController addAction:okAction];
	
	[self presentViewController:alertController animated:YES completion:nil];
}


-(void)viewWillDisappear:(BOOL)animated {
	
	
	[zipCodeTextField resignFirstResponder];
	
	[alertController dismissViewControllerAnimated:YES completion:nil];
	
	[super viewWillDisappear:YES];
	
	
}



@end
