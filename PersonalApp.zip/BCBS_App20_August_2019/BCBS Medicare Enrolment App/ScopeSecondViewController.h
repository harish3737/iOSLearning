//
//  ScopeSecondViewController.h
//  BcBs
//
//  Created by CSS Corp on 12/05/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>

@interface ScopeSecondViewController : UIBaseContainerViewController

@property (weak, nonatomic) IBOutlet UIView *parentView;
@property (nonatomic)BOOL isView1;
@property (nonatomic)BOOL isView2;
@property (nonatomic)BOOL isView3;



- (IBAction)nextView:(id)sender;
- (IBAction)previousView:(id)sender;

@end
