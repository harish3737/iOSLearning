//
//  ScopeViewController.m
//  autolayout programmatically
//
//  Created by CSS Corp on 06/05/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "ScopeViewController.h"
#import <CSSUIFramwork/CSSUIFramwork.h>
#import "ScopeSecondViewController.h"
#import "ScopeAppointmentFormViewcontroller.h"
#import "ScopeViewController.h"
#import "ScopeView.h"
#import "ScopeView2.h"
#import "ScopeView3.h"
#import "ScopeView4.h"
#import "ScopeBaseViewController.h"
#import "MedicarePlanViewController.h"
#import "DashboardBaseViewController.h"
#import "DashboardViewController.h"
#import "AppConfig.h"


@interface ScopeViewController (){
    
    NSTimer *alertDismisstimer;
    UIAlertController *alertController;
	
}
@property (nonatomic,strong)NSMutableArray *beneficiaryArray;
@end

@implementation ScopeViewController
@synthesize beneficiaryArray,PdpButton,advantagePlanButton,supplementPlanButton,dateView,SubTitle,dsnpPlanButton;
@synthesize selectTypeLabel,checkboxBtnView,textLabel;



- (void)viewDidLoad {
    [super viewDidLoad];

	[[AppConfig medicarePlanArray] removeAllObjects];
	
	[PdpButton setChecked:NO];
	[advantagePlanButton setChecked:NO];
	
    
    // old values
//	beneficiaryArray = [NSMutableArray arrayWithObjects:@"Self",@"Spouse",@"Father",@"Mother",@"Cousin",@"Brother",@"Sister",@"Aunt",@"Uncle", nil];
    
    
    // new values added
    
    if([[LanguageCentral internalizeString] isEqualToString:@"en"]){

        beneficiaryArray = [NSMutableArray arrayWithObjects:@"Self",@"Spouse",@"Father",@"Mother",@"Cousin",@"Brother",@"Sister",@"Aunt",@"Uncle",@"Niece",@"Nephew",@"Friend",nil];
        
        [self.beneficiaryView setTitleString:@"Self"];
        self.beneficiaryView.selectedString = @"self";
        
    }else {
        
        beneficiaryArray = [NSMutableArray arrayWithObjects:@"Yo",@"Esposa",@"Padre",@"Madre",@"Prima",@"hermano",@"Hermana",@"Tía",@"Tío",@"Sobrina",@"Sobrino",@"Amigo",nil];
        
        [self.beneficiaryView setTitleString:@"Yo"];
        self.beneficiaryView.selectedString = @"Yo";

    }
    
    checkboxBtnView.checkBoxButton.validatorString = @"MandatoryValidator";
	checkboxBtnView.contentButton.localizationKey = @"AGREE_PRODUCT_SELECTED";
	self.beneficiaryView.isDatePickerShow = NO;
	self.beneficiaryView.isMultipleSelection = NO;
	self.beneficiaryView.contentArray = beneficiaryArray;
	
	
	self.dateView.isDatePickerShow = YES;
	self.dateView.isMultipleSelection =YES;
	dateView.dropDownImageView.hidden = YES;
	NSDate *todayDate = [NSDate date];
	NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
	dateFormatter.dateFormat = @"MM/dd/yyyy";
	[self.dateView setTitleString:[dateFormatter stringFromDate:todayDate]];
    self.dateView.selectedString = [dateFormatter stringFromDate:todayDate];

	

	
	
//	self.PdpButton.validatorString = @"NoValidation";
//	self.advantagePlanButton.validatorString = @"NoValidation";
//	self.supplementPlanButton.validatorString =@"NoValidation";
	
	
    self.beneficiaryTextField.validatorString =@"AlphabetValidator";
    self.representativeNameField.validatorString =@"OptionalAlphabetValidator";
    //self.beneficiaryView.validatorString =@"MandatoryValidator";
	
    PdpButton.parent = self;
    advantagePlanButton.parent = self;
    supplementPlanButton.parent = self;
	dsnpPlanButton.parent = self;
	
	PdpButton.tag=1;
	advantagePlanButton.tag=2;
	supplementPlanButton.tag=3;
	dsnpPlanButton.tag=4;
	
	[self.sharedataObj setForwardNextButtonTitle:@"Next"];
	[self.sharedataObj setNextProgressIndex:-1];
	
	[self.sharedataObj setPreviousNextButtonTitle:@"Next"];
	[self.sharedataObj setBackProgressIndex:-1];
    
	
	NSMutableArray *buttonArray;
	if ([[AppConfig enrollYear] isEqual:@"2016"]) {
		
		[dsnpPlanButton removeFromSuperview];
		
		buttonArray = [NSMutableArray arrayWithObjects:@"1",@"2",@"3",nil];
		[self loadPlanImage:buttonArray];
		
	}else{
		buttonArray = [NSMutableArray arrayWithObjects:@"1",@"2",@"3",@"4",nil];
		[self loadPlanImage:buttonArray];
	}
	
	ScopeViewController *weakSelf = self;
	
	self.willLoadNext = ^(id object){
		
		[AppConfig setGeneralJSONDictioanry:[AppConfig setValue:[AppConfig generalJSONDictionary] :@"general:scope:soa_included" :@"Yes"]];
		
		[UINavigationQueue deleteAfter:[ScopeBaseViewController class] container:[ScopeViewController class] xib:nil];

		[weakSelf addScopeDescription];
		[weakSelf addRemainingContainer];
		
		
	};
	
	self.willBackPage = ^(id object){
//		[UINavigationQueue deleteAfter:[DashboardBaseViewController class] container:[DashboardViewController class] xib:nil];
//		
//		[UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[ScopeSecondViewController class] xibName:[ScopeView class]];
    
		
	};
	
	self.willSkipTouch = ^(id object){
		
		[AppConfig setGeneralJSONDictioanry:[AppConfig setValue:[AppConfig generalJSONDictionary] :@"general:scope:soa_included" :@"No"]];

		
		[UINavigationQueue deleteAfter:[ScopeBaseViewController class] container:[ScopeViewController class] xib:nil];
		
		[weakSelf addRemainingContainer];
	};
	
    PdpButton.actionblock = ^(id sender, id parent){
        
        [parent changeButtonColor];
        
        //date restriction method call
      [parent planTappedAction:sender plan:@"PDP" date:@"10/15/2018"];
        
    };
    
    advantagePlanButton.actionblock = ^(id sender,id parent){
        
        [parent changeButtonColor];
         [parent planTappedAction:sender plan:@"MAPD" date:@"10/15/2018"]; // Date Restriction alert popup
    };
    
	dsnpPlanButton.actionblock = ^(id sender,id parent) {
		
		[parent changeButtonColor];
        [parent planTappedAction:sender plan:@"TotalCare" date:@"10/15/2018"]; // Date Restriction alert popup
		
	};

    supplementPlanButton.actionblock = ^(id sender,id parent) {
        
        [parent changeButtonColor];
        
//        [parent planTappedAction:sender plan:@"Supplement" date:@"10/1/2018"]; // Date Restriction alert popup
        
//       [parent planTappedAction:sender plan:@"Supplement" date:@"11/1/2018"]; // Date Restriction alert popup
        
       [parent planTappedAction:sender plan:@"Supplement" date:@"10/15/2018"]; // NEW DATE RESTRICTION
    };
	
	
}

-(void)viewWillAppear:(BOOL)animated{
	
    [ScopeBaseViewController populateCurrentItemValue];
    [self loadBackData];
	[super viewDidAppear:animated];
	
}

-(void)changeButtonColor {
    
    
    PdpButton.layer.borderColor = [UIColor clearColor].CGColor;
    advantagePlanButton.layer.borderColor = [UIColor clearColor].CGColor;
    supplementPlanButton.layer.borderColor = [UIColor clearColor].CGColor;
	dsnpPlanButton.layer.borderColor = [UIColor clearColor].CGColor;
    
    [self buttonLayerBorderWidth];
}

-(void)buttonLayerBorderWidth {
    
    PdpButton.layer.borderWidth = 1.0f;
    advantagePlanButton.layer.borderWidth = 1.0f;
    supplementPlanButton.layer.borderWidth = 1.0f;
	dsnpPlanButton.layer.borderWidth = 1.0f;
}


-(BOOL)validateVC {
	
     [self buttonLayerBorderWidth];
    
	if([PdpButton ischecked]||[advantagePlanButton ischecked]||[supplementPlanButton ischecked]||[dsnpPlanButton ischecked]){
        
        PdpButton.layer.borderColor = [UIColor clearColor].CGColor;
        advantagePlanButton.layer.borderColor = [UIColor clearColor].CGColor;
        supplementPlanButton.layer.borderColor = [UIColor clearColor].CGColor;
		dsnpPlanButton.layer.borderColor = [UIColor clearColor].CGColor;
		
		SubTitle.textColor = [UIColor colorWithRed:(153.0/255.0) green:(153.0/255.0) blue:(153.0/255.0) alpha:1.0f];
		return NO;
	}else {
        PdpButton.layer.borderColor = [UIColor colorWithRed:(240.0/255.0) green:(108.0/255.0) blue:(108.0/255.0) alpha:1.0f].CGColor;
        advantagePlanButton.layer.borderColor = [UIColor colorWithRed:(240.0/255.0) green:(108.0/255.0) blue:(108.0/255.0) alpha:1.0f].CGColor;
        supplementPlanButton.layer.borderColor = [UIColor colorWithRed:(240.0/255.0) green:(108.0/255.0) blue:(108.0/255.0) alpha:1.0f].CGColor;
		dsnpPlanButton.layer.borderColor = [UIColor colorWithRed:(240.0/255.0) green:(108.0/255.0) blue:(108.0/255.0) alpha:1.0f].CGColor;
		SubTitle.textColor = [UIColor colorWithRed:(240.0/255.0) green:(108.0/255.0) blue:(108.0/255.0) alpha:1.0f];
        
		return YES;
	}
}


-(void)addScopeDescription{
	
	if ([PdpButton ischecked]) {
		[AppConfig setMedicarePlanArray:@"1"];
        [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[ScopeSecondViewController class] xibName:[ScopeView class]];
	}
	if ([advantagePlanButton ischecked]){
		
		[AppConfig setMedicarePlanArray:@"2"];
        [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[ScopeSecondViewController class] xibName:[ScopeView2 class]];
	}
	
	if ([supplementPlanButton ischecked]) {
	
		[AppConfig setMedicarePlanArray:@"3"];
		[UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[ScopeSecondViewController class] xibName:[ScopeView3 class]];
	}
	
	if ([dsnpPlanButton ischecked]) {
		
		[AppConfig setMedicarePlanArray:@"4"];
		
		[UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[ScopeSecondViewController class] xibName:[ScopeView4 class]];
	}
	
	
	[UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[ScopeAppointmentFormViewcontroller class] xibName:@"ScopeFormAppointment"];

	
	
}
-(void)addRemainingContainer{
	

	[UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[MedicarePlanViewController class] xibName:nil];
    
}

-(void)loadNextPage {
	
	NSMutableArray *planArray = [[NSMutableArray alloc]init];
	
	if([PdpButton ischecked]){
		[planArray addObject:@"PDP"];
	}
	
	if([advantagePlanButton ischecked]){
		[planArray addObject:@"MAPD"];
	}
	
	if([supplementPlanButton ischecked]){
		[planArray addObject:@"Medigap"];
	}
	
	if([dsnpPlanButton ischecked]){
		
		[planArray addObject:@"DSNP"];
	}
	
	[AppConfig setGeneralJSONDictioanry:[AppConfig setValue:[AppConfig generalJSONDictionary] :@"general:scope:type_of_product" :planArray]];
	
	[AppConfig setGeneralJSONDictioanry:[AppConfig setValue:[AppConfig generalJSONDictionary] :@"general:scope:signature" :[_beneficiaryTextField getValueString]]];
    
    
    [AppConfig setGeneralJSONDictioanry:[AppConfig setValue:[AppConfig generalJSONDictionary] :@"general:scope:signature_confirmation" :[checkboxBtnView.checkBoxButton getValueString]]];
    
    [AppConfig setGeneralJSONDictioanry:[AppConfig setValue:[AppConfig generalJSONDictionary] :@"general:scope:relationship_to_beneficiary" :[_beneficiaryView getValueString]]];
    
    [AppConfig setGeneralJSONDictioanry:[AppConfig setValue:[AppConfig generalJSONDictionary] :@"general:scope:signature_date" :[dateView getValueString]]];
    
     [AppConfig setGeneralJSONDictioanry:[AppConfig setValue:[AppConfig generalJSONDictionary] :@"general:scope:representative_name" :[_representativeNameField getValueString]]];
    
   
    
}


-(void)loadBackData {
	
	
	
	NSArray *planArray =(NSArray *) [AppConfig getValueFromXpath:[AppConfig generalJSONDictionary] :@"general:scope:type_of_product"];
	
	
	if(planArray.count>0){
		
		if([planArray containsObject:@"PDP"]){
			
			[PdpButton setChecked:YES];
		}
		
		if([planArray containsObject:@"MAPD"]){
			
			[advantagePlanButton setChecked:YES];
		}
		
		if([planArray containsObject:@"Medigap"]){
			
			[supplementPlanButton setChecked:YES];
		}
		
		if([planArray containsObject:@"DSNP"]){
			
			[dsnpPlanButton setChecked:YES];
		}

	}
	
	

    if(![[AppConfig getValueFromXpath:[AppConfig generalJSONDictionary] :@"general:scope:signature"] isEqualToString:@""]){
         [_beneficiaryTextField setValueString:[AppConfig getValueFromXpath:[AppConfig generalJSONDictionary] :@"general:scope:signature"]];
    }
    
    if(![[AppConfig getValueFromXpath:[AppConfig generalJSONDictionary] :@"general:scope:signature_confirmation"]isEqualToString:@""]){
            [checkboxBtnView.checkBoxButton setValueString:[AppConfig getValueFromXpath:[AppConfig generalJSONDictionary] :@"general:scope:signature_confirmation"]];
    }
    
    if(![[AppConfig getValueFromXpath:[AppConfig generalJSONDictionary] :@"general:scope:relationship_to_beneficiary"]isEqualToString:@""]){
         [_beneficiaryView setValueString:[AppConfig getValueFromXpath:[AppConfig generalJSONDictionary] :@"general:scope:relationship_to_beneficiary"]];
    }
    
    if(![[AppConfig getValueFromXpath:[AppConfig generalJSONDictionary] :@"general:scope:signature_date"]isEqualToString:@""]){
          [dateView setValueString:[AppConfig getValueFromXpath:[AppConfig generalJSONDictionary] :@"general:scope:signature_date"]];
    }
    
    if(![[AppConfig getValueFromXpath:[AppConfig generalJSONDictionary] :@"general:scope:representative_name"] isEqualToString:@""]){
    [_representativeNameField setValueString:[AppConfig getValueFromXpath:[AppConfig generalJSONDictionary] :@"general:scope:representative_name"]];
    }
}



-(void)loadPlanImage:(NSMutableArray *)buttonArray{
	
	[PdpButton setTranslatesAutoresizingMaskIntoConstraints:NO];
	[advantagePlanButton setTranslatesAutoresizingMaskIntoConstraints:NO];
	[supplementPlanButton setTranslatesAutoresizingMaskIntoConstraints:NO];
	[dsnpPlanButton setTranslatesAutoresizingMaskIntoConstraints:NO];
	
	UICheckBox *tempBtn = nil;
	
	
	for (int i=0; i<buttonArray.count;i++){
		
		
		UICheckBox *button = (UICheckBox *)[self.view viewWithTag:[[buttonArray objectAtIndex:i] integerValue]];
		
		button.translatesAutoresizingMaskIntoConstraints = NO;
		button.hidden = NO;
		[button setChecked:NO];
        
        [self.view addConstraint:[NSLayoutConstraint constraintWithItem:button
                                                              attribute:NSLayoutAttributeWidth
                                                              relatedBy:NSLayoutRelationEqual
                                                                 toItem:nil
                                                              attribute:NSLayoutAttributeNotAnAttribute
                                                             multiplier:1.0
                                                               constant:203]];
		
		if(buttonArray.count==1){
			
			[self.view addConstraint:[NSLayoutConstraint constraintWithItem:button attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterX multiplier:1 constant:1.0]];
			
			[self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[selectTypeLabel]-20-[button(203)]-20-[checkboxBtnView]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(selectTypeLabel,button,checkboxBtnView)]];
			
		}else if(buttonArray.count>1 && buttonArray.count<3) {
			
			if(i==1){
				[self.view addConstraint:[NSLayoutConstraint constraintWithItem:button attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterX multiplier:1 constant:120.0]];
				
				[self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[selectTypeLabel]-20-[button(203)]-20-[checkboxBtnView]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(selectTypeLabel,checkboxBtnView,button)]];
			}else {
				
				[self.view addConstraint:[NSLayoutConstraint constraintWithItem:button attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterX multiplier:1 constant:-120.0]];
				
				[self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[selectTypeLabel]-20-[button(203)]-20-[checkboxBtnView]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(selectTypeLabel,checkboxBtnView,button)]];
				
			}
			
			
			
			
		}else if(buttonArray.count>2 && buttonArray.count<4){
			
			if(i==1){
				[self.view addConstraint:[NSLayoutConstraint constraintWithItem:button attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterX multiplier:1 constant:1.0]];
				
				[self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[selectTypeLabel]-20-[button(203)]-20-[checkboxBtnView]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(selectTypeLabel,checkboxBtnView,button)]];
			}else if(i==0) {
				
				[self.view addConstraint:[NSLayoutConstraint constraintWithItem:button attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterX multiplier:1 constant:-243.0]];
				
				[self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[selectTypeLabel]-20-[button(203)]-20-[checkboxBtnView]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(selectTypeLabel,checkboxBtnView,button)]];
				
			}else {
				[self.view addConstraint:[NSLayoutConstraint constraintWithItem:button attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterX multiplier:1 constant:243.0]];
				
				[self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[selectTypeLabel]-20-[button(203)]-20-[checkboxBtnView]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(selectTypeLabel,checkboxBtnView,button)]];
				
			}
			
		}else if(buttonArray.count>3){
			
			if(i==1){
				[self.view addConstraint:[NSLayoutConstraint constraintWithItem:button attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterX multiplier:1 constant:1.0]];
				
				[self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[selectTypeLabel]-20-[button(203)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(selectTypeLabel,button)]];
			}else if(i==0) {
				
				[self.view addConstraint:[NSLayoutConstraint constraintWithItem:button attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterX multiplier:1 constant:-250.0]];
				
				[self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[selectTypeLabel]-20-[button(203)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(selectTypeLabel,button)]];
				
			}else if(i==2){
				[self.view addConstraint:[NSLayoutConstraint constraintWithItem:button attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterX multiplier:1 constant:250.0]];
				
				[self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[selectTypeLabel]-20-[button(203)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(selectTypeLabel,button)]];
				
			}else {
				
				[self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[tempBtn]-40-[button(203)]-20-[checkboxBtnView]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(checkboxBtnView,button,tempBtn)]];
				[self.view addConstraint:[NSLayoutConstraint constraintWithItem:button attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterX multiplier:1 constant:1.0]];
				
				
			}
			
		}
		tempBtn = button;
	}
	[self.view updateConstraints];
	[self.view layoutIfNeeded];
}

#pragma mark Plan Action Methods

-(void)planTappedAction:(id)sender plan:(NSString *)planName date:(NSString *)dateString {
    
     //new code (hardcoded values)
    
    if([planName containsString:@"Supplement"]){
        
        if(![self enableMedigapPlanAfter1oct2018] && [[AppConfig enrollYear] isEqualToString:@"2019"]){
            [sender setChecked:NO];
            //            [self errorMessageAlert:@"ALERT" message:[self getErrorMessageForPlans:planName date:dateString]];
//            [self errorMessageAlert:@"ALERT" message:@"2019 Supplement Plan enrollment will start soon"]; //old code
            
               [self errorMessageAlert:@"ALERT" message:@"2019 Supplement Plan enrollment will start from 10/15/2018"];
        }
    }
    
    if([planName containsString:@"MAPD"]){
        
        if(![self enablePDPMAPDTotalCarePlanAfter15OCT2018] && [[AppConfig enrollYear] isEqualToString:@"2019"]){
            [sender setChecked:NO];
//            [self errorMessageAlert:@"ALERT" message:@"2019 Medicare Advantage Plan Enrollment starts from 10/15/2018"];
            [self errorMessageAlert:@"ALERT" message:@"2019 Medicare Advantage Plan enrollment will start from 10/15/2018"];
            
        }
    }
    
    if([planName containsString:@"PDP"]){
        
        if(![self enablePDPMAPDTotalCarePlanAfter15OCT2018] && [[AppConfig enrollYear] isEqualToString:@"2019"]){
            [sender setChecked:NO];
//            [self errorMessageAlert:@"ALERT" message:@"2019 Medicare Prescription Drug Plan Enrollment starts from 10/15/2018"];
            [self errorMessageAlert:@"ALERT" message:@"2019 Medicare Prescription Drug Plan enrollment will start from 10/15/2018"];
        }
    }
    
    if([planName containsString:@"TotalCare"]){
        
        if(![self enablePDPMAPDTotalCarePlanAfter15OCT2018] && [[AppConfig enrollYear] isEqualToString:@"2019"]){
            [sender setChecked:NO];
//            [self errorMessageAlert:@"ALERT" message:@"2019 TotalCare Plan Enrollment starts from 10/15/2018"];
            [self errorMessageAlert:@"ALERT" message:@"2019 TotalCare Plan enrollment will start from 10/15/2018"];
        }
    }
    
    
    
    
    /*
    
    if([planName containsString:@"Supplement"]){
        
        if(![self enableMedigapPlanAfter1oct2018] && [[AppConfig enrollYear] isEqualToString:@"2019"]){
            [sender setChecked:NO];
//            [self errorMessageAlert:@"ALERT" message:[self getErrorMessageForPlans:planName date:dateString]];
            [self errorMessageAlert:@"ALERT" message:@"2019 Supplement Plan enrollment will start soon"];
        }
    }else {
        
        if(![self enablePDPMAPDTotalCarePlanAfter15OCT2018] && [[AppConfig enrollYear] isEqualToString:@"2019"]){
            [sender setChecked:NO];
            [self errorMessageAlert:@"ALERT" message:[self getErrorMessageForPlans:planName date:dateString]];
        }
    }
     */
    
    
}

#pragma mark Plan Restriction Methods
-(BOOL)enableMedigapPlanAfter1oct2018 {
    
    // Enable Medigap Plan from 1st-Oct-2018
    
    // logic for showing alert for year restriction
    BOOL value;
    
    NSDate *currentDate = [NSDate date];
    
    // enable Medigap Plans from 10/1/2018
    NSDateComponents *octDateComps = [[NSDateComponents alloc] init];
    [octDateComps setDay:15];
    [octDateComps setMonth:10];
    [octDateComps setYear:2018];
    
    NSDate *dateOct2018 = [[NSCalendar currentCalendar] dateFromComponents:octDateComps];
    
    // simplified logic code
    if([currentDate compare:dateOct2018] == NSOrderedSame) {
        value = YES; // date is same to 10/1/2018 -> Enable medigap
    }else if([currentDate compare:dateOct2018] == NSOrderedDescending){
        value = YES; // date is greater than 10/1/2018 -> Enable medigap
    }else {
        value = NO;  // -> Disable Medigap
    }
    
    return value;
    
}


-(BOOL)enablePDPMAPDTotalCarePlanAfter15OCT2018 {
    
    // Enable PDP,MAPD,DSNP Plan from 15st-Oct-2018
    
    // logic for showing alert for year restriction
    BOOL value;
    
    NSDate *currentDate = [NSDate date];
    
    // Disable Medigap Plans from 10/15/2018
    NSDateComponents *octDateComps2 = [[NSDateComponents alloc] init];
    [octDateComps2 setDay:15];
    [octDateComps2 setMonth:10];
    [octDateComps2 setYear:2018];
    
    NSDate *date15Oct2018 = [[NSCalendar currentCalendar] dateFromComponents:octDateComps2];
    
    // simplified logic code
    if([currentDate compare:date15Oct2018] == NSOrderedSame) {
        value = YES; // date is same to 10/15/2018 -> Enable medigap
    }else if([currentDate compare:date15Oct2018] == NSOrderedDescending){
        value = YES; // date is greater than 10/15/2018 -> Enable medigap
    }else {
        value = NO;
    }
    return value;
    
}


#pragma mark Alert Message methods


-(NSString *)getErrorMessageForPlans:(NSString *)planName date:(NSString *)dateString {
    
    NSString *planAvailableStr = ([planName containsString:@"Supplement"])?[LanguageCentral languageSelectedString:@"PLAN_ARE_AVAILABLE_FROM"]:[LanguageCentral languageSelectedString:@"PLAN_AVAILABLE_FROM"];
    //    NSString *msgString = (localizeMessage.length>0)?localizePlanMsg:message;
    NSString *enrollForString = [LanguageCentral languageSelectedString:@"ENROLLMENTS_FOR"];
    
    return [NSString stringWithFormat:@"%@ %@ %@ %@",enrollForString,planName,planAvailableStr,dateString];
}

-(void)errorMessageAlert:(NSString *)title message:(NSString *)message {
    
    
    NSString *localizeTitle = [LanguageCentral languageSelectedString:title];
    NSString *titleString = (localizeTitle.length>0)?localizeTitle:title;
    
    
    NSString *localizeMessage = [LanguageCentral languageSelectedString:message];
    NSString *msgString = (localizeMessage.length>0)?localizeMessage:message;
    
    
    alertController = nil;
    alertController = [UIAlertController alertControllerWithTitle:titleString message:msgString preferredStyle:UIAlertControllerStyleAlert];
    alertController.view.tag = 100;
    
    UIAlertAction *okAction = [UIAlertAction
                               actionWithTitle:NSLocalizedString(@"OK", @"OK action")
                               style:UIAlertActionStyleDefault
                               handler:^(UIAlertAction *action)
                               {
                                   PRINTLOG(@"plan OK action");
                                   //                                   [self alertTimerInvalidate];
                               }];
    
    [alertController addAction:okAction];
    
    
    //    alertDismisstimer = [NSTimer scheduledTimerWithTimeInterval:10.0 target:self selector:@selector(dismissAlertPopup) userInfo:nil repeats:YES];
    
    [self presentViewController:alertController animated:YES completion:nil];
    
}

-(void)dismissAlertPopup {
    
    
    [self alertTimerInvalidate];
    
    [alertController dismissViewControllerAnimated:YES completion:nil];
    
}
-(void)alertTimerInvalidate {
    
    if(alertDismisstimer!=nil){
        [alertDismisstimer invalidate];
        alertDismisstimer=nil;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
