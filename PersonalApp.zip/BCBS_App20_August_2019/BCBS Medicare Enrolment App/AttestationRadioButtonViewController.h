//
//  AttestationRadioButtonViewController.h
//  SampleBCBSPOC
//
//  Created by CSS Admin on 6/1/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>

@interface AttestationRadioButtonViewController : UIBaseContainerViewController <UIRadioButtonDelegate>

@property (weak, nonatomic) IBOutlet UIView *radioButtonView;

@property (strong, nonatomic) IBOutlet UILabel *pleaseSelectLabel;

@property (weak, nonatomic) IBOutlet ValidatorLabel *detailLabel;
@property (strong, nonatomic) IBOutlet ValidatorLabel *titleString;

@property (strong,nonatomic) NSMutableArray *groupedItemsArray;




@end
