//
//  YearViewController.m
//  BcBs
//
//  Created by CSS Corp on 11/05/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "YearViewController.h"
#import "ScopeBaseViewController.h"
#import "ScopeViewController.h"
#import "DashboardBaseViewController.h"
#import "DashboardViewController.h"
#import "AppConfig.h"

@interface YearViewController ()
{
	UIAlertController *alertController;
}
@end

@implementation YearViewController
@synthesize buttonCurrentYear;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
	
//    buttonCurrentYear.userInteractionEnabled = NO;

}

-(void)viewWillAppear:(BOOL)animated {
    
    
    [super viewWillAppear:animated];
    [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"DashboardView"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    NSDateComponents *comps = [[NSDateComponents alloc]init];
    comps.year = 2019;
    comps.month = 10;
    comps.day = 14;
    NSCalendar *calender = [NSCalendar currentCalendar];
    NSDate *year2020 = [calender dateFromComponents:comps];
    NSDate *today = [NSDate date];
    PRINTLOG(@"today:%@ > Year2020:%@", today, year2020);

//   if([today compare:year2020] == NSOrderedDescending){
//        PRINTLOG(@"date Event called");
//        _buttonNextYear.userInteractionEnabled = YES;
//    }
    
    _buttonNextYear.userInteractionEnabled = YES;
    
}


-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
 
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)currentYearButtonAction:(id)sender {
    
    // enable 2017 plan restriction before october 15th

    BOOL value;
    NSDate *currentDate = [NSDate date];
    
    NSDateComponents *comps = [[NSDateComponents alloc] init];
    [comps setDay:01];
    [comps setMonth:01];
    [comps setYear:2020];
    NSDate *dateToAllow2017Enrollment = [[NSCalendar currentCalendar] dateFromComponents:comps];
    
    if([currentDate compare:dateToAllow2017Enrollment] == NSOrderedSame){
        value = YES;
        
    }else if([currentDate compare:dateToAllow2017Enrollment] == NSOrderedAscending){
        
        
    //  [self alertMessage:@"Alert" message:@"Enrollment starts from 15th Oct 2016"];
        
        
        value = YES;
        
    }else if([currentDate compare:dateToAllow2017Enrollment] == NSOrderedDescending){
        [self alertMessage:@"Alert" message:@"Enrollments for 2019 plans are not available from 1/1/2020."];
        value = NO;
    }

    if(value){
  
        PRINTLOG(@"currentYearButtonAction");
        
//        if([[AppConfig enrollYear] isEqualToString:@"2019"]){  //if previous year selected was "2016"
        
            [AppConfig resetGeneralJSONDictionary];
            [AppConfig resetAppConfig];
            [AppConfig resetPlanListArray];
            [AppConfig loadGeneralJSONPlist];
            [AppConfig setcounty:@""];
            [AppConfig setCountyZipcode:@""];
//        }
        
        
        [UINavigationQueue deleteAfter:[DashboardBaseViewController class] container:[YearViewController class] xib:nil];
        
        [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[ScopeViewController class] xibName:nil];
        
        [UINavigationQueue showNext:(UIBaseViewController *)self.parentViewController];
        
        [AppConfig setEnrollYear:@"2019"];
        
        PRINTLOG(@"%@",[AppConfig enrollYear]);
    }
}

- (IBAction)nextYearButtonAction:(id)sender {

    /*
     */
    BOOL value;
    NSDate *currentDate = [NSDate date];

    NSDateComponents *comps = [[NSDateComponents alloc] init];
    [comps setDay:15];
    [comps setMonth:10];
    [comps setYear:2019];
    NSDate *dateToAllow2017Enrollment = [[NSCalendar currentCalendar] dateFromComponents:comps];

    if([currentDate compare:dateToAllow2017Enrollment] == NSOrderedSame){
        value = YES;

    }else if([currentDate compare:dateToAllow2017Enrollment] == NSOrderedAscending){


    //  [self alertMessage:@"Alert" message:@"Enrollment starts from 15th Oct 2016"];

//        [self alertMessage:@"Alert" message:@"Enrollments for 2020 plans are available from 10/15/2019."];
        value = YES;

    }else if([currentDate compare:dateToAllow2017Enrollment] == NSOrderedDescending){

        value = YES;
    }

    if(value){
        PRINTLOG(@"nextYearButtonAction");
       

            [AppConfig resetGeneralJSONDictionary];
            [AppConfig resetAppConfig];
            [AppConfig resetPlanListArray];
            [AppConfig loadGeneralJSONPlist];
            [AppConfig setcounty:@""];
            [AppConfig setCountyZipcode:@""];
        
        

        [UINavigationQueue deleteAfter:[DashboardBaseViewController class] container:[YearViewController class] xib:nil];

        [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[ScopeViewController class] xibName:nil];

        [UINavigationQueue showNext:(UIBaseViewController *)self.parentViewController];

        [AppConfig setEnrollYear:@"2020"];



        PRINTLOG(@"%@",[AppConfig enrollYear]);
    }
    
   

}

-(void)alertMessage: (NSString*)title message: (NSString*)message {
    
    NSString *localizeTitle = [LanguageCentral languageSelectedString:title];
    NSString *titleString = (localizeTitle.length>0)?localizeTitle:title;
    
    
    NSString *localizeMessage = [LanguageCentral languageSelectedString:message];
    NSString *msgString = (localizeMessage.length>0)?localizeMessage:message;
	
	alertController = [UIAlertController alertControllerWithTitle:titleString
														  message:msgString preferredStyle:UIAlertControllerStyleAlert];
	
	UIAlertAction *okAction = [UIAlertAction
							   actionWithTitle:NSLocalizedString(@"OK", @"OK action")
							   style:UIAlertActionStyleDefault
							   handler:^(UIAlertAction *action)
							   {
                                   PRINTLOG(@"OK action");
							   }];
	
	
	[alertController addAction:okAction];
	
	[self presentViewController:alertController animated:YES completion:nil];

	
}


@end
