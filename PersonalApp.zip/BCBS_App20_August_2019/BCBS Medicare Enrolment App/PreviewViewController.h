//
//  PreviewViewController.h
//  BCBS Medicare Enrolment App
//
//  Created by CSS CORP on 06/06/18.
//  Copyright © 2018 CSS Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>


@interface PreviewViewController : UIBaseContainerViewController


@property (weak, nonatomic) IBOutlet UIView *view1;

@property (nonatomic) id childPreviewView;

@property (weak, nonatomic) IBOutlet ValidatorLabel *titleString;

@property (weak, nonatomic) IBOutlet ValidatorLabel *currentPlanName;

@property (weak, nonatomic) IBOutlet ValidatorLabel *planNameTitle;

@property (weak, nonatomic) IBOutlet ValidatorLabel *rateLabel;
@property (weak, nonatomic) IBOutlet ValidatorLabel *currentRateLabel;

@property (strong, nonatomic) IBOutlet ValidatorLabel *rateDisclaimerLabel;

- (IBAction)personalAction:(id)sender;
- (IBAction)healthAction:(id)sender;
- (IBAction)checklistAction:(id)sender;

-(void)counterTask;
-(IBAction)editIndexButtonPressed:(id)sender;



@end
