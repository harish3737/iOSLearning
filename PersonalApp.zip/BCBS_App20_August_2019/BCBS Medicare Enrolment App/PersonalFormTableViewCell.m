//
//  PersonalFormTableViewCell.m
//  SampleBCBSPOC
//
//  Created by CSS Admin on 5/24/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import "PersonalFormTableViewCell.h"

@implementation PersonalFormTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

-(id)initWithCoder:(NSCoder *)aDecoder {
    
    
    if(self = [super initWithCoder:aDecoder]){
        
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
