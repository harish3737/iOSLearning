//
//  ScopeView.h
//  Autolayout
//
//  Created by CSS Corp on 28/04/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>


@interface ScopeView : UIView

@property (weak, nonatomic) IBOutlet ScopeView *contentView;
@property (strong, nonatomic) IBOutlet ValidatorLabel *titleString;


@end
