//
//  QuestionnaireViewController.h
//  BCBS Medicare Enrolment App
//
//  Created by CSS Corp on 02/06/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>




@interface QuestionnaireViewController : UIBaseContainerViewController
@property (weak, nonatomic) IBOutlet UIView *firstView;
@property (weak, nonatomic) IBOutlet UIView *secondView;
@property (strong, nonatomic) IBOutlet ValidatorLabel *titleString;

@property (strong,nonatomic) NSMutableDictionary *objDictionary;

@property (strong,nonatomic) NSString *yesQuestion;
@property (strong,nonatomic) NSString *noQuestion;
@property (strong,nonatomic) NSString *nextQuestion;
@property (strong,nonatomic) NSArray *trailingScreen;

@property(nonatomic)BOOL isShowDenialAlert; //new code vrl BR2.0


@end
