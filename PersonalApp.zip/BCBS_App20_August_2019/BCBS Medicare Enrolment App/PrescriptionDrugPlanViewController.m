//
//  PrescriptionDrugPlanViewController.m
//  BCBS Medicare Enrolment App
//
//  Created by CSS Corp on 03/06/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "PrescriptionDrugPlanViewController.h"
#import "AppDelegate.h"
#import "AppConfig.h"
#import "ScopeBaseViewController.h"

@interface PrescriptionDrugPlanViewController (){
	
}
@property (nonatomic,strong)NSMutableArray *planEnrollArray;
@property (nonatomic,strong)NSMutableArray *getPlanArray;
@end

@implementation PrescriptionDrugPlanViewController
@synthesize planEnrollArray,planEnrolView,effectiveDateView;
@synthesize getPlanArray;


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
	
	getPlanArray = [[NSMutableArray alloc]init];
	planEnrolView.validatorString = @"MandatoryValidator";
	effectiveDateView.validatorString=@"MandatoryValidator";
	planEnrolView.isPlanDropDown = YES;
    
    _titleString.text = [NSString stringWithFormat:@"%@ %@ - \n%@",[AppConfig enrollYear],[LanguageCentral languageSelectedString:[[AppConfig currentPlanDictionary] objectForKey:@"PlanTitle"]],[LanguageCentral languageSelectedString:[[[AppConfig currentPlanDictionary] objectForKey:NSStringFromClass([self class])]objectForKey:@"title"]]];
	
	[planEnrolView setTitleString:@"Select a Plan"];
	[effectiveDateView setTitleString:@"Select a Date"];
    
	effectiveDateView.xPath = @"data:plan_details:effective_date";
	
	
    [self.sharedataObj setForwardNextButtonTitle:@"Continue_to_billing_active"];
    [self.sharedataObj setNextProgressIndex:1];
    
    [self.sharedataObj setPreviousNextButtonTitle:@"Next"];
    [self.sharedataObj setBackProgressIndex:1];
	
	NSNumberFormatter * numberFormatter = [[NSNumberFormatter alloc] init];
	
	NSDateComponents *components = [[NSCalendar currentCalendar] components:NSCalendarUnitMonth | NSCalendarUnitYear fromDate:[NSDate date]];
	NSMutableArray *effectiveDateArray = [[NSMutableArray alloc]init];
	NSString *month = [numberFormatter stringFromNumber:[NSNumber numberWithInteger:[components month]]];
	NSInteger currentMonth = [components month];
	NSInteger currentYear = [components year];
	
	
	NSString *planYear = [AppConfig enrollYear];
	NSInteger year = [planYear intValue];
	if(year > currentYear){
		currentYear = year;
		currentMonth = 0;
		month = @"0";
	}
	for(int iteration = 1; iteration <= 3 ; iteration ++){
		currentMonth += 1;
		int monthInt = [month intValue];// I assume you need it as an integer.
		month= [NSString stringWithFormat:@"%d",++monthInt];
		
		if(currentMonth < 13)
		{
			if(month.length == 1){
				[effectiveDateArray addObject:[NSString stringWithFormat:@"0%ld/01/%ld",(long)currentMonth,(long)currentYear]];
			}else{
				[effectiveDateArray addObject:[NSString stringWithFormat:@"%ld/01/%ld",(long)currentMonth,(long)currentYear]];
				
			}
			
		}
		//else{
		//    currentYear = currentYear+1;
		//  currentMonth = 1;
		// }
		
	}
	effectiveDateView.contentArray =effectiveDateArray;
	
	AppDelegate *appDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    NSString *selectQuery = [NSString stringWithFormat:@"Select Plan_Name, Monthly_Premium,CSV_Plan_Name from bcbs_pdp_plan where Plan_Year like '%@%%'",[AppConfig enrollYear]];
	NSArray *valueArray = [[NSArray alloc]initWithArray:[appDelegate.appDelegateDBHelper loadDataFromDB:selectQuery]];
    
    PRINTLOG(@"Fetch ::%@",valueArray);
	
	NSMutableArray *pdpArray =[[NSMutableArray alloc]init];
	
	if (valueArray.count>0) {
		
		for(NSArray *arrayValues in valueArray){
			
			NSString *planString = [NSString stringWithFormat:@"%@ -- %@",[arrayValues objectAtIndex:0],[arrayValues objectAtIndex:1]];
			
			[pdpArray addObject:planString];
//            [getPlanArray addObject:arrayValues];
			
		}
        getPlanArray = [valueArray copy];
        [AppConfig setPlanEnrollArray:getPlanArray];
	}else{
		
		[pdpArray addObject:@""];
        [getPlanArray removeAllObjects];
		[planEnrolView setTitleString:@"Select a Plan"];
        [AppConfig setPlanEnrollArray:nil];
	}
	
	
    PRINTLOG(@"pdpArray ::%@",pdpArray);
    
   	
	self.planEnrolView.contentArray = pdpArray;
    
    PrescriptionDrugPlanViewController *weakSelf = self;
    
    self.willLoadNext = ^(id object){
        
//        [weakSelf addCustomJsonValue];
        
    };
}

-(void)loadNextPage {
    [self addCustomJsonValue];
}


-(void)viewWillAppear:(BOOL)animated {
    
    [ScopeBaseViewController populateCurrentItemValue];
    [self loadBackData];
    
    [super viewWillAppear:animated];
}

-(void)addCustomJsonValue {
    

    [AppConfig fillJSONDictionary:@"data:plan_details:plan_year" value:[AppConfig enrollYear]];
    
    int index=0;
    
    if([self.planEnrolView.contentArray containsObject:self.planEnrolView.selectedString]) {
        index = [self.planEnrolView.contentArray indexOfObject: self.planEnrolView.selectedString];
       
		if(getPlanArray.count>0){
			 [AppConfig fillJSONDictionary:@"data:plan_details:csv_plan_name" value:[[getPlanArray objectAtIndex:index]objectAtIndex:2]];
		}
    } else {
       
        [AppConfig fillJSONDictionary:@"data:plan_details:csv_plan_name" value:@""];
    }
    
    [AppConfig fillJSONDictionary:@"data:plan_details:effective_date" value:effectiveDateView.selectedString];
    
}

-(void)loadBackData {
    
    if(![[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:plan_details:csv_plan_name"]isEqualToString:@""]){
        
        for(NSArray *planArray in [AppConfig planEnrollArray]){
            
            if([planArray containsObject:[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:plan_details:csv_plan_name"]]){
                NSString *planEnrollString = [NSString stringWithFormat:@"%@ -- %@",[planArray objectAtIndex:0],[planArray objectAtIndex:1]];
                

                [planEnrolView setValueString:planEnrollString];
            }
        }
        
        NSMutableArray *pdpArray =[[NSMutableArray alloc]init];
        if ([AppConfig planEnrollArray].count>0) {
            
            for(NSArray *arrayValues in [AppConfig planEnrollArray]){
                
                NSString *planString = [NSString stringWithFormat:@"%@ -- %@",[arrayValues objectAtIndex:0],[arrayValues objectAtIndex:1]];
                
                [pdpArray addObject:planString];
                
            }
            getPlanArray = [AppConfig planEnrollArray];
        }else{
            
            [pdpArray addObject:@""];
            [planEnrolView setTitleString:@"Select a Plan"];
            [AppConfig setPlanEnrollArray:nil];
        }
        
        self.planEnrolView.contentArray = pdpArray;

    }else {
        [planEnrolView setTitleString:@"Select a Plan"];
        
    }
    
    
    if(![[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:plan_details:effective_date"] isEqualToString:@""]){
        [effectiveDateView setValueString:[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:plan_details:effective_date"]];
    }else {
        [effectiveDateView setTitleString:@"Select a Date"];
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
