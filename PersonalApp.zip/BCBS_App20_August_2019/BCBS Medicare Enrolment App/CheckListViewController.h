//
//  CheckListViewController.h
//  BCBS Medicare Enrolment App
//
//  Created by CSS Corp on 15/06/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>

@interface CheckListViewController : UIBaseContainerViewController
@property (weak, nonatomic) IBOutlet UIView *view1;
@property (weak, nonatomic) IBOutlet UIView *view2;
@property (weak, nonatomic) IBOutlet UIView *view3;
@property (weak, nonatomic) IBOutlet UIView *view4;
@property (strong, nonatomic) IBOutlet UIView *view5;

@property (strong, nonatomic) IBOutlet UIView *view6;


@property (weak, nonatomic) IBOutlet ValidatorTextView *explanationTextView;
@property (strong, nonatomic) IBOutlet ValidatorLabel *titleString;
@property (strong, nonatomic) IBOutlet UIDropDown *dateView;
@property (strong, nonatomic) IBOutlet ValidatorTextField *agentSignature;
@property (strong, nonatomic) IBOutlet ValidatorLabel *agentNameLabel;
@property (strong, nonatomic) IBOutlet ValidatorLabel *beneficiaryName;

@end
