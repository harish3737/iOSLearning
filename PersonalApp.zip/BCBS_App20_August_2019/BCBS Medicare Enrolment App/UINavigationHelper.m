//
//  UINavigationHelper.m
//  BCBS Medicare Enrolment App
//
//  Created by CSS Admin on 8/1/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "UINavigationHelper.h"
#import "ScopeBaseViewController.h"
#import "PrescriptionDrugPlanViewController.h"
#import "PersonalFormViewController.h"
#import "PaymentOptionViewController.h"
#import "QuestionnaireViewController.h"
#import "AttestationRadioButtonViewController.h"
#import "AttestationViewController.h"
#import "AuthorizationViewController.h"
#import "CheckListViewController.h"
#import "EmailCollectionViewController.h"
#import "SubmissionViewController.h"
#import "HealthViewController.h"
#import "CountyViewController.h"
#import "SupplementPlanViewController.h"
#import "QuestionnaireLastViewController.h"
#import "SupplementNoticeViewController.h"
#import "SupplementPaymentOptionViewController.h"
#import "MedigapStaticInfoViewController.h"
#import "PlanPremiumViewController.h"
#import "SupplementGuaranteedQuestionViewController.h" // vrl added
#import "GuaranteedIssueRightsViewController.h"
#import "EFTDiscountViewController.h"
#import "PreviewViewController.h"

#import "AppConfig.h"


@implementation UINavigationHelper


+(void)addPDPScreens{
    
    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[PrescriptionDrugPlanViewController class] xibName:nil];
    
    [self addUptoPayment];
    
    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[QuestionnaireViewController class] xibName:[NSString stringWithFormat:@"%@DrugCoverageQuestionForm%@",[AppConfig currentPlan],[AppConfig enrollYear]]];

    
    
    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[QuestionnaireViewController class] xibName:[NSString stringWithFormat:@"%@HealthCareAddressQuestionForm%@",[AppConfig currentPlan],[AppConfig enrollYear]]];
    
    
    [UINavigationHelper addFromHealthToAuthorization];
    
    
    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[CheckListViewController class] xibName:nil];
    
     [self addEmailSubmissionScreen];
    
}
+(void)addMAPDScreens{
    
    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[CountyViewController class] xibName:nil];
    
     [self addUptoPayment];
    
    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[QuestionnaireViewController class] xibName:[NSString stringWithFormat:@"%@EsrdQuestionForm%@",[AppConfig currentPlan],[AppConfig enrollYear]]];
    
    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[QuestionnaireViewController class] xibName:[NSString stringWithFormat:@"%@DrugCoverageQuestionForm%@",[AppConfig currentPlan],[AppConfig enrollYear]]];
    
    
    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[QuestionnaireViewController class] xibName:[NSString stringWithFormat:@"%@HealthCareAddressQuestionForm%@",[AppConfig currentPlan],[AppConfig enrollYear]]];
    
    
    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[QuestionnaireViewController class] xibName:[NSString stringWithFormat:@"%@MedicaidEnrollQuestionForm%@",[AppConfig currentPlan],[AppConfig enrollYear]]];
    
    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[QuestionnaireViewController class] xibName:[NSString stringWithFormat:@"%@WorkQuestionForm%@",[AppConfig currentPlan],[AppConfig enrollYear]]];
    
    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[QuestionnaireViewController class] xibName:[NSString stringWithFormat:@"%@SpouseWorkQuestionForm%@",[AppConfig currentPlan],[AppConfig enrollYear]]];
    
    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[QuestionnaireLastViewController class] xibName:nil];
    
    [UINavigationHelper addFromHealthToAuthorization];
    

    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[CheckListViewController class] xibName:nil];
    
    [self addEmailSubmissionScreen];
    
}
+(void)addDSNPScreens{
    
    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[CountyViewController class] xibName:nil];
    
//     [self addUptoPayment];
    
     [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[PersonalFormViewController class] xibName:nil];
    
    
    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[QuestionnaireViewController class] xibName:[NSString stringWithFormat:@"%@EsrdQuestionForm%@",[AppConfig currentPlan],[AppConfig enrollYear]]];
    
    
    
    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[QuestionnaireLastViewController class] xibName:nil];
    
    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[CheckListViewController class] xibName:nil];
    
    [self addFromHealthToAuthorization];
    [self addEmailSubmissionScreen];
    
}
+(void)addSupplementScreens{
	
	 [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[SupplementPlanViewController class] xibName:nil];

//    [self addUptoPayment];
    
    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[PersonalFormViewController class] xibName:nil];
    
    if([[AppConfig currentPlan] isEqualToString:@"Supplement Plan 65 and over"] && ([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"])){
        [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[PaymentOptionViewController class] xibName:nil];
        [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[SupplementPaymentOptionViewController class] xibName:nil];
        
       
//        [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[EFTDiscountViewController class] xibName:nil];
         [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[QuestionnaireViewController class] xibName:[NSString stringWithFormat:@"%@1A%@",[AppConfig currentPlan],[AppConfig enrollYear]]];
        [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[GuaranteedIssueRightsViewController class] xibName:nil];
         [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[SupplementGuaranteedQuestionViewController class] xibName:nil];
    }
    
    //svk addded
    else if([[AppConfig currentPlan] isEqualToString:@"Supplement Plan 50-64"] && [[AppConfig enrollYear] isEqualToString:@"2020"]){
        [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[PaymentOptionViewController class] xibName:nil];
        [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[SupplementPaymentOptionViewController class] xibName:nil];
    }
    else if([[AppConfig currentPlan] isEqualToString:@"SupplementUnder50"] &&  [[AppConfig enrollYear] isEqualToString:@"2020"])
    {
        [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[PaymentOptionViewController class] xibName:nil];
        [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[SupplementPaymentOptionViewController class] xibName:nil];

    }
    else {
         [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[SupplementPaymentOptionViewController class] xibName:nil];
    }
    
      [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[MedigapStaticInfoViewController class] xibName:nil];
    
    if([[AppConfig currentPlan] isEqualToString:@"SupplementUnder50"]){
        
        
        [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[QuestionnaireViewController class] xibName:[NSString stringWithFormat:@"%@1B%@",[AppConfig currentPlan],[AppConfig enrollYear]]];
        
    }
    
    if([[AppConfig currentPlan] isEqualToString:@"Supplement Plan 50-64"]){
        
        
        [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[QuestionnaireViewController class] xibName:[NSString stringWithFormat:@"%@1A%@",[AppConfig currentPlan],[AppConfig enrollYear]]];
    }
    
    if([[AppConfig currentPlan] isEqualToString:@"Supplement Plan 65 and over"]){
        
        if(([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"]) ){
        [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[QuestionnaireViewController class] xibName:[NSString stringWithFormat:@"%@2A%@",[AppConfig currentPlan],[AppConfig enrollYear]]];
        }else {
        [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[QuestionnaireViewController class] xibName:[NSString stringWithFormat:@"%@1A%@",[AppConfig currentPlan],[AppConfig enrollYear]]];
        }
    }
    
    [self addFromHealthToAuthorization];
    [self addEmailSubmissionScreen];
}

+(void)addUptoPayment {
    
    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[PersonalFormViewController class] xibName:nil];
    
    if(![[AppConfig currentPlan] isEqualToString:@"DSNP"]){
        
    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[PaymentOptionViewController class] xibName:nil];
    
    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[PlanPremiumViewController class] xibName:nil];
    }
}

+(void)addFromHealthToAuthorization {
    
    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[HealthViewController class] xibName:nil];
    
    if(![[AppConfig currentPlan] isEqualToString:@"DSNP"]){
        
        [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[AttestationRadioButtonViewController class] xibName:nil];
    }
    
    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[AttestationViewController class] xibName:nil];
    
    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[AuthorizationViewController class] xibName:nil];
}

+(void)addEmailSubmissionScreen {
    
    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[EmailCollectionViewController class] xibName:@"EmailCollection"];
    
     if([[AppConfig currentPlan] containsString:@"Supplement"] && ([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"])){
         [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[PreviewViewController class] xibName:nil];
     }
    
    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[SubmissionViewController class] xibName:nil];
    
}


@end
