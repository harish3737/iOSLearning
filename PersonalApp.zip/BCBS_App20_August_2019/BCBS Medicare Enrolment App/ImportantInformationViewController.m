//
//  ImportantInformationViewController.m
//  BCBS Medicare Enrolment App
//
//  Created by CSS Corp on 31/08/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "ImportantInformationViewController.h"
#import "AppConfig.h"

@interface ImportantInformationViewController ()

@end

@implementation ImportantInformationViewController
@synthesize staticContent;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
	
    _titleString.text = [NSString stringWithFormat:@"%@ %@ - \n%@",[AppConfig enrollYear],[LanguageCentral languageSelectedString:[[AppConfig currentPlanDictionary] objectForKey:@"PlanTitle"]],[LanguageCentral languageSelectedString:[[[AppConfig currentPlanDictionary] objectForKey:NSStringFromClass([self class])]objectForKey:@"title"]]];
	
	if([[AppConfig currentPlan] isEqualToString:@"DSNP"]){
		[self.sharedataObj setForwardNextButtonTitle:@"Continue_to_authorization"];
		[self.sharedataObj setNextProgressIndex:2];
		
		[self.sharedataObj setPreviousNextButtonTitle:@"Next"];
		[self.sharedataObj setBackProgressIndex:2];
	}else {
		[self.sharedataObj setForwardNextButtonTitle:@"continue_to_attestation"];
		[self.sharedataObj setNextProgressIndex:3];
		
		[self.sharedataObj setPreviousNextButtonTitle:@"Next"];
		[self.sharedataObj setBackProgressIndex:3];
	}

    if ([[AppConfig currentPlan] isEqualToString:@"PDP"]){
        staticContent.localizationKey=@"PDP_READ_IMPORTANT_INFO_2019";
        
    }else if ([[AppConfig currentPlan] isEqualToString:@"MAPD"]){
         staticContent.localizationKey=@"MAPD_READ_IMPORTANT_INFO_2019";
    }else if ([[AppConfig currentPlan] isEqualToString:@"DSNP"] && [[AppConfig enrollYear] isEqualToString:@"2019"]){
        staticContent.localizationKey=@"DSNP_READ_IMPORTANT_INFO_2019";  //changed 
    }else if ([[AppConfig currentPlan] isEqualToString:@"DSNP"] && [[AppConfig enrollYear] isEqualToString:@"2020"]){
        staticContent.localizationKey=@"DSNP_READ_IMPORTANT_INFO_2020";
    }else {
        staticContent.localizationKey=@"READ_IMPORTANT_INFORMATION";
    }
    
    
	
	staticContent.layer.borderColor = [UIColor clearColor].CGColor;
	staticContent.font=[UIFont fontWithName:@"Arial" size:18];
	staticContent.textColor=[UIColor colorWithRed:(102/255.f) green:(102/255.f) blue:(102/255.f) alpha:1.0];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
