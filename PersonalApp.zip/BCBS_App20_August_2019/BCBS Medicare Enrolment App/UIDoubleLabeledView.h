//
//  UIDoubleLabeledView.h
//  CSSUIFramwork
//
//  Created by CSS CORP on 27/06/18.
//  Copyright © 2018 csscorp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>
#import "CustomValidatorLabel.h"

IB_DESIGNABLE

@interface UIDoubleLabeledView : UIView
@property (strong, nonatomic) IBOutlet UIDoubleLabeledView *doubleLabeledView;
@property (strong, nonatomic) IBOutlet CustomValidatorLabel *leftLabel;
@property (strong, nonatomic) IBOutlet CustomValidatorLabel *rightLabel;

@property (strong,nonatomic) NSString *xPath;

@property (nonatomic,strong) NSString *comparator;
@property (nonatomic,weak) DataValidator dataValidator;
@property (copy) UICallback *callback;

@property(nonatomic,strong) NSString *compareValue;

-(NSString *)getValueString;
-(NSString *)xPath;


@end
