//
//  AppConfig.h
//  BCBS Medicare Enrolment App
//
//  Created by CSS Corp on 30/06/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


typedef void(^AlertActionBlock)(id data , id handler);
static AlertActionBlock alertActionBlock;

@interface AppConfig : NSObject


+(NSString *) enrollYear;
+(void)setEnrollYear:(NSString *)year;

+(NSString *)countyZipcode;
+(void)setCountyZipcode: (NSString *)zipValue;

+(NSMutableArray *) medicarePlanArray;
+(void)setMedicarePlanArray:(NSString *)planArray;

+(void)resetAppConfig;
+(void)setEnrollmentFormArray:(NSString *)formArray;
+(NSMutableArray *) enrollmentFormArray;

+(void)setRequestJSONDictionary:(id)jsonDictionary;
+(NSMutableDictionary *)currentPlanJSONDictionary;
+(NSMutableDictionary *)getPlanJSONDictionaries;

// method for tempJSON dictionary
+(void)setTempJSONDictionary:(id)jsonDictionary;
+(NSMutableDictionary *)tempCurrentPlanJSONDictionary;

+(NSString *) lastUpdated;
+(NSString *) lastUpdatedDate;
+(void)setLastUpdatedDate:(NSString *)updatedDate;

+(void)setNetworkStatus:(BOOL)isNetwork;
+(BOOL)getNetworkStatus;

+(void)setUserName:(NSString*)userName;
+(NSString*)getUserName;

+(UIScrollView *)getBaseScrollView;
+(UIView *)getBaseMainView;

+(void)addPlans:(NSString *)currentPlan;
+(NSMutableArray *)planPlistArray;
+(void)deletePlans;
+(NSString *)currentPlan;
+(void)resetPlanListArray;

+(void)showLoaderGif;
+(void) stopAnimatingGif;

+(void)IncrementPlanIndex;

+(void)DecrementPlanIndex;

+(void)loadPlanPlistDict;
+(NSString *)getUserLoginStatusForSession;

+(NSMutableDictionary *)currentPlanDictionary;


+(NSString *)languageString;

+(NSMutableArray *)progressTitleArray;

+(NSMutableDictionary *)progressBarInfoDict;

+(void)loadProgressInfo;

+(void)clearProgressInfo;

+(void)setUserLoginInfo:(NSMutableDictionary *)loginInfo;

+(NSMutableDictionary *)userLoginInfo;

+(void)setAgentProfileInfo:(NSMutableDictionary *)agentInfo;

+(NSMutableDictionary *)agentProfileInfo;

+(NSMutableDictionary *)headerList;

+(void)loadJSONPlist:(NSString *)plan;

+(NSString *) county;
+(void)setcounty:(NSString *)countyString;

+(void)fillJSONDictionary :(NSString *)xPath value:(id)value;
+(NSString *)getValueFromXpath:(NSDictionary *)requestDict :(NSString *)xPath;
+(void)removeXpathFromJSONDictionary:(NSString *)xPath;

+(NSMutableArray *)ErrorResponseJSONSerialization:(id)response;

+(void)setUserLoggedIn:(BOOL)login;
+(BOOL)getUserLoginStatus;

+(UIFont *)boldFontWithFont:(UIFont *)font size:(CGFloat)sizeValue;

// set value for xpath in json dictionary
+(id)setValue :(NSDictionary *)requestDict :(NSString *)xPath : (id)value;


+(NSString*)getJsonStringByDictionary:(NSDictionary*)dictionary;

+(void)populateValue:(NSDictionary *)jsonDict :(id)currentHeadItem;

+(NSMutableDictionary *)generalJSONDictionary;
+(void)loadGeneralJSONPlist;
+(void)setGeneralJSONDictioanry:(id)jsonDict;
+(void)resetGeneralJSONDictionary;


+(NSMutableArray *)countyArray;
+(void)setCountyArray: (NSMutableArray *)countyValues;

+(NSMutableArray *)planEnrollArray;
+(void)setPlanEnrollArray: (NSMutableArray *)planArray;

+(NSMutableArray *)medigapPlanEnrollArray;
+(void)setMedigapPlanEnrollArray: (NSMutableArray *)medigapArray;

+(void)removePlans:(NSString *)currentPlan;
+(void)clearAllPlans;
+(void)removeRequestJSONDictionary:(NSString *)planName;
+(void)removeTempSONDictionary:(NSString *)planName;
+(void)insertPlan:(NSString *)planName index:(NSUInteger)index;

+(NSMutableArray *)medigapEffectiveArray;
+(void)setmedigapEffectiveArray: (NSMutableArray *)dateArray;


+(NSMutableArray *)medigapPlanCEffectiveArray;
+(void)setmedigapPlanCEffectiveArray: (NSMutableArray *)dateArray;

+(NSMutableArray *)medigapOtherPlanEffectiveArray;
+(void)setmmedigapOtherPlanEffectiveArray: (NSMutableArray *)dateArray;

+(NSMutableDictionary *)medigapPlanMetaDict;
+(void)setmedigapPlanMetaDict: (NSMutableDictionary *)dateDict;

//vrl added
+(NSInteger)editPageIndex;
+(void)setEditPageIndex:(NSInteger)index;

+(NSInteger)editPageIndexBasedOnString:(NSString *)pageName pageArray:(NSMutableArray *)pageArray;
+(NSInteger)pageIndexBasedOnSubViewString:(NSString *)pageName pageArray:(NSMutableArray *)pageArray;


+(NSInteger)pageIndex:(NSString *)pageName pageArray:(NSMutableArray *)pageArray;

+(void)setIsFromPreview:(BOOL)isFromPreview;
+(BOOL)isFromPreview;

+(void)setInsertPageIndex:(NSInteger)index;
+(NSInteger)insertPageIndex;

+(void)setRateAPIParams:(NSMutableDictionary *)paramDict;
+(NSMutableDictionary *)getRateAPIParams;

+(void)setIsCallRateAPI:(BOOL)isRateAPI;
+(BOOL)isCallRateAPI;

+(void)setRateAmount:(NSString *)rateAmt;
+(NSString *)rateAmount;

+(void)incrementEditIndex;
+(void)incrementInsertIndex;

+(void)decrementEditIndex;
+(void)decrementInsertIndex;

+(void)setIsAddNoticePage:(BOOL)isAddNotice;
+(BOOL)isAddNoticePage;

//BRD 2.0
+(void)showAlertView:(NSString *)title message:(NSString *)message class:(id)classVC actionBlock:(AlertActionBlock)actionBlock;


+(void)showAlertView:(NSString *)title message:(NSString *)message OkTitle:(NSString *)okTitle CanelTitle:(NSString *)cancelTitle class:(id)classVC okAction:(AlertActionBlock)okActionBlock cancelAction:(AlertActionBlock)cancelAction;

+(void)dismissAlertController;

+(void)setBirthDate:(NSString *)birthDateString;
+(NSString *)birthDateString;


+(void)setIsFromQuestionPage:(BOOL)isFromQuesPage;
+(BOOL)isFromQuestionPage;

+(void)setIsTurn65InAfter3monthsFuture:(BOOL)isTurn65;
+(BOOL)isTurn65After3monthsFuture;


//svk added
+(void)showEffectiveDateDropDownsFor65:(BOOL)show;
+(BOOL)getShowEffectiveDateDropDownsFor65;

//anitha added
+(void)testWrapper:(id)url query:(id)operation callback:(id)handler;
+(void)errorMessageAlert:(NSString *)title message:(NSString *)message class:(id)classVC;
+(void)removeActivityIndicator;


@end
