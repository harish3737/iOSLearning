//
//  ResetPasswordViewController.m
//  BcBs
//
//  Created by CSS Corp on 10/05/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "ResetPasswordViewController.h"
#import "AppConfig.h"

#import <CacheLib/CacheLib.h>
#import <CacheLib/WebServiceWrapper.h>
#import <CacheLib/Callback.h>
#import <CacheLib/Global.h>

#define kOFFSET_FOR_KEYBOARD 100.0
@interface ResetPasswordViewController ()

@end

@implementation ResetPasswordViewController
@synthesize scrollView;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
	
	self.usernameTextField.validatorString=@"EmptyValidator";
	self.emailaddressTextField.validatorString=@"EmailValidator";
    
    self.emailaddressTextField.keyboardTypeName = UIKeyboardTypeEmailAddress;
	
	self.usernameTextField.autocorrectionType = UITextAutocorrectionTypeNo;
	self.emailaddressTextField.autocorrectionType = UITextAutocorrectionTypeNo;

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)resetPassword:(id)sender{
	
    if([AppConfig getNetworkStatus]){
        
        BOOL hasError = NO;
        hasError |= !_usernameTextField.validate;
        hasError |= !_emailaddressTextField.validate;
        
        if(!hasError) {
            
            [AppConfig showLoaderGif];
            [Validator ValidationDone]; // headItem
          [self resetPasswordWebservice]; //future uncomment for this reset password webservice
            
			self.usernameTextField.text = @"";
			self.emailaddressTextField.text = @"";
            
        }
    }else {
        PRINTLOG(@"SignIN Button - network offline");
    
        [AppConfig stopAnimatingGif];
//        [self errorMessageAlert:@"INFO" message:@"The Internet connection appears to be offline."];
        //anitha added
        [AppConfig errorMessageAlert:@"INFO" message:@"The Internet connection appears to be offline." class:self];
    }

}

-(void)resetPasswordWebservice {
    
    __block ResetPasswordViewController *weakSelf = self;
    
    Callback *cacheCallback = [[Callback alloc]initWithCallbacks: ^(id response,id operation,id handler){
        PRINTLOG(@"Reset Response Success ::\n%@",response);
//        NSError *jsonError;
//        NSData *objectData = [response dataUsingEncoding:NSUTF8StringEncoding];
//        NSMutableDictionary *jsonData = [NSJSONSerialization JSONObjectWithData:objectData
//                                                                        options:NSJSONReadingMutableContainers
//                                                                          error:&jsonError];
        [AppConfig stopAnimatingGif];
        [handler submitDatasuccess];
        
        
    }:^(id response,id operation,id handler){
        PRINTLOG(@"Response Failed ::\n%@",response);
        [AppConfig stopAnimatingGif];
        [handler errorMessageAlert:@"Error" message:[[AppConfig ErrorResponseJSONSerialization:response]objectAtIndex:0]];
        PRINTLOG(@"Response Error ::\n%@",[[AppConfig ErrorResponseJSONSerialization:response]objectAtIndex:0]);
        
    }: weakSelf];
    
    
    Cache *cache = [[Cache alloc]init];
    [cache setService: [[WebServiceWrapper alloc] init]];
    [cache settimeoutInMin:1.0];
    
    
    NSMutableDictionary *resetData = [NSMutableDictionary dictionaryWithObjectsAndKeys:_usernameTextField.text,@"name",nil];
    
    JsonOperation *jOP = [[JsonOperation alloc]init];

    
     [cache registerTaskAndExecute:RESET_PWD_URL :[jOP getJsonStringByDictionary:resetData] : cacheCallback : NO_CACHE];
    

}

-(void)errorMessageAlert:(NSString *)title message:(NSString *)message {


    NSString *localizeTitle = [LanguageCentral languageSelectedString:title];
    NSString *titleString = (localizeTitle.length>0)?localizeTitle:title;


    NSString *localizeMessage = [LanguageCentral languageSelectedString:message];
    NSString *msgString = (localizeMessage.length>0)?localizeMessage:message;


    UIAlertController *alertController = [UIAlertController
                                          alertControllerWithTitle:titleString
                                          message:msgString
                                          preferredStyle:UIAlertControllerStyleAlert];

    UIAlertAction *okAction = [UIAlertAction
                               actionWithTitle:NSLocalizedString(@"OK", @"OK action")
                               style:UIAlertActionStyleDefault
                               handler:^(UIAlertAction *action)
                               {
                                   PRINTLOG(@"ok action");
                               }];

    [alertController addAction:okAction];

    [self presentViewController:alertController animated:YES completion:nil];

}




-(void)submitDatasuccess {
	
	UIAlertController * alert=   [UIAlertController
								  alertControllerWithTitle:@"Thank You!"
								  message:@"An email has been sent to the email address on file.\n\nPlease click on the link and follow the steps to reset your password."
								  preferredStyle:UIAlertControllerStyleAlert];
	
	UIAlertAction* ok = [UIAlertAction
						 actionWithTitle:@"Continue to Sign In"
						 style:UIAlertActionStyleDefault
						 handler:^(UIAlertAction * action)
						 {
							 [alert dismissViewControllerAnimated:YES completion:nil];
							 CATransition* transition = [CATransition animation];
							 transition.duration = 0.25f;
							 transition.type = kCATransitionFade;
							 transition.subtype = kCATransitionFromTop;
							 [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
							 
							 [self.navigationController popToRootViewControllerAnimated:NO];

						 }];
	[alert addAction:ok];
	
	[self presentViewController:alert animated:YES completion:nil];
	
}




- (IBAction)backToSignIn:(id)sender {
	
	CATransition* transition = [CATransition animation];
	transition.duration = 0.25f;
	transition.type = kCATransitionFade;
	transition.subtype = kCATransitionFromTop;
	[self.navigationController.view.layer addAnimation:transition forKey:kCATransition];

	[self.navigationController popToRootViewControllerAnimated:NO];
	
}


-(void)viewWillAppear:(BOOL)animated{
	
	[super viewWillAppear:animated];
	
	
	
}




- (void)viewWillDisappear:(BOOL)animated
{
	[Validator ValidationDone];
	[super viewWillDisappear:animated];
	
}


@end
