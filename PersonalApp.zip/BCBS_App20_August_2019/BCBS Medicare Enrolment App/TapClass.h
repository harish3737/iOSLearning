//
//  TapClass.h
//  GestureSample
//
//  Created by Ganesh on 19/07/16.
//  Copyright © 2016 CSS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppConfig.h"
#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>

@interface TapClass : UIApplication <UIAlertViewDelegate>

@property (nonatomic) NSUInteger remainingTime;
@property (nonatomic,strong) UIAlertController *alertController,*timeOutAlert,*userAlert,*bgSessionAlert;
+(void) disableTimer;

+(instancetype)sharedInstance;
- (void)idleTimerExceeded;
-(void)sessionLogoutFromAppDelegate;
-(void)disableTimeOutAlertView;

@end
