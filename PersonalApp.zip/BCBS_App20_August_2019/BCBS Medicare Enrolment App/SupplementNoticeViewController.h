//
//  SupplementNoticeViewController.h
//  BCBS Medicare Enrolment App
//
//  Created by Ganesh on 04/08/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <CSSUIFramwork/CSSUIFramwork.h>

@interface SupplementNoticeViewController : UIBaseContainerViewController
@property (strong, nonatomic) IBOutlet UIView *radioButtonView;
@property (strong, nonatomic) IBOutlet ValidatorLabel *titleString;
@property (strong, nonatomic) IBOutlet UIView *indexedLabelView;
@property (strong, nonatomic) IBOutlet ValidatorTextField *applicantSignatureTextField;
@property (strong, nonatomic) IBOutlet UIDropDown *dateView;
@property (strong, nonatomic) IBOutlet UIDropDown *applicantDateView;
@property (strong, nonatomic) IBOutlet ValidatorTextField *agentSignatureTextField;

@property (weak, nonatomic) IBOutlet ValidatorLabel *agentDateLabel;
@property (weak, nonatomic) IBOutlet ValidatorLabel *applicantDateLabel;
@property (weak, nonatomic) IBOutlet ValidatorLabel *agentSignatureLabel;
@property (weak, nonatomic) IBOutlet ValidatorLabel *applicantSignatureLabel;
@property (weak, nonatomic) IBOutlet ValidatorLabel *saveNoticeLabel;
@property (weak, nonatomic) IBOutlet ValidatorLabel *accordingApplicationLabel;
@property (weak, nonatomic) IBOutlet ValidatorLabel *statementApplicantLabel;
@property (weak, nonatomic) IBOutlet ValidatorLabel *reviewInsuranceLabel;



@end
