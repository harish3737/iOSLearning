//
//  AppDelegate.m
//  BCBS Medicare Enrolment App
//
//  Created by CSS Corp on 17/05/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "AppDelegate.h"
#import "AppConfig.h"
#import "GAIHelper.h"
#import "AppConfig.h"

#import <CacheLib/CacheLib.h>
#import <CacheLib/WebServiceWrapper.h>
#import <CacheLib/Callback.h>
#import <CacheLib/Global.h>

#import "TapClass.h"


@interface AppDelegate ()
{
    NSTimer* t;
    NSDate *backgroundEnterTime;

}

@end


@implementation AppDelegate

BOOL timerStarted = FALSE;


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
	
	
	// Override point for customization after application launch.
	self.appDelegateDBHelper = [[DBHelper alloc]initWithDatabaseFilename:@"Medicare.DB"];
	
	[GAIHelper initGAI];


	return YES;
}


-(void)createTableQuery:(DBHelper *)dbHelper{
	
	NSString *createPDPTableQuery = [NSString stringWithFormat:@"CREATE TABLE bcbs_pdp_plan(Plan_Name VARCHAR(50) NULL DEFAULT NULL,CSV_Plan_Name VARCHAR(50) NULL DEFAULT NULL,Plan_Year VARCHAR(50) NULL DEFAULT NULL,Monthly_Premium VARCHAR(50) NULL DEFAULT NULL)"];
	
	[dbHelper createQuery:createPDPTableQuery];
	
	
	NSString *createMAPDTAbleQuery = [NSString stringWithFormat:@"CREATE TABLE bcbs_mapd_plan (Plan_name VARCHAR(50) NULL DEFAULT NULL,CSV_Plan_Name VARCHAR(50) NULL DEFAULT NULL,Plan_Year VARCHAR(50) NULL DEFAULT NULL,Region VARCHAR(50) NULL DEFAULT NULL,Monthly_Premium VARCHAR(50) NULL DEFAULT NULL,Plan_Type VARCHAR(50) NULL DEFAULT NULL,Updated VARCHAR(50) NULL DEFAULT NULL)"];
	
	[dbHelper createQuery:createMAPDTAbleQuery];
	
	//old code
//    NSString *createMediGapTableQuery = [NSString stringWithFormat:@"CREATE TABLE bcbs_medigap_plan (Plan_Name VARCHAR(50) NULL DEFAULT NULL,CSV_Plan_Name VARCHAR(50) NULL DEFAULT NULL,Plan_Year VARCHAR(50) NULL DEFAULT NULL,Min_Age_Range VARCHAR(50) NULL DEFAULT NULL,Max_Age_Range VARCHAR(50) NULL DEFAULT NULL,Monthly_Premium VARCHAR(50) NULL DEFAULT NULL)"];
    
    NSString *createMediGapTableQuery = [NSString stringWithFormat:@"CREATE TABLE bcbs_medigap_plan (Plan_Name VARCHAR(50) NULL DEFAULT NULL,CSV_Plan_Name VARCHAR(50) NULL DEFAULT NULL,Plan_Year VARCHAR(50) NULL DEFAULT NULL,Min_Age_Range VARCHAR(50) NULL DEFAULT NULL,Max_Age_Range VARCHAR(50) NULL DEFAULT NULL,Monthly_Premium VARCHAR(50) NULL DEFAULT NULL,Coverage_Code VARCHAR(50) NULL DEFAULT NULL)"];
	
	[dbHelper createQuery:createMediGapTableQuery];
	
	
	NSString *createZipCountyTableQuery = [NSString stringWithFormat:@"CREATE TABLE bcbs_zip_county_region_map (Zip_Code VARCHAR(500) DEFAULT NULL,Region VARCHAR(50) DEFAULT NULL,County VARCHAR(50) DEFAULT NULL,Enroll_Year VARCHAR(50) DEFAULT NULL)"];
	
	[dbHelper createQuery:createZipCountyTableQuery];
	
}


- (void)applicationWillResignActive:(UIApplication *)application {
	// Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
	// Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
	// Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
	// If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    
     PRINTLOG(@"applicationDidEnterBackground -- %d",[TapClass sharedInstance].remainingTime);
    
    //check if application status is in background
    if ( [UIApplication sharedApplication].applicationState == UIApplicationStateBackground) {
    
        //start updating timer
        backgroundEnterTime = [NSDate date];
        
        PRINTLOG(@"Background ::%@",backgroundEnterTime);

    }
    
    
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
	// Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    
     PRINTLOG(@"applicationWillEnterForeground -- %d",[TapClass sharedInstance].remainingTime);

    NSTimeInterval sessionTimerSeconds = [[NSDate date] timeIntervalSinceDate:backgroundEnterTime];
    
//    PRINTLOG(@"sessionTimerDifference :: %f",sessionTimerDifference);
    
    if([TapClass sharedInstance].remainingTime <= sessionTimerSeconds) {
        [TapClass sharedInstance].remainingTime = 1;
        
        
        //vrl added new // to dismiss the plan restriction alert popup
        id basevcMainRoot = [[[UIApplication sharedApplication]keyWindow]rootViewController];
        id vcAlertVC = [basevcMainRoot visibleViewController];
        
        if([vcAlertVC isKindOfClass:[UIAlertController class]]){
            PRINTLOG(@"Dismiss plan restriction alert");
            if([vcAlertVC view].tag == 100 || [vcAlertVC view].tag == 200){
                [vcAlertVC dismissViewControllerAnimated:YES completion:nil];
            }
        }
        
        
        // if timeOut Alert
        if([TapClass sharedInstance].timeOutAlert!=nil || [TapClass sharedInstance].bgSessionAlert!=nil){
            PRINTLOG(@"Tap class timeout alert not nil");
            
            [[TapClass sharedInstance] disableTimeOutAlertView];
            
        }
            
        [[TapClass sharedInstance] sessionLogoutFromAppDelegate];

    }
    
   
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
	// Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (BOOL)application:(UIApplication *)application shouldAllowExtensionPointIdentifier:(NSString *)extensionPointIdentifier {
    if ([extensionPointIdentifier isEqualToString: UIApplicationKeyboardExtensionPointIdentifier]) {
       
        return NO;
    }
    return YES;
}

- (void)applicationWillTerminate:(UIApplication *)application {
	// Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    
	__block AppDelegate *weakSelf = self;

	
	Callback *cacheCallback = [[Callback alloc]initWithCallbacks: ^(id response,id operation,id handler){
		
		NSError *jsonError;
		NSData *objectData = [response dataUsingEncoding:NSUTF8StringEncoding];
		NSMutableDictionary *jsonData = [NSJSONSerialization JSONObjectWithData:objectData
																		options:NSJSONReadingMutableContainers
																		  error:&jsonError];
		
    
		[handler logoutSuccessAction];
		
		
	}:^(id response,id operation,id handler){
       
//        [handler errorMessageAlert:@"Error" message:[[AppConfig ErrorResponseJSONSerialization:response]objectAtIndex:0]]; 
		
	}:weakSelf];
	
	
	Cache *cache = [[Cache alloc]init];
	[cache setService: [[WebServiceWrapper alloc] init]];
	[cache settimeoutInMin:1.0];
    
	[cache registerTask:LOGOUT_URL :@"NoData" :cacheCallback :NO_CACHE];
	[cache setHeaders:LOGOUT_URL  :@"NoData" :[AppConfig headerList]];
	[cache execute : LOGOUT_URL :@"NoData"];    
}



-(void)logoutSuccessAction {
	
    [AppConfig stopAnimatingGif];
	[Validator ValidationDone];
	[AppConfig resetAppConfig];
	[UINavigationQueue clearNavigationQueue:-1];
	
	CATransition* transition = [CATransition animation];
	transition.duration = 0.25f;
	transition.type = kCATransitionFade;
	transition.subtype = kCATransitionFromTop;
    
}


@end
