//
//  MedicarePlanViewController.m
//  BCBS Medicare Enrolment App
//
//  Created by CSS Corp on 01/06/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "MedicarePlanViewController.h"
#import "ScopeBaseViewController.h"
#import "PrescriptionDrugPlanViewController.h"
#import "PersonalFormViewController.h"
#import "PaymentOptionViewController.h"
#import "QuestionnaireViewController.h"
#import "HealthViewController.h"
#import "AttestationRadioButtonViewController.h"
#import "AttestationViewController.h"
#import "SupplementPlanViewController.h"
#import "SubmissionViewController.h"
#import "CountyViewController.h"
#import "AuthorizationViewController.h"
#import "CheckListViewController.h"
#import "QuestionnaireLastViewController.h"
#import "EmailCollectionViewController.h"
#import "UINavigationHelper.h"

#import <CacheLib/CacheLib.h>
#import <CacheLib/WebServiceWrapper.h>
#import <CacheLib/Callback.h>
#import <CacheLib/Global.h>


@interface MedicarePlanViewController (){
    
    BOOL isEnableMedigap;
    UIAlertController *alertController;
}

@end

@implementation MedicarePlanViewController
@synthesize pdpButton,advantagePlanButton,supplementPlanUnder50Button,supplementPlan50To64Button,supplementPlan65AndOverButton,dsnpPlanButton,titleString,SubTitle;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
//    [AppConfig resetPlanListArray];
    PRINTLOG(@"Get JSON Dict ::%@",[AppConfig getPlanJSONDictionaries]);
	
	pdpButton.parent = self;
	advantagePlanButton.parent = self;
	supplementPlanUnder50Button.parent = self;
	supplementPlan50To64Button.parent = self;
	supplementPlan65AndOverButton.parent = self;
	dsnpPlanButton.parent = self;
	
//	pdpButton.validatorString=@"MandatoryValidator";
//	advantagePlanButton.validatorString=@"MandatoryValidator";
//	supplementPlanUnder50Button.validatorString=@"MandatoryValidator";
//	supplementPlan50To64Button.validatorString=@"MandatoryValidator";
//	supplementPlan65AndOverButton.validatorString=@"MandatoryValidator";
//	dsnpPlanButton.validatorString=@"MandatoryValidator";
	
	[self.sharedataObj setForwardNextButtonTitle:@"Next"];
	[self.sharedataObj setNextProgressIndex:-1];
	
	[self.sharedataObj setPreviousNextButtonTitle:@"Next"];
	[self.sharedataObj setBackProgressIndex:-1];
	
	
//	[pdpButton setChecked:YES];
	
//	pdpButton.validatorString=@"NoValidation";
//	supplementPlanUnder50Button.validatorString=@"NoValidation";
	
	if ([[AppConfig enrollYear] isEqual:@"2016"]) {
		
//		titleString.text = @"HORIZON MEDICARE PLAN - 2016";
//		titleString.font = [UIFont fontWithName:@"AvenirNext-DemiBold" size:28];
//		titleString.textColor = [UIColor colorWithRed:(0/255.f) green:(82/255.f) blue:(157/255.f) alpha:1.0];
		
	
		[dsnpPlanButton removeFromSuperview];
		
			advantagePlanButton.translatesAutoresizingMaskIntoConstraints = NO;
			[self.view addConstraint:[NSLayoutConstraint constraintWithItem:advantagePlanButton attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterX multiplier:1 constant:120]];
		

	
	}else {
		
	}

    titleString.text = [NSString stringWithFormat:@"%@ - %@",[LanguageCentral languageSelectedString:@"HORIZON_MEDICARE_PLAN"],[AppConfig enrollYear]];
    titleString.font = [UIFont fontWithName:@"AvenirNext-DemiBold" size:28];
    titleString.textColor = [UIColor colorWithRed:(0/255.f) green:(82/255.f) blue:(157/255.f) alpha:1.0];
	
	MedicarePlanViewController *weakSelf = self;
	
	self.willLoadNext = ^(id object){
		
		[UINavigationQueue deleteAfter:[ScopeBaseViewController class] container:[MedicarePlanViewController class] xib:nil];
		[weakSelf addMedicarePlanDescription];
	};
	
	
	pdpButton.actionblock = ^(id sender, id parent){
		[parent pdpLogic];
	};
	
	
	
	advantagePlanButton.actionblock = ^(id sender,id parent){
		
		[parent advantageLogic];
	};
	
	
	supplementPlanUnder50Button.actionblock = ^(id sender,id parent) {
		
		[parent supplementUnder50Logic];
		
	};
	
	
	supplementPlan50To64Button.actionblock = ^(id sender,id parent) {
		
		[parent supplementUnder50To64Logic];
	};
	
	
	supplementPlan65AndOverButton.actionblock = ^(id sender,id parent) {
		
		[parent supplementPlan65AndOverLogic];
	};
	
	
	dsnpPlanButton.actionblock = ^(id sender,id parent) {
		
		[parent dsnpLogic];
	};
    
    //svk added 15/07
   if([[AppConfig enrollYear]isEqualToString:@"2020"])
   {
//       pdpButton.userInteractionEnabled = NO;
//       advantagePlanButton.userInteractionEnabled = NO;
//       dsnpPlanButton.userInteractionEnabled = NO;

   }
   
    [AppConfig showEffectiveDateDropDownsFor65:NO];

}

- (void)viewWillAppear:(BOOL)animated{
    
    [ScopeBaseViewController populateCurrentItemValue];
    [self loadBackData];
    
    // Don't enable this code , bcaz we waiting for client side clarification about logic
//    if([[AppConfig enrollYear] isEqualToString:@"2019"]){
//        isEnableMedigap = [self logicForEnableMedigap2019];
//    }else {
//        isEnableMedigap = YES;
//    }
    
    //vrl Add new logic based on BRD2.0 changes
    if([AppConfig isFromQuestionPage]) {
        
        [AppConfig resetPlanListArray];
        [supplementPlan65AndOverButton setChecked:NO];
        [self supplementPlan65AndOverLogic];
        
        [AppConfig setEditPageIndex:0];
        
    }
    [AppConfig setIsFromQuestionPage:NO];
    
    [super viewWillAppear:animated];
}

-(void)loadBackData {
    
    
    if([[AppConfig planPlistArray]containsObject:@"PDP"]){
        
        [pdpButton setChecked:YES];
        [self pdpLogic];
    }
    
    if([[AppConfig planPlistArray]containsObject:@"MAPD"]){
       [advantagePlanButton setChecked:YES];
        [self advantageLogic];

    }
    
    if([[AppConfig planPlistArray]containsObject:@"DSNP"]){
        [dsnpPlanButton setChecked:YES];
        [self dsnpLogic];
    }
    
    if([[AppConfig planPlistArray]containsObject:@"SupplementUnder50"]){
         [supplementPlanUnder50Button setChecked:YES];
        [self supplementUnder50Logic];
    
    }
    
    if([[AppConfig planPlistArray]containsObject:@"Supplement Plan 50-64"]){
        [supplementPlan50To64Button setChecked:YES];
        [self supplementUnder50To64Logic];
    }
    
    if([[AppConfig planPlistArray]containsObject:@"Supplement Plan 65 and over"]){
         [supplementPlan65AndOverButton setChecked:YES];
        [self supplementPlan65AndOverLogic];
    }
    

    
    
}

-(void)loadNextPage {
    

    
}

-(void)pdpLogic{
    

    // new hardcoded values cecil added
    if(![self enablePDPMAPDTotalCarePlanAfter15OCT2018] && [[AppConfig enrollYear] isEqualToString:@"2019"]){
        
        [self.pdpButton setChecked:NO];

//         [self errorMessageAlert:@"ALERT" message:@"2019 Medicare Prescription Drug Plan enrollment will start from 10/15/2018"];
        //anitha added
        [AppConfig errorMessageAlert:@"ALERT" message:@"2019 Medicare Prescription Drug Plan enrollment will start from 10/15/2018" class:self];
        
    }else {
        
        
        if([AppConfig planPlistArray].count>1){
            [AppConfig DecrementPlanIndex];
        }
        
    }
    
    [self.advantagePlanButton setChecked:NO];
    if(self.dsnpPlanButton!=nil){
        [self.dsnpPlanButton setChecked:NO];
    }
    [self clearButtonLayerColor];


    
    /*
    //vrl added
    // new code logic based on enable plan After 15 Oct 2018
    if(![self enablePDPMAPDTotalCarePlanAfter15OCT2018] && [[AppConfig enrollYear] isEqualToString:@"2019"]){
        
        [self.pdpButton setChecked:NO];
        [self errorMessageAlert:@"ALERT" message:[self getErrorMessageForPlans:@"PDP" date:@"10/15/2018"]];
        
    }else {
        
        
        if([AppConfig planPlistArray].count>1){
            [AppConfig DecrementPlanIndex];
        }
        
    }
    
    [self.advantagePlanButton setChecked:NO];
    if(self.dsnpPlanButton!=nil){
        [self.dsnpPlanButton setChecked:NO];
    }
    [self clearButtonLayerColor];
     */
    
    /*
      // old code logic  //important don't delete this code
    if([AppConfig planPlistArray].count>1){
        [AppConfig DecrementPlanIndex];
    }
    [self.advantagePlanButton setChecked:NO];
    if(self.dsnpPlanButton!=nil){
        [self.dsnpPlanButton setChecked:NO];
    }
       [self clearButtonLayerColor];
     */

	
}


-(void)advantageLogic {
    

    // hardcoded values added by cecil
    if(![self enablePDPMAPDTotalCarePlanAfter15OCT2018] && [[AppConfig enrollYear] isEqualToString:@"2019"]){
        
        [self.advantagePlanButton setChecked:NO];

//        [self errorMessageAlert:@"ALERT" message:@"2019 Medicare Advantage Plan enrollment will start from 10/15/2018"];
        [AppConfig errorMessageAlert:@"ALERT" message:@"2019 Medicare Prescription Drug Plan enrollment will start from 10/15/2018" class:self];
    }else {
        
        if([AppConfig planPlistArray].count>1){
            [AppConfig DecrementPlanIndex];
        }
    }
    [self.pdpButton setChecked:NO];
    [self.supplementPlanUnder50Button setChecked:NO];
    [self.supplementPlan50To64Button setChecked:NO];
    [self.supplementPlan65AndOverButton setChecked:NO];
    if(self.dsnpPlanButton!=nil){
        [self.dsnpPlanButton setChecked:NO];
    }
    [self clearButtonLayerColor];
  
    
    
    /*
	
    // new code logic based on enable plan After 15 Oct 2018
    if(![self enablePDPMAPDTotalCarePlanAfter15OCT2018] && [[AppConfig enrollYear] isEqualToString:@"2019"]){
        
        [self.advantagePlanButton setChecked:NO];
        [self errorMessageAlert:@"ALERT" message:[self getErrorMessageForPlans:@"MAPD" date:@"10/15/2018"]];
    }else {
        
        if([AppConfig planPlistArray].count>1){
            [AppConfig DecrementPlanIndex];
        }
    }
    
    [self.pdpButton setChecked:NO];
    [self.supplementPlanUnder50Button setChecked:NO];
    [self.supplementPlan50To64Button setChecked:NO];
    [self.supplementPlan65AndOverButton setChecked:NO];
    if(self.dsnpPlanButton!=nil){
        [self.dsnpPlanButton setChecked:NO];
    }
    [self clearButtonLayerColor];
    */
    
    
    /*
    // old code logic //don't delete this code
    if([AppConfig planPlistArray].count>1){
        [AppConfig DecrementPlanIndex];
    }

    [self.pdpButton setChecked:NO];
    [self.supplementPlanUnder50Button setChecked:NO];
    [self.supplementPlan50To64Button setChecked:NO];
    [self.supplementPlan65AndOverButton setChecked:NO];
    if(self.dsnpPlanButton!=nil){
        [self.dsnpPlanButton setChecked:NO];
    }
    [self clearButtonLayerColor];
     */
  
	
}


-(void)dsnpLogic{
    
 
    // hardcoded values added by cecil
    if(![self enablePDPMAPDTotalCarePlanAfter15OCT2018] && [[AppConfig enrollYear] isEqualToString:@"2019"]){
        
        [self.dsnpPlanButton setChecked:NO];

//        [self errorMessageAlert:@"ALERT" message:@"2019 TotalCare Plan enrollment will start from 10/15/2018"];
        [AppConfig errorMessageAlert:@"ALERT" message:@"2019 TotalCare Plan enrollment will start from 10/15/2018" class:self];
        
    }else{
        
        if([AppConfig planPlistArray].count>1){
            [AppConfig DecrementPlanIndex];
        }
    }
    [self.pdpButton setChecked:NO];
    [self.advantagePlanButton setChecked:NO];
    [self.supplementPlanUnder50Button setChecked:NO];
    [self.supplementPlan50To64Button setChecked:NO];
    [self.supplementPlan65AndOverButton setChecked:NO];
    [self clearButtonLayerColor];

    

    /*
    // new code logic based on enable plan After 15 Oct 2018
    if(![self enablePDPMAPDTotalCarePlanAfter15OCT2018] && [[AppConfig enrollYear] isEqualToString:@"2019"]){
        
        [self.dsnpPlanButton setChecked:NO];
        [self errorMessageAlert:@"ALERT" message:[self getErrorMessageForPlans:@"TotalCare" date:@"10/15/2018"]];
        
    }else{
        
        if([AppConfig planPlistArray].count>1){
            [AppConfig DecrementPlanIndex];
        }
    }
    
    [self.pdpButton setChecked:NO];
    [self.advantagePlanButton setChecked:NO];
    [self.supplementPlanUnder50Button setChecked:NO];
    [self.supplementPlan50To64Button setChecked:NO];
    [self.supplementPlan65AndOverButton setChecked:NO];
    [self clearButtonLayerColor];
     */
    

    /*
     // old logic //don't delete this code
     if([AppConfig planPlistArray].count>1){
     [AppConfig DecrementPlanIndex];
     }
     [self.pdpButton setChecked:NO];
     [self.advantagePlanButton setChecked:NO];
     [self.supplementPlanUnder50Button setChecked:NO];
     [self.supplementPlan50To64Button setChecked:NO];
     [self.supplementPlan65AndOverButton setChecked:NO];
     [self clearButtonLayerColor];
    */
  

}

-(void)supplementUnder50Logic {
    
    
    // new code logic based on enable added by cecil
    if(![self enableMedigapPlanAfter1oct2018] && [[AppConfig enrollYear] isEqualToString:@"2019"]){
        [self.supplementPlanUnder50Button setChecked:NO];
//        [self errorMessageAlert:@"ALERT" message:@"2019 Supplement Plan enrollment will start from 10/15/2018"];
        [AppConfig errorMessageAlert:@"ALERT" message:@"2019 Supplement Plan enrollment will start from 10/15/2018" class:self];
    }
    
    
    // new code logic based on enable plan After 1st Oct 2018
//    if(![self enableMedigapPlanAfter1oct2018] && [[AppConfig enrollYear] isEqualToString:@"2019"]){
//        [self.supplementPlanUnder50Button setChecked:NO];
//        [self errorMessageAlert:@"ALERT" message:[self getErrorMessageForPlans:@"SupplementUnder50" date:@"10/1/2018"]];
//    }
	
    //old code //don't delete this code
    [self.advantagePlanButton setChecked:NO];
    [self.supplementPlan50To64Button setChecked:NO];
    [self.supplementPlan65AndOverButton setChecked:NO];
    if(self.dsnpPlanButton!=nil){
        [self.dsnpPlanButton setChecked:NO];
    }
    [self clearButtonLayerColor];
}


-(void)supplementUnder50To64Logic {
    
    // new code logic based on enable added by cecil
    if(![self enableMedigapPlanAfter1oct2018] && [[AppConfig enrollYear] isEqualToString:@"2019"]){
            [self.supplementPlan50To64Button setChecked:NO];
//            [self errorMessageAlert:@"ALERT" message:@"2019 Supplement Plan enrollment will start from 10/15/2018"];
        [AppConfig errorMessageAlert:@"ALERT" message:@"2019 Supplement Plan enrollment will start from 10/15/2018" class:self];
    }

    // new code logic based on enable plan After 1st Oct 2018
//    if(![self enableMedigapPlanAfter1oct2018] && [[AppConfig enrollYear] isEqualToString:@"2019"]){
//        [self.supplementPlan50To64Button setChecked:NO];
//        [self errorMessageAlert:@"ALERT" message:[self getErrorMessageForPlans:@"Supplement Plan 50-64" date:@"10/1/2018"]];
//    }
    
    //old code //don't delete this code
    [self.advantagePlanButton setChecked:NO];
    [self.supplementPlanUnder50Button setChecked:NO];
    [self.supplementPlan65AndOverButton setChecked:NO];
    if(self.dsnpPlanButton!=nil){
        [self.dsnpPlanButton setChecked:NO];
    }
    [self clearButtonLayerColor];
}

-(void)supplementPlan65AndOverLogic {
    
    // new code logic based on enable added by cecil
    if(![self enableMedigapPlanAfter1oct2018] && [[AppConfig enrollYear] isEqualToString:@"2019"]){
            [self.supplementPlan65AndOverButton setChecked:NO];
//            [self errorMessageAlert:@"ALERT" message:@"2019 Supplement Plan enrollment will start from 10/15/2018"];
        [AppConfig errorMessageAlert:@"ALERT" message:@"2019 Supplement Plan enrollment will start from 10/15/2018" class:self];
    }

    // new code logic based on enable plan After 1st Oct 2018
//    if(![self enableMedigapPlanAfter1oct2018] && [[AppConfig enrollYear] isEqualToString:@"2019"]){
//        [self.supplementPlan65AndOverButton setChecked:NO];
//        [self errorMessageAlert:@"ALERT" message:[self getErrorMessageForPlans:@"Supplement Plan 65 and over" date:@"10/1/2018"]];
//    }
    
    //old code //don't delete this code
    [self.advantagePlanButton setChecked:NO];
    [self.supplementPlanUnder50Button setChecked:NO];
    [self.supplementPlan50To64Button setChecked:NO];
    if(self.dsnpPlanButton!=nil){
        [self.dsnpPlanButton setChecked:NO];
    }
    [self clearButtonLayerColor];
}





- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




-(void)addMedicarePlanDescription{
	
    
    if([[AppConfig planPlistArray]count]==0){
        
        [self addInitialPlanEntry];
        
    }else if([[AppConfig planPlistArray]count]==1){
        [self addPlanEntryAtIndexFirst];
    }else if([[AppConfig planPlistArray]count]==2) {
        // if two plans added,reset planlistArray & json data
        [self addTwoPlanEntryAtIndex];
    }else {
        [AppConfig resetPlanListArray];
        [self addInitialPlanEntry];
    }
    
}

-(void)addInitialPlanEntry {
    
    if ([pdpButton ischecked]) {
        
        [AppConfig setEnrollmentFormArray:@"1"];
        if(![[AppConfig planPlistArray]containsObject:@"PDP"]){
            [AppConfig addPlans:@"PDP"];
            [AppConfig loadJSONPlist:@"PDP"];
        }
        [AppConfig loadPlanPlistDict];
        [AppConfig loadProgressInfo];
        [UINavigationHelper addPDPScreens];
        
    }
    
    if ([advantagePlanButton ischecked]){
        
        [AppConfig setEnrollmentFormArray:@"2"];
        
        if(![[AppConfig planPlistArray]containsObject:@"MAPD"]){
            [AppConfig addPlans:@"MAPD"];
            [AppConfig loadJSONPlist:@"MAPD"];
        }
        [AppConfig loadPlanPlistDict];
        [AppConfig loadProgressInfo];
        [UINavigationHelper addMAPDScreens];
        
    }
    
    if ([dsnpPlanButton ischecked]) {
        
        if(![[AppConfig planPlistArray]containsObject:@"DSNP"]){
            [AppConfig addPlans:@"DSNP"];
            [AppConfig loadJSONPlist:@"DSNP"];
        }
        [AppConfig loadPlanPlistDict];
        [AppConfig loadProgressInfo];
        [UINavigationHelper addDSNPScreens];
        
    }
    
    if ([supplementPlanUnder50Button ischecked]) {
        
        
        [AppConfig setEnrollmentFormArray:@"3"];
        [pdpButton setChecked:NO];
        
        [advantagePlanButton setChecked:NO];
        
        if(![[AppConfig planPlistArray]containsObject:@"SupplementUnder50"]){
            [AppConfig addPlans:@"SupplementUnder50"];
            [AppConfig loadJSONPlist:@"SupplementUnder50"];
        }
        
        
        if([AppConfig planPlistArray].count <=1){
            [AppConfig loadPlanPlistDict];
            [AppConfig loadProgressInfo];
        }
        
        [UINavigationHelper addSupplementScreens];
    }
    
    if ([supplementPlan50To64Button ischecked]) {
        
        [AppConfig setEnrollmentFormArray:@"4"];
        [pdpButton setChecked:NO];
        
        [advantagePlanButton setChecked:NO];
        
        if(![[AppConfig planPlistArray]containsObject:@"Supplement Plan 50-64"]){
            [AppConfig addPlans:@"Supplement Plan 50-64"];
            [AppConfig loadJSONPlist:@"Supplement Plan 50-64"];
        }
        

        if([AppConfig planPlistArray].count <=1){
            [AppConfig loadPlanPlistDict];
            [AppConfig loadProgressInfo];
        }
        
        [UINavigationHelper addSupplementScreens];
        
    }
    
    if ([supplementPlan65AndOverButton ischecked]) {
        
        [AppConfig setEnrollmentFormArray:@"5"];
        [pdpButton setChecked:NO];
        
        [advantagePlanButton setChecked:NO];
        
        if(![[AppConfig planPlistArray]containsObject:@"Supplement Plan 65 and over"]){
            [AppConfig addPlans:@"Supplement Plan 65 and over"];
            [AppConfig loadJSONPlist:@"Supplement Plan 65 and over"];
            
        }
        
       
        if([AppConfig planPlistArray].count <=1){
            [AppConfig loadPlanPlistDict];
            [AppConfig loadProgressInfo];
        }
        
        [UINavigationHelper addSupplementScreens];
        
    }
    
}


-(id)getPlanSelected:(NSString *)planName {
    
    if([planName isEqualToString:@"PDP"]){
        return pdpButton;
        
    }else if([planName isEqualToString:@"MAPD"]){
        return advantagePlanButton;
        
    }else if([planName isEqualToString:@"DSNP"]){
        
         return dsnpPlanButton;
        
    }else if([planName isEqualToString:@"SupplementUnder50"]){
          return supplementPlanUnder50Button;
        
        
    }else if([planName isEqualToString:@"Supplement Plan 50-64"]){
         return supplementPlan50To64Button;
        
    }else if([planName isEqualToString:@"Supplement Plan 65 and over"]){
          return supplementPlan65AndOverButton;
        
    }else {
        return nil;
        
    }
    
}

-(void)addPlanEntryAtIndexFirst {
    
    NSString *planName = [[AppConfig planPlistArray]objectAtIndex:0];

    
    
    if([planName containsString:@"Supplement"] && pdpButton.ischecked){
            
            [AppConfig insertPlan:@"PDP" index:0];
            [AppConfig loadJSONPlist:@"PDP"];
            
            NSString *secondPlan = [[AppConfig planPlistArray]objectAtIndex:1];
        
            
            if(![[self getPlanSelected:secondPlan]ischecked]){
                PRINTLOG(@"not selected");
                [AppConfig removeRequestJSONDictionary:secondPlan];
                [AppConfig removeTempSONDictionary:secondPlan];
                [[AppConfig planPlistArray]removeObjectAtIndex:1];
                [AppConfig setcounty:@""];
                [AppConfig setCountyZipcode:@""];
                [self addInitialPlanEntry];
            }else {
                [self addInitialPlanEntry];
            }
        
    }else if(![[self getPlanSelected:planName]ischecked]){
        PRINTLOG(@"not selected");
        
        [AppConfig removeRequestJSONDictionary:planName];
        [AppConfig removeTempSONDictionary:planName];
        [[AppConfig planPlistArray]removeObjectAtIndex:0];
        [AppConfig setcounty:@""];
        [AppConfig setCountyZipcode:@""];
        
        [self addInitialPlanEntry];
    }else {
        PRINTLOG(@"selected");
        [self addInitialPlanEntry];
    }
}

-(void)addTwoPlanEntryAtIndex{
    
    NSString *firstPlan = [[AppConfig planPlistArray]objectAtIndex:0];

    
    NSString *secondPlan = [[AppConfig planPlistArray]objectAtIndex:1];

    
   
    
    if(![[self getPlanSelected:@"PDP"]ischecked]){
        
        [AppConfig resetPlanListArray];
        [self addInitialPlanEntry];
        
    }else {
        
        if(![[self getPlanSelected:secondPlan]ischecked]){
            PRINTLOG(@"not selected");
            [AppConfig removeRequestJSONDictionary:secondPlan];
            [AppConfig removeTempSONDictionary:secondPlan];
            [[AppConfig planPlistArray]removeObjectAtIndex:1];
            [AppConfig setcounty:@""];
            [AppConfig setCountyZipcode:@""];
            [self addInitialPlanEntry];
            
        }else {
            PRINTLOG(@"selected");
            [self addInitialPlanEntry];
        }
        
    }
   
    
    
}

-(BOOL)validateVC
{
    
    
	[self buttonLayerBorderWidth];
    
	if([pdpButton ischecked]||[advantagePlanButton ischecked]||[supplementPlanUnder50Button ischecked]||[supplementPlan50To64Button ischecked]||[supplementPlan65AndOverButton ischecked]||[dsnpPlanButton ischecked]){
        
        pdpButton.layer.borderColor = [UIColor clearColor].CGColor;
        advantagePlanButton.layer.borderColor = [UIColor clearColor].CGColor;
        supplementPlanUnder50Button.layer.borderColor = [UIColor clearColor].CGColor;
        supplementPlan50To64Button.layer.borderColor = [UIColor clearColor].CGColor;
        supplementPlan65AndOverButton.layer.borderColor = [UIColor clearColor].CGColor;
        dsnpPlanButton.layer.borderColor = [UIColor clearColor].CGColor;
		SubTitle.textColor = [UIColor colorWithRed:(153.0/255.0) green:(153.0/255.0) blue:(153.0/255.0) alpha:1.0f];
		return NO;
	}else {
        
        pdpButton.layer.borderColor = [UIColor colorWithRed:(240.0/255.0) green:(108.0/255.0) blue:(108.0/255.0) alpha:1.0f].CGColor;
        advantagePlanButton.layer.borderColor =[UIColor colorWithRed:(240.0/255.0) green:(108.0/255.0) blue:(108.0/255.0) alpha:1.0f].CGColor;
        supplementPlanUnder50Button.layer.borderColor = [UIColor colorWithRed:(240.0/255.0) green:(108.0/255.0) blue:(108.0/255.0) alpha:1.0f].CGColor;
        supplementPlan50To64Button.layer.borderColor = [UIColor colorWithRed:(240.0/255.0) green:(108.0/255.0) blue:(108.0/255.0) alpha:1.0f].CGColor;
        supplementPlan65AndOverButton.layer.borderColor = [UIColor colorWithRed:(240.0/255.0) green:(108.0/255.0) blue:(108.0/255.0) alpha:1.0f].CGColor;
        dsnpPlanButton.layer.borderColor = [UIColor colorWithRed:(240.0/255.0) green:(108.0/255.0) blue:(108.0/255.0) alpha:1.0f].CGColor;
        SubTitle.textColor = [UIColor colorWithRed:(240.0/255.0) green:(108.0/255.0) blue:(108.0/255.0) alpha:1.0f];
		return YES;
	}
}



-(void)clearButtonLayerColor {
    
    pdpButton.layer.borderColor = [UIColor clearColor].CGColor;
    advantagePlanButton.layer.borderColor = [UIColor clearColor].CGColor;
    supplementPlanUnder50Button.layer.borderColor = [UIColor clearColor].CGColor;
    supplementPlan50To64Button.layer.borderColor = [UIColor clearColor].CGColor;
    supplementPlan65AndOverButton.layer.borderColor = [UIColor clearColor].CGColor;
    dsnpPlanButton.layer.borderColor = [UIColor clearColor].CGColor;
    [self buttonLayerBorderWidth];
    
}

-(void)buttonLayerBorderWidth {
    
    pdpButton.layer.borderWidth = 1.0f;
    advantagePlanButton.layer.borderWidth = 1.0f;
    supplementPlanUnder50Button.layer.borderWidth = 1.0f;
    supplementPlan50To64Button.layer.borderWidth = 1.0f;
    supplementPlan65AndOverButton.layer.borderWidth = 1.0f;
    dsnpPlanButton.layer.borderWidth = 1.0f;
    
}

// we waiting for clarification from client side then we enable this method
 // Logic method for Enable / Disable Medigap Plans based on Date 2019 year
-(BOOL)logicForEnableMedigap2019 {
    
    
    // enable 2019 Medigap plan restriction before october 15th
    
    
    // Logic workFlow Statement
    /*
    2019 Medigap Go Live could be delayed. So, I wanted to know following:
     
   Can disable all MEDIGAP (<50, 50-64, 65+) and have all other plan enabled for 2019 from 10/15/2019 onwards?
    What is the effort needed to implement this?
     
    Looks like 2019 MEDIGAP (<50, 50-64, 65+) has to be available from 10/1/2019
    Can we have 2019 MEDIGAP (<50, 50-64, 65+) enrollment enabled from 10/1/2019 and all other plan categories (2019 MAPD/PDP/DSNP) from 10/15/2019?
    What is the effort needed to implement this?
     */
    
    
    
 // logic for showing alert for year restriction
     BOOL value;
     NSDate *currentDate = [NSDate date];
    
    // Disable Medigap Plans from 10/15/2019
     NSDateComponents *octDateComps = [[NSDateComponents alloc] init];
     [octDateComps setDay:15];
     [octDateComps setMonth:10];
     [octDateComps setYear:2018];
    
     NSDate *dateOct2018 = [[NSCalendar currentCalendar] dateFromComponents:octDateComps];
    
    // Enable Medigap Plans from 1/10/2019
    NSDateComponents *janDatecomps = [[NSDateComponents alloc] init];
    [janDatecomps setDay:10];
    [janDatecomps setMonth:1];
    [janDatecomps setYear:2019];
    
     NSDate *dateJan2019 = [[NSCalendar currentCalendar] dateFromComponents:janDatecomps];
    
    /* // basic logic code
     if([currentDate compare:dateOct2018] == NSOrderedSame){
         value = NO; // date is same to 10/15/2019 -> Disable medigap
     }else if([currentDate compare:dateOct2018] == NSOrderedAscending){
         value = YES; // date is less than 10/15/2019 -> enable medigap
     }else if([currentDate compare:dateOct2018] == NSOrderedDescending){
         value = NO; // date is greater than 10/15/2019 -> Disable medigap
     }else if([currentDate compare:dateJan2019] == NSOrderedSame) {
         value = YES; // date is same to 1/10/2019 -> Enable medigap
     }else if([currentDate compare:dateJan2019] == NSOrderedAscending){
         value = NO; // date is less than 1/10/2019 -> Disable medigap
     }else if([currentDate compare:dateJan2019] == NSOrderedDescending){
         value = YES; // date is greater than 1/10/2019 -> Enable medigap
     }else {
        value = NO;
     }
     */
    
    // simplified logic code
    if([currentDate compare:dateOct2018] == NSOrderedAscending){
        value = YES; // date is less than 10/15/2019 -> Enable medigap
    }else if([currentDate compare:dateJan2019] == NSOrderedSame) {
        value = YES; // date is same to 1/10/2019 -> Enable medigap
    }else if([currentDate compare:dateJan2019] == NSOrderedDescending){
        value = YES; // date is greater than 1/10/2019 -> Enable medigap
    }else {
        value = NO;
    }
    return value;
    
}

-(BOOL)enableMedigapPlanAfter1oct2018 {
    
    // Enable Medigap Plan from 1st-Oct-2018
    
    // logic for showing alert for year restriction
    BOOL value;
    
    NSDate *currentDate = [NSDate date];
    
    // enable Medigap Plans from 10/1/2018
    NSDateComponents *octDateComps = [[NSDateComponents alloc] init];
    [octDateComps setDay:15];
    [octDateComps setMonth:10];
    [octDateComps setYear:2018];
    
    NSDate *dateOct2018 = [[NSCalendar currentCalendar] dateFromComponents:octDateComps];
    
    // simplified logic code
    if([currentDate compare:dateOct2018] == NSOrderedSame) {
        value = YES; // date is same to 10/1/2018 -> Enable medigap
    }else if([currentDate compare:dateOct2018] == NSOrderedDescending){
        value = YES; // date is greater than 10/1/2018 -> Enable medigap
    }else {
        value = NO;  // -> Disable Medigap
    }
    
    return value;
    
}


-(BOOL)enablePDPMAPDTotalCarePlanAfter15OCT2018 {
    
    // Enable PDP,MAPD,DSNP Plan from 15st-Oct-2018
    
    // logic for showing alert for year restriction
    BOOL value;
    
    NSDate *currentDate = [NSDate date];
    
    // Disable Medigap Plans from 10/15/2018
    NSDateComponents *octDateComps2 = [[NSDateComponents alloc] init];
    [octDateComps2 setDay:15];
    [octDateComps2 setMonth:10];
    [octDateComps2 setYear:2018];
    
    NSDate *date15Oct2018 = [[NSCalendar currentCalendar] dateFromComponents:octDateComps2];
    
    // simplified logic code
    if([currentDate compare:date15Oct2018] == NSOrderedSame) {
        value = YES; // date is same to 10/15/2018 -> Enable medigap
    }else if([currentDate compare:date15Oct2018] == NSOrderedDescending){
        value = YES; // date is greater than 10/15/2018 -> Enable medigap
    }else {
        value = NO;
    }
    return value;
    
}

#pragma mark Alert Message methods


-(NSString *)getErrorMessageForPlans:(NSString *)planName date:(NSString *)dateString {
    
    NSString *planAvailableStr = [LanguageCentral languageSelectedString:@"PLAN_AVAILABLE_FROM"];
    //    NSString *msgString = (localizeMessage.length>0)?localizePlanMsg:message;
    NSString *enrollForString = [LanguageCentral languageSelectedString:@"ENROLLMENTS_FOR"];
    
    return [NSString stringWithFormat:@"%@ %@ %@ %@",enrollForString,planName,planAvailableStr,dateString];
}

//-(void)errorMessageAlert:(NSString *)title message:(NSString *)message {
//
//
//    NSString *localizeTitle = [LanguageCentral languageSelectedString:title];
//    NSString *titleString = (localizeTitle.length>0)?localizeTitle:title;
//
//
//    NSString *localizeMessage = [LanguageCentral languageSelectedString:message];
//    NSString *msgString = (localizeMessage.length>0)?localizeMessage:message;
//
//
//    alertController = nil;
//    alertController = [UIAlertController
//                       alertControllerWithTitle:titleString
//                       message:msgString
//                       preferredStyle:UIAlertControllerStyleAlert];
//
//    alertController.view.tag = 200;
//
//    UIAlertAction *okAction = [UIAlertAction
//                               actionWithTitle:NSLocalizedString(@"OK", @"OK action")
//                               style:UIAlertActionStyleDefault
//                               handler:^(UIAlertAction *action)
//                               {
//                                   PRINTLOG(@"plan OK action");
//                               }];
//
//    [alertController addAction:okAction];
//
//    [self presentViewController:alertController animated:YES completion:nil];
//
//}





/* //dummy codes
 // new code logic based on enable PDP After 15 Oct 2018
 if([self enablePDPMAPDTotalCarePlanAfter15OCT2018]){
 
 if([AppConfig planPlistArray].count>1){
 [AppConfig DecrementPlanIndex];
 }
 
 }else {
 [self.pdpButton setChecked:NO];
 }
 
 [self.advantagePlanButton setChecked:NO];
 if(self.dsnpPlanButton!=nil){
 [self.dsnpPlanButton setChecked:NO];
 }
 [self clearButtonLayerColor];
 */

@end
