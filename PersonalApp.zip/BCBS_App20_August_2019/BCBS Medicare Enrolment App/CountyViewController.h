//
//  CountyViewController.h
//  BCBS Medicare Enrolment App
//
//  Created by CSS Corp on 01/06/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>
#import "ScopeBaseViewController.h"

@interface CountyViewController : UIBaseContainerViewController<UITextFieldDelegate,DropDownDelegate>
@property (strong, nonatomic) IBOutlet UIDropDown *countyView;
@property (strong, nonatomic) IBOutlet UIDropDown *planEnrollView;
@property (strong, nonatomic) IBOutlet UIDropDown *effectiveDateView;
@property (strong, nonatomic) IBOutlet ValidatorLabel *countyLabel;
@property (strong, nonatomic) IBOutlet ValidatorLabel *effectiveDateLabel;

@property (strong, nonatomic) IBOutlet ValidatorLabel *planEnrollLabel;
@property (strong, nonatomic) IBOutlet ValidatorTextField *zipCodeTextField;
@property (strong, nonatomic) IBOutlet ValidatorLabel *titleString;
@property (strong, nonatomic) IBOutlet ValidatorLabel *zipCodeLabel;
@property (strong, nonatomic) IBOutlet ValidatorLabel *planSelectLabel;

@end
