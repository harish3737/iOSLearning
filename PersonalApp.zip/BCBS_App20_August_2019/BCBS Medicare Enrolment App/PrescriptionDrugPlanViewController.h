//
//  PrescriptionDrugPlanViewController.h
//  BCBS Medicare Enrolment App
//
//  Created by CSS Corp on 03/06/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>

@interface PrescriptionDrugPlanViewController : UIBaseContainerViewController
@property (strong, nonatomic) IBOutlet UIDropDown *planEnrolView;
@property (strong, nonatomic) IBOutlet ValidatorLabel *titleString;
@property (strong, nonatomic) IBOutlet UIDropDown *effectiveDateView;
@property (strong, nonatomic) IBOutlet ValidatorLabel *effectiveDateLabel;

@end
