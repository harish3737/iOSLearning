//
//  PersonalFormTableViewCell.h
//  SampleBCBSPOC
//
//  Created by CSS Admin on 5/24/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PersonalFormTableViewCell : UITableViewCell

@end
