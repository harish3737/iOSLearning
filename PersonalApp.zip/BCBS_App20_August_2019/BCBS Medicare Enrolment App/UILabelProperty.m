//
//  UILabelProperty.m
//  BCBS Medicare Enrolment App
//
//  Created by CSS Admin on 7/18/18.
//  Copyright © 2018 CSS Corp. All rights reserved.
//

#import "UILabelProperty.h"

@implementation UILabelProperty



-(instancetype)init {
    
    self = [super init];
    if(self){
    }
    return self;
}

-(void)setFontName:(NSString *)fontName {
    self.fontName = fontName;
}


-(void)setFontSize:(NSString *)fontSize {
    self.fontSize = fontSize;
}
@end
