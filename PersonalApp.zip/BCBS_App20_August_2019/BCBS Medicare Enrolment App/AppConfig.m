//
//  AppConfig.m
//  BCBS Medicare Enrolment App
//
//  Created by CSS Corp on 30/06/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "AppConfig.h"
#import <CSSUIFramwork/CSSUIFramwork.h>
#import "UIImage+animatedGIF.h"


static NSString * enrollYear;
static NSString * countyName;
static NSString *zipcode;
static NSMutableArray *countyArray;
static NSMutableArray *planEnrollArray;
static NSMutableArray *medigapPlanEnrollArray;
static NSMutableArray *medigapEffectiveArray;
static NSMutableArray *planCEffectiveArray;
static NSMutableArray *otherPlanEffectiveArray;

static NSMutableArray * medicarePlanArray;
static NSMutableArray * enrollmentFormArray;
static NSMutableDictionary *reqJSONDictionary;
static NSString * lastUpdatedDate;
static NSString * currentUserName;
static NSMutableArray *planPlistArray;
static NSMutableDictionary *planPlistDict;
static NSMutableArray *titleArray;
static NSMutableDictionary *progressbarDict;
static NSMutableDictionary *loginInfoDict;
static NSMutableDictionary *agentProfileDict;

static NSMutableDictionary *tempJSONDictionary;
static NSMutableDictionary *generalJSONDictionary;

static NSMutableDictionary *medigapMetaDict;

static JsonOperation *jsonOperation;

static NSUInteger currentPlanIndex = 0;
UIView *currentView;
UIImageView *loader;
static BOOL networkStatus;
static BOOL userLoginStatus;

static NSInteger editIndex=-1;

static NSInteger insertIndex=-1;

static BOOL isFromPreviewPage,isCallRateAPI,isAddNoticePage;

static NSMutableDictionary *rateAPIDict;

static NSString *rateAmount;

//BRD2.0
static UIAlertController *alertController;
static UIAlertAction *alertOKAction;
static UIAlertAction *alertCancelAction;
static NSString *birthDateStr;
static BOOL isFromQuestionPageScreen;

static BOOL isTurn65After3Months;
static NSUInteger valueForChange;

//svk added
static BOOL showEffectiveDateDropDowns;

@implementation AppConfig


+(void) testWrapper:(id)url query:(id)operation callback:(id)handler{
    Cache *cache = [[Cache alloc]init];
    [cache setService: [[WebServiceWrapper alloc] init]];
    [cache settimeoutInMin:1.0];
    
    //uncomment when add headers in post method
    [cache registerTask:url :operation :handler :NO_CACHE];
    [cache setHeaders:url  :operation :[AppConfig headerList]];
    [cache execute : url :operation];
}




+(NSString *)enrollYear{
    
    PRINTLOG(@"%@",enrollYear);
    return enrollYear;
}
+(void)setEnrollYear:(NSString *)year{
    
    enrollYear = year;
    PRINTLOG(@"%@",enrollYear);
}


+(NSString *)countyZipcode{
    
    return zipcode;
}


+(void)setCountyZipcode : (NSString *)zipValue{
    
    zipcode = zipValue;
    
}

+(NSMutableArray *)countyArray{
    PRINTLOG(@"countyArray%@",countyArray);
    return countyArray;
    
}
+(void)setCountyArray: (NSMutableArray *)countyValues{
    if(countyArray==nil){
        countyArray = [[NSMutableArray alloc]init];
    }
    countyArray = countyValues;
    PRINTLOG(@"set County%@",countyArray);
}

+(NSMutableArray *)planEnrollArray{
    PRINTLOG(@"planEnrollArray%@",planEnrollArray);
    return planEnrollArray;
    
}
+(void)setPlanEnrollArray: (NSMutableArray *)planArray{
    if(planEnrollArray==nil){
        planEnrollArray = [[NSMutableArray alloc]init];
    }
    planEnrollArray = planArray;
    PRINTLOG(@"set planEnroll%@",planEnrollArray);
}

+(NSMutableArray *)medigapPlanEnrollArray{
    PRINTLOG(@"medigap %@",medigapPlanEnrollArray);
    return medigapPlanEnrollArray;
    
}
+(void)setMedigapPlanEnrollArray: (NSMutableArray *)medigapArray{
    if(medigapPlanEnrollArray==nil){
        medigapPlanEnrollArray = [[NSMutableArray alloc]init];
    }
    medigapPlanEnrollArray = medigapArray;
    PRINTLOG(@"set medigap planEnroll%@",medigapPlanEnrollArray);
}

+(NSMutableArray *)medigapEffectiveArray{
    
    return medigapEffectiveArray;
    
}

+(void)setmedigapEffectiveArray: (NSMutableArray *)dateArray{
    
    if(medigapEffectiveArray==nil){
        medigapEffectiveArray = [[NSMutableArray alloc]init];
    }
    medigapEffectiveArray = dateArray;
}

+(NSMutableArray *) medicarePlanArray{
    
    PRINTLOG(@"%@",medicarePlanArray);
    return medicarePlanArray;
}


+(NSMutableArray *)medigapPlanCEffectiveArray{
    return planCEffectiveArray;
}
+(void)setmedigapPlanCEffectiveArray: (NSMutableArray *)dateArray{
    
    if(planCEffectiveArray==nil){
        planCEffectiveArray = [[NSMutableArray alloc]init];
    }
    planCEffectiveArray = dateArray;
    PRINTLOG(@"Plan C ::%@",otherPlanEffectiveArray);
}

+(NSMutableArray *)medigapOtherPlanEffectiveArray{
    
    return otherPlanEffectiveArray;
}
+(void)setmmedigapOtherPlanEffectiveArray: (NSMutableArray *)dateArray{
    if(otherPlanEffectiveArray==nil){
        otherPlanEffectiveArray = [[NSMutableArray alloc]init];
    }
    otherPlanEffectiveArray = dateArray;
    PRINTLOG(@"other Plan ::%@",otherPlanEffectiveArray);
}


+(NSMutableDictionary *)medigapPlanMetaDict{
    
    
    PRINTLOG(@"GET meta Dict ::%@",medigapMetaDict);
    return medigapMetaDict;
    
}


+(void)setmedigapPlanMetaDict: (NSMutableDictionary *)dateDict{
    
    
    if(medigapMetaDict==nil){
        medigapMetaDict = [[NSMutableDictionary alloc]init];
    }
    
    medigapMetaDict = dateDict;
    
    PRINTLOG(@"SET meta Dict ::%@",medigapMetaDict);
}

+(void)setMedicarePlanArray:(NSString *)planArray{
    
    if(medicarePlanArray==nil){
        medicarePlanArray = [[NSMutableArray alloc]init];
    }
    
    [medicarePlanArray addObject:planArray];
    PRINTLOG(@"%@",medicarePlanArray);
}
+(NSMutableArray *) enrollmentFormArray{
    
    PRINTLOG(@"%@",enrollmentFormArray);
    return enrollmentFormArray;
}

+(void)setEnrollmentFormArray:(NSString *)formArray{
    
    if (enrollmentFormArray==nil) {
        enrollmentFormArray = [[NSMutableArray alloc]init];
    }
    [enrollmentFormArray addObject:formArray];
    PRINTLOG(@"%@",enrollmentFormArray);
}

+(void)resetAppConfig{
    
    zipcode = nil;
    medicarePlanArray = nil;
    enrollmentFormArray =nil;
    [AppConfig setIsTurn65InAfter3monthsFuture: NO];
    [AppConfig stopAnimatingGif];
}


+(void)showLoaderGif{
    
    currentView = [self getBaseMainView];
    
    NSString *filePath = [[NSBundle mainBundle] pathForResource: @"HB-loader-fullsquare-final-notext 3" ofType: @"gif"];
    
    NSData *gifData = [NSData dataWithContentsOfFile: filePath];
    
    
    loader = [[UIImageView alloc]initWithImage:[UIImage animatedImageWithAnimatedGIFData:gifData]];
    loader.frame = CGRectMake(0,0, 59,59);
    loader.clipsToBounds = YES;
    [currentView addSubview:loader];
    loader.translatesAutoresizingMaskIntoConstraints = NO;
    
    [loader addConstraint:[NSLayoutConstraint constraintWithItem:loader attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:0 multiplier:1 constant:59]];
    [loader addConstraint:[NSLayoutConstraint constraintWithItem:loader attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:nil attribute:0 multiplier:1 constant:59]];
    
    [currentView addConstraint:[NSLayoutConstraint constraintWithItem:loader attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:currentView attribute:NSLayoutAttributeCenterY multiplier:1 constant:0]];
    [currentView addConstraint:[NSLayoutConstraint constraintWithItem:loader attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:currentView attribute:NSLayoutAttributeCenterX multiplier:1 constant:0]];
    [currentView addSubview:loader];
    currentView.userInteractionEnabled = NO;
    
}


+(void) stopAnimatingGif{
    
    if(loader!=nil){
        [loader removeFromSuperview];
    }
    currentView.userInteractionEnabled = YES;
}

+(NSString *) lastUpdated {
    return @"last_updated";
}
+(NSString *) lastUpdatedDate {
    
    return lastUpdatedDate;
}
+(void)setLastUpdatedDate:(NSString *)updatedDate{
    PRINTLOG(@" App COnfig %@", updatedDate);
    lastUpdatedDate = updatedDate;
    
}


+(void)setNetworkStatus:(BOOL)isNetwork {
    
    networkStatus = isNetwork;
    
}
+(BOOL)getNetworkStatus{
    return networkStatus;
    
}


+(void)setUserLoggedIn:(BOOL)login {
    
    userLoginStatus = login;
    
}
+(BOOL)getUserLoginStatus{
    return userLoginStatus;
    
}



+(void)setUserName:(NSString*)userName
{
    currentUserName = userName;
}
+(NSString*)getUserName
{
    return  currentUserName;
}

+(UIScrollView *)getBaseScrollView{
    
    
    id baseVC= [UIApplication sharedApplication].keyWindow.rootViewController;
    
    if([baseVC isKindOfClass:[UINavigationController class]]){
        
        PRINTLOG(@"visible ::%@",[baseVC visibleViewController]);
        
        
        UIViewController *visibleViewcontroller = [baseVC visibleViewController];
        
        for (id subview in visibleViewcontroller.view.subviews){
            
            if([subview isKindOfClass:[UIScrollView class]]){
                PRINTLOG(@"scrollView ::%@",subview);
                
                return subview;
            }
        }
        
    }
    
    return nil;
    
}

+(UIView *)getBaseMainView {
    
    id baseVC= [UIApplication sharedApplication].keyWindow.rootViewController;
    if([baseVC isKindOfClass:[UINavigationController class]]){
        
        PRINTLOG(@"visible ::%@",[baseVC visibleViewController]);
        
        UIViewController *visibleViewcontroller = [baseVC visibleViewController];
        PRINTLOG(@"BaseMainView ::%@",visibleViewcontroller.view);
        return visibleViewcontroller.view;
    }else{
        return nil;
    }
    
}


+(void)addPlans:(NSString *)currentPlan{
    
    if (planPlistArray==nil) {
        planPlistArray = [[NSMutableArray alloc]init];
    }
    [planPlistArray addObject:currentPlan];
    PRINTLOG(@"add plan plist ::%@",planPlistArray);
    if([[self planPlistArray]count]>1)
    {
        valueForChange = 12;
    }
    else
    {
        valueForChange = 0;
    }
}

+(void)insertPlan:(NSString *)planName index:(NSUInteger)index{
    
    
    [planPlistArray insertObject:planName atIndex:index];
    PRINTLOG(@"After Index ::%@",planPlistArray);
}


+(void)removePlans:(NSString *)currentPlan{
    
    if(planPlistArray.count>0){
        [planPlistArray removeObject:currentPlan];
    }
    
    PRINTLOG(@"remove plan plist ::%@",planPlistArray);
}

+(void)clearAllPlans{
    
    [planPlistArray removeAllObjects];
    PRINTLOG(@"clear plan plist ::%@",planPlistArray);
}

+(void)deletePlans{
    
    if(currentPlanIndex==0){
        [planPlistArray removeObjectAtIndex:currentPlanIndex];
    }else {
        [planPlistArray removeObjectAtIndex:--currentPlanIndex];
    }
    
}

+(void)IncrementPlanIndex {
    
    ++currentPlanIndex;
    PRINTLOG(@"Current Plan string ::%@",[planPlistArray objectAtIndex:currentPlanIndex]);
    [self loadPlanPlistDict];
    
}

+(void)DecrementPlanIndex{
    if(currentPlanIndex>0){
        --currentPlanIndex;
    }
    
    PRINTLOG(@"Current Plan string ::%@",[planPlistArray objectAtIndex:currentPlanIndex]);
    [self loadPlanPlistDict];
}

+(NSString *)currentPlan{
    if(currentPlanIndex>0){
        PRINTLOG(@"Current Plan string ::%@",[planPlistArray objectAtIndex:currentPlanIndex]);
        return [planPlistArray objectAtIndex:currentPlanIndex];
    }else {
        PRINTLOG(@"Current Plan string ::%@",[planPlistArray objectAtIndex:currentPlanIndex]);
        return [planPlistArray objectAtIndex:0];
    }
    
    
}

+(NSMutableArray *)planPlistArray{
    
    return planPlistArray;
}


+(NSMutableDictionary *)currentPlanDictionary{
    return planPlistDict;
}

+(void)setRequestJSONDictionary:(id)jsonDictionary {
    
    //    reqJSONDictionary = jsonDictionary;
    [reqJSONDictionary setObject:jsonDictionary forKey:[AppConfig currentPlan]];
}

+(void)removeRequestJSONDictionary:(NSString *)planName {
    
    [reqJSONDictionary removeObjectForKey:planName];
    PRINTLOG(@"After remove JSON ::%@",reqJSONDictionary);
    
}
+(NSMutableDictionary *)getPlanJSONDictionaries {
    
    return reqJSONDictionary;
}


+(NSMutableDictionary *)currentPlanJSONDictionary {
    
    PRINTLOG(@"curent plan JSON ::%@",[AppConfig currentPlan]);
    return [reqJSONDictionary objectForKey:[AppConfig currentPlan]];
}


+(void)setTempJSONDictionary:(id)jsonDictionary {
    
    [tempJSONDictionary setObject:jsonDictionary forKey:[AppConfig currentPlan]];
}

+(void)removeTempSONDictionary:(NSString *)planName {
    
    [tempJSONDictionary removeObjectForKey:planName];
    PRINTLOG(@"After remove temp JSON ::%@",reqJSONDictionary);
    
}

+(NSMutableDictionary *)tempCurrentPlanJSONDictionary {
    
    PRINTLOG(@"TEMP JSON ::%@",reqJSONDictionary);
    
    return [tempJSONDictionary objectForKey:[AppConfig currentPlan]];
}

+(void)setGeneralJSONDictioanry:(id)jsonDict{
    
    [generalJSONDictionary setObject:jsonDict forKey:@"general"];
}

+(NSMutableDictionary *)generalJSONDictionary{
    
    return [generalJSONDictionary objectForKey:@"general"];
}

+(void)loadGeneralJSONPlist{
    NSString *planJSONString = [NSString  stringWithFormat:@"general"];
    PRINTLOG(@"Plan JSON String ::%@",planJSONString);
    
    NSString *path = [[NSBundle mainBundle] pathForResource:planJSONString ofType:@"plist"];
    
    if(generalJSONDictionary==nil){
        generalJSONDictionary = [[NSMutableDictionary alloc]init];
    }
    
    [generalJSONDictionary setObject: [[NSMutableDictionary alloc] initWithContentsOfFile:path] forKey:@"general"];
    
    PRINTLOG(@"load JSON ::%@",generalJSONDictionary);
    
    
}

+(void)loadJSONPlist:(NSString *)plan{
    
    NSString *planJSONString;

//    svk change 03/08
    
//    if(([plan isEqualToString:@"PDP"]||[plan isEqualToString:@"MAPD"]||[plan isEqualToString:@"DSNP"]||[plan isEqualToString:@"Supplement Plan 65 and over"]) && ([[AppConfig enrollYear]isEqualToString:@"2019"] || [[AppConfig enrollYear]isEqualToString:@"2020"])){
        planJSONString = [NSString  stringWithFormat:@"%@%@_enroll",plan,[AppConfig enrollYear]];
        
        
        
//    }else {
//        planJSONString = [NSString  stringWithFormat:@"%@_enroll",plan];
//    }
    GENERATEJSONPLIST_NAME(planJSONString);
    
    PRINTLOG(@"Plan JSON String ::%@",planJSONString);
    NSString *path = [[NSBundle mainBundle] pathForResource:planJSONString ofType:@"plist"];
    
    if(reqJSONDictionary==nil){
        reqJSONDictionary = [[NSMutableDictionary alloc]init];
    }
    if(tempJSONDictionary==nil){
        tempJSONDictionary = [[NSMutableDictionary alloc]init];
    }
    [reqJSONDictionary setObject: [[NSMutableDictionary alloc] initWithContentsOfFile:path] forKey:plan];
    [tempJSONDictionary setObject: [[NSMutableDictionary alloc] initWithContentsOfFile:path] forKey:plan];
    
    PRINTLOG(@"load JSON ::%@",reqJSONDictionary);
    
}

+(void)loadPlanPlistDict {
    
    //vrl new code for DSNP new attestation 2019 , see below code also
    NSString *plistFileName;
    if([[self currentPlan] isEqualToString:@"DSNP"] && ([[self enrollYear] isEqualToString:@"2019"] ||[[self enrollYear] isEqualToString:@"2020"])) {
        plistFileName = [NSString stringWithFormat:@"%@%@.plist",[self currentPlan],[self enrollYear]];
    }else {
        plistFileName = [NSString stringWithFormat:@"%@.plist",[self currentPlan]];
    }
    PRINTLOG(@"Plist Name :::%@",plistFileName);
    
    //original code
    //    NSString *plistFileName = [NSString stringWithFormat:@"%@.plist",[self currentPlan]];
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask,YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *path = [documentsDirectory stringByAppendingPathComponent:plistFileName];
    
    if(![[NSFileManager defaultManager] fileExistsAtPath:path]){
        
        //        //vrl new code for DSNP new attestation
        if([[self currentPlan] isEqualToString:@"DSNP"] && ([[self enrollYear] isEqualToString:@"2019"] || [[self enrollYear] isEqualToString:@"2020"])) {
            path = [[NSBundle mainBundle]pathForResource:[NSString stringWithFormat:@"%@%@",[self currentPlan],[self enrollYear]] ofType:@"plist"];
        }else {
            path = [[NSBundle mainBundle]pathForResource:[self currentPlan] ofType:@"plist"];
        }
        
        //original code
        //        path = [[NSBundle mainBundle]pathForResource:[self currentPlan] ofType:@"plist"];
    }
    
    planPlistDict =  [[NSMutableDictionary alloc]initWithContentsOfFile:path];
    
}


+(NSString *)languageString{
    
    if([[LanguageCentral internalizeString]isEqualToString:@"es"]){
        return @"Spanish";
    }else {
        return @"English";
    }
    
}


+(NSMutableArray *)progressTitleArray {
    
    titleArray = [[AppConfig currentPlanDictionary]objectForKey:@"ProgressLabelArray"];
    
    if(titleArray.count >0){
        
    }else {
        //        titleArray =[NSMutableArray arrayWithObjects:@"SCOPE",@"PERSONAL",@"BILLING",@"HEALTH",@"ATTESTATION",@"AUTHORIZATION",@"COMPLETE",nil];
        titleArray =[NSMutableArray arrayWithObjects:@"PERSONAL",@"BILLING",@"HEALTH",@"ATTESTATION",@"AUTHORIZATION",@"COMPLETE",nil];
    }
    return titleArray;
}


+(NSMutableDictionary *)progressBarInfoDict{
    
    progressbarDict  = [[AppConfig currentPlanDictionary]objectForKey:@"ProgressBarInfo"];
    
    if(progressbarDict!=nil){
        
    }else {
        
        progressbarDict = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"90",@"PortraitWidth",@"133",@"LandscapeWidth",@"non-selected-line",@"non-selected-line",@"selected-line",@"selected-line",nil];
    }
    PRINTLOG(@"ProgressBarInfo ::%@",progressbarDict);
    return progressbarDict;
    
}

+(void)loadProgressInfo {
    
    titleArray = [[AppConfig currentPlanDictionary]objectForKey:@"ProgressLabelArray"];
    
    progressbarDict  = [[AppConfig currentPlanDictionary]objectForKey:@"ProgressBarInfo"];
    
    
    
}




+(void)setUserLoginInfo:(NSMutableDictionary *)loginInfo {
    
    loginInfoDict = loginInfo;
    
}

+(NSMutableDictionary *)userInfoData{
    
    return loginInfoDict;
}

+(void)setAgentProfileInfo:(NSMutableDictionary *)agentInfo{
    
    agentProfileDict = agentInfo;
}

+(NSMutableDictionary *)agentProfileInfo{
    PRINTLOG(@"Agent profile ::%@",agentProfileDict);
    return agentProfileDict;
    
}

+(NSMutableDictionary *)headerList{
    
    if([loginInfoDict objectForKey:@"sessid"]!=nil){
        
        NSString *cookieString = [NSString stringWithFormat:@"%@=%@",[loginInfoDict objectForKey:@"session_name"],[loginInfoDict objectForKey:@"sessid"]];
        
        PRINTLOG(@"header cookie ::%@",[NSMutableDictionary dictionaryWithObjectsAndKeys:cookieString,@"Cookie",[loginInfoDict objectForKey:@"token"],@"X-csrf-token",nil]);
        
        return [NSMutableDictionary dictionaryWithObjectsAndKeys:cookieString,@"Cookie",[loginInfoDict objectForKey:@"token"],@"X-csrf-token",nil];
    }else {
        return nil;
    }
    
}

+(NSString *) county{
    PRINTLOG(@"%@",countyName);
    return countyName;
    
}
+(void)setcounty:(NSString *)countyString{
    
    countyName = countyString;
    PRINTLOG(@"Set County :%@",countyName);
}


+(void)fillJSONDictionary :(NSString *)xPath value:(id)value{
    
    if(jsonOperation==nil){
        jsonOperation = [[JsonOperation alloc]init];
    }
    [AppConfig setRequestJSONDictionary:[jsonOperation setValue:[AppConfig currentPlanJSONDictionary] :xPath :value]];
    
}

+(NSString *)getValueFromXpath:(NSDictionary *)requestDict :(NSString *)xPath{
    
    NSDictionary *tmpDict = requestDict;
    NSMutableArray *keysArray = [NSMutableArray arrayWithArray:[xPath componentsSeparatedByString:@":"]];
    
    if([keysArray containsObject:@"tempJSON"]){
        [keysArray removeObjectAtIndex:0];
    }
    
    for(int iteration=0; iteration<[keysArray count]-1; iteration++)
    {
        tmpDict = [tmpDict objectForKey:[keysArray objectAtIndex:iteration]];
    }
    
    PRINTLOG(@"getXpathValue ::%@",[tmpDict valueForKey:[keysArray objectAtIndex:[keysArray count]-1]]);
    return [tmpDict valueForKey:[keysArray objectAtIndex:[keysArray count]-1]];
    
}

+(void)removeXpathFromJSONDictionary:(NSString *)xPath{
    
    NSMutableDictionary *tmpDict = [AppConfig currentPlanJSONDictionary];
    NSArray *keysArray = [xPath componentsSeparatedByString:@":"];
    
    for(int iteration=0; iteration<[keysArray count]-1; iteration++)
    {
        tmpDict = [tmpDict objectForKey:[keysArray objectAtIndex:iteration]];
    }
    [tmpDict removeObjectForKey:[keysArray objectAtIndex:[keysArray count]-1]];
    
    NSMutableDictionary *currentDictTest = [AppConfig currentPlanJSONDictionary];
    
    currentDictTest = [currentDictTest objectForKey:[keysArray objectAtIndex:0]];
    [currentDictTest removeObjectForKey:[keysArray objectAtIndex:[keysArray count]-2]];
    
    [currentDictTest setObject:tmpDict forKey:[keysArray objectAtIndex:[keysArray count]-2]];
    PRINTLOG(@"after remove XPATH ::%@",currentDictTest);
    
    [reqJSONDictionary setObject:currentDictTest forKey:[keysArray objectAtIndex:0]];
    
}


+(NSMutableArray *)ErrorResponseJSONSerialization:(id)response {
    
    NSError *jsonError;
    NSData *objectData = [response dataUsingEncoding:NSUTF8StringEncoding];
    NSMutableArray *jsonData = [NSJSONSerialization JSONObjectWithData:objectData
                                                               options:NSJSONReadingMutableContainers error:&jsonError];
    
    PRINTLOG(@"Error msg ::%@",jsonData);
    
    return jsonData;
    
}

+(UIFont *)boldFontWithFont:(UIFont *)font size:(CGFloat)sizeValue
{
    UIFontDescriptor * fontD = [font.fontDescriptor
                                fontDescriptorWithSymbolicTraits:UIFontDescriptorTraitBold];
    return [UIFont fontWithDescriptor:fontD size:sizeValue];
}

+(id)setValue :(NSDictionary *)requestDict :(NSString *)xPath : (id)value
{
    NSDictionary *tmpDict = requestDict;
    NSMutableArray *keysArray = [NSMutableArray arrayWithArray:[xPath componentsSeparatedByString:@":"]];
    
    if([keysArray containsObject:@"tempJSON"]){
        [keysArray removeObjectAtIndex:0];
    }
    for(int i=0; i<[keysArray count]-1; i++)
    {
        tmpDict = [tmpDict objectForKey:[keysArray objectAtIndex:i]];
    }
    // trimming space in JSON value
    if([value isKindOfClass:[NSString class]]){
        value = [value stringByTrimmingCharactersInSet:
                 [NSCharacterSet whitespaceCharacterSet]];
    }
    
    [tmpDict setValue:value forKey:[keysArray objectAtIndex:[keysArray count]-1]];
    PRINTLOG(@"App Config::Temp Dict ::%@",tmpDict);
    return requestDict;
}


+(void)populateValue:(NSDictionary *)jsonDict :(id)currentHeadItem{
    
    PRINTLOG(@"populate Xpath ::%@",[currentHeadItem xPath]);
    
    NSString *populateString = [AppConfig getValueFromXpath:jsonDict :[currentHeadItem xPath]];
    
    PRINTLOG(@"populateString ::%@",populateString);
    [currentHeadItem setValueString:populateString];
    
    [currentHeadItem setUserInteractionEnabled:[currentHeadItem isUserInteractionEnabled]];
    
    if([currentHeadItem isKindOfClass:[UIDropDown class]] && populateString.length==0){
        
        PRINTLOG(@"Dropdown titleString ::%@",[currentHeadItem titleString]);
        [currentHeadItem setValueString:[currentHeadItem titleString]];
        
    }
}

+(NSString*)getJsonStringByDictionary:(NSDictionary*)dictionary{
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dictionary
                                                       options:NSJSONWritingPrettyPrinted
                                                         error:&error];
    return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
}


+(void)clearProgressInfo {
    
    [titleArray removeAllObjects];
    [progressbarDict removeAllObjects];
}

+(void)resetPlanListArray{
    
    planPlistArray = nil;
    currentPlanIndex = 0;
    planPlistDict = nil;
    reqJSONDictionary = nil;
    tempJSONDictionary = nil;
    planEnrollArray = nil;
    medigapPlanEnrollArray = nil;
    countyArray = nil;
    
}

+(void)resetGeneralJSONDictionary {
    
    generalJSONDictionary = nil;
    
}

//vrl added
+(NSInteger)editPageIndex {
    
    PRINTLOG(@"GEt Edit Index ::%ld",editIndex);
    return editIndex;
}
+(void)setEditPageIndex:(NSInteger)index;
{
    
    editIndex = index;
    PRINTLOG(@"SEt Edit Index ::%ld",editIndex);
    
    
}

+(void)setInsertPageIndex:(NSInteger)index {
    
    
    insertIndex = index;
    PRINTLOG(@"set Insert Index ::%ld",editIndex);
}
+(NSInteger)insertPageIndex {
    PRINTLOG(@"GEt Insert Index ::%ld",insertIndex);
    return insertIndex;
}

+(void)incrementEditIndex {
    
    editIndex = editIndex+1;
}
+(void)incrementInsertIndex {
    insertIndex = insertIndex+1;
}


+(void)decrementEditIndex {
    editIndex = editIndex-1;;
}
+(void)decrementInsertIndex {
    insertIndex = insertIndex-1;
}

+(NSInteger)editPageIndexBasedOnString:(NSString *)pageName pageArray:(NSMutableArray *)pageArray {
    
    
    PRINTLOG(@"page Name ::%@",pageName);
    
    int i;
    if([[self planPlistArray]count]>1)
    {
        for (i = PDP_PAGES; i < [pageArray count]; i++) {
            PRINTLOG(@"%@",[pageArray objectAtIndex:i]);
            NSString *classNameString = [NSString stringWithFormat:@"%@",NSStringFromClass([[pageArray objectAtIndex:i]objectAtIndex:1])];
            if([classNameString isEqualToString:pageName]) {
                PRINTLOG(@"fetch Index ::%d",i);
                
                return i+1;
            }
        }
    }
    else
    {
    for (i = 0; i < [pageArray count]; i++) {
        PRINTLOG(@"%@",[pageArray objectAtIndex:i]);
        NSString *classNameString = [NSString stringWithFormat:@"%@",NSStringFromClass([[pageArray objectAtIndex:i]objectAtIndex:1])];
        if([classNameString isEqualToString:pageName]) {
            PRINTLOG(@"fetch Index ::%d",i);
          
            return i+1;
           
            
        }
    }
    }
//    unsigned long i;
//    for (i = [pageArray count]-1; i >= 0; i--) {
//        PRINTLOG(@"%@",[pageArray objectAtIndex:i]);
//        NSString *classNameString = [NSString stringWithFormat:@"%@",NSStringFromClass([[pageArray objectAtIndex:i]objectAtIndex:1])];
//        if([classNameString isEqualToString:pageName]) {
//            PRINTLOG(@"fetch Index ::%lu",i);
//            return i-1;
//        }
//    }

    
    return 0;
}

+(NSInteger)pageIndexBasedOnSubViewString:(NSString *)pageName pageArray:(NSMutableArray *)pageArray {
    
    
    PRINTLOG(@"page Name ::%@",pageName);
    
    int i;
    for (i = 0; i < [pageArray count]; i++) {
        PRINTLOG(@"%@",[pageArray objectAtIndex:i]);
        NSString *classNameString;

        NSMutableArray *getArray = [pageArray objectAtIndex:i];
        if([getArray containsObject:pageName]){
            classNameString = [NSString stringWithFormat:@"%@",[getArray objectAtIndex:2]];
            if([classNameString isEqualToString:pageName]) {
                PRINTLOG(@"fetch Index ::%d",i);
                return i;
            }
        }
    }
//    unsigned long i;
//    for (i = [pageArray count]-1; i >=0 ; i--) {
//        PRINTLOG(@"%@",[pageArray objectAtIndex:i]);
//        NSString *classNameString;
//
//        NSMutableArray *getArray = [pageArray objectAtIndex:i];
//        if([getArray containsObject:pageName]){
//            classNameString = [NSString stringWithFormat:@"%@",[getArray objectAtIndex:2]];
//            if([classNameString isEqualToString:pageName]) {
//                PRINTLOG(@"fetch Index ::%lu",i);
//                return i+1;
//            }
//        }
//    }
    return 0;
}


+(NSInteger)pageIndex:(NSString *)pageName pageArray:(NSMutableArray *)pageArray {
    
    PRINTLOG(@"page Name ::%@",pageName);
    
    int j;

    for (j = 0; j < [pageArray count]; j++) {
        PRINTLOG(@"%@",[pageArray objectAtIndex:j]);
        NSString *classNameString = [NSString stringWithFormat:@"%@",NSStringFromClass([[pageArray objectAtIndex:j]objectAtIndex:1])];
        if([classNameString isEqualToString:pageName]) {
            PRINTLOG(@"fetch Index ::%d",j);
            return j;
        }
    }
//    unsigned long j;
//
//    for (j = [pageArray count]-1; j >=0 ; j--) {
//        PRINTLOG(@"%@",[pageArray objectAtIndex:j]);
//        NSString *classNameString = [NSString stringWithFormat:@"%@",NSStringFromClass([[pageArray objectAtIndex:j]objectAtIndex:1])];
//        if([classNameString isEqualToString:pageName]) {
//            PRINTLOG(@"fetch Index ::%lu",j);
//            return j;
//        }
//    }
    return 0;
}
+(void)setIsFromPreview:(BOOL)isFromPreview {
    isFromPreviewPage = isFromPreview;
}
+(BOOL)isFromPreview {
    PRINTLOG(@"isFromPreview ::%d",isFromPreviewPage);
    return isFromPreviewPage;
}


+(void)setIsAddNoticePage:(BOOL)isAddNotice {
    isAddNoticePage = isAddNotice;
}
+(BOOL)isAddNoticePage {
    return isAddNoticePage;
}

+(void)setIsCallRateAPI:(BOOL)isRateAPI {
    isCallRateAPI = isRateAPI;
}
+(BOOL)isCallRateAPI {
    return isCallRateAPI;
}

+(void)setRateAPIParams:(NSMutableDictionary *)paramDict {
    
    if(rateAPIDict==nil){
        rateAPIDict = [[NSMutableDictionary alloc]init];
    }
    rateAPIDict = paramDict;
    
}
+(NSMutableDictionary *)getRateAPIParams {
    return rateAPIDict;
}

+(void)setRateAmount:(NSString *)rateAmt {
    rateAmount = rateAmt;
}
+(NSString *)rateAmount {
    return rateAmount;
}


// BRD2.0
+(void)showAlertView:(NSString *)title message:(NSString *)message class:(id)classVC actionBlock:(AlertActionBlock)actionBlock {
    
    PRINTLOG(@"Show Alert View");
    alertController = nil;
    alertOKAction = nil;
    
    alertActionBlock = actionBlock;
    
    NSString *localizeTitle = [LanguageCentral languageSelectedString:title];
    NSString *displayTitle = (localizeTitle.length>0)? localizeTitle : title;
    
    NSString *localizeMsg = [LanguageCentral languageSelectedString:message];
    NSString *displayMsg = (localizeTitle.length>0)? localizeMsg : message;
    
    
    if (alertController == nil) {
        
        alertController = [UIAlertController alertControllerWithTitle:displayTitle message:displayMsg preferredStyle:UIAlertControllerStyleAlert];
    }
    
    if(alertOKAction== nil) {
        alertOKAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"OK",@"OK action") style:UIAlertActionStyleDefault handler:^(UIAlertAction *okAction){
            alertActionBlock(okAction,classVC);
            [classVC dismissViewControllerAnimated:YES completion:nil];
        }];
    }
    
    [alertController addAction:alertOKAction];
    [classVC presentViewController:alertController animated:YES completion:nil];
}


+(void)showAlertView:(NSString *)title message:(NSString *)message OkTitle:(NSString *)okTitle CanelTitle:(NSString *)cancelTitle class:(id)classVC okAction:(AlertActionBlock)okActionBlock cancelAction:(AlertActionBlock)cancelAction {
    
    alertController = nil;
    alertOKAction = nil;
    alertCancelAction = nil;
    
    
    NSString *localizeTitle = [LanguageCentral languageSelectedString:title];
    NSString *displayTitle = (localizeTitle.length>0)? localizeTitle : title;
    
    NSString *localizeMsg = [LanguageCentral languageSelectedString:message];
    NSString *displayMsg = (localizeTitle.length>0)? localizeMsg : message;
    
    
    if (alertController == nil) {
        
        alertController = [UIAlertController alertControllerWithTitle:displayTitle message:displayMsg preferredStyle:UIAlertControllerStyleAlert];
    }
    
    if(alertOKAction== nil) {
        alertOKAction = [UIAlertAction actionWithTitle:NSLocalizedString(okTitle,@"OK action") style:UIAlertActionStyleDefault handler:^(UIAlertAction *okAction){
            okActionBlock(okAction,classVC);
            [classVC dismissViewControllerAnimated:YES completion:nil];
        }];
    }
    
    if(alertCancelAction==nil) {
        alertCancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(cancelTitle, @"Cancel Action") style:UIAlertActionStyleCancel handler:^(UIAlertAction *cancelBtn) {
            cancelAction(cancelBtn,classVC);
        }];
    }
    
    [alertController addAction:alertOKAction];
    [alertController addAction:alertCancelAction];
    [classVC presentViewController:alertController animated:YES completion:nil];
}


+(void)dismissAlertController {
    
    [alertController dismissViewControllerAnimated:YES completion:nil];
}

+(void)setBirthDate:(NSString *)birthDateString {
    
    birthDateStr = birthDateString;
}

+(NSString *)birthDateString {
    
    return birthDateStr;
}



+(void)setIsFromQuestionPage:(BOOL)isFromQuesPage {
    
    isFromQuestionPageScreen = isFromQuesPage;
}
+(BOOL)isFromQuestionPage {
    return isFromQuestionPageScreen;
}

// this method used to handle hide replacement questions in submission page based on customer turn 65 after 3 months in future
+(void)setIsTurn65InAfter3monthsFuture:(BOOL)isTurn65 {
    isTurn65After3Months = isTurn65;
}
+(BOOL)isTurn65After3monthsFuture{
    return isTurn65After3Months;
}


//anitha added
+(void)errorMessageAlert:(NSString *)title message:(NSString *)message class:(id)classVC {
    PRINTLOG(@"Show error Alert View");
    alertController = nil;
    alertOKAction = nil;
    
    [AppConfig removeActivityIndicator];
    
    NSString *localizeTitle = [LanguageCentral languageSelectedString:title];
    NSString *titleString = (localizeTitle.length>0)?localizeTitle:title;
    
    
    NSString *localizeMessage = [LanguageCentral languageSelectedString:message];
    NSString *msgString = (localizeMessage.length>0)?localizeMessage:message;
    
    
    
    UIAlertController *alertController = [UIAlertController
                                          alertControllerWithTitle:titleString
                                          message:msgString
                                          preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *okAction = [UIAlertAction
                               actionWithTitle:NSLocalizedString(@"OK", @"OK action")
                               style:UIAlertActionStyleDefault
                               handler:^(UIAlertAction *action)
                               {
                                   PRINTLOG(@"ok action");
                               }];
    
    [alertController addAction:okAction];
    
    [classVC presentViewController:alertController animated:YES completion:nil];
}


+(void)removeActivityIndicator{
    
    [AppConfig stopAnimatingGif];
    
}
//svk added
+(void)showEffectiveDateDropDownsFor65:(BOOL)show
{
    showEffectiveDateDropDowns = show;
    
}

+(BOOL)getShowEffectiveDateDropDownsFor65
{
    return showEffectiveDateDropDowns;
}


@end
