//
//  PersonalFormViewController.m
//  SampleBCBSPOC
//
//  Created by CSS Admin on 5/24/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import "PersonalFormViewController.h"
#import "AppConfig.h"
#import "ScopeBaseViewController.h"
#define REDCOLOR [UIColor colorWithRed:(240.0/255.0) green:(108.0/255.0) blue:(108.0/255.0) alpha:1.0f]
#define TEXTCOLOR [UIColor colorWithRed:(153.0/255.0) green:(153.0/255.0) blue:(153.0/255.0) alpha:1.0f]
#define BORDERCOLOR [UIColor colorWithRed:(204.0/255.0) green:(204.0/255.0) blue:(204.0/255.0) alpha:1.0f].CGColo

@interface PersonalFormViewController (){
	
	UIDropDown *birthdate,*startDate,*endDate,*relationToBeneficiary;
	UIDropDown *genderObj;
	UIDropDown *mailingAddressSameAsPermanent;
	ValidatorTextField *ageTextField,*medicareName; 
	ValidatorTextField *firstName, *lastName, *middleInitial;
	ValidatorTextField *genderInMedicare;
	ValidatorTextField *mailingStreetAddress,*mailingCity,*mailingZipCode;
	ValidatorTextField *permanentStreetAddress,*permanentCity,*permanentZipCode;
    
    //svk added 20/08
    ValidatorTextField *permananentCounty,*mailingCounty;
    
	NSString *planName;

	UIDropDown *state,*residentOfNJ;
    UIDropDown *mailingState;
    
    
    //new BRD2.0
    NSInteger effectiveDate_year;
    NSInteger effectiveDate_month;
    NSInteger effectiveDate_day;
}

@property (weak,nonatomic) UIDropDown *partB_date;
@property (weak,nonatomic) UIDropDown *partA_date;

@end

@implementation PersonalFormViewController

- (void)viewDidLoad {
	[super viewDidLoad];
	// Do any additional setup after loading the view.

_titleString.text = [NSString stringWithFormat:@"%@ %@ - \n%@",[AppConfig enrollYear],[LanguageCentral languageSelectedString:[[AppConfig currentPlanDictionary] objectForKey:@"PlanTitle"]],[LanguageCentral languageSelectedString:[[[AppConfig currentPlanDictionary] objectForKey:NSStringFromClass([self class])]objectForKey:@"title"]]];
	
    if([[AppConfig currentPlan]isEqualToString:@"DSNP"]){
        [self.sharedataObj setForwardNextButtonTitle:@"Next"];
        [self.sharedataObj setNextProgressIndex:1];
        
        [self.sharedataObj setPreviousNextButtonTitle:@"Continue_to_health"];
        [self.sharedataObj setBackProgressIndex:1];
    }else {
        [self.sharedataObj setForwardNextButtonTitle:@"Continue_to_health"];
        [self.sharedataObj setNextProgressIndex:1];
        [self.sharedataObj setPreviousNextButtonTitle:@"Continue_to_billing_active"];
        [self.sharedataObj setBackProgressIndex:1];
    }
	
    
    //anitha added
	if ([[AppConfig currentPlan]isEqualToString:@"Supplement Plan 50-64"] && ([[AppConfig enrollYear] isEqualToString:@"2019"])){
		
		[_medicalDisabilityTitle setLocalizationKey:@"MEDICARE_DISABILITY_PERSONAL"];
		
	}else{
		_medicalDisabilityTitle.text=@"";
        
	}
	

	
	planName = [NSString stringWithFormat:@"%@PersonalForm%@",[AppConfig currentPlan],[AppConfig enrollYear]];
	
	[UIRenderer renderPlist:self plist:[NSString stringWithFormat:@"%@PersonalForm%@",[AppConfig currentPlan],[AppConfig enrollYear]]];
    
    [mailingState setUserInteractionEnabled:NO];
    
    
    if([[AppConfig currentPlan]containsString:@"Supplement"] && (([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"]) || [[AppConfig enrollYear] isEqualToString:@"2020"])){
        self.medicalInfoLabel.localizationKey = @"MEDICARE_INSURANCE";
    }else {
         self.medicalInfoLabel.localizationKey = @"MEDICARE_INSURANCE_INFORMATION";
    }
    
    
    // 2019
    if(![[AppConfig currentPlan]isEqualToString:@"SupplementUnder50"] && ![[AppConfig currentPlan]isEqualToString:@"Supplement Plan 50-64"] && ![[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"]){
        if([[AppConfig currentPlan]isEqualToString:@"DSNP"])
        {
            state = [UIRenderer getComponentAtIndex:12];
        }
        else
        {
         state = [UIRenderer getComponentAtIndex:11];
        }
        
    }else {
        
       state = ((([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"]) ))?[UIRenderer getComponentAtIndex:10]:[UIRenderer getComponentAtIndex:11];
        
    }
    [state setUserInteractionEnabled:NO];
	
	if(![[AppConfig currentPlan]isEqualToString:@"SupplementUnder50"] && ![[AppConfig currentPlan]isEqualToString:@"Supplement Plan 50-64"] && ![[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"] && ![[AppConfig currentPlan]isEqualToString:@"DSNP"]){ //Except supplement plans && DSNP //svk changes 30/08
	
		genderObj = [UIRenderer getComponentAtIndex:7];
		medicareName = [UIRenderer getComponentAtIndex:25];
		firstName = [UIRenderer getComponentAtIndex:2];
		lastName = [UIRenderer getComponentAtIndex:3];
		middleInitial = [UIRenderer getComponentAtIndex:4];
		firstName.delegate = self;
		middleInitial.delegate = self;
		lastName.delegate = self;
		medicareName.userInteractionEnabled = NO;
        
        
       
		relationToBeneficiary = [UIRenderer getComponentAtIndex:24];

		mailingAddressSameAsPermanent = [UIRenderer getComponentAtIndex:14];
		
		residentOfNJ = [UIRenderer getComponentAtIndex:13];
		
		permanentStreetAddress = [UIRenderer getComponentAtIndex:9];
		permanentCity = [UIRenderer getComponentAtIndex:10];
		permanentZipCode = [UIRenderer getComponentAtIndex:12];
		
		mailingStreetAddress = [UIRenderer getComponentAtIndex:15];
		mailingCity = [UIRenderer getComponentAtIndex:16];
         mailingState = [UIRenderer getComponentAtIndex:17];
		mailingZipCode = [UIRenderer getComponentAtIndex:18];
		
		[genderInMedicare setUserInteractionEnabled:NO];

		[mailingZipCode setUserInteractionEnabled:NO];
		[mailingStreetAddress setUserInteractionEnabled:NO];
		[mailingCity setUserInteractionEnabled:NO];
		[mailingZipCode setUserInteractionEnabled:NO];
		
		
		[mailingZipCode setLocalizationKey:@""];
		[mailingCity setLocalizationKey:@""];
		[mailingStreetAddress setLocalizationKey:@""];
		
		[mailingStreetAddress setEnableTextField:NO];
		[mailingCity setEnableTextField:NO];
		[mailingZipCode setEnableTextField:NO];
		
		[mailingZipCode setUserInteractionEnabled:NO];
		[mailingStreetAddress setUserInteractionEnabled:NO];
		[mailingCity setUserInteractionEnabled:NO];
		
		genderObj.parent = self;
		genderObj.actionBlock = ^(id selectedGender, id parent){
			
			[genderInMedicare setLocalizationKey:selectedGender];
		};
		
		
		
		mailingAddressSameAsPermanent.parent = self;
		mailingAddressSameAsPermanent.actionBlock = ^(id address,id parent){
			
			if([address isEqualToString:@"Yes"]||[address isEqualToString:@"Sí"]){
				
				[mailingZipCode setLocalizationKey:@""];
				[mailingCity setLocalizationKey:@""];
				[mailingStreetAddress setLocalizationKey:@""];
				
				[mailingStreetAddress setEnableTextField:NO];
				[mailingCity setEnableTextField:NO];
				[mailingZipCode setEnableTextField:NO];
				
				[mailingZipCode setUserInteractionEnabled:NO];
				[mailingStreetAddress setUserInteractionEnabled:NO];
				[mailingCity setUserInteractionEnabled:NO];
				
			}
			else{
				
                [mailingStreetAddress setUserInteractionEnabled:YES];
                [mailingCity setUserInteractionEnabled:YES];
                [mailingZipCode setUserInteractionEnabled:YES];

                [mailingStreetAddress setEnableTextField:YES];
                [mailingCity setEnableTextField:YES];
                [mailingZipCode setEnableTextField:YES];
                
               
				
			}
		};
    }else if(([[AppConfig currentPlan] isEqualToString:@"Supplement Plan 65 and over"])||([[AppConfig currentPlan]isEqualToString:@"SupplementUnder50"] && ([[AppConfig enrollYear] isEqualToString:@"2020"]))||([[AppConfig currentPlan]isEqualToString:@"Supplement Plan 50-64"] && ([[AppConfig enrollYear] isEqualToString:@"2020"]))) {
        
        permanentStreetAddress = [UIRenderer getComponentAtIndex:8];
        permanentCity = [UIRenderer getComponentAtIndex:9];
        permanentZipCode = [UIRenderer getComponentAtIndex:11];
        
        mailingAddressSameAsPermanent = [UIRenderer getComponentAtIndex:12];
        
        mailingStreetAddress = [UIRenderer getComponentAtIndex:13];
        mailingCity = [UIRenderer getComponentAtIndex:14];
        mailingState = [UIRenderer getComponentAtIndex:15];
        mailingZipCode = [UIRenderer getComponentAtIndex:16];
        

        
        [mailingZipCode setUserInteractionEnabled:NO];
        [mailingStreetAddress setUserInteractionEnabled:NO];
        [mailingCity setUserInteractionEnabled:NO];
        
        
        [mailingZipCode setLocalizationKey:@""];
        [mailingCity setLocalizationKey:@""];
        [mailingStreetAddress setLocalizationKey:@""];
        
        [mailingStreetAddress setEnableTextField:NO];
        [mailingCity setEnableTextField:NO];
        [mailingZipCode setEnableTextField:NO];
        
        [mailingZipCode setUserInteractionEnabled:NO];
        [mailingStreetAddress setUserInteractionEnabled:NO];
        [mailingCity setUserInteractionEnabled:NO];
        
        
        // BRD2.0
        self.partA_date = [UIRenderer getComponentAtIndex:20];
        self.partB_date = [UIRenderer getComponentAtIndex:21];
        
        [self.partA_date setUserInteractionEnabled:[AppConfig getShowEffectiveDateDropDownsFor65]];
        [self.partB_date setUserInteractionEnabled:[AppConfig getShowEffectiveDateDropDownsFor65]];
        self.partA_date.validatorString = @"MandatoryValidator";  //changed 23/july/2019
        self.partB_date.validatorString = @"MandatoryValidator";
        
        mailingAddressSameAsPermanent.parent = self;
        mailingAddressSameAsPermanent.actionBlock = ^(id address,id parent){
            
            if([address isEqualToString:@"Yes"]||[address isEqualToString:@"Sí"]){
                
                [mailingZipCode setLocalizationKey:@""];
                [mailingCity setLocalizationKey:@""];
                [mailingStreetAddress setLocalizationKey:@""];
                
                [mailingStreetAddress setEnableTextField:NO];
                [mailingCity setEnableTextField:NO];
                [mailingZipCode setEnableTextField:NO];
                
                [mailingZipCode setUserInteractionEnabled:NO];
                [mailingStreetAddress setUserInteractionEnabled:NO];
                [mailingCity setUserInteractionEnabled:NO];
                
            }
            else{
                
                [mailingStreetAddress setUserInteractionEnabled:YES];
                [mailingCity setUserInteractionEnabled:YES];
                [mailingZipCode setUserInteractionEnabled:YES];

                [mailingStreetAddress setEnableTextField:YES];
                [mailingCity setEnableTextField:YES];
                [mailingZipCode setEnableTextField:YES];
            }
        
        };
        
      
    }
    else if([[AppConfig currentPlan]isEqualToString:@"DSNP"])
    { //svk changes 30/08 DSNP ADDITION
        
        genderObj = [UIRenderer getComponentAtIndex:7];
        medicareName = [UIRenderer getComponentAtIndex:27];
        firstName = [UIRenderer getComponentAtIndex:2];
        lastName = [UIRenderer getComponentAtIndex:3];
        middleInitial = [UIRenderer getComponentAtIndex:4];
        firstName.delegate = self;
        middleInitial.delegate = self;
        lastName.delegate = self;
        medicareName.userInteractionEnabled = NO;
        
        
        
        relationToBeneficiary = [UIRenderer getComponentAtIndex:26];
        
        mailingAddressSameAsPermanent = [UIRenderer getComponentAtIndex:15];
        
        residentOfNJ = [UIRenderer getComponentAtIndex:14];
        
        permanentStreetAddress = [UIRenderer getComponentAtIndex:9];
        permanentCity = [UIRenderer getComponentAtIndex:10];
        permananentCounty = [UIRenderer getComponentAtIndex:11];
        permanentZipCode = [UIRenderer getComponentAtIndex:13];
        
        mailingStreetAddress = [UIRenderer getComponentAtIndex:16];
        mailingCity = [UIRenderer getComponentAtIndex:17];
        mailingCounty = [UIRenderer getComponentAtIndex:18];
        mailingState = [UIRenderer getComponentAtIndex:19];
        mailingZipCode = [UIRenderer getComponentAtIndex:20];
        
        [genderInMedicare setUserInteractionEnabled:NO];
        
        [mailingZipCode setUserInteractionEnabled:NO];
        [mailingStreetAddress setUserInteractionEnabled:NO];
        [mailingCity setUserInteractionEnabled:NO];
        [mailingZipCode setUserInteractionEnabled:NO];
        
        
        [mailingZipCode setLocalizationKey:@""];
        [mailingCity setLocalizationKey:@""];
        [mailingStreetAddress setLocalizationKey:@""];
        
        [mailingStreetAddress setEnableTextField:NO];
        [mailingCity setEnableTextField:NO];
        [mailingZipCode setEnableTextField:NO];
        
        [mailingZipCode setUserInteractionEnabled:NO];
        [mailingStreetAddress setUserInteractionEnabled:NO];
        [mailingCity setUserInteractionEnabled:NO];
        
        genderObj.parent = self;
        genderObj.actionBlock = ^(id selectedGender, id parent){
            
            [genderInMedicare setLocalizationKey:selectedGender];
        };
        
        
        
        mailingAddressSameAsPermanent.parent = self;
        mailingAddressSameAsPermanent.actionBlock = ^(id address,id parent){
            
            if([address isEqualToString:@"Yes"]||[address isEqualToString:@"Sí"]){
                
                [mailingZipCode setLocalizationKey:@""];
                [mailingCity setLocalizationKey:@""];
                [mailingStreetAddress setLocalizationKey:@""];
                [mailingCounty setLocalizationKey:@""];
                
                [mailingStreetAddress setEnableTextField:NO];
                [mailingCity setEnableTextField:NO];
                [mailingCounty setEnableTextField:NO];
                [mailingZipCode setEnableTextField:NO];
                
                [mailingZipCode setUserInteractionEnabled:NO];
                [mailingCounty setUserInteractionEnabled:NO];
                [mailingStreetAddress setUserInteractionEnabled:NO];
                [mailingCity setUserInteractionEnabled:NO];
                
            }
            else{
                
                [mailingStreetAddress setUserInteractionEnabled:YES];
                [mailingCounty setUserInteractionEnabled:YES];
                [mailingCity setUserInteractionEnabled:YES];
                [mailingZipCode setUserInteractionEnabled:YES];
                
                [mailingStreetAddress setEnableTextField:YES];
                [mailingCounty setEnableTextField:YES];
                [mailingCity setEnableTextField:YES];
                [mailingZipCode setEnableTextField:YES];
                
                
                
            }
        };
    }
	
	
    PersonalFormViewController *weakSelf = self;
    
    self.willLoadNext = ^(id object){
        
        [weakSelf addCustomJsonValue];
        
    };
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
	
		medicareName.text = [NSString stringWithFormat:@"%@ %@ %@", firstName.text,middleInitial.text,lastName.text];
}

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
	// Always allow a backspace
	
	ValidatorTextField *text_field = (ValidatorTextField*)textField;
	
	if ([string isEqualToString:@""]) {
		return YES;
	}
	
	if(range.length + range.location > text_field.text.length)
	{
		return NO;
	}
	
	if(!text_field.maxLength)
		text_field.maxLength = 100;
	if(text_field.text.length < text_field.maxLength)
		return YES;
	else
		return NO;
}

-(void)viewWillAppear:(BOOL)animated{
	
   
    [super viewWillAppear:animated];
	
    [ScopeBaseViewController populateCurrentItemValue];
    [self loadBackData];
    
	[self ageCalculation];
    
    _view5.backgroundColor = [UIColor whiteColor];
    
    if([[AppConfig enrollYear] isEqualToString:@"2017"]){
        
        self.emailLabelHeightConstant.constant = 0.0;
        
    }else {
        
        if([[AppConfig currentPlan] containsString:@"Supplement"]){
             self.emailLabelHeightConstant.constant = (([[AppConfig currentPlan] isEqualToString:@"Supplement Plan 65 and over"])||([[AppConfig currentPlan]isEqualToString:@"SupplementUnder50"] && ([[AppConfig enrollYear] isEqualToString:@"2020"]))||([[AppConfig currentPlan]isEqualToString:@"Supplement Plan 50-64"] && ([[AppConfig enrollYear] isEqualToString:@"2020"])))?50.0 :0.0;
        }else {
             self.emailLabelHeightConstant.constant = 50.0;
        }
    }
	
}
-(BOOL)validateVC {
    
    BOOL hasError = NO;
    
    if ([[AppConfig currentPlan] containsString:@"Supplement Plan 65 and over"]) {
        
        NSString *effectiveDateValue = self.partB_date.selectedString;
        
        if(![effectiveDateValue isEqualToString:@"Select"] && effectiveDateValue!=nil) {
            
            [self effectiveDateCalcuation:effectiveDateValue];
            // effective date greater than 3  months from current date
            if(effectiveDate_year>=0 && ((effectiveDate_month>3 && effectiveDate_day>=0) || (effectiveDate_month==3 && effectiveDate_day>0))) {
                
                
                self.partB_date.confirmImgView.hidden = YES;
                
                __block PersonalFormViewController *weakself = self;
                [AppConfig showAlertView:@"Error" message:@"The Medical Insurance (Part B) Effective Date you entered was invalid. It cannot be greater than 3 months from current date. Please select a valid Medical Insurance (Part B) Effective Date" class:weakself actionBlock:^(id data,id handler){
                    PRINTLOG(@"button pressed");
                }];
                
                return hasError = YES;
            }
        }
    }
    
    return hasError;
}
-(void)ageCalculation{
	
    if(![[AppConfig currentPlan]isEqualToString:@"SupplementUnder50"] && ![[AppConfig currentPlan]isEqualToString:@"Supplement Plan 50-64"] && ![[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"] ){
        birthdate = [UIRenderer getComponentAtIndex:5];
        ageTextField = [UIRenderer getComponentAtIndex:6];
    }else {
        
         birthdate = (([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"]))?[UIRenderer getComponentAtIndex:4]:[UIRenderer getComponentAtIndex:5];
         ageTextField = (([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"]))?[UIRenderer getComponentAtIndex:5]:[UIRenderer getComponentAtIndex:6];
     }
	
	
	[ageTextField setUserInteractionEnabled:NO]; 
	
	birthdate.parent = self;
	birthdate.actionBlock = ^(id selectedDate, id parent){
		
		NSString *calculatedAge = [PersonalFormViewController ageCalculation:selectedDate];
		[ageTextField setLocalizationKey:calculatedAge];
	};
	
	
	
	NSString *birthDateGivenBefore = [AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:customer_information:birth_date"];
	
	if([birthDateGivenBefore length] > 0){
		
		birthdate.dropDownTextLabel.text = birthDateGivenBefore;
		[birthdate setUserInteractionEnabled:NO];
		
		NSString *calculatedAge = [PersonalFormViewController ageCalculation:birthDateGivenBefore];
		[ageTextField setLocalizationKey:calculatedAge];
	}	

}



-(void)addCustomJsonValue {
    
//    ScopeBaseViewController *scopeObj = [[ScopeBaseViewController alloc]init];
    
    // needs to enable in future - waiting for business confirmation

    if([[AppConfig currentPlan]isEqualToString:@"DSNP"])
    {
        [AppConfig fillJSONDictionary:@"data:permanent_residence:county" value:permananentCounty.text];
    }
    else
    {
    [AppConfig fillJSONDictionary:@"data:permanent_residence:county" value:[AppConfig county]];
    }
	
	[AppConfig fillJSONDictionary:@"data:customer_information:birth_date" value:birthdate.dropDownTextLabel.text];

    PRINTLOG(@"mailing Address ::%@",mailingAddressSameAsPermanent.selectedString);
	
	if([mailingAddressSameAsPermanent.selectedString isEqualToString:@"Yes"]||[mailingAddressSameAsPermanent.selectedString isEqualToString:@"Sí"]){
        
     
        
       if(([[AppConfig currentPlan] isEqualToString:@"Supplement Plan 65 and over"])||([[AppConfig currentPlan]isEqualToString:@"SupplementUnder50"] && ([[AppConfig enrollYear] isEqualToString:@"2020"]))||([[AppConfig currentPlan]isEqualToString:@"Supplement Plan 50-64"] && ([[AppConfig enrollYear] isEqualToString:@"2020"]))){
           
//           [AppConfig fillJSONDictionary:@"tempJSON:data:customer_information:mailing_address:mail_address" value:mailingAddressSameAsPermanent.selectedString];
           
             [AppConfig setTempJSONDictionary:[AppConfig setValue:[AppConfig tempCurrentPlanJSONDictionary] :@"tempJSON:data:customer_information:mailing_address:mail_address" :mailingAddressSameAsPermanent.selectedString]];
           
           [AppConfig fillJSONDictionary:@"data:customer_information:mailing_address:mail_address" value:@"Yes"];
           
           [AppConfig fillJSONDictionary:@"data:customer_information:mailing_address:street_address" value:permanentStreetAddress.text];
             
             [AppConfig fillJSONDictionary:@"data:customer_information:mailing_address:city" value:permanentCity.text];
             
             [AppConfig fillJSONDictionary:@"data:customer_information:mailing_address:zip_code4" value:permanentZipCode.text];
           
         }else {
             
              [AppConfig fillJSONDictionary:@"data:mailing_address:same_as_permanent_address" value:@"1"];
             [AppConfig fillJSONDictionary:@"data:mailing_address:street_address" value:permanentStreetAddress.text];
             
             [AppConfig fillJSONDictionary:@"data:mailing_address:city" value:permanentCity.text];
             
             [AppConfig fillJSONDictionary:@"data:mailing_address:zip_code" value:permanentZipCode.text];
         }
        
        
        
    }else {
        
        if(([[AppConfig currentPlan] isEqualToString:@"Supplement Plan 65 and over"])||([[AppConfig currentPlan]isEqualToString:@"SupplementUnder50"] && ([[AppConfig enrollYear] isEqualToString:@"2020"]))||([[AppConfig currentPlan]isEqualToString:@"Supplement Plan 50-64"] && ([[AppConfig enrollYear] isEqualToString:@"2020"]))){
//             [AppConfig fillJSONDictionary:@"tempJSON:data:customer_information:mailing_address:mail_address" value:mailingAddressSameAsPermanent.selectedString];
             [AppConfig setTempJSONDictionary:[AppConfig setValue:[AppConfig tempCurrentPlanJSONDictionary] :@"tempJSON:data:customer_information:mailing_address:mail_address" :mailingAddressSameAsPermanent.selectedString]];
            
              [AppConfig fillJSONDictionary:@"data:customer_information:mailing_address:mail_address" value:@"No"];
            
        }else {
             [AppConfig fillJSONDictionary:@"data:mailing_address:same_as_permanent_address" value:@"0"];
        }
    }
    
      if(([[AppConfig currentPlan] isEqualToString:@"Supplement Plan 65 and over"])||([[AppConfig currentPlan]isEqualToString:@"SupplementUnder50"] && ([[AppConfig enrollYear] isEqualToString:@"2020"]))||([[AppConfig currentPlan]isEqualToString:@"Supplement Plan 50-64"] && ([[AppConfig enrollYear] isEqualToString:@"2020"]))){
          [AppConfig fillJSONDictionary:@"data:customer_information:mailing_address:state" value:@"NJ"];
          [AppConfig fillJSONDictionary:@"data:customer_information:permanent_residence:state" value:@"NJ"];
          
      }else {
          [AppConfig fillJSONDictionary:@"data:mailing_address:state" value:@"NJ"];
          if([[AppConfig currentPlan]isEqualToString:@"DSNP"])
          {
              [AppConfig fillJSONDictionary:@"data:mailing_address:county" value:mailingCounty.text];
          }
          else
          {
          [AppConfig fillJSONDictionary:@"data:mailing_address:county" value:[AppConfig county]];
          }
          
          [AppConfig fillJSONDictionary:@"data:permanent_residence:state" value:@"NJ"];
          
          [AppConfig fillJSONDictionary:@"data:customer_information:state" value:@"NJ"];
          
          [AppConfig fillJSONDictionary:@"data:emergency_contact:relationship_to_you" value:[relationToBeneficiary getValueString]];
          
          [AppConfig fillJSONDictionary:@"data:additional_info:resident_of_new_jersey" value:[residentOfNJ getValueString]];
      }
    
	
    
	
	if([[LanguageCentral internalizeString] isEqualToString:@"es"]){
        
		if([[AppConfig currentPlan] containsString:@"Supplement"]){
			[AppConfig fillJSONDictionary:@"data:customer_information:language_code" value:@"es"];
		}else {
			[AppConfig fillJSONDictionary:@"data:plan_details:language_code" value:@"es"];
		}
		
	}else{
		if([[AppConfig currentPlan] containsString:@"Supplement"]){
			[AppConfig fillJSONDictionary:@"data:customer_information:language_code" value:@""];
		}else {
			[AppConfig fillJSONDictionary:@"data:plan_details:language_code" value:@""];
		}
	}
	

    
	[self sendScopeOfAppointmentData];
	
}

-(void)sendScopeOfAppointmentData {
	
	
	[AppConfig fillJSONDictionary:@"data:scope_of_appointment:soa_included" value:[AppConfig getValueFromXpath:[AppConfig generalJSONDictionary] :@"general:scope:soa_included"]];
	
	[AppConfig fillJSONDictionary:@"data:scope_of_appointment:type_of_product" value:[AppConfig getValueFromXpath:[AppConfig generalJSONDictionary] :@"general:scope:type_of_product"]];
	
	[AppConfig fillJSONDictionary:@"data:scope_of_appointment:signature_confirmation" value:[AppConfig getValueFromXpath:[AppConfig generalJSONDictionary] :@"general:scope:signature_confirmation"]];
	
	[AppConfig fillJSONDictionary:@"data:scope_of_appointment:beneficiary:signature" value:[AppConfig getValueFromXpath:[AppConfig generalJSONDictionary] :@"general:scope:signature"]];
	
	[AppConfig fillJSONDictionary:@"data:scope_of_appointment:beneficiary:signature_date" value:[AppConfig getValueFromXpath:[AppConfig generalJSONDictionary] :@"general:scope:signature_date"]];
	
	[AppConfig fillJSONDictionary:@"data:scope_of_appointment:representative:representative_name" value:[AppConfig getValueFromXpath:[AppConfig generalJSONDictionary] :@"general:scope:representative_name"]];
	
	[AppConfig fillJSONDictionary:@"data:scope_of_appointment:representative:relationship_to_beneficiary" value:[AppConfig getValueFromXpath:[AppConfig generalJSONDictionary] :@"general:scope:relationship_to_beneficiary"]];
	
	[AppConfig fillJSONDictionary:@"data:scope_of_appointment:agent:agent_name" value:[AppConfig getValueFromXpath:[AppConfig generalJSONDictionary] :@"general:scope:agent_name"]];
	
	[AppConfig fillJSONDictionary:@"data:scope_of_appointment:agent:agent_phone" value:[AppConfig getValueFromXpath:[AppConfig generalJSONDictionary] :@"general:scope:agent_phone"]];
	
	NSString *firstLastName = [NSString stringWithFormat:@"%@ %@",[AppConfig getValueFromXpath:[AppConfig generalJSONDictionary] :@"general:scope:first_name"],[AppConfig getValueFromXpath:[AppConfig generalJSONDictionary] :@"general:scope:last_name"]];
	
	if(firstLastName.length>0){
		
		[AppConfig fillJSONDictionary:@"data:scope_of_appointment:agent:beneficiary_name" value:firstLastName];
	}else {
		[AppConfig fillJSONDictionary:@"data:scope_of_appointment:agent:beneficiary_name" value:@""];
	}
	
	[AppConfig fillJSONDictionary:@"data:scope_of_appointment:agent:beneficiary_phone" value:[AppConfig getValueFromXpath:[AppConfig generalJSONDictionary] :@"general:scope:beneficiary_phone"]];
	
	[AppConfig fillJSONDictionary:@"data:scope_of_appointment:agent:beneficiary_address" value:[AppConfig getValueFromXpath:[AppConfig generalJSONDictionary] :@"general:scope:beneficiary_address"]];
	
	[AppConfig fillJSONDictionary:@"data:scope_of_appointment:agent:beneficiary_city" value:[AppConfig getValueFromXpath:[AppConfig generalJSONDictionary] :@"general:scope:beneficiary_city"]];
	
	[AppConfig fillJSONDictionary:@"data:scope_of_appointment:agent:beneficiary_state" value:[AppConfig getValueFromXpath:[AppConfig generalJSONDictionary] :@"general:scope:beneficiary_state"]];
	
	[AppConfig fillJSONDictionary:@"data:scope_of_appointment:agent:beneficiary_zipcode" value:[AppConfig getValueFromXpath:[AppConfig generalJSONDictionary] :@"general:scope:beneficiary_zipcode"]];
	
	[AppConfig fillJSONDictionary:@"data:scope_of_appointment:agent:initial_method_of_contact" value:[AppConfig getValueFromXpath:[AppConfig generalJSONDictionary] :@"general:scope:initial_method_of_contact"]];
	
	[AppConfig fillJSONDictionary:@"data:scope_of_appointment:agent:plans_represented" value:[AppConfig getValueFromXpath:[AppConfig generalJSONDictionary] :@"general:scope:plans_represented"]];
	
	[AppConfig fillJSONDictionary:@"data:scope_of_appointment:agent:agent_signature" value:[AppConfig getValueFromXpath:[AppConfig generalJSONDictionary] :@"general:scope:agent_signature"]];
	
	[AppConfig fillJSONDictionary:@"data:scope_of_appointment:agent:date_completed" value:[AppConfig getValueFromXpath:[AppConfig generalJSONDictionary] :@"general:scope:date_completed"]];
	
	[AppConfig fillJSONDictionary:@"data:scope_of_appointment:plan_use_only:explanation" value:[AppConfig getValueFromXpath:[AppConfig generalJSONDictionary] :@"general:scope:explanation"]];
	
}

-(void)loadBackData {
    
	[state setTitleString:@"New Jersey"];
    [state setUserInteractionEnabled:NO];
    
	
	if([[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:additional_info:resident_of_new_jersey"]isEqualToString:@""]){
        
        if([[LanguageCentral internalizeString] isEqualToString:@"en"]){ //english
            [residentOfNJ setValueString:@"Yes"];
        }else {
           
             [residentOfNJ setValueString:@"Sí"];
        }
		
	}else {
		[residentOfNJ setValueString: [AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:additional_info:resident_of_new_jersey"]];
	}

    
    [mailingState setTitleString:@"New Jersey"];
    [mailingState setUserInteractionEnabled:NO];
	
	if([[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:emergency_contact:relationship_to_you"]isEqualToString:@""]){
        
        if([[LanguageCentral internalizeString] isEqualToString:@"en"]){
            
		[relationToBeneficiary setValueString:@"Spouse"];
            
        }else {
            [relationToBeneficiary setValueString:@"Esposa"];
        }
	}else {
		[relationToBeneficiary setValueString: [AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:emergency_contact:relationship_to_you"]];
	}

    
    if([[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:mailing_address:same_as_permanent_address"]isEqualToString:@"1"]||[mailingAddressSameAsPermanent.selectedString isEqualToString:@""]){
        
        if([[LanguageCentral internalizeString] isEqualToString:@"en"]){ //english
            [mailingAddressSameAsPermanent setValueString:@"Yes"];
        }else {
            [mailingAddressSameAsPermanent setValueString:@"Sí"];
        }
        
        
        [mailingStreetAddress setEnableTextField:NO];
        [mailingCity setEnableTextField:NO];
        [mailingCounty setEnableTextField:NO];
        [mailingZipCode setEnableTextField:NO];
        
        
        [mailingZipCode setUserInteractionEnabled:NO];
        [mailingCounty setUserInteractionEnabled:NO];
        [mailingStreetAddress setUserInteractionEnabled:NO];
        [mailingCity setUserInteractionEnabled:NO];
        
        
        [mailingZipCode setLocalizationKey:@""];
        [mailingCity setLocalizationKey:@""];
        [mailingCounty setLocalizationKey:@""];
        [mailingStreetAddress setLocalizationKey:@""];
        
    }else if([[AppConfig getValueFromXpath:[AppConfig tempCurrentPlanJSONDictionary] :@"tempJSON:data:customer_information:mailing_address:mail_address"]isEqualToString:@"Yes"]||[[AppConfig getValueFromXpath:[AppConfig tempCurrentPlanJSONDictionary] :@"tempJSON:data:customer_information:mailing_address:mail_address"]isEqualToString:@"1"]||[[AppConfig getValueFromXpath:[AppConfig tempCurrentPlanJSONDictionary] :@"tempJSON:data:customer_information:mailing_address:mail_address"]isEqualToString:@"Sí"]) {
        
         if([[LanguageCentral internalizeString] isEqualToString:@"en"]){ //english
              [mailingAddressSameAsPermanent setValueString:@"Yes"];
         }else {
              [mailingAddressSameAsPermanent setValueString:@"Sí"];
         }
        
       
        
        [mailingStreetAddress setEnableTextField:NO];
        [mailingCity setEnableTextField:NO];
        [mailingZipCode setEnableTextField:NO];
        [mailingCounty setEnableTextField:NO];
        
        
        [mailingZipCode setUserInteractionEnabled:NO];
        [mailingStreetAddress setUserInteractionEnabled:NO];
        [mailingCity setUserInteractionEnabled:NO];
        [mailingCounty setUserInteractionEnabled:NO];
        
        
        [mailingZipCode setLocalizationKey:@""];
        [mailingCity setLocalizationKey:@""];
        [mailingStreetAddress setLocalizationKey:@""];
        [mailingCounty setLocalizationKey:@""];
        
    }else if ([[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:customer_information:mailing_address:mail_address"]isEqualToString:@"1"]||[mailingAddressSameAsPermanent.selectedString isEqualToString:@""]||[[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:customer_information:mailing_address:mail_address"]isEqualToString:@"Sí"]) {
        
        if([[LanguageCentral internalizeString] isEqualToString:@"en"]){ //english
            [mailingAddressSameAsPermanent setValueString:@"Yes"];
        }else {
            [mailingAddressSameAsPermanent setValueString:@"Sí"];
        }
        
        [mailingStreetAddress setEnableTextField:NO];
        [mailingCity setEnableTextField:NO];
        [mailingZipCode setEnableTextField:NO];
        [mailingCounty setEnableTextField:NO];
        
        
        [mailingZipCode setUserInteractionEnabled:NO];
        [mailingStreetAddress setUserInteractionEnabled:NO];
        [mailingCity setUserInteractionEnabled:NO];
        [mailingCounty setUserInteractionEnabled:NO];
        
        [mailingCounty setLocalizationKey:@""];
        [mailingZipCode setLocalizationKey:@""];
        [mailingCity setLocalizationKey:@""];
        [mailingStreetAddress setLocalizationKey:@""];
        
    }else if (mailingAddressSameAsPermanent.selectedString==nil){
        
        if([[LanguageCentral internalizeString] isEqualToString:@"en"]){ //english
            [mailingAddressSameAsPermanent setValueString:@"Yes"];
        }else {
            [mailingAddressSameAsPermanent setValueString:@"Sí"];
        }
        
        [mailingStreetAddress setEnableTextField:NO];
        [mailingCity setEnableTextField:NO];
        [mailingZipCode setEnableTextField:NO];
        [mailingCounty setEnableTextField:NO];
        
        [mailingCounty setUserInteractionEnabled:NO];
        [mailingZipCode setUserInteractionEnabled:NO];
        [mailingStreetAddress setUserInteractionEnabled:NO];
        [mailingCity setUserInteractionEnabled:NO];
        
        [mailingCounty setLocalizationKey:@""];
        [mailingZipCode setLocalizationKey:@""];
        [mailingCity setLocalizationKey:@""];
        [mailingStreetAddress setLocalizationKey:@""];
    }else {
        
        [mailingAddressSameAsPermanent setValueString:@"No"];
//        [mailingStreetAddress setValueString:[permanentStreetAddress getValueString]];
//        [mailingCity setValueString:[permanentCity getValueString]];
//        [mailingZipCode setValueString:[permanentZipCode getValueString]];

        [mailingStreetAddress setUserInteractionEnabled:YES];
        [mailingCity setUserInteractionEnabled:YES];
        [mailingZipCode setUserInteractionEnabled:YES];
        [mailingCounty setUserInteractionEnabled:YES]; 
        
        [mailingCounty setEnableTextField:YES];
        [mailingStreetAddress setEnableTextField:YES];
        [mailingCity setEnableTextField:YES];
        [mailingZipCode setEnableTextField:YES];
        
    }
	
}


+(NSString*) ageCalculation : (NSString*)dateOfBirth{
	
	
	NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
	
	// ...using a date format corresponding to your date
	[dateFormatter setDateFormat:@"MM/dd/yyyy"];
	//[dateFormatter setDateStyle:NSDateFormatterMediumStyle];
	
	
	// Parse the string representation of the date
	NSDate *birthday = [dateFormatter dateFromString:dateOfBirth];
	
	NSDate* now = [NSDate date];
	NSDateComponents* ageComponents = [[NSCalendar currentCalendar] 
									   components:NSCalendarUnitYear 
									   fromDate:birthday
									   toDate:now
									   options:0];
	NSInteger age = [ageComponents year];
	
	return [NSString stringWithFormat:@"%ld",(long)age];
}

-(void)viewWillDisappear:(BOOL)animated {
    
    [super viewWillDisappear:animated];
    
    [self removeAllView];
    
}

-(void)removeAllView {
    
    for (UIView *v in self.view.subviews) {
        [v removeFromSuperview];
    }
}

-(void)effectiveDateCalcuation:(NSString *)effectiveDateString {
    
    PRINTLOG(@"EffectiveDate String :: %@",effectiveDateString);
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
    [dateFormatter setDateFormat:@"MM/dd/yyyy"];
    [dateFormatter setTimeZone:[NSTimeZone timeZoneWithName:@"EST"]]; // add timezone because we get difference in months , days.
    
    NSDate *effectiveDate = [dateFormatter dateFromString:effectiveDateString];
    
    NSString *dateStrValue = [dateFormatter stringFromDate:[NSDate date]];
    
    NSDate *getEstDateValue = [dateFormatter dateFromString:dateStrValue];
    
    
    
    NSDateComponents* dateComponents = [[NSCalendar currentCalendar]
                                        components:NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay
                                        fromDate:getEstDateValue
                                        toDate:effectiveDate
                                        options:0];

    effectiveDate_year = [dateComponents year];
    effectiveDate_month = [dateComponents month];
    effectiveDate_day = [dateComponents day];
    
    PRINTLOG(@"year :: %ld",(long)effectiveDate_year);
    PRINTLOG(@"month :: %ld",(long)effectiveDate_month);
    PRINTLOG(@"days :: %ld",(long)effectiveDate_day);
    
}

@end
