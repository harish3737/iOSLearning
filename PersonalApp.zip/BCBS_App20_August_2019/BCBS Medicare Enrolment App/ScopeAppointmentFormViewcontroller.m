//
//  ScopeAppointmentFormViewcontroller.m
//  SampleBCBSPOC
//
//  Created by CSS Admin on 5/10/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import "ScopeAppointmentFormViewcontroller.h"
#import "AppConfig.h"
#import "ScopeBaseViewController.h"


#define REDCOLOR [UIColor colorWithRed:240.0/255.0 green:108.0/255.0 blue:108.0/255.0 alpha:1.0f]
@interface ScopeAppointmentFormViewcontroller (){
	

    
}
@property (nonatomic,strong) UITextView *activeField;
@property (nonatomic,strong) ValidatorTextField *agentName;
@property (nonatomic,strong) ValidatorTextField *agentPhone;



@end

@implementation ScopeAppointmentFormViewcontroller
@synthesize explanationTextView,signatureTextField,dateView;
@synthesize pdpButton,advantagePlanButton,supplementPlanButton,dsnpPlanButton;
@synthesize meetingLabel,explanationLabel;
@synthesize agentName,agentPhone;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
	
	[UINavigationQueue showXibName:self];
	
	[self.sharedataObj setForwardNextButtonTitle:@"Next"];
	[self.sharedataObj setNextProgressIndex:-1];
	
	[self.sharedataObj setPreviousNextButtonTitle:@"Start_appointment"];
	[self.sharedataObj setBackProgressIndex:-1];

	
	
    PRINTLOG(@"%@",[AppConfig medicarePlanArray]);
	
	[explanationTextView setDelegate:self];
    self.view.backgroundColor = [UIColor whiteColor];
	
    
    explanationTextView.layer.borderColor = [UIColor lightGrayColor].CGColor;
    explanationTextView.layer.borderWidth = 1.0f;
    
    signatureTextField.layer.borderColor = [UIColor lightGrayColor].CGColor;
    signatureTextField.layer.borderWidth = 1.0f;
    
//    dateButtonField.layer.borderColor = [UIColor lightGrayColor].CGColor;
//    dateButtonField.layer.borderWidth = 1.0f;
	

	NSMutableArray *buttonArray = [AppConfig medicarePlanArray];
    PRINTLOG(@"ButtonArray ::%@",buttonArray);
	
	pdpButton.hidden = YES;
	advantagePlanButton.hidden = YES;
	supplementPlanButton.hidden = YES;
	dsnpPlanButton.hidden =YES;
	
	[self loadPlanImage:buttonArray];
	
	signatureTextField.validatorString =@"AlphabetValidator";
	
	dateView.isDatePickerShow =YES;
    dateView.isMultipleSelection = YES;
    

    agentName = [UIRenderer getComponentAtIndex:7];
    agentPhone = [UIRenderer getComponentAtIndex:8];
    
    
}

-(void)loadPlanImage:(NSMutableArray *)buttonArray{
	
	[pdpButton setTranslatesAutoresizingMaskIntoConstraints:NO];
	[advantagePlanButton setTranslatesAutoresizingMaskIntoConstraints:NO];
	[supplementPlanButton setTranslatesAutoresizingMaskIntoConstraints:NO];
	[dsnpPlanButton setTranslatesAutoresizingMaskIntoConstraints:NO];
	
	UICheckBox *tempBtn = nil;
	
	
	for (int i=0; i<buttonArray.count;i++){
		
		UICheckBox *button = (UICheckBox *)[self.view viewWithTag:[[buttonArray objectAtIndex:i] integerValue]];
		
		button.translatesAutoresizingMaskIntoConstraints = NO;
		button.hidden = NO;
		[button setChecked:YES];
        
        [self.view addConstraint:[NSLayoutConstraint constraintWithItem:button
                                                              attribute:NSLayoutAttributeWidth
                                                              relatedBy:NSLayoutRelationEqual
                                                                 toItem:nil
                                                              attribute:NSLayoutAttributeNotAnAttribute
                                                             multiplier:1.0
                                                               constant:203]];
		
		if(buttonArray.count==1){
			
			[self.view addConstraint:[NSLayoutConstraint constraintWithItem:button attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterX multiplier:1 constant:1.0]];
			
			[self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[meetingLabel]-20-[button(203)]-20-[explanationLabel]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(meetingLabel,explanationLabel,button)]];
			
		}else if(buttonArray.count>1 && buttonArray.count<3) {
			
			if(i==1){
				[self.view addConstraint:[NSLayoutConstraint constraintWithItem:button attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterX multiplier:1 constant:120.0]];
				
				[self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[meetingLabel]-20-[button(203)]-20-[explanationLabel]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(meetingLabel,explanationLabel,button)]];
			}else {
				
				[self.view addConstraint:[NSLayoutConstraint constraintWithItem:button attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterX multiplier:1 constant:-120.0]];
				
				[self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[meetingLabel]-20-[button(203)]-20-[explanationLabel]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(meetingLabel,explanationLabel,button)]];
				
			}
			
			
			
			
		}else if(buttonArray.count>2 && buttonArray.count<4){
			
			if(i==1){
				[self.view addConstraint:[NSLayoutConstraint constraintWithItem:button attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterX multiplier:1 constant:1.0]];
				
				[self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[meetingLabel]-20-[button(203)]-20-[explanationLabel]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(meetingLabel,explanationLabel,button)]];
			}else if(i==0) {
				
				[self.view addConstraint:[NSLayoutConstraint constraintWithItem:button attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterX multiplier:1 constant:-243.0]];
				
				[self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[meetingLabel]-20-[button(203)]-20-[explanationLabel]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(meetingLabel,explanationLabel,button)]];
				
			}else {
				[self.view addConstraint:[NSLayoutConstraint constraintWithItem:button attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterX multiplier:1 constant:243.0]];
				
				[self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[meetingLabel]-20-[button(203)]-20-[explanationLabel]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(meetingLabel,explanationLabel,button)]];
				
			}
			
		}else if(buttonArray.count>3){
			
			if(i==1){
				[self.view addConstraint:[NSLayoutConstraint constraintWithItem:button attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterX multiplier:1 constant:1.0]];
				
				[self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[meetingLabel]-20-[button(203)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(meetingLabel,explanationLabel,button)]];
			}else if(i==0) {
				
				[self.view addConstraint:[NSLayoutConstraint constraintWithItem:button attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterX multiplier:1 constant:-243.0]];
				
				[self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[meetingLabel]-20-[button(203)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(meetingLabel,explanationLabel,button)]];
				
			}else if(i==2){
				[self.view addConstraint:[NSLayoutConstraint constraintWithItem:button attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterX multiplier:1 constant:243.0]];
				
				[self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[meetingLabel]-20-[button(203)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(meetingLabel,explanationLabel,button)]];
				
			}else {
				
				[self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[tempBtn]-40-[button(203)]-20-[explanationLabel]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(meetingLabel,explanationLabel,button,tempBtn)]];
				[self.view addConstraint:[NSLayoutConstraint constraintWithItem:button attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterX multiplier:1 constant:1.0]];
				
				
			}
			
		}
		tempBtn = button;
	}
	[self.view updateConstraints];
	[self.view layoutIfNeeded];
    
	pdpButton.userInteractionEnabled = NO;
	advantagePlanButton.userInteractionEnabled = NO;
	supplementPlanButton.userInteractionEnabled = NO;
	dsnpPlanButton.userInteractionEnabled = NO;
}


- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    PRINTLOG(@"touchesBegan:withEvent:");
	[self.view endEditing:YES];
	[super touchesBegan:touches withEvent:event];
}


// remove copy,paste,select option for textfield text
- (BOOL)canPerformAction:(SEL)action withSender:(id)sender
{
    
    if (action == @selector(paste:) ||
        action == @selector(cut:) ||
        action == @selector(copy:) ||
        action == @selector(select:) ||
        action == @selector(selectAll:) ||
        action == @selector(delete:) ||
        action == @selector(makeTextWritingDirectionLeftToRight:) ||
        action == @selector(makeTextWritingDirectionRightToLeft:) ||
        action == @selector(toggleBoldface:) ||
        action == @selector(toggleItalics:) ||
        action == @selector(toggleUnderline:)
        ) {
        UIPasteboard *pb = [UIPasteboard generalPasteboard];
        [pb setValue:@"" forPasteboardType:UIPasteboardNameGeneral];
        
        return NO;
    }
    return [super canPerformAction:action withSender:sender];
    
}

- (BOOL)textViewShouldBeginEditing:(UITextView *)textView{
    PRINTLOG(@"textViewShouldBeginEditing:");
	return YES;
}

- (void)textViewDidBeginEditing:(UITextView *)textView {
    PRINTLOG(@"textViewDidBeginEditing:");
	if([textView.text isEqualToString:@"Enter Text here..."]){
		textView.text = @"";
	}
	self.activeField = textView;
    // hide custom language keyboard letters in keyboard
    if([textView keyboardType]==UIKeyboardTypeNumberPad|| [textView keyboardType]==UIKeyboardTypePhonePad ){
    }else {
        textView.keyboardType = UIKeyboardTypeASCIICapable;
    }

    [self registerForKeyboardNotifications];
}


- (BOOL)textViewShouldEndEditing:(UITextView *)textView{
    PRINTLOG(@"textViewShouldEndEditing:");
	return YES;
}

- (void)textViewDidEndEditing:(UITextView *)textView{
    PRINTLOG(@"textViewDidEndEditing:");
	self.activeField = nil;
    [self unregisterForKeyboardNotification];
}


- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
	
	
	return YES;
}
- (void)textViewDidChange:(UITextView *)textView{
	if([textView.text isEqualToString:@"Enter Text here..."]){
		textView.text = @"";
	}

    PRINTLOG(@"textViewDidChange:");
}


- (void)textViewDidChangeSelection:(UITextView *)textView{
    PRINTLOG(@"textViewDidChangeSelection:");
}


-(void)registerForKeyboardNotifications{
	
	
	[[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(keyboardDidShow:)
												 name:UIKeyboardDidShowNotification
											   object:nil];
	
	[[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(keyboardWillBeHidden:)
												 name:UIKeyboardWillHideNotification
											   object:nil];
}


-(void)unregisterForKeyboardNotification {
	[[NSNotificationCenter defaultCenter] removeObserver:self
													name:UIKeyboardWillShowNotification
												  object:nil];
	
	[[NSNotificationCenter defaultCenter] removeObserver:self
													name:UIKeyboardWillHideNotification
												  object:nil];
	
}


- (void)keyboardDidShow:(NSNotification *)notification
{
	NSDictionary* info = [notification userInfo];
//    CGRect kbRect = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue];
    CGRect kbRect = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue];  //ios 11 keyboard issue

	// If you are using Xcode 6 or iOS 7.0, you may need this line of code. There was a bug when you
	// rotated the device to landscape. It reported the keyboard as the wrong size as if it was still in portrait mode.
	//kbRect = [self.view convertRect:kbRect fromView:nil];
	
	UIEdgeInsets contentInsets = UIEdgeInsetsMake(0.0, 0.0, kbRect.size.height, 0.0);
	[AppConfig getBaseScrollView].contentInset = contentInsets;
	[AppConfig getBaseScrollView].scrollIndicatorInsets = contentInsets;
	
	CGRect aRect = [AppConfig getBaseMainView].frame;
	aRect.size.height -= kbRect.size.height;
	//    if (!CGRectContainsPoint(aRect, self.activeField.frame.origin) ) {
	//        [_currentScrollView scrollRectToVisible:self.activeField.frame animated:YES];
	//    }
	
	UIInterfaceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation;
	if(orientation == UIInterfaceOrientationLandscapeRight || orientation == UIInterfaceOrientationLandscapeLeft){
		if (!CGRectContainsPoint(aRect, self.activeField.frame.origin) ) {
			CGPoint scrollPoint = CGPointMake(0.0, self.activeField.frame.origin.y);
			//        CGPoint moveScrollPoint = CGPointMake(scrollPoint.x, scrollPoint.y+200);
//                    PRINTLOG(@"move ::%f",moveScrollPoint.y);
			[[AppConfig getBaseScrollView] setContentOffset:scrollPoint animated:YES];
			//        [_currentScrollView setContentOffset:moveScrollPoint animated:YES];
		}}
	else {
		if (!CGRectContainsPoint(aRect, self.activeField.frame.origin) ) {
			CGPoint scrollPoint = CGPointMake(0.0, self.activeField.frame.origin.y-kbRect.size.height);
			//        CGPoint moveScrollPoint = CGPointMake(scrollPoint.x, scrollPoint.y+200);
//                    PRINTLOG(@"move ::%f",moveScrollPoint.y);
			[[AppConfig getBaseScrollView] setContentOffset:scrollPoint animated:YES];
			//        [_currentScrollView setContentOffset:moveScrollPoint animated:YES];
		}}
	
	
}

- (void)keyboardWillBeHidden:(NSNotification *)notification
{
	UIEdgeInsets contentInsets = UIEdgeInsetsZero;
	[AppConfig getBaseScrollView].contentInset = contentInsets;
	[AppConfig getBaseScrollView].scrollIndicatorInsets = contentInsets;
}

-(void)viewWillAppear:(BOOL)animated {
    
    [ScopeBaseViewController populateCurrentItemValue];
    [self loadBackData];
    [super viewWillAppear:animated];
	
	
	dateView.dropDownImageView.hidden = YES;
	[dateView setUserInteractionEnabled:NO];
	NSDate *todayDate = [NSDate date];
 
	NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
	dateFormatter.dateFormat = @"MM/dd/yyyy";
	
	[dateView setTitleString:[dateFormatter stringFromDate:todayDate]];
	dateView.selectedString = [dateFormatter stringFromDate:todayDate];

    
}
-(void)viewDidAppear:(BOOL)animated {
	
	[super viewDidAppear:YES];
}
//

-(void)loadNextPage {
    PRINTLOG(@"text view ::%@",explanationTextView.text);
    if([explanationTextView.text isEqualToString:@"Enter Text here..."]){
        
         [AppConfig setGeneralJSONDictioanry:[AppConfig setValue:[AppConfig generalJSONDictionary] :@"general:scope:explanation" :@""]];
    }else {
         [AppConfig setGeneralJSONDictioanry:[AppConfig setValue:[AppConfig generalJSONDictionary] :@"general:scope:explanation" :explanationTextView.text]];
    }
   
    
    [AppConfig setGeneralJSONDictioanry:[AppConfig setValue:[AppConfig generalJSONDictionary] :@"general:scope:agent_signature" :[signatureTextField getValueString]]];
    
    [AppConfig setGeneralJSONDictioanry:[AppConfig setValue:[AppConfig generalJSONDictionary] :@"general:scope:date_completed" :[dateView getValueString]]];
	
	
	 [AppConfig setGeneralJSONDictioanry:[AppConfig setValue:[AppConfig generalJSONDictionary] :@"general:scope:beneficiary_state" :@"NJ"]];
	

	[AppConfig setGeneralJSONDictioanry:[AppConfig setValue:[AppConfig generalJSONDictionary] :@"general:scope:plans_represented" :[AppConfig getValueFromXpath:[AppConfig generalJSONDictionary] :@"general:scope:type_of_product"]]];
	
 
}


-(void)loadBackData {

    
    NSString *textString = [AppConfig getValueFromXpath:[AppConfig generalJSONDictionary] :@"general:scope:explanation"];
    PRINTLOG(@"TextView :::%@",textString);
    
    if([textString isEqualToString:@""]){
        [explanationTextView setText:@"Enter Text here..."];
    }else {
         [explanationTextView setText:[AppConfig getValueFromXpath:[AppConfig generalJSONDictionary] :@"general:scope:explanation"]];
    }
    
    [signatureTextField setValueString:[AppConfig getValueFromXpath:[AppConfig generalJSONDictionary] :@"general:scope:agent_signature"]];
    
    [dateView setValueString:[AppConfig getValueFromXpath:[AppConfig generalJSONDictionary] :@"general:scope:date_completed"]];
    
    // crash appear when dictionary has empty object .. lakshman 
    NSDictionary *dictionary = [AppConfig agentProfileInfo];
    NSString *firstLastName = [NSString stringWithFormat:@"%@ %@",[[dictionary valueForKey:@"first_name"]objectAtIndex:0],[[dictionary valueForKey:@"last_name"]objectAtIndex:0]];
   
    if(firstLastName.length>0){
        [agentName setLocalizationKey:firstLastName];
    }else {
        agentName.text = @"";
    }
	
   [agentPhone setLocalizationKey:[[dictionary valueForKey:@"mobile"]objectAtIndex:0]];
	
    
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
