//
//  LanguageViewController.m
//  BcBs
//
//  Created by CSS Corp on 11/05/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "LanguageViewController.h"
#import "DashboardBaseViewController.h"
#import "YearViewController.h"
#import "DashboardViewController.h"
#import "ScopeBaseViewController.h"
#import "ScopeViewController.h"


@interface LanguageViewController ()

@end

@implementation LanguageViewController

- (void)viewDidLoad {
	
		
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)englishButtonAction:(id)sender {

	if([[LanguageCentral internalizeString] isEqualToString:@"es"]){  //if previous language selected was "Spanish"
		
		[AppConfig resetGeneralJSONDictionary];
		[AppConfig resetAppConfig];
		[AppConfig resetPlanListArray];
		[AppConfig loadGeneralJSONPlist];
		[AppConfig setcounty:@""];
		[AppConfig setCountyZipcode:@""];
	
	}
	
	[LanguageCentral setInternalizeString:@"en"]; //en - English
    
    [UINavigationQueue deleteAfter:[DashboardBaseViewController class] container:[LanguageViewController class] xib:nil];
	
	[UINavigationQueue pushClass:[DashboardBaseViewController class] containerVC:[YearViewController class] xibName:nil];
	[UINavigationQueue showNext:(UIBaseViewController *)self.parentViewController];
}

- (IBAction)spanishButtonAction:(id)sender {
	
	if([[LanguageCentral internalizeString] isEqualToString:@"en"]){  //if previous language selected was "English"
		
		[AppConfig resetGeneralJSONDictionary];
		[AppConfig resetAppConfig];
		[AppConfig resetPlanListArray];
		[AppConfig loadGeneralJSONPlist];
		[AppConfig setcounty:@""];
		[AppConfig setCountyZipcode:@""];
		
	}

	[LanguageCentral setInternalizeString:@"es"]; //es - spanish
    
    [UINavigationQueue deleteAfter:[DashboardBaseViewController class] container:[LanguageViewController class] xib:nil];
	
	[UINavigationQueue pushClass:[DashboardBaseViewController class] containerVC:[YearViewController class] xibName:nil];
    
	[UINavigationQueue showNext:(UIBaseViewController *)self.parentViewController];
}









@end
