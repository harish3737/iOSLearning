//
//  MedigapStaticInfoViewController.m
//  BCBS Medicare Enrolment App
//
//  Created by Ganesh on 03/08/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "MedigapStaticInfoViewController.h"
#import "AppConfig.h"

@interface MedigapStaticInfoViewController ()

@end

@implementation MedigapStaticInfoViewController

//svk added 05/08
@synthesize readInfo,readInfoTitle,dontNeedMore,needMultipleCoverage,benefitsUnderMedicaid,eligibleToApply,guaranteedAcceptanceConstraint,A,B,C,D,E,F,ifYouLost;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
    _titleString.text = [NSString stringWithFormat:@"%@ %@ - \n%@",[AppConfig enrollYear],[LanguageCentral languageSelectedString:[[AppConfig currentPlanDictionary] objectForKey:@"PlanTitle"]],[LanguageCentral languageSelectedString:[[[AppConfig currentPlanDictionary] objectForKey:NSStringFromClass([self class])]objectForKey:@"title"]]];
    
    [self.sharedataObj setForwardNextButtonTitle:@"Next"];
    [self.sharedataObj setNextProgressIndex:3];
    
    [self.sharedataObj setPreviousNextButtonTitle:@"Next"];
    [self.sharedataObj setBackProgressIndex:3];
    

    if ([[AppConfig currentPlan]isEqualToString:@"SupplementUnder50"] &&[[AppConfig enrollYear]isEqualToString:@"2019"]) {
         self.afterPurchasingLabel.localizationKey = @"MEDIGAP_50_AFTER_PURCHASING_THIS_POLICY_2019";
         self.policyDisabilityLabel.localizationKey = @"MEDIGAP_50_POLICY_BY_DISABILITY_2019";
     }else {
         self.afterPurchasingLabel.localizationKey = @"MEDIGAP_50_AFTER_PURCHASING_THIS_POLICY_2019";
         self.policyDisabilityLabel.localizationKey = @"MEDIGAP_50_POLICY_BY_DISABILITY_2019";
     }
}

-(void)viewWillAppear:(BOOL)animated{
    if(([[AppConfig currentPlan]isEqualToString:@"SupplementUnder50"] ||[[AppConfig currentPlan]isEqualToString:@"Supplement Plan 50-64"])&&[[AppConfig enrollYear]isEqualToString:@"2020"])
    {
        self.readInfo.hidden = YES;
        self.readInfoTitle.hidden = YES;
        self.dontNeedMore.hidden = YES;
        self.needMultipleCoverage.hidden = YES;
        self.benefitsUnderMedicaid.hidden = YES;
        self.afterPurchasingLabel.hidden = YES;
        self.policyDisabilityLabel.hidden = YES;
        self.counselingLabel.hidden = YES;
        self.A.hidden=YES;
        self.B.hidden = YES;
        self.C.hidden = YES;
        self.D.hidden = YES;
        self.E.hidden = YES;
        self.F.hidden = YES;
        self.eligibleToApply.localizationKey = @"ELIGIBLE_TO_APPLY_2020";
        self.ifYouLost.localizationKey=@"IF_YOU_LOST_2020";
        self.guaranteedAcceptanceConstraint.constant = 21;
        
    } else {
         self.guaranteedAcceptanceConstraint.constant = 731;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
