//
//  PreviewViewController.m
//  BCBS Medicare Enrolment App
//
//  Created by CSS CORP on 06/06/18.
//  Copyright © 2018 CSS Corp. All rights reserved.
//

#import "PreviewViewController.h"
#import "AppConfig.h"
#import "ScopeBaseViewController.h"
#import "SubmissionViewController.h"
#import "UIImage+animatedGIF.h"
#import "UIHeaderLabelEditButtonView.h"


static NSInteger currentIndex = -1;
static NSInteger editPageIndex = -1;

@interface PreviewViewController ()
{
    ScopeBaseViewController *baseView;
    NSMutableArray *previewSectionArray;
    
    NSMutableDictionary *getRateDict;
    BOOL isCallRateAPI;
    
    Cache *cache;
    
    UIImageView *loader;
    UIView *currentBaseView;

}
@property (nonatomic) id tempCustomView;
@end

@implementation PreviewViewController
@synthesize view1,childPreviewView,tempCustomView;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self.sharedataObj setForwardNextButtonTitle:@"Back_to_dashboard"];
    [self.sharedataObj setNextProgressIndex:6];
    
    id baseVC= [UIApplication sharedApplication].keyWindow.rootViewController;
    
    if([baseVC isKindOfClass:[UINavigationController class]]){
        baseView = (ScopeBaseViewController *)[baseVC visibleViewController];
    }
    
//    if(currentIndex<0){
//        currentIndex = [UINavigationQueue getCurrentVCIndex];
//    }
    
    currentIndex = [UINavigationQueue getCurrentVCIndex];
    
    
    PRINTLOG(@"currentIndex :::%ld",currentIndex);
    
   
    self.willLoadNext = ^(id object){
        PRINTLOG(@"load next called preview");
    };
    
    self.willBackPage = ^(id object){
        PRINTLOG(@"Back will page called preview");
        
    };
    
    _currentPlanName.localizationKey = [AppConfig currentPlan];
    
    getRateDict = [AppConfig getRateAPIParams];
    
    PRINTLOG(@"Rate API ::%@",getRateDict);
    
  
}

-(void)rateAPILogic {
    
    PRINTLOG(@"Rate Dict ::%@",getRateDict);
    
     if([[AppConfig currentPlan] isEqualToString:@"Supplement Plan 65 and over"]){
        
         NSMutableDictionary *getJsonDict = [AppConfig currentPlanJSONDictionary];
         
         NSMutableDictionary *getHealtStmtDict = [[getJsonDict objectForKey:@"data"]objectForKey:@"health_statements"];
         
         PRINTLOG(@"health stmt ::%@",getHealtStmtDict);
         
         NSMutableDictionary *getGuaranteedDict = [[getJsonDict objectForKey:@"data"]objectForKey:@"acceptance_guaranteed"];
         
          PRINTLOG(@"Acceptance Guaranteed stmt ::%@",getGuaranteedDict);
         
         //    5b - data:acceptance_guaranteed:enroll_medicare
         if([[getGuaranteedDict objectForKey:@"enroll_medicare"] isEqualToString:@"Yes"]){
             [getRateDict setObject:@"true" forKey:@"preferredindicator"]; // preferred Rate
             [getRateDict setObject:@"false" forKey:@"tobaccouseindicator"];
             
         }else if([[getGuaranteedDict objectForKey:@"other_health_coverage"] isEqualToString:@"Yes"]){
             // 5c - data:acceptance_guaranteed:other_health_coverage
             [getRateDict setObject:@"true" forKey:@"preferredindicator"]; // preferred Rate
             [getRateDict setObject:@"false" forKey:@"tobaccouseindicator"];
         }else {
             
             if([[getHealtStmtDict objectForKey:@"5e1"] isEqualToString:@"No"]&&[[getHealtStmtDict objectForKey:@"5e2"] isEqualToString:@"No"]&&[[getHealtStmtDict objectForKey:@"5f"] isEqualToString:@"No"]){
                 [getRateDict setObject:@"true" forKey:@"preferredindicator"]; // preferred Rate
             }else {
                 [getRateDict setObject:@"false" forKey:@"preferredindicator"]; // standard Rate
             }
             
             if([[getHealtStmtDict objectForKey:@"5g"] isEqualToString:@"Yes"]){
                 [getRateDict setObject:@"true" forKey:@"tobaccouseindicator"]; // tobacco user rate
             }else {
                 [getRateDict setObject:@"false" forKey:@"tobaccouseindicator"]; // non tobacco user rate
             }
         }
         
         NSMutableDictionary *getPaymentDict = [[getJsonDict objectForKey:@"data"]objectForKey:@"payment_mode"];
         
         if([[getPaymentDict objectForKey:@"options"] isEqualToString:@"eft"]){
             [getRateDict setObject:@"true" forKey:@"eftindicator"];
         }else {
             [getRateDict setObject:@"false" forKey:@"eftindicator"];
         }
         
     }//    SVK Added 02/09
    
     else if([[AppConfig currentPlan] isEqualToString:@"SupplementUnder50"]||[[AppConfig currentPlan] isEqualToString:@"Supplement Plan 50-64"])
         
     {
         
         NSMutableDictionary *getJsonDict = [AppConfig currentPlanJSONDictionary];
         
         NSMutableDictionary *getPaymentDict = [[getJsonDict objectForKey:@"data"]objectForKey:@"payment_mode"];
         
         
         
         if([[getPaymentDict objectForKey:@"options"] isEqualToString:@"eft"]){
             
             [getRateDict setObject:@"true" forKey:@"eftindicator"];
             
         }else {
             
             [getRateDict setObject:@"false" forKey:@"eftindicator"];
             
         }
         
         [getRateDict setObject:@"true" forKey:@"preferredindicator"];
         
         [getRateDict setObject:@"false" forKey:@"tobaccouseindicator"];
         
     }
     else {
////         svk added 02/09
//          NSMutableDictionary *getJsonDict = [AppConfig currentPlanJSONDictionary];
//         NSMutableDictionary *getPaymentDict = [[getJsonDict objectForKey:@"data"]objectForKey:@"payment_mode"];
//
//         if([[getPaymentDict objectForKey:@"options"] isEqualToString:@"eft"]){
//             [getRateDict setObject:@"true" forKey:@"eftindicator"];
//         }else {
//             [getRateDict setObject:@"false" forKey:@"eftindicator"];
//         }
         [getRateDict setObject:@"false" forKey:@"eftindicator"];
         [getRateDict setObject:@"true" forKey:@"preferredindicator"];
         [getRateDict setObject:@"false" forKey:@"tobaccouseindicator"];
     }
    
    [getRateDict setObject:[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:customer_information:sex"] forKey:@"gender"];
    
     PRINTLOG(@"GetRateDict ::%@",getRateDict);
   
    if(getRateDict!=nil){
        [self startActivityIndicator];
          [self rateAPIWebService];
    }
    
}

-(void)loadPreviewDataFromPlist {
    
    previewSectionArray = [self getArrayFromPlist:[NSString stringWithFormat:@"%@Preview%@",[AppConfig currentPlan],[AppConfig enrollYear]]];
    
    //     previewSectionArray = [NSMutableArray arrayWithObjects:@"PDPPersonalFormPreview2018",@"PDPPaymentOptionFormPreview2018",nil];
    
    tempCustomView = nil;
    childPreviewView = nil;
    
    for (NSString *keyString in previewSectionArray) {
        
//        tempCustomView = [self loadCustomViewForPreview:tempCustomView];
        
         [self loadPreviewSubView];
       
        [UIRenderer renderPlistToView:self plist:[NSString stringWithFormat:@"%@%@Preview%@",[AppConfig currentPlan],keyString,[AppConfig enrollYear]] viewObject:tempCustomView appConfig:[AppConfig currentPlanJSONDictionary] extraData:[AppConfig tempCurrentPlanJSONDictionary]];
        
       
        
        //         [UIRenderer renderPlistToView:self plist:[NSString stringWithFormat:@"%@",keyString] viewObject:tempCustomView];
    }
    childPreviewView = nil;
    
   
}

-(void)getEditButtonFromPlist {
    
    int i=0;
    while ([UIRenderer getComponentAtIndex:i]!=nil) {
        
        
        if([[UIRenderer getComponentAtIndex:i] isKindOfClass:[UIHeaderLabelEditButtonView class]]){
            PRINTLOG(@"Edit button ::: %d",i);
        }
        i++;
    }
    
    PRINTLOG(@"INDex renderer ::%@",[UIRenderer getComponentAtIndex:0]);
}

-(void)loadPreviewSubView {
    
    NSDictionary *metrics =@{@"leading":[NSNumber numberWithFloat:0.0],
                             @"trailing":[NSNumber numberWithFloat:0.0],
                             @"top":[NSNumber numberWithFloat:0.0],
                             @"bottom":[NSNumber numberWithFloat:0.0],
                             @"width":[NSNumber numberWithFloat:self.view1.bounds.size.width],
                             @"height":[NSNumber numberWithFloat:40.0],
                             @"vertical":[NSNumber numberWithFloat:0.0],
                             @"horizontal":[NSNumber numberWithFloat:0.0]};
    
    tempCustomView = [[UIView alloc]init];
    [tempCustomView setBackgroundColor:[UIColor whiteColor]];
   
    [self.view1 addSubview:tempCustomView];
    [tempCustomView setTranslatesAutoresizingMaskIntoConstraints:NO];
    
    [self.view1 addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-leading-[tempCustomView]-trailing-|" options:0 metrics:metrics views:NSDictionaryOfVariableBindings(tempCustomView)]];
    
    
    if(childPreviewView == nil){
        [self.view1 addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-top-[tempCustomView(height@250)]->=bottom-|" options:0 metrics:metrics views:NSDictionaryOfVariableBindings(tempCustomView)]];
      
    }else {
        
        [self.view1 addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[childPreviewView(>=height)]-vertical-[tempCustomView(>=height)]->=bottom-|" options:0 metrics:metrics views:NSDictionaryOfVariableBindings(childPreviewView,tempCustomView)]];
    }
    
    childPreviewView = tempCustomView;
    [self.view1 setNeedsUpdateConstraints];
    [self.view1 layoutIfNeeded];
}


-(UIView *)loadCustomViewForPreview:(UIView *)previousView {
    
    NSDictionary *metrics =@{@"leading":[NSNumber numberWithFloat:0.0],
                             @"trailing":[NSNumber numberWithFloat:0.0],
                             @"top":[NSNumber numberWithFloat:0.0],
                             @"bottom":[NSNumber numberWithFloat:0.0],
                             @"width":[NSNumber numberWithFloat:self.view1.bounds.size.width],
                             @"height":[NSNumber numberWithFloat:40.0],
                             @"vertical":[NSNumber numberWithFloat:0.0],
                             @"horizontal":[NSNumber numberWithFloat:0.0]};
        
        childPreviewView = [[UIView alloc]init];
        [childPreviewView setBackgroundColor:[UIColor whiteColor]];
        
        [self.view1 addSubview:childPreviewView];
        [childPreviewView setTranslatesAutoresizingMaskIntoConstraints:NO];
        
        [self.view1 addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-leading-[childPreviewView]-trailing-|" options:0 metrics:metrics views:NSDictionaryOfVariableBindings(childPreviewView)]];
    
    
        if(previousView == nil){
             [self.view1 addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-top-[childPreviewView(height@250)]->=bottom-|" options:0 metrics:metrics views:NSDictionaryOfVariableBindings(childPreviewView)]];
        }else {

            [self.view1 addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[previousView(>=height)]-vertical-[childPreviewView(>=height)]->=bottom-|" options:0 metrics:metrics views:NSDictionaryOfVariableBindings(childPreviewView,previousView)]];
        }

        [self.view1 setNeedsUpdateConstraints];
        [self.view1 layoutIfNeeded];
    return childPreviewView;
}


-(NSMutableArray *)getArrayFromPlist:(NSString *)plistName {
    
    NSString *plistFileName = [NSString stringWithFormat:@"%@.plist",plistName];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask,YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *path = [documentsDirectory stringByAppendingPathComponent:plistFileName];
    
    if(![[NSFileManager defaultManager] fileExistsAtPath:path]){
        
        path = [[NSBundle mainBundle]pathForResource:plistName ofType:@"plist"];
        
    }
    //    NSMutableDictionary *data = [[NSMutableDictionary alloc]initWithContentsOfFile:path];
    NSMutableArray *getArray = [[NSMutableArray alloc]initWithContentsOfFile:path];
    return getArray;
}


-(void)viewWillAppear:(BOOL)animated{
    
    [AppConfig setIsFromPreview:NO];
    
    [super viewWillAppear:animated];
    
    
    
}

-(void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
    if([AppConfig isCallRateAPI]){
//        [self startActivityIndicator];
        self.currentRateLabel.text = @"";
        [self rateAPILogic];
    }else {
//         [self startActivityIndicator];
        self.currentRateLabel.text = [AppConfig rateAmount];
       
    }

    [self loadPreviewDataFromPlist];

     PRINTLOG(@"before Array ::%@",[UINavigationQueue getPushlistArray]);
    
    if([AppConfig editPageIndex]>0){
//        [UINavigationQueue RemoveClassAtIndex:[AppConfig insertPageIndex]];
        
        if([AppConfig isAddNoticePage]){
            // set index after which page inserting the preview VC.  - it get name from index 1
            [AppConfig setInsertPageIndex:[AppConfig editPageIndexBasedOnString:@"AttestationViewController" pageArray:[UINavigationQueue getPushlistArray]]];
            
            // set preview vc class
            [UINavigationQueue InsertClass:[ScopeBaseViewController class] containerVC:[[[NSClassFromString(@"AuthorizationViewController") alloc] init] class] xibName:nil index:[AppConfig insertPageIndex]];
            
            [AppConfig setIsAddNoticePage:NO];
        }
        
          [UINavigationQueue RemoveClassAtIndex:[AppConfig pageIndex:@"PreviewViewController" pageArray:[UINavigationQueue getPushlistArray]]];
    }
    
     PRINTLOG(@"After Array ::%@",[UINavigationQueue getPushlistArray]);
//     [self stopActivityIndicator];
    
     [self getEditButtonFromPlist];
}

-(void)loadNextPage {
    
    PRINTLOG(@"Load Next Page current Index ::%ld",currentIndex);
    
     PRINTLOG(@"page Name Index ::%ld",[AppConfig editPageIndexBasedOnString:@"SubmissionViewController" pageArray:[UINavigationQueue getPushlistArray]]);
    
//    // fill the "Yes" value when data:acceptance_guaranteed:other_health_coverage is empty
//    if ([[AppConfig currentPlan]containsString:@"65 and over"] && [[AppConfig enrollYear] isEqualToString:@"2019"]) {
//
//        NSString *otherHealthCoverage = [AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:acceptance_guaranteed:other_health_coverage"];
//        if(otherHealthCoverage.length==0) {
//            [AppConfig fillJSONDictionary:@"data:acceptance_guaranteed:other_health_coverage" value:@"Yes"];
//        }
//
//    }
    

    NSInteger submitIndex = [AppConfig pageIndex:@"PreviewViewController" pageArray:[UINavigationQueue getPushlistArray]];
     [UINavigationQueue gotoScreen:submitIndex BaseVC:nil];
    
    

}

-(void)didFinishContainerVC {
    
    // method called after next button tapped
    
   
}

-(BOOL)validateVC {
    return NO;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(IBAction)editIndexButtonPressed:(id)sender {


    [AppConfig setIsFromPreview:YES];
    
    isCallRateAPI = (([[sender pageName] isEqualToString:@"PersonalFormViewController"])||([[sender pageName] isEqualToString:@"PaymentOptionViewController"])||([[sender pageName] isEqualToString:@"QuestionnaireViewController"]))? YES : NO;
    
    [AppConfig setIsCallRateAPI:isCallRateAPI];

    
    // Set index which page move to edit
    [AppConfig setEditPageIndex:[AppConfig editPageIndexBasedOnString:[sender pageName] pageArray:[UINavigationQueue getPushlistArray]]];
    
//    [AppConfig setEditPageIndex:24];
    if([[sender nextToName]length]>0){
        
        
        if([[sender nextToName] isEqualToString:@"SupplementPaymentOptionViewController"]){
            
            // set index after which page inserting the preview VC.  - it get name from index 1
             [AppConfig setInsertPageIndex:[AppConfig editPageIndexBasedOnString:[sender nextToName] pageArray:[UINavigationQueue getPushlistArray]]];
        }else {
            // set index after which page inserting the preview VC. - it get name from index 2
            [AppConfig setInsertPageIndex:[AppConfig pageIndexBasedOnSubViewString:[sender nextToName] pageArray:[UINavigationQueue getPushlistArray]]];
        }
        // set preview vc class
         [UINavigationQueue InsertClass:[ScopeBaseViewController class] containerVC:[PreviewViewController class] xibName:nil index:[AppConfig insertPageIndex]];
        
      
    }else {
        // set index after which page inserting the preview VC.  - it get name from index 1
        [AppConfig setInsertPageIndex:[AppConfig editPageIndexBasedOnString:[sender pageName] pageArray:[UINavigationQueue getPushlistArray]]];
        
        // set preview vc class
         [UINavigationQueue InsertClass:[ScopeBaseViewController class] containerVC:[PreviewViewController class] xibName:nil index:[AppConfig editPageIndex]];
    }
   
    [UINavigationQueue gotoScreen:[AppConfig editPageIndex] BaseVC:baseView];
    if(baseView!=nil){
        [baseView backButton:sender];
    }
}

-(void)rateAPIWebService {
    
    __block PreviewViewController *weakSelf = self;
    
    Callback *cacheCallback = [[Callback alloc]initWithCallbacks: ^(id response,id operation,id handler){
        
        PRINTLOG(@" preview Response :: %@",response);
        NSError *jsonError;
        NSData *objectData = [response dataUsingEncoding:NSUTF8StringEncoding];
        if(objectData==nil){
             [handler displayRateText:@"$0.00"];
        }else {
            NSMutableArray *jsonData = [NSJSONSerialization JSONObjectWithData:objectData options:NSJSONReadingMutableContainers error:&jsonError];
           
             [handler displayRateText:jsonData];
        }
        
    }:^(id response,id operation,id handler){
        PRINTLOG(@"preview Response :: %@",response);
        if([response isKindOfClass:[NSDictionary class]]){
            [handler errorMessageAlert:@"Error" message:@""];
            
        }else {
            [handler errorMessageAlert:@"Error" message:[[AppConfig ErrorResponseJSONSerialization:response]objectAtIndex:0]];
        }
       
        [handler displayRateText:response];
        
    }: weakSelf];

    [AppConfig setRateAPIParams:getRateDict];
    
    JsonOperation *jOP = [[JsonOperation alloc]init];
    
  
    //    [AppConfig testWrapper:RATE_URL query:[jOP getJsonStringByDictionary:getRateDict] callback:cacheCallback];
    
    
    
    GENERATESERVICE(RATE_URL, [jOP getJsonStringByDictionary:getRateDict] , cacheCallback);
    
}

-(void)displayRateText:(id)getRateData {
    
    PRINTLOG(@"Preview rate display ::%@",getRateData);
    
    if([getRateData isKindOfClass:[NSArray class]]){
        if([getRateData count]>0){
            //vrl add only two decimal digits in rate value
            self.currentRateLabel.text = [NSString stringWithFormat:@"$%.2f",[[getRateData objectAtIndex:0]doubleValue]];
        }else {
            self.currentRateLabel.text = @"$0.00";
            
        }
    }else {
        self.currentRateLabel.text = @"$0.00";
    }
    [AppConfig setRateAmount:self.currentRateLabel.text];
    [AppConfig setIsCallRateAPI:NO];
    [self stopActivityIndicator];
}

#pragma mark ActivityIndicator methods


- (void)startActivityIndicator
{
    currentBaseView = [AppConfig getBaseMainView];
    
    NSString *filePath = [[NSBundle mainBundle] pathForResource: @"HB-loader-fullsquare-final-notext 3" ofType: @"gif"];
    
    NSData *gifData = [NSData dataWithContentsOfFile: filePath];
    
    
    UIImageView *loader = [[UIImageView alloc]initWithImage:[UIImage animatedImageWithAnimatedGIFData:gifData]];
    loader.frame = CGRectMake(0,0, 59,59);
    loader.clipsToBounds = YES;
    [self.view addSubview:loader];
    loader.translatesAutoresizingMaskIntoConstraints = NO;
    
    [loader addConstraint:[NSLayoutConstraint constraintWithItem:loader attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:0 multiplier:1 constant:59]];
    [loader addConstraint:[NSLayoutConstraint constraintWithItem:loader attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:nil attribute:0 multiplier:1 constant:59]];
    
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:loader attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterY multiplier:1 constant:0]];
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:loader attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterX multiplier:1 constant:0]];
    
    [self.view updateConstraintsIfNeeded];
    self.view.userInteractionEnabled = NO;
    currentBaseView.userInteractionEnabled = NO;
    
}

- (void)stopActivityIndicator
{   loader = nil;
    [loader removeFromSuperview];
    
    for(id subViewData in self.view.subviews){
        if([subViewData isKindOfClass:[UIImageView class]]){
            [subViewData removeFromSuperview];
        }
    }
    self.view.userInteractionEnabled = YES;
    currentBaseView.userInteractionEnabled = YES;
}

#pragma mark -
-(void)viewWillDisappear:(BOOL)animated {
    
    [super viewWillDisappear:animated];
    [self removeAllView];
    tempCustomView = nil;
    childPreviewView = nil;
    view1 = nil;
    
    cache = nil;
    
    loader = nil;
    currentBaseView = nil;
    
}

-(void)errorMessageAlert:(NSString *)title message:(NSString *)message {
    
//        [self removeActivityIndicator];
    
    NSString *localizeTitle = [LanguageCentral languageSelectedString:title];
    NSString *titleString = (localizeTitle.length>0)?localizeTitle:title;
    
    
    NSString *localizeMessage = [LanguageCentral languageSelectedString:message];
    NSString *msgString = (localizeMessage.length>0)?localizeMessage:message;
    
    
    
    UIAlertController *alertController = [UIAlertController
                                          alertControllerWithTitle:titleString
                                          message:msgString
                                          preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *okAction = [UIAlertAction
                               actionWithTitle:NSLocalizedString(@"OK", @"OK action")
                               style:UIAlertActionStyleDefault
                               handler:^(UIAlertAction *action)
                               {
                                   PRINTLOG(@"ok action");
                               }];
    
    [alertController addAction:okAction];
    
    [self presentViewController:alertController animated:YES completion:nil];
    
}

-(void)removeAllView {
    
    for (UIView *v in view1.subviews) {
        [v removeFromSuperview];
    }
}


-(void)dealloc {
    
    tempCustomView = nil;
    childPreviewView = nil;
    view1 = nil;
}
@end
