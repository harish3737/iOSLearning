//
//  ScopeView.m
//  Autolayout
//
//  Created by CSS Corp on 28/04/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "ScopeView.h"
#import "ScopeViewController.h"

@implementation ScopeView


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    
    UIView *newView = [[[NSBundle mainBundle]loadNibNamed:NSStringFromClass([self class]) owner:self options:nil] objectAtIndex: 0];
    [self addSubview: newView];
    [UIRenderer stretchToSuperView: newView];
	
    [super drawRect:rect];
}


-(instancetype)initWithCoder:(NSCoder *)aDecoder {
	self = [super initWithCoder:aDecoder];
	if(self){
		[[NSBundle mainBundle]loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
		self.bounds = self.contentView.bounds;
		[self addSubview:_contentView];
 }
	return self;
}



@end
