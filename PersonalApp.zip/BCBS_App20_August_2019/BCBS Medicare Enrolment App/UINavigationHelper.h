//
//  UINavigationHelper.h
//  BCBS Medicare Enrolment App
//
//  Created by CSS Admin on 8/1/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>

@interface UINavigationHelper : NSObject

+(void)addPDPScreens;
+(void)addMAPDScreens;
+(void)addDSNPScreens;
+(void)addSupplementScreens;
+(void)addUptoPayment;
+(void)addFromHealthToAuthorization;
+(void)addEmailSubmissionScreen;

@end
