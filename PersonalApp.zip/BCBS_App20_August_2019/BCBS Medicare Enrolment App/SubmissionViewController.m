//
//  SubmissionViewController.m
//  BCBS Medicare Enrolment App
//
//  Created by CSS Corp on 08/06/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "SubmissionViewController.h"
#import "DashboardBaseViewController.h"
#import "DashboardViewController.h"
#import "AppConfig.h"

#import <CacheLib/CacheLib.h>
#import <CacheLib/WebServiceWrapper.h>
#import <CacheLib/Callback.h>
#import <CacheLib/Global.h>



@interface SubmissionViewController (){
    UIActivityIndicatorView* activity;
    BOOL hasError;
    BOOL isDenialAlert;
    BOOL isHealthCoverage;
    
    BOOL isHealthReplacePolicy; //BRD2.0
}
@property (nonatomic,strong)NSString *planTitle;

@end

@implementation SubmissionViewController
@synthesize planTitle;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    hasError = NO;
    _titleString.hidden = YES;
    _messageContent.hidden = YES;
    _disclaimerMsgLabel.hidden = YES;
    
    _firstView.hidden = YES;
    _secondView.hidden = YES;
    _responseTextView.hidden = YES;
    
    _responseDict = [[NSMutableDictionary alloc]init];
    _responseArray = [[NSMutableArray alloc]init];
    _pdpConfirmationNumberLabel.text = @"";
    _spConfirmationNumberLabel.text = @"";
    
    _pdpTitleLabel.text = @"";
    _spTitleLabel.text = @"";
    
    
    _responseTextView.layer.borderColor = [UIColor colorWithRed:(204.0/255.0) green:(204.0/255.0) blue:(204.0/255.0) alpha:1.0f].CGColor;
    _responseTextView.layer.borderWidth = 1.0f;
    
    _textViewString = [[NSMutableString alloc]init];
    
    if([[AppConfig currentPlan] isEqualToString:@"DSNP"]){
        //vrl added for new dsnp attestation
        if([[AppConfig progressTitleArray]count]>4){
            [self.sharedataObj setForwardNextButtonTitle:@"Back_to_dashboard"];
            [self.sharedataObj setNextProgressIndex:5]; //6
        }else {
            [self.sharedataObj setForwardNextButtonTitle:@"Back_to_dashboard"];
            [self.sharedataObj setNextProgressIndex:4]; //6
        }
        
    }else {
        [self.sharedataObj setForwardNextButtonTitle:@"Back_to_dashboard"];
        [self.sharedataObj setNextProgressIndex:6];
    }
    
    
    SubmissionViewController *weakSelf = self;
    
    self.willLoadNext = ^(id object){
        
        //        [UINavigationQueue deleteAfter:[DashboardBaseViewController class] container:[DashboardViewController class] xib:nil];
        
        [weakSelf backToDashboard];
        
    };
    
    planTitle = @"";
    PRINTLOG(@"Final JSON Dict :::%@",[AppConfig getPlanJSONDictionaries]);
    
    //lakshman
    /*// old code before 12.2.2018
     [self startActivityIndicator];
     //Call Submit Form API method
     [self submitPlanForm];  // Fixed issue of not displaying alert view when no internet connection
     */
    
}

//lakshman // new code for addressing issue of not displaying alert view when no internet connection
-(void)viewDidAppear:(BOOL)animated {
    
    [super viewDidAppear:animated];
    [self startActivityIndicator];
    //Call Submit Form API method
    [self submitPlanForm];
}

-(BOOL)validateVC {
    
    return hasError;
    
}


#pragma mark Custom methods

- (void)startActivityIndicator
{
    [AppConfig showLoaderGif];
    //    activity = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    //    [activity setHidesWhenStopped:TRUE];
    //    [activity setAlpha:1.0];
    //    [activity setFrame:CGRectMake((self.view.frame.origin.x+self.view.frame.size.width)/2.0, ((self.view.frame.origin.y+self.view.frame.size.height)/2.0)-250.0, activity.frame.size.width, activity.frame.size.height)];
    //    [self.view addSubview:activity];
    //    [activity startAnimating];
    
}

- (void)removeActivityIndicator
{
    [AppConfig stopAnimatingGif];
    
    //    [activity stopAnimating];
    //    [activity removeFromSuperview];
}

#pragma mark SUBMIT FORM API

-(void)submitPlanForm {
    
    NSMutableDictionary *planJsonDict = [AppConfig getPlanJSONDictionaries];
    
    for(NSString *keyString in planJsonDict){
        
        // display denial message / health coverage disclaimer message alert logic
        if([keyString isEqualToString:@"Supplement Plan 65 and over"]){
            
            NSMutableDictionary *getHealtStmtDict = [[[planJsonDict objectForKey:keyString]objectForKey:@"data"]objectForKey:@"health_statements"];
            
            NSMutableDictionary *getGuaranteedDict = [[[planJsonDict objectForKey:keyString]objectForKey:@"data"]objectForKey:@"acceptance_guaranteed"];
            
            NSString *getHealthCoverage = [getGuaranteedDict objectForKey:@"other_health_coverage"];
            
            
            /* If health statements contains YES value , we display the denial alert */
            //            isDenialAlert = ([[getHealtStmtDict allValues] containsObject:@"Yes"])?YES:NO;  // old logic
            
            /* If health statements 5a - 5d4 contains YES value , we display the denial alert */
            NSArray *denialMsgKeys = [NSArray arrayWithObjects:@"5a",@"5b",@"5c1",@"5c2",@"5c3",@"5c4",@"5c5",@"5c6",@"5c7",@"5c8",@"5c9",@"5c10",@"5c11",@"5d1",@"5d2",@"5d3",@"5d4",nil];
            
            isDenialAlert = NO;
            for (NSString *keyValue in denialMsgKeys){
                
                if([[getHealtStmtDict objectForKey:keyValue] isEqualToString:@"Yes"]){
                    PRINTLOG(@"keyValue --- %@ --- %@",keyValue,[getHealtStmtDict objectForKey:keyValue]);
                    isDenialAlert = YES;
                }
            }
            
            PRINTLOG(@"isDenial Alert ::%d",isDenialAlert);
            
            /* If 5c questions has Yes value , we display the disclaimer message alert */
            isHealthCoverage = ([getHealthCoverage isEqualToString:@"Yes"])?YES:NO;
            
            
            // based on New BRD 2.0 changes , we showed the denial message 7c & 7g
            NSString *get6hValue = [[[[planJsonDict objectForKey:keyString]objectForKey:@"data"]objectForKey:@"health_coverage"]objectForKey:@"6h"];
            NSString *get6dValue = [[[[planJsonDict objectForKey:keyString]objectForKey:@"data"]objectForKey:@"health_coverage"]objectForKey:@"6d"];
            
            PRINTLOG(@"Get 6H value :: %@",get6hValue);
            PRINTLOG(@"Get 6D value :: %@",get6dValue);
            //
            /* 7c & 7g - No , we will display denial message */
//            isHealthReplacePolicy = ([get6dValue isEqualToString:@"No"]||[get6hValue isEqualToString:@"No"])?YES:NO;
            isHealthReplacePolicy = ([get6hValue isEqualToString:@"No"])?YES:NO;
            
        }else {
            
            isDenialAlert = NO;
            isHealthCoverage = NO;
            isHealthReplacePolicy = NO; //BRD2.0
        }
        
        
        //changes 12/06
//        original code for webservice
            [self planWebService:MAKE_URL_WITH_VARIABLE([[planJsonDict objectForKey:keyString] objectForKey:@"url"]) params:[[planJsonDict objectForKey:keyString] objectForKey:@"data"] planTitle:[[planJsonDict objectForKey:keyString] objectForKey:@"title"]];
//
        // for Testing purpose , when move to release please delete this code
//        planTitle = @"";
//        [[self firstView]setHidden:NO];
//        [[self responseDict]setDictionary:planJsonDict];
//        [self showPageTitle:YES];
        
    }
}


-(void)planWebService:(NSString *)url params:(NSMutableDictionary *)paramDict planTitle:(NSString *)title {
    
    
    JsonOperation * jOP = [[JsonOperation alloc] init];
    
    NSMutableDictionary *finalParamDict = [NSMutableDictionary dictionaryWithObjectsAndKeys:paramDict,@"data",nil];
    
    
    NSString *urlParamString = [NSString stringWithFormat:@"URL ::%@\n\nPost Data::\n%@",url,[jOP getJsonStringByDictionary:finalParamDict]];
    
    NSMutableString *responseString = [NSMutableString stringWithFormat:@"%@\n%@",urlParamString,_textViewString];
    
    _textViewString = responseString;
    
    // please comment below ur link..
    PRINTLOG(@"TEXTView ::%@",_textViewString);
    //
    //    _textViewString = [NSMutableString stringWithFormat:@"URL ::%@\n\nPost Data::\n%@",url,[jOP getJsonStringByDictionary:finalParamDict]]; // plz commment when webservice was called
    
    planTitle = @"";
    NSString *titleLocalizeString = [LanguageCentral languageSelectedString:title];
    planTitle = (titleLocalizeString.length>0)?titleLocalizeString:title;
    
    
    PRINTLOG(@"Plan API title ::%@",planTitle);
    
    
    if([AppConfig getNetworkStatus]){
        
        Callback *cacheCallback1 = [[Callback alloc]initWithCallbacks:^(id response,id operation,id ihandler){
            
            NSError *jsonError;
            NSData *objectData = [response dataUsingEncoding:NSUTF8StringEncoding];
            NSMutableDictionary *jsonData = [NSJSONSerialization JSONObjectWithData:objectData options:NSJSONReadingMutableContainers error:&jsonError];
            
            PRINTLOG(@"Submit JSON ::%@",jsonData);
            
            if([[ihandler pdpConfirmationNumberLabel].text isEqualToString:@""]){
                [[ihandler pdpConfirmationNumberLabel] setText:[jsonData objectForKey:@"confirmation_number"]];
                //            [[ihandler pdpTitleLabel]setText:[ihandler planTitle]];
                
                
                if([[jsonData objectForKey:@"plan_type"] isEqualToString:@"PDP"]){
                    
                    [[ihandler pdpTitleLabel]setText:[LanguageCentral languageSelectedString:@"PRESCRIPTION_DRUG_PLAN"]];
                }else if([[jsonData objectForKey:@"plan_type"] isEqualToString:@"MAPD"]){
                    
                    [[ihandler pdpTitleLabel]setText:[LanguageCentral languageSelectedString:@"MEDICARE_ADVANTAGE_PLAN"]];
                }else if([[jsonData objectForKey:@"plan_type"] isEqualToString:@"DSNP"]){
                    
                    [[ihandler pdpTitleLabel]setText:[LanguageCentral languageSelectedString:@"TOTALCARE_PLAN"]];
                }else {
                    [[ihandler pdpTitleLabel]setText:[ihandler planTitle]];
                }
                
                [[ihandler firstView]setHidden:NO];
                [[ihandler responseDict]setDictionary:jsonData];
                
                
            }else {
                
                [[ihandler spConfirmationNumberLabel] setText:[jsonData objectForKey:@"confirmation_number"]];
                //            [[ihandler spTitleLabel]setText:[ihandler planTitle]];
                
                if([[jsonData objectForKey:@"plan_type"] isEqualToString:@"PDP"]){
                    
                    [[ihandler spTitleLabel]setText:[LanguageCentral languageSelectedString:@"PRESCRIPTION_DRUG_PLAN"]];
                }else if([[jsonData objectForKey:@"plan_type"] isEqualToString:@"MAPD"]){
                    
                    [[ihandler spTitleLabel]setText:[LanguageCentral languageSelectedString:@"MEDICARE_ADVANTAGE_PLAN"]];
                }else if([[jsonData objectForKey:@"plan_type"] isEqualToString:@"DSNP"]){
                    
                    [[ihandler spTitleLabel]setText:[LanguageCentral languageSelectedString:@"TOTALCARE_PLAN"]];
                }else {
                    [[ihandler spTitleLabel]setText:[ihandler planTitle]];
                }
                
                [[ihandler secondView]setHidden:NO];
                
                [[ihandler responseDict]setDictionary:jsonData];
                
            }
            [ihandler showPageTitle:YES];
            
            
        }:^(id response,id operation,id handler){
            
            
            // for text view error output print
            NSError *jsonError;
            NSData *objectData = [response dataUsingEncoding:NSUTF8StringEncoding];
            NSMutableArray *jsonData = [NSJSONSerialization JSONObjectWithData:objectData options:NSJSONReadingMutableContainers error:&jsonError];
            
            PRINTLOG(@"Submit error JSON ::%@",jsonData);
            
            [[handler responseArray]setArray:jsonData];
            
            [handler errorMessageAlert:@"Error" message:[[AppConfig ErrorResponseJSONSerialization:response]objectAtIndex:0]];
            [handler showPageTitle:NO];
            
            
        }:self];
        
        
        Cache *cache = [[Cache alloc]init];
        [cache setService: [[WebServiceWrapper alloc] init]];
        [cache settimeoutInMin:1.0];
        
        
        [cache registerTask:url :[jOP getJsonStringByDictionary:finalParamDict] :cacheCallback1 :NO_CACHE];
        [cache setHeaders:url :[jOP getJsonStringByDictionary:finalParamDict] :[AppConfig headerList]];
        PRINTLOG(@"header cookie ::%@",[AppConfig headerList]);
        [cache execute : url :[jOP getJsonStringByDictionary:finalParamDict]];
        
    }else{
        hasError = NO;
        //        [self errorMessageAlert:@"INFO" message:@"The Internet connection appears to be offline."];
        [AppConfig errorMessageAlert:@"INFO" message:@"The Internet connection appears to be offline." class:self];
    }
}

-(void)showPageTitle:(BOOL)success {
    
    
    if(success){
        _titleString.hidden = NO;
        _titleString.localizationKey = @"SUBMISSION_SUCCESSFUL";
        _messageContent .hidden = NO;
        _responseTextView.hidden = NO;
        _disclaimerMsgLabel.hidden = YES;
        
        
        NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] init]; //BRD2.0
        //
        if(isDenialAlert) {
            
            //            [self errorMessageAlert:@"Denial Alert" message:@"Based on your responses to certain questions in the Health Statements section, you do not meet our medical underwriting criteria to enroll."];
            
            _disclaimerMsgLabel.hidden = NO;
            self.disclaimerMsgLabel.text = @"Based on your responses to certain questions in the Health Statements section, you do not meet our medical underwriting criteria to enroll.\n\nBased on your responses to our questions, we will not be able to offer you a Medicare Supplement plan at this time. We do offer Medicare Advantage plans that can be the right plan to fit your needs.\n\nVisit HorizonBlue.com/MAOptions to see your options.";
            
            // old code , it commented bcause of BRD2.0
            //             self.disclaimerMsgLabel.text = @"Based on your responses to certain questions in the Health Statements section, you do not meet our medical underwriting criteria to enroll.\n\nBased on your responses to our questions, we will not be able to offer you a Medicare Supplement plan at this time. We do offer Medicare Advantage plans that can be the right plan to fit your needs.";
            
            [attributedString appendAttributedString:[[NSAttributedString alloc] initWithString:@"Based on your responses to certain questions in the Health Statements section, you do not meet our medical underwriting criteria to enroll.\n\n"
                                                                                     attributes:@{NSUnderlineStyleAttributeName: @(NSUnderlineStyleNone)}]];
            
            [attributedString appendAttributedString:[[NSAttributedString alloc] initWithString:@"We will not be able to offer you a Medicare Supplement plan at this time. However, we do offer Medicare Advantage plans that can be the right plan to fit your needs." attributes:@{NSUnderlineStyleAttributeName: @(NSUnderlineStyleSingle),NSBackgroundColorAttributeName: [UIColor clearColor],NSFontAttributeName:[UIFont fontWithName:@"Arial-BoldMT" size:18.0]}]];
            
            self.disclaimerMsgLabel.attributedText = attributedString;
        }
        
        
        if(isHealthCoverage) {
            
            // original code
            //            NSString *healthMsg = @"Please provide a copy of the termination notice you received from your prior plan or employer, which verifies the circumstances of your prior plan’s termination and describes your right to guaranteed issue of Medicare supplement insurance.\n\nPlease send by fax or mail:\nFax: 1-973-274-2295\nMail: Horizon Blue Cross Blue Shield of New Jersey\nPO Box 10138\nMail Station PP-12L\nNewark, NJ 07101-3147\n\nUpon receipt, we will determine whether your acceptance is guaranteed.";
            
            [attributedString appendAttributedString:[[NSAttributedString alloc] initWithString:@"Please provide a copy of the termination notice you received from your prior plan or employer, which verifies the circumstances of your prior plan’s termination and describes your right to guaranteed issue of Medicare supplement insurance.\n\nPlease send by fax or mail:\nFax: 1-973-274-2295\nMail: Horizon Blue Cross Blue Shield of New Jersey\nPO Box 10138\nMail Station PP-12L\nNewark, NJ 07101-3147\n\nUpon receipt, we will determine whether your acceptance is guaranteed." attributes:@{NSUnderlineStyleAttributeName: @(NSUnderlineStyleNone)}]];
            
            //             [self errorMessageAlert:@"Alert" message:healthMsg];
            _disclaimerMsgLabel.hidden = NO;
            //            self.disclaimerMsgLabel.text = healthMsg; // original code
            
            self.disclaimerMsgLabel.attributedText = attributedString;
            
        }
        
        //       Comments -  Customer answers ‘Y’ to one of the health underwriting questions and also answers ‘N’ to one of the replacement notice question. In this scenario, Health underwriting denial message should be shown .
        if(isHealthReplacePolicy && !isDenialAlert) {
            
            //comments - Customer turning age 65 after 3 months in future (say 10-Aug-2019) [AND] answers “No” to any one of the replacement questions - No denial message will be displayed and customer will be allowed to submit the application.
            
            if(![AppConfig isTurn65After3monthsFuture]) {
                
                _disclaimerMsgLabel.hidden = NO;
                
                //31/07/2019 
//                 [attributedString appendAttributedString:[[NSAttributedString alloc] initWithString:@"\n\nWe will not be able to offer you a Medicare Supplement plan at this time. However, we do offer Medicare Advantage plans that can be the right plan to fit your needs." attributes:@{NSUnderlineStyleAttributeName: @(NSUnderlineStyleSingle),NSBackgroundColorAttributeName: [UIColor clearColor],NSFontAttributeName:[UIFont fontWithName:@"Arial-BoldMT" size:18.0]}]];
                
                [attributedString appendAttributedString:[[NSAttributedString alloc] initWithString:@"\n\nBased on your response, you do not intend to replace your current Medicare Advantage or Medicare Supplement plan. We will not be able to offer you a Medicare Supplement plan at this time because we cannot issue a plan that duplicates coverage." attributes:@{NSUnderlineStyleAttributeName: @(NSUnderlineStyleNone)}]];
                
                self.disclaimerMsgLabel.attributedText = attributedString;
            }
            
        }
        
        PRINTLOG(@"GA Screen Name :::%@",[NSString stringWithFormat:@"%@ %@ %@",[AppConfig enrollYear],[[[AppConfig currentPlanDictionary] objectForKey:NSStringFromClass([self class])]objectForKey:@"GA_Screen_Name"],@"Successful submission"]);
        
        [GAIHelper sendScreenWithName:[NSString stringWithFormat:@"%@ %@ %@",[AppConfig enrollYear],[[[AppConfig currentPlanDictionary] objectForKey:NSStringFromClass([self class])]objectForKey:@"GA_Screen_Name"],@"SUCCESS"]];
        
        // for enable JSON result textview  uncomment below 3 lines when build in SIT,UAT
        NSString *responseString = [NSString stringWithFormat:@"%@\n%@",_textViewString,_responseDict];
        NSMutableString *finalString = [NSMutableString stringWithFormat:@"%@\n%@",_responseTextView.text,responseString];
        _responseTextView.text = finalString;
        
        
        PRINTLOG(@"resposnetextView ::%@",_responseTextView.text);
        
        // For disable JSON result textview uncomment below 2 lines when build in production
//                        _responseTextView.text = @"";
//                        _responseTextView.hidden = YES;
        
        hasError = NO;
        
    }else {
        _titleString.hidden = NO;
        _titleString.localizationKey = @"SUBMISSION_UNSUCCESSFUL";
        _messageContent.hidden = YES;
        _firstView.hidden = YES;
        _secondView.hidden = YES;
        _responseTextView.hidden = NO;
        self.disclaimerMsgLabel.hidden = YES;
        
        
        PRINTLOG(@"GA Screen Name :::%@",[NSString stringWithFormat:@"%@ %@ %@",[AppConfig enrollYear],[[[AppConfig currentPlanDictionary] objectForKey:NSStringFromClass([self class])]objectForKey:@"GA_Screen_Name"],@"Submission failed"]);
        
        [GAIHelper sendScreenWithName:[NSString stringWithFormat:@"%@ %@ %@",[AppConfig enrollYear],[[[AppConfig currentPlanDictionary] objectForKey:NSStringFromClass([self class])]objectForKey:@"GA_Screen_Name"],@"FAILED"]];
        
        // for enable JSON result textview uncomment below 3 lines when build in SIT , UIT
        NSString *responseString = [NSString stringWithFormat:@"%@\n%@",_textViewString,[_responseArray objectAtIndex:0]];
        NSMutableString *finalString = [NSMutableString stringWithFormat:@"%@\n%@",_responseTextView.text,responseString];
        _responseTextView.text = finalString;
//
        PRINTLOG(@"resposnetextView ::%@",_responseTextView.text);
        
        // For disable JSON result textview uncomment below 2 lines when build in Production
//                _responseTextView.text = @"";
//                _responseTextView.hidden = YES;
        
        hasError = NO;
    }
    [self removeActivityIndicator];
}

-(void)errorMessageAlert:(NSString *)title message:(NSString *)message {
    
    
    NSString *localizeTitle = [LanguageCentral languageSelectedString:title];
    NSString *titleString = (localizeTitle.length>0)?localizeTitle:title;
    
    
    NSString *localizeMessage = [LanguageCentral languageSelectedString:message];
    NSString *msgString = (localizeMessage.length>0)?localizeMessage:message; // fix new code
    
    
    if (([msgString rangeOfString:@"is missing or empty"].location == NSNotFound))
    {
        msgString = (localizeMessage.length>0)?localizeMessage:message;
        
    } else
    {
        msgString = @"Submission unsuccessful";
    }
    
    UIAlertController *alertController = [UIAlertController
                                          alertControllerWithTitle:titleString
                                          message:msgString
                                          preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *okAction = [UIAlertAction
                               actionWithTitle:NSLocalizedString(@"OK", @"OK action")
                               style:UIAlertActionStyleDefault
                               handler:^(UIAlertAction *action)
                               {
                                   PRINTLOG(@"ok action");
                               }];
    
    [alertController addAction:okAction];
    
    [self presentViewController:alertController animated:YES completion:nil];
    
    [self removeActivityIndicator];
    
}


-(void)backToDashboard{
    
    [UINavigationQueue clearNavigationQueue:-1];
    [UINavigationQueue pushClass:[DashboardBaseViewController class] containerVC:[DashboardViewController class] xibName:nil];
    
    [AppConfig setcounty:@""];
    [AppConfig setCountyZipcode:@""];
    
    //[UINavigationQueue showInitialContainerViewcontroller:self];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
