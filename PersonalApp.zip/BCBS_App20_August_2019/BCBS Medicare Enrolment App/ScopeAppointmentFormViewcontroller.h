//
//  ScopeAppointmentFormViewcontroller.h
//  SampleBCBSPOC
//
//  Created by CSS Admin on 5/10/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>

@interface ScopeAppointmentFormViewcontroller : UIBaseContainerViewController<UITextViewDelegate>


@property (weak, nonatomic) IBOutlet UIView *multipleContentView;

@property (weak, nonatomic) IBOutlet UILabel *scopeTitleLabel;


@property (weak, nonatomic) IBOutlet UILabel *scopeSubtitleLabel;


@property (strong, nonatomic) IBOutlet UITextView *explanationTextView;

@property (strong, nonatomic) IBOutlet ValidatorTextField *signatureTextField;

@property (strong, nonatomic) IBOutlet UIDropDown *dateView;


@property (strong, nonatomic) IBOutlet UICheckBox *pdpButton;
@property (strong, nonatomic) IBOutlet UICheckBox *advantagePlanButton;
@property (strong, nonatomic) IBOutlet UICheckBox *supplementPlanButton;
@property (strong, nonatomic) IBOutlet UICheckBox *dsnpPlanButton;

@property (strong, nonatomic) IBOutlet ValidatorLabel *meetingLabel;

@property (strong, nonatomic) IBOutlet ValidatorLabel *explanationLabel;

@end
