//
//  ContentCollectionViewCell.h
//  CustomCollectionLayout
//
//  Created by CSS Corp on 22/04/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ContentCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UILabel *contentLabel;
@property (strong, nonatomic) IBOutlet UILabel *borderLabel;

@end
