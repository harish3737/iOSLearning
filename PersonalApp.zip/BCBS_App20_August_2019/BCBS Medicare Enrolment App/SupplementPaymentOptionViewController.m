//
//  SupplementPaymentOptionViewController.m
//  BCBS Medicare Enrolment App
//
//  Created by Ganesh on 09/08/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "SupplementPaymentOptionViewController.h"
#import "AppConfig.h"
#import "ScopeBaseViewController.h"

@interface SupplementPaymentOptionViewController ()

@end

@implementation SupplementPaymentOptionViewController



- (void)viewDidLoad {
	// Do any additional setup after loading the view.
    
     [super viewDidLoad];
    
_titleString.text = [NSString stringWithFormat:@"%@ %@ - \n%@",[AppConfig enrollYear],[LanguageCentral languageSelectedString:[[AppConfig currentPlanDictionary] objectForKey:@"PlanTitle"]],[LanguageCentral languageSelectedString:[[[AppConfig currentPlanDictionary] objectForKey:NSStringFromClass([self class])]objectForKey:@"title"]]];
	
	[_monthlyButton setRadioButtonSelected:YES];
	_monthlyButton.xPath = @"data:payment_schedule:options";
	_semiAnnualButton.xPath = @"data:payment_schedule:options";
	_quarterlyButton.xPath = @"data:payment_schedule:options";
	
	
	//	mailButton.validatorString=@"MandatoryValidator";
	//	phoneButton.validatorString=@"MandatoryValidator";
	//	eftButton.validatorString=@"MandatoryValidator";
	//	rrbButton.validatorString=@"MandatoryValidator";
	
	
    [self.sharedataObj setForwardNextButtonTitle:@"Next"];
    [self.sharedataObj setNextProgressIndex:2];
    
    [self.sharedataObj setPreviousNextButtonTitle:@"Continue_to_health"];
    [self.sharedataObj setBackProgressIndex:2];
	

    //vrl added
    if(([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear]isEqualToString:@"2020"] )&& [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"]){
        self.headTitleLabel.localizationKey = @"";
        self.SubTitle.localizationKey = @"PLEASE_SELECT_FREQUENTLY_BILLED";
    }else {
        self.headTitleLabel.localizationKey = @"PAYMENT_SCHEDULE_CHOOSE_ONE";
        self.SubTitle.localizationKey = @"CHOOSE_PAYMENT_SCHEDULE";
    }
}



-(void)loadNextPage {
    
    if(_monthlyButton.buttonSelected){
        [AppConfig fillJSONDictionary:@"data:payment_schedule:options" value:@"Monthly"];
    }else if(_quarterlyButton.buttonSelected){
        [AppConfig fillJSONDictionary:@"data:payment_schedule:options" value:@"Quarterly"];
        
    }else if(_semiAnnualButton.buttonSelected){
        
        [AppConfig fillJSONDictionary:@"data:payment_schedule:options" value:@"Semi-Annually"];
        
    }else {
        [AppConfig fillJSONDictionary:@"data:payment_schedule:options" value:@""];
        
    }
    
    
}

-(void)viewWillAppear:(BOOL)animated{
	
    [ScopeBaseViewController populateCurrentItemValue];
    [self loadBackData];
    [super viewWillAppear:animated];
}

-(void)loadBackData {
	
	NSString *paymentOptions = [AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:payment_schedule:options"];
	
    PRINTLOG(@"Paymentoptions ::%@",paymentOptions);
	
	
	if([paymentOptions isEqualToString:@"Monthly"]){
		
//		[_monthlyButton setRadioButtonSelected:YES];
	}

	if([paymentOptions isEqualToString:@"Quarterly"]){
		
		[_quarterlyButton setRadioButtonSelected:YES];
	}
	if([paymentOptions isEqualToString:@"Semi-Annually"]){
		[_semiAnnualButton setRadioButtonSelected:YES];
	}
	
}

- (void)didReceiveMemoryWarning {
	[super didReceiveMemoryWarning];
	// Dispose of any resources that can be recreated.
}



@end
