//
//  PaymentOptionViewController.h
//  BCBS Medicare Enrolment App
//
//  Created by CSS Corp on 27/05/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>

@interface PaymentOptionViewController : UIBaseContainerViewController



@property (strong, nonatomic) IBOutlet UIView *contentView;
@property (nonatomic,strong)UIView *eftView;
@property (strong, nonatomic) IBOutlet UIRadioButton *mailButton;
@property (strong, nonatomic) IBOutlet UIRadioButton *phoneButton;
@property (strong, nonatomic) IBOutlet UIRadioButton *eftButton;
@property (strong, nonatomic) IBOutlet UIRadioButton *rrbButton;
@property (strong, nonatomic) IBOutlet UIRadioButton *addNewButton;

@property (strong, nonatomic) IBOutlet ValidatorLabel *titleString;
@property (strong, nonatomic) IBOutlet ValidatorLabel *SubTitle;
@property (strong, nonatomic) ValidatorLabel *myLabel;
@property (weak, nonatomic) IBOutlet ValidatorLabel *headTitleLabel;

- (IBAction)mailMeBillButton:(id)sender;
- (IBAction)payByPhoneButton:(id)sender;
- (IBAction)rrbButton:(id)sender;
- (IBAction)eftButton:(id)sender;
- (IBAction)addNewButtonAction:(id)sender;

@end
