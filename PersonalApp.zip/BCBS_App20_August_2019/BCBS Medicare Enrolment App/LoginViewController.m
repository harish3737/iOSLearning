//
//  ViewController.m
//  BcBs
//
//  Created by CSS Corp on 09/05/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "LoginViewController.h"
#import "ResetPasswordViewController.h"
#import "DashboardBaseViewController.h"
#import "DashboardViewController.h"
#import "ScopeBaseViewController.h"
#import "ScopeViewController.h"

#import <CacheLib/CacheLib.h>
#import <CacheLib/WebServiceWrapper.h>
#import <CacheLib/Callback.h>
#import <CacheLib/Global.h>

#import "AppDelegate.h"
#import "AppConfig.h"
#import "Reachability.h"
#import "SupplementNoticeViewController.h"
#import "GAI.h"
#import "GAIDictionaryBuilder.h"
#import "GAITrackedViewController.h"
#import "GAIHelper.h"

#import "TapClass.h"
#import "UIImage+animatedGIF.h"


#define CURRENT_VERSION [[[UIDevice currentDevice] systemVersion] integerValue]
#define IOS5 5
#define IOS4 4
#define IOS6 6
#define IOS7 7
#define IOS8 8
#define IOS9 9


@interface LoginViewController ()
{
    TapClass *gestureObject;
    BOOL isloadAgentProfile;  //vrl
}

@property (nonatomic,strong) DBHelper *dbHelper;
@property (nonatomic,strong) Callback * pdpCallback;
@property (nonatomic,strong) Callback * mapdCallback;
@property (nonatomic,strong) Callback * medigapCallback;
@property (nonatomic,strong) Callback * zipCallback;


-(void)syncPDP :(id) handler;
-(void)syncMAPD :(id) handler;
-(void)syncMEDIGAP :(id) handler;
-(void)syncZIPCODE :(id) handler;
@end

@implementation LoginViewController

Reachability* internetReachable;
Reachability* hostReachable;
UIActivityIndicatorView* activity;

@synthesize dbHelper,usernameTextField;
@synthesize scrollView;



- (void)viewDidLoad {
    [super viewDidLoad];
    
    //    #if DEBUG
    //    NSLog(@"message: %@", @"Debug mode"); //Debug==1 release = 0
    //    #endif
    //NSLog(@"message: %@", @"disabled"); //release it will print in log
    //    #define NSLog(...)
    
    
    PRINTLOG(@"Hello: %@", @"world");
    self.usernameTextField.autocorrectionType = UITextAutocorrectionTypeNo;
    self.passwordTextField.autocorrectionType = UITextAutocorrectionTypeNo;
    
    if ([self.navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        self.navigationController.interactivePopGestureRecognizer.enabled = NO;
    }
    
    AppDelegate *appDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    self.dbHelper = appDelegate.appDelegateDBHelper;
    
    self.navigationController.navigationBar.hidden = YES;
    
    [GAIHelper sendScreenWithName:@"LoginScreen"];
    
    [AppConfig stopAnimatingGif];
    
    
    // Display the app version string
    NSDictionary* infoDict = [[NSBundle mainBundle] infoDictionary];
    NSString* version = [infoDict objectForKey:@"CFBundleShortVersionString"];
    self.appversionTextLabel.text = [NSString stringWithFormat:@"App Version %@",version];
    
    
}
-(void)viewWillAppear:(BOOL)animated{
    
    [AppConfig stopAnimatingGif];
    
    [TapClass disableTimer];
    
    
    isloadAgentProfile = NO; //vrl
    
    [AppConfig resetGeneralJSONDictionary];
    [AppConfig resetAppConfig];
    [AppConfig resetPlanListArray];
    [AppConfig setcounty:@""];
    [AppConfig setCountyZipcode:@""];
    
    [super viewWillAppear:animated];
    self.usernameTextField.validatorString = @"EmptyValidator";
    self.passwordTextField.validatorString = @"EmptyValidator";
    [usernameTextField becomeFirstResponder];
    
    [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"DashboardView"];
    [[NSUserDefaults standardUserDefaults]synchronize];
}



- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    // unregister for keyboard notifications while not visible.
}

-(void)viewDidDisappear:(BOOL)animated {
    
    [super viewDidDisappear:animated];
}


- (void)viewDidAppear:(BOOL)animated
{
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(checkNetworkStatus:) name:kReachabilityChangedNotification object:nil];
    
    internetReachable = [Reachability reachabilityForInternetConnection];
    [internetReachable startNotifier];
    
    // check if a pathway to a random host exists
    hostReachable = [Reachability reachabilityWithHostName:@"www.google.com"];
    [hostReachable startNotifier];
    
}

#pragma mark Custom methods

- (void)startActivityIndicator
{
    [AppConfig showLoaderGif];
    
    //    activity = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    //    [activity setHidesWhenStopped:TRUE];
    //    [activity setAlpha:1.0];
    //    [activity setFrame:CGRectMake(self.view.frame.origin.x+self.view.frame.size.width /2, self.view.frame.origin.y+self.view.frame.size.height /2, activity.frame.size.width, activity.frame.size.height)];
    //    [self.view addSubview:activity];
    //    [activity startAnimating];
    
}

- (void)removeActivityIndicator
{
    [AppConfig stopAnimatingGif];
    //
    ////    [activity stopAnimating];
    ////    [activity removeFromSuperview];
}

-(void) checkNetworkStatus:(NSNotification *)notice
{
    
    
    // called after network status changes
    NetworkStatus internetStatus = [internetReachable currentReachabilityStatus];
    switch (internetStatus)
    {
        case NotReachable:
        {
            [[NSUserDefaults standardUserDefaults]setBool:NO forKey:@"isNetConnected"];
            
            [AppConfig setNetworkStatus:NO];
            break;
        }
        case ReachableViaWiFi:
        {
            [[NSUserDefaults standardUserDefaults]setBool:YES forKey:@"isNetConnected"];
            [AppConfig setNetworkStatus:YES];
            
            break;
        }
        case ReachableViaWWAN:
        {
            [[NSUserDefaults standardUserDefaults]setBool:YES forKey:@"isNetConnected"];
            [AppConfig setNetworkStatus:YES];
            
            break;
        }
    }
    
    NetworkStatus hostStatus = [hostReachable currentReachabilityStatus];
    switch (hostStatus)
    {
        case NotReachable:
        {
            [[NSUserDefaults standardUserDefaults]setBool:NO forKey:@"isNetConnected"];
            [AppConfig setNetworkStatus:NO];
            
            break;
        }
        case ReachableViaWiFi:
        {
            [[NSUserDefaults standardUserDefaults]setBool:YES forKey:@"isNetConnected"];
            [AppConfig setNetworkStatus:YES];
            
            break;
        }
        case ReachableViaWWAN:
        {
            [[NSUserDefaults standardUserDefaults]setBool:YES forKey:@"isNetConnected"];
            [AppConfig setNetworkStatus:YES];
            
            break;
        }
    }
    
    
    
    
}


-(void)callWebService {
    
    [self syncDB];
    
}
-(void)syncPDP :(id) handler {
    
    Callback *cacheCallback = [[Callback alloc]initWithCallbacks:^(id response,id operation,id handler){
                    PRINTLOG(@"PDP Response Success ::\n%@",response);
        
        
        [handler insertData:response template:@"insert into bcbs_pdp_plan values ('@plan@','@csv plan name@','@plan year@','@monthly premium@')"];
        [handler showTable:@"bcbs_pdp_plan"];
        
        [handler syncMAPD : handler];
        
        
        
    }:^(id response,id operation,id handler){
                    PRINTLOG(@"Response Failed ::\n%@",response);
        
        [handler removeActivityIndicator];
        if([[AppConfig ErrorResponseJSONSerialization:response] isKindOfClass:[NSMutableArray class]]){
            [handler errorMessageAlert:@"Error" message:[[AppConfig ErrorResponseJSONSerialization:response]objectAtIndex:0]];
            
        }else {
            [handler errorMessageAlert:@"Error" message:@"Unable to fetch data from server. Please try again"];
        }
        
    }:handler ];
    
  
//    [AppConfig testWrapper:PDP_PLAN_URL query:@"" callback:cacheCallback];
    
    GENERATESERVICE(PDP_PLAN_URL, @"", cacheCallback);
    
    
}

-(void)syncMAPD :(id) handler{
    
    Callback *cacheCallback = [[Callback alloc]initWithCallbacks:^(id response,id operation,id handler){
                        PRINTLOG(@"MAPD Response Success ::\n%@",response);
        
        
        [handler insertData:response template:@"insert into bcbs_mapd_plan values ('@plan@','@csv plan name@','@plan year@','@region@','@monthly premium@','@plan type@','@updated date@')"];
        
        [handler showTable:@"bcbs_mapd_plan"];
        
        [handler syncMEDIGAP : handler];
        
        
    }:^(id response,id operation,id handler){
                PRINTLOG(@"Response Failed ::\n%@",response);
        
        [handler removeActivityIndicator];
        if([[AppConfig ErrorResponseJSONSerialization:response] isKindOfClass:[NSMutableArray class]]){
            [handler errorMessageAlert:@"Error" message:[[AppConfig ErrorResponseJSONSerialization:response]objectAtIndex:0]];
            
        }else {
            [handler errorMessageAlert:@"Error" message:@"Unable to fetch data from server. Please try again"];
        }
        
    }:handler ];
    
   
//    [AppConfig testWrapper:MAPD_PLAN_URL query:@"" callback:cacheCallback];
    
    GENERATESERVICE(MAPD_PLAN_URL, @"", cacheCallback);
    
    
}


-(void)syncMEDIGAP :(id) handler{
    
    Callback *cacheCallback = [[Callback alloc]initWithCallbacks:^(id response,id operation,id ihandler){
        
                PRINTLOG(@"Medigap Response Success ::\n%@",response);
        //            [handler responseReceived:response];
        
        
        //old code
        //        [ihandler insertData:response template:@"insert into bcbs_medigap_plan values ('@plan@','@csv plan name@','@plan year@','@min age range@','@max age range@','@monthly premium@')"];
        
        [ihandler insertData:response template:@"insert into bcbs_medigap_plan values ('@plan@','@csv plan name@','@plan year@','@min age range@','@max age range@','@monthly premium@','@coverage code@')"];
        
        [ihandler showTable:@"bcbs_medigap_plan"];
        
        [ihandler syncDSNP: ihandler]; //newly added code for DSNP plan
        
        
    }:^(id response,id operation,id handler){
                PRINTLOG(@"Response Failed ::\n%@",response);
        
        [handler removeActivityIndicator];
        if([[AppConfig ErrorResponseJSONSerialization:response] isKindOfClass:[NSMutableArray class]]){
            [handler errorMessageAlert:@"Error" message:[[AppConfig ErrorResponseJSONSerialization:response]objectAtIndex:0]];
            
        }else {
            [handler errorMessageAlert:@"Error" message:@"Unable to fetch data from server. Please try again"];
        }
        
    }:handler ];
    
//    [AppConfig testWrapper:MEDIGAP_PLAN_URL query:@"" callback:cacheCallback];
    
    GENERATESERVICE(MEDIGAP_PLAN_URL, @"", cacheCallback);
    
}

-(void)syncDSNP :(id) handler{
    
    Callback *cacheCallback = [[Callback alloc]initWithCallbacks:^(id response,id operation,id ihandler){
                PRINTLOG(@"DSNP Response Success ::\n%@",response);
        
        [ihandler insertData:response template:@"insert into bcbs_dsnp_plan values ('@plan@','@csv plan name@','@plan year@','@monthly premium@','@updated date@','@plan type@','@county@')"];
        
        [ihandler showTable:@"bcbs_dsnp_plan"];
        
        [ihandler syncZIPCODE: ihandler];
        
    }:^(id response,id operation,id handler){
                PRINTLOG(@"Response Failed ::\n%@",response);
        
        [handler removeActivityIndicator];
        if([[AppConfig ErrorResponseJSONSerialization:response] isKindOfClass:[NSMutableArray class]]){
            [handler errorMessageAlert:@"Error" message:[[AppConfig ErrorResponseJSONSerialization:response]objectAtIndex:0]];
            
        }else {
            [handler errorMessageAlert:@"Error" message:@"Unable to fetch data from server. Please try again"];
        }
        
    }:handler ];
    
//    [AppConfig testWrapper:DSNP_PLAN_URL query:@"" callback:cacheCallback];
    
    GENERATESERVICE(DSNP_PLAN_URL, @"", cacheCallback);
    
    //NSString * plistPath =@"planlist";
    //NSString *path = [[NSBundle mainBundle] pathForResource: plistPath ofType: @"plist"];
    //NSDictionary *dict = [NSDictionary dictionaryWithContentsOfFile: path];
    //PRINTLOG(@"dsnp dict:%@", dict);
    //NSDictionary *responseDictionary = [dict objectForKey:DSNP_PLAN_URL];
    //PRINTLOG(@"dsnp response:%@", responseDictionary);
    
}


-(void)syncZIPCODE:(id) handler{
    
    Callback *cacheCallback = [[Callback alloc]initWithCallbacks:^(id response,id operation,id ihandler){
        
                PRINTLOG(@"Zipcode Response Success ::\n%@",response);
        
        
        [ihandler insertData:response template:@"insert into bcbs_zip_county_region_map values ('@zip@','@region@','@county@','@enroll_year@')"];
        
        [ihandler showTable:@"bcbs_zip_county_region_map"];
        
        [[NSUserDefaults standardUserDefaults]setObject:[AppConfig lastUpdatedDate] forKey:[AppConfig lastUpdated]];
        
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        [ihandler syncAgentProfile:ihandler];
        
        
    }:^(id response,id operation,id handler){
                PRINTLOG(@"Response Failed ::\n%@",response);
        
        [handler removeActivityIndicator];
        if([[AppConfig ErrorResponseJSONSerialization:response] isKindOfClass:[NSMutableArray class]]){
            [handler errorMessageAlert:@"Error" message:[[AppConfig ErrorResponseJSONSerialization:response]objectAtIndex:0]];
            
        }else {
            [handler errorMessageAlert:@"Error" message:@"Unable to fetch data from server. Please try again"];
        }
        
    }:handler ];
    
//    [AppConfig testWrapper:ZIPCODE_URL query:@"" callback:cacheCallback];
    GENERATESERVICE(ZIPCODE_URL, @"", cacheCallback);
}



-(void)syncAgentProfile:(id) handler {
    
    
    Callback *cacheCallback = [[Callback alloc]initWithCallbacks:^(id response,id operation,id ihandler){
                PRINTLOG(@"Agent Response ::\n%@",response);
        
        
        NSError *jsonError;
        NSData *objectData = [response dataUsingEncoding:NSUTF8StringEncoding];
        NSMutableDictionary *jsonData = [NSJSONSerialization JSONObjectWithData:objectData options:NSJSONReadingMutableContainers error:&jsonError];
        
        [AppConfig setAgentProfileInfo:jsonData];
        
        //        NSLog(@"agent profile ::%@",[AppConfig agentProfileInfo]);
        
        
        [ihandler removeActivityIndicator];
        [ihandler submitDatasuccess]; //old code
        
        
        
    }:^(id response,id operation,id handler){
        //        NSLog(@"Response Failed ::\n%@",response);
        [handler removeActivityIndicator];
        if([[AppConfig ErrorResponseJSONSerialization:response] isKindOfClass:[NSMutableArray class]]){
            [handler errorMessageAlert:@"Error" message:[[AppConfig ErrorResponseJSONSerialization:response]objectAtIndex:0]];
            
        }else {
            [handler errorMessageAlert:@"Error" message:@"Unable to fetch data from server. Please try again"];
        }
        
    }:handler ];

    NSString *urlstring = [NSString stringWithFormat:@"%@%@",AGENT_PROFILE_URL,[AppConfig getUserName]];
    
//    [AppConfig testWrapper:urlstring query:@"" callback:cacheCallback];
    
    GENERATESERVICE(urlstring, @"", cacheCallback);
    

}



-(void)insertData:(NSString *)jsonResponse template:(NSString*)template{
    
    
        PRINTLOG(@"%@  -- InsertData In",[[NSDate date]description]);
    
    PRINTLOG(@"JsonResponse:%@", jsonResponse);
    
    [self.dbHelper executeQuery:jsonResponse queryTemplate:template];
    
        PRINTLOG(@"%@  -- InsertData out",[[NSDate date]description]);
    
}
-(void)showTable:(NSString *)tableName{
    
    
    NSString *selectQuery = [NSString stringWithFormat:@"Select * from %@",tableName];
    NSArray *valueArray = [[NSArray alloc]initWithArray:[self.dbHelper loadDataFromDB:selectQuery]];
        PRINTLOG(@"Fetch - %@ -::%@",tableName,valueArray);
    
}
-(void)syncDB{
    
    Callback *cacheCallback = [[Callback alloc]initWithCallbacks:^(id response,id operation,id handler){
        
                PRINTLOG(@"check update Response Success ::\n%@",response);
        //        [handler responseReceived:response];
        
        NSError *jsonError;
        NSData *objectData = [response dataUsingEncoding:NSUTF8StringEncoding];
        NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                             options:NSJSONReadingMutableContainers
                                                               error:&jsonError];
        
        
        NSString* lastUpdated =  [[NSUserDefaults standardUserDefaults]objectForKey:[AppConfig lastUpdated]];
        
        
        if (![lastUpdated isEqualToString:[json objectForKey:[AppConfig lastUpdated]]]) {
            
            [AppConfig setLastUpdatedDate:[json objectForKey:[AppConfig lastUpdated]]];
            
            [handler deleteTables];
            [handler syncPDP:handler];
            
            //            [[NSUserDefaults standardUserDefaults]setObject:[json objectForKey:@"last_updated"] forKey:[AppConfig lastUpdated]];
            //            [[NSUserDefaults standardUserDefaults]synchronize];
            
            
        }else{
            
            [handler syncAgentProfile:handler];
        }
        
        PRINTLOG(@"standard ::%@",[[NSUserDefaults standardUserDefaults]objectForKey:[AppConfig lastUpdated]]);
    }:^(id response,id operation,id handler){
                PRINTLOG(@"Response Failed ::\n%@",response);
        
        [handler removeActivityIndicator];
        if([[AppConfig ErrorResponseJSONSerialization:response] isKindOfClass:[NSMutableArray class]]){
            [handler errorMessageAlert:@"Error" message:[[AppConfig ErrorResponseJSONSerialization:response]objectAtIndex:0]];
            
        }else {
            [handler errorMessageAlert:@"Error" message:@"Unable to fetch data from server. Please try again"];
        }
        //        [self errorMessageAlert:@"INFO" message:@"The Internet connection appears to be offline."];
        
        
    }:self ];
    
//    [AppConfig testWrapper:CHECK_UPDATE_URL query:@"" callback:cacheCallback];
    GENERATESERVICE(CHECK_UPDATE_URL, @"", cacheCallback);
  
  
}


-(void)deleteTables{
    
    
    NSString *createQuery = [NSString stringWithFormat:@"CREATE TABLE IF NOT EXISTS bcbs_pdp_plan(Plan_Name VARCHAR(50) NULL DEFAULT NULL,CSV_Plan_Name VARCHAR(50) NULL DEFAULT NULL,Plan_Year VARCHAR(50) NULL DEFAULT NULL,Monthly_Premium VARCHAR(50) NULL DEFAULT NULL)"];
    [self.dbHelper createQuery:createQuery];
    
    
    createQuery = [NSString stringWithFormat:@"CREATE TABLE IF NOT EXISTS bcbs_mapd_plan (Plan_name VARCHAR(50) NULL DEFAULT NULL,CSV_Plan_Name VARCHAR(50) NULL DEFAULT NULL,Plan_Year VARCHAR(50) NULL DEFAULT NULL,Region VARCHAR(50) NULL DEFAULT NULL,Monthly_Premium VARCHAR(50) NULL DEFAULT NULL,Plan_Type VARCHAR(50) NULL DEFAULT NULL,Updated VARCHAR(50) NULL DEFAULT NULL)"];
    [self.dbHelper createQuery:createQuery];
    
    //old code vrl
    //        createQuery = [NSString stringWithFormat:@"CREATE TABLE IF NOT EXISTS bcbs_medigap_plan (Plan_Name VARCHAR(50) NULL DEFAULT NULL,CSV_Plan_Name VARCHAR(50) NULL DEFAULT NULL,Plan_Year VARCHAR(50) NULL DEFAULT NULL,Min_Age_Range VARCHAR(50) NULL DEFAULT NULL,Max_Age_Range VARCHAR(50) NULL DEFAULT NULL,Monthly_Premium VARCHAR(50) NULL DEFAULT NULL)"];
    
    //vrl
    createQuery = [NSString stringWithFormat:@"CREATE TABLE IF NOT EXISTS bcbs_medigap_plan (Plan_Name VARCHAR(50) NULL DEFAULT NULL,CSV_Plan_Name VARCHAR(50) NULL DEFAULT NULL,Plan_Year VARCHAR(50) NULL DEFAULT NULL,Min_Age_Range VARCHAR(50) NULL DEFAULT NULL,Max_Age_Range VARCHAR(50) NULL DEFAULT NULL,Monthly_Premium VARCHAR(50) NULL DEFAULT NULL,Coverage_Code VARCHAR(50) NULL DEFAULT NULL)"];
    
    
    [self.dbHelper createQuery:createQuery];
    
    createQuery = [NSString stringWithFormat:@"CREATE TABLE IF NOT EXISTS bcbs_dsnp_plan (Plan_name VARCHAR(50) NULL DEFAULT NULL,CSV_Plan_Name VARCHAR(50) NULL DEFAULT NULL,Plan_Year VARCHAR(50) NULL DEFAULT NULL,Monthly_Premium VARCHAR(50) NULL DEFAULT NULL,Updated VARCHAR(50) NULL DEFAULT NULL,Plan_Type VARCHAR(50) NULL DEFAULT NULL,County VARCHAR(500) DEFAULT NULL)"];
    [self.dbHelper createQuery:createQuery];
    
    createQuery = [NSString stringWithFormat:@"CREATE TABLE IF NOT EXISTS bcbs_zip_county_region_map (Zip_Code VARCHAR(500) DEFAULT NULL,Region VARCHAR(50) DEFAULT NULL,County VARCHAR(50) DEFAULT NULL,Enroll_Year VARCHAR(50) DEFAULT NULL)"];
    
    [self.dbHelper createQuery:createQuery];
    
    NSString *deleteQuery = [NSString stringWithFormat:@"DELETE FROM bcbs_pdp_plan"];
    [self.dbHelper executeQuery:deleteQuery];
    
    deleteQuery = [NSString stringWithFormat:@"DELETE FROM bcbs_mapd_plan"];
    [self.dbHelper executeQuery:deleteQuery];
    
    
    deleteQuery = [NSString stringWithFormat:@"DELETE FROM bcbs_medigap_plan"];
    [self.dbHelper executeQuery:deleteQuery];
    
    deleteQuery = [NSString stringWithFormat:@"DELETE FROM bcbs_dsnp_plan"];
    [self.dbHelper executeQuery:deleteQuery];
    
    
    deleteQuery = [NSString stringWithFormat:@"DELETE FROM bcbs_zip_county_region_map"];
    [self.dbHelper executeQuery:deleteQuery];
    
}

-(void)responseReceived:(id)jsonResponse {
    
    PRINTLOG(@"JSON Response ::%@",jsonResponse);
    
            PRINTLOG(@"JSON Response ::%@",jsonResponse);
    
    
    [self.dbHelper executeQuery:jsonResponse queryTemplate:@"insert into bcbs_pdp_plan values ('@plan@','@csv plan name@','@plan year@','@monthly premium@')"];
    
    NSString *selectQuery = @"Select * from bcbs_pdp_plan";
    NSArray *valueArray = [[NSArray alloc]initWithArray:[self.dbHelper loadDataFromDB:selectQuery]];
    PRINTLOG(@"Fetch PDP::%@",valueArray);
    
    
    //    http://medicareuat.horizonbluestaging.com/restapi/v1/views/plans_ma
    //    [self.dbHelper executeQuery:jsonResponse queryTemplate:@"insert into bcbs_mapd_plan values ('@plan@','@csv plan name@','@plan year@','@region@''@monthly premium@','@plan type@','@updated date@')"];
    
    //        NSString *selectQuery = @"Select * from bcbs_mapd_plan";
    //        NSArray *valueArray = [[NSArray alloc]initWithArray:[self.dbHelper loadDataFromDB:selectQuery]];
    //        PRINTLOG(@"Fetch PDP::%@",valueArray);
    
    //      http://medicareuat.horizonbluestaging.com/restapi/v1/views/plans_medigap
    //    [self.dbHelper executeQuery:jsonResponse queryTemplate:@"insert into bcbs_medigap_plan values ('@plan@','@csv plan name@','@plan year@','@min age range@','@max age range@','@monthly premium@')"];
    
    
    [self.dbHelper executeQuery:jsonResponse queryTemplate:@"insert into bcbs_zip_county_region_map values ('@zip@','@region@','@county@')"];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)signIn:(id)sender {
    
        [usernameTextField resignFirstResponder];        //hiding keyboard after sign-in
        [_passwordTextField resignFirstResponder];         //hiding keyboard after sign-in
//
    //SIT
    usernameTextField.text = @"agent1";
    _passwordTextField.text = @"P@ssw0rd!@#";

    //UAT
//    usernameTextField.text = @"testagent";
//    _passwordTextField.text = @"P@ssw0rd!@#";
    
    isloadAgentProfile = NO; //vrl
    
    if([AppConfig getNetworkStatus]){
        
        BOOL hasError = NO;
        hasError |= !usernameTextField.validate;
        hasError |= !_passwordTextField.validate;
        
        if(!hasError) {
            
            //            [Validator ValidationDone]; // headItem
            
            [AppConfig setUserName:usernameTextField.text];
            //
            [self startActivityIndicator];
            
//            [self loginURL];   // Call login Webservice
            
            
            //directly move to dashboard page if not call login API
                        [self submitDatasuccess];
            
        }
        
    }else {
        self.usernameTextField.text = @"";
        self.passwordTextField.text = @"";
        
//        [self errorMessageAlert:@"INFO" message:@"The Internet connection appears to be offline."];
        //anitha added
        [AppConfig errorMessageAlert:@"INFO" message:@"The Internet connection appears to be offline." class:self];
    }
    
}


-(void)loginURL {
    
    __block LoginViewController *weakSelf = self;
    
    Callback *cacheCallback = [[Callback alloc]initWithCallbacks: ^(id response,id operation,id handler){
                PRINTLOG(@"login :::%@",response);
        NSError *jsonError;
        NSData *objectData = [response dataUsingEncoding:NSUTF8StringEncoding];
        NSMutableDictionary *jsonData = [NSJSONSerialization JSONObjectWithData:objectData options:NSJSONReadingMutableContainers error:&jsonError];
                PRINTLOG(@"Login response :::%@",jsonData);
        [AppConfig setUserLoginInfo:jsonData];
        [handler setUserIdForGA];
        
                PRINTLOG(@"header info ::%@",[AppConfig headerList]);
        
        [AppConfig setUserLoggedIn:YES];
        [handler callWebService];
        
    }:^(id response,id operation,id handler){
        
                PRINTLOG(@"login :::%@",response);
        [handler removeActivityIndicator];
        if([[AppConfig ErrorResponseJSONSerialization:response] isKindOfClass:[NSMutableArray class]]){
            [handler errorMessageAlert:@"Error" message:[[AppConfig ErrorResponseJSONSerialization:response]objectAtIndex:0]];
            
        }else {
            [handler errorMessageAlert:@"Error" message:@"Unable to fetch data from server. Please try again"];
        }
    }: weakSelf];
 
    NSMutableDictionary *loginCredentials = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                             usernameTextField.text,@"username",_passwordTextField.text,@"password",nil];

    JsonOperation *jOP = [[JsonOperation alloc]init];
    
    PRINTLOG(@"Login jop:%@", [jOP getJsonStringByDictionary:loginCredentials]);
    
//    [AppConfig testWrapper:LOGIN_URL query:[jOP getJsonStringByDictionary:loginCredentials] callback:cacheCallback];

//    NSString * plistPath =@"planlist";
//    NSString *path = [[NSBundle mainBundle] pathForResource: plistPath ofType: @"plist"];
//    NSDictionary *dict = [NSDictionary dictionaryWithContentsOfFile: path];
//    NSDictionary *responseDictionary = [dict objectForKey:LOGIN_URL];
//    PRINTLOG(@"key value:%@", [responseDictionary valueForKey:[jOP getJsonStringByDictionary:loginCredentials]]);
//    cacheCallback.onSuccess([responseDictionary valueForKey:[jOP getJsonStringByDictionary:loginCredentials]], nil, self);
    
    GENERATESERVICE(LOGIN_URL, [jOP getJsonStringByDictionary:loginCredentials] , cacheCallback);
  
}



-(void)setUserIdForGA{
    
    
    [GAIHelper setGAUserId:self.usernameTextField.text];
    
    self.usernameTextField.text = @"";
    self.passwordTextField.text = @"";
    
}




-(void)errorMessageAlert:(NSString *)title message:(NSString *)message {
    
    self.usernameTextField.text = @"";
    self.passwordTextField.text = @"";
    
    [self removeActivityIndicator];
    
    NSString *localizeTitle = [LanguageCentral languageSelectedString:title];
    NSString *titleString = (localizeTitle.length>0)?localizeTitle:title;
    
    
    NSString *localizeMessage = [LanguageCentral languageSelectedString:message];
    //    NSString *msgString;
    
    NSString *msgString  = localizeMessage; // new changes for display error message in pop view . issue fixes.
    
    
    if (([msgString rangeOfString:@"CSRF validation failed"].location == NSNotFound))
    {
        msgString = (localizeMessage.length>0)?localizeMessage:message;
        
    } else
    {
        msgString = @"Login Failed.Try again.";
    }
    
    UIAlertController *alertController = [UIAlertController
                                          alertControllerWithTitle:titleString
                                          message:msgString
                                          preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *okAction = [UIAlertAction
                               actionWithTitle:NSLocalizedString(@"OK", @"OK action")
                               style:UIAlertActionStyleDefault
                               handler:^(UIAlertAction *action)
                               {
                                   //NSLog(@"ok action");
                               }];
    
    [alertController addAction:okAction];
    
    [self presentViewController:alertController animated:YES completion:nil];
    
    
}


-(void)submitDatasuccess{
    
    /*  verify alert commented now, future we will handle
     
     NSString *alertTitle = @"Verification";
     
     NSString *alertMessage = @"\nWe have sent a temporary verification code to your registered mobile number.\n\n";
     
     NSString *alertOkButtonText = @"Verify";
     
     UILabel *testLabel = [[UILabel alloc]init];
     
     if (CURRENT_VERSION >=IOS9) {
     
     testLabel = [[UILabel alloc]initWithFrame:CGRectMake(20, 120, 120, 40)];
     testLabel.text = @"Verification Code";
     testLabel.font = [UIFont fontWithName:@"Arial" size:14];
     }else{
     testLabel = [[UILabel alloc]initWithFrame:CGRectMake(20, 100, 120, 40)];
     testLabel.text = @"Verification Code";
     testLabel.font = [UIFont fontWithName:@"Arial" size:14];
     //testLabel.textColor =[UIColor colorWithRed:65 green:65 blue:65 alpha:0];
     }
     
     
     UIAlertController *alert = [UIAlertController alertControllerWithTitle:alertTitle message:alertMessage preferredStyle:UIAlertControllerStyleAlert];
     [alert addAction:[UIAlertAction actionWithTitle:alertOkButtonText style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
     
     [UINavigationQueue pushClass:[DashboardBaseViewController class] containerVC:[DashboardViewController class] xibName:nil];
     
     [UINavigationQueue showNext:self];
     
     
     }]];
     [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
     //        textField.placeholder = @"Enter text:";
     textField.secureTextEntry = YES;
     }];
     [alert.view addSubview:testLabel];
     [self presentViewController:alert animated:YES completion:nil];
     
     */
    
    if(!isloadAgentProfile){
        isloadAgentProfile = YES;
        [TapClass sharedInstance].remainingTime = LOGOUT_TIMER;
        
        [Validator ValidationDone];
        [UINavigationQueue pushClass:[DashboardBaseViewController class] containerVC:[DashboardViewController class] xibName:nil];
        
        [UINavigationQueue showNext:self];
    }
    
}



- (IBAction)resetPassword:(id)sender {
    
    
    UIStoryboard *storyboard;
    
    storyboard = [UIStoryboard storyboardWithName:@"Main" bundle: nil];
    
    
    ResetPasswordViewController*  resetPasswordView = [storyboard instantiateViewControllerWithIdentifier:@"ResetPasswordViewController"];
    
    //        [self.navigationController pushViewController:resetPasswordView animated:NO];
    
    CATransition* transition = [CATransition animation];
    transition.duration = 0.25f;
    transition.type = kCATransitionFade;
    transition.subtype = kCATransitionFromTop;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:resetPasswordView animated:NO];
    
}



@end
