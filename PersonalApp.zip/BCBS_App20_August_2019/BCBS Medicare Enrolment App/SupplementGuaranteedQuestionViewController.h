//
//  SupplementGuaranteedQuestionViewController.h
//  BCBS Medicare Enrolment App
//
//  Created by CSS Admin on 6/22/18.
//  Copyright © 2018 CSS Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>

@interface SupplementGuaranteedQuestionViewController : UIBaseContainerViewController

@property (strong, nonatomic) IBOutlet ValidatorLabel *titleString;
@property (strong, nonatomic) IBOutlet UIView *view1;

@end
