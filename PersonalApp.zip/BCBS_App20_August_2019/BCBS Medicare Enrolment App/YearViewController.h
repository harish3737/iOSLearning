//
//  YearViewController.h
//  BcBs
//
//  Created by CSS Corp on 11/05/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>

@interface YearViewController :UIBaseContainerViewController
- (IBAction)currentYearButtonAction:(id)sender;
- (IBAction)nextYearButtonAction:(id)sender;
@property (strong, nonatomic) IBOutlet ValidatorLabel *titleString;
@property (strong, nonatomic) IBOutlet UIButton *buttonCurrentYear;
@property (strong, nonatomic) IBOutlet UIButton *buttonNextYear;

@end
