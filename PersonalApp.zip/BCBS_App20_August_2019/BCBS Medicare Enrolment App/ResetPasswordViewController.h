//
//  ResetPasswordViewController.h
//  BcBs
//
//  Created by CSS Corp on 10/05/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>

@interface ResetPasswordViewController : UIViewController<UITextFieldDelegate>

- (IBAction)resetPassword:(id)sender;
- (IBAction)backToSignIn:(id)sender;
@property (weak, nonatomic) IBOutlet ValidatorTextField *usernameTextField;
@property (weak, nonatomic) IBOutlet ValidatorTextField *emailaddressTextField;
@property (strong, nonatomic) IBOutlet UIScrollView *scrollView;

@end
