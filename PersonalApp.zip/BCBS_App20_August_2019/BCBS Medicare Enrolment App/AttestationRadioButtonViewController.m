//
//  AttestationRadioButtonViewController.m
//  SampleBCBSPOC
//
//  Created by CSS Admin on 6/1/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import "AttestationRadioButtonViewController.h"
#import "PersonalFormTableViewCell.h"
#import "AppConfig.h"
#import "ScopeBaseViewController.h"


#define REDCOLOR [UIColor colorWithRed:240.0/255.0 green:108.0/255.0 blue:108.0/255.0 alpha:1.0f]


@interface AttestationRadioButtonViewController (){
    
}

//vrl
//@property (nonatomic,strong) UICheckBoxGrouped *getHeadItem;

@property (nonatomic,strong) id getHeadItem;

@end

@implementation AttestationRadioButtonViewController
@synthesize detailLabel,pleaseSelectLabel,getHeadItem;

@synthesize groupedItemsArray;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
	
	
      _titleString.text = [NSString stringWithFormat:@"%@ %@ - \n%@",[AppConfig enrollYear],[LanguageCentral languageSelectedString:[[AppConfig currentPlanDictionary] objectForKey:@"PlanTitle"]],[LanguageCentral languageSelectedString:[[[AppConfig currentPlanDictionary] objectForKey:NSStringFromClass([self class])]objectForKey:@"title"]]];
    PRINTLOG(@"%lu",(unsigned long)[[AppConfig progressTitleArray]count]);
    // vrl for add new DSNP Attestation
     if(([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"]) && [[AppConfig progressTitleArray]count]>4){
    
        [self.sharedataObj setForwardNextButtonTitle:@"Next"];
        [self.sharedataObj setNextProgressIndex:3]; //6
        
        [self.sharedataObj setPreviousNextButtonTitle:@"Next"];
        [self.sharedataObj setBackProgressIndex:3];
        
    }else {
        //original code
        [self.sharedataObj setForwardNextButtonTitle:@"Next"];
        [self.sharedataObj setNextProgressIndex:4];
        
        [self.sharedataObj setPreviousNextButtonTitle:@"Continue_to_authorization"];
        [self.sharedataObj setBackProgressIndex:4];
    }
    
  
	
	
	if ([[AppConfig currentPlan]isEqualToString:@"PDP"]) {
		
		[detailLabel setLocalizationKey: @"TYPICALLY_YOU_MAY_ENROLL"];
        
        NSString *substring = @"Typically, you may enroll in a Medicare Prescription Drug Plan only during the annual enrollment period from October 15 through December 7 of each year.";
        
        NSRange range = [self.detailLabel.text rangeOfString:substring];
        
        NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc]initWithString:self.detailLabel.text];
        
        [attributedString setAttributes:@{NSFontAttributeName:[UIFont fontWithName:@"Arial-BoldMT" size:18.0]} range:range];
        
        self.detailLabel.attributedText = attributedString;
		
		
	}
	
	if ([[AppConfig currentPlan]isEqualToString:@"MAPD"]) {
		
		detailLabel.localizationKey= @"ENROLL_IN_MEDICARE";
        
        NSString *substring = @"Typically, you may enroll in a Medicare Advantage plan only during the annual enrollment period from October 15 through December 7 of each year.";
        
        NSRange range = [self.detailLabel.text rangeOfString:substring];
        
        NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc]initWithString:self.detailLabel.text];
        
        [attributedString setAttributes:@{NSFontAttributeName:[UIFont fontWithName:@"Arial-BoldMT" size:18.0]} range:range];
        
        self.detailLabel.attributedText = attributedString;
		
		
	}
//    if([AppConfig enrollYear]isEqualToString:@"2019")
//    {
//        
//    }
//    else
        
	if ([[AppConfig currentPlan]isEqualToString:@"SupplementUnder50"]){
		
		detailLabel.localizationKey = @"REVIEWED_YOUR_INSURANCE";
	}
	
	if ([[AppConfig currentPlan]isEqualToString:@"Supplement Plan 50-64"]){
		
		detailLabel.localizationKey=@"REVIEWED_YOUR_INSURANCE";
		
	}
	if ([[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"]){
		
		detailLabel.localizationKey=@"REVIEWED_YOUR_INSURANCE";
		
	}
    // vrl for add new DSNP Attestation
    if([[AppConfig currentPlan]isEqualToString:@"DSNP"]) {
        
        detailLabel.localizationKey=@"DSNP_ATTESTATION_2019_TYPICALLY_YOU_MAY_ENROLL";
        
        NSString *substring = @"Typically, you may enroll in a Medicare Advantage plan only during the annual enrollment period from October 15 through December 7 of each year.";
        
        NSRange range = [self.detailLabel.text rangeOfString:substring];
        
        NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc]initWithString:self.detailLabel.text];
        
         [attributedString setAttributes:@{NSFontAttributeName:[UIFont fontWithName:@"Arial-BoldMT" size:18.0]} range:range];
        
        self.detailLabel.attributedText = attributedString;
        
    }

	 [UIRenderer renderPlist:self plist:[NSString stringWithFormat:@"%@RadioButtonForm%@",[AppConfig currentPlan],[AppConfig enrollYear]]];

}




-(void)addCustomJsonValue {
    
    /*
	UIRadioButton *tempheadItem = getHeadItem;
	
	while (getHeadItem!=nil) {
		
		
		if([getHeadItem isKindOfClass:[UIRadioButton class]] && [getHeadItem.groupName isEqualToString:@"ATTESTATION"]){
			
			[AppConfig fillJSONDictionary:getHeadItem.xPath value:@"No"];
		}else if([getHeadItem isKindOfClass:[UIDropDown class]]){
			[AppConfig fillJSONDictionary:getHeadItem.xPath value:@""];
		}
		getHeadItem = [getHeadItem getNextField];
		
	}
	
	[AppConfig fillJSONDictionary:[tempheadItem getActiveButton].xPath value:@"Yes"];
	
	for (id subObj in [tempheadItem getActiveButton].superview.subviews){
		
		if([subObj isKindOfClass:[UILabeledButton class]]){
			UILabeledButton *labelBtnObj = subObj;
			//PRINTLOG(@"DropDown ::%@",labelBtnObj.dropDownCustomView.dropDownTextLabel.text);
            if([labelBtnObj.dropDownCustomView.dropDownTextLabel.text isEqualToString:@"Select"]){
                [AppConfig fillJSONDictionary:labelBtnObj.dropDownCustomView.xPath value:@""];
            }else {
                [AppConfig fillJSONDictionary:labelBtnObj.dropDownCustomView.xPath value:labelBtnObj.dropDownCustomView.dropDownTextLabel.text];
            }
			
		}
	}
     */
    
     //MAPD,PDP,DSNP 2019 plans
     if(![[AppConfig currentPlan] containsString:@"Supplement"] && ([[AppConfig enrollYear] isEqualToString:@"2019"] ||[[AppConfig enrollYear] isEqualToString:@"2020"])){
         
     }else {  // Not MAPD,PDP,DSNP 2019 plans
         
         UIRadioButton *tempheadItem = getHeadItem;
         
         while (getHeadItem!=nil) {
             
             
             if([getHeadItem isKindOfClass:[UIRadioButton class]] && [[getHeadItem groupName] isEqualToString:@"ATTESTATION"]){
                 
                 [AppConfig fillJSONDictionary:[getHeadItem xPath] value:@"No"];
             }else if([getHeadItem isKindOfClass:[UIDropDown class]]){
                 [AppConfig fillJSONDictionary:[getHeadItem xPath] value:@""];
             }
             getHeadItem = [getHeadItem getNextField];
             
         }
         
         [AppConfig fillJSONDictionary:[tempheadItem getActiveButton].xPath value:@"Yes"];
         
         for (id subObj in [tempheadItem getActiveButton].superview.subviews){
             
             if([subObj isKindOfClass:[UILabeledButton class]]){
                 UILabeledButton *labelBtnObj = subObj;
                 PRINTLOG(@"DropDown ::%@",labelBtnObj.dropDownCustomView.dropDownTextLabel.text);
                 if([labelBtnObj.dropDownCustomView.dropDownTextLabel.text isEqualToString:@"Select"]){
                     [AppConfig fillJSONDictionary:labelBtnObj.dropDownCustomView.xPath value:@""];
                 }else {
                     [AppConfig fillJSONDictionary:labelBtnObj.dropDownCustomView.xPath value:labelBtnObj.dropDownCustomView.dropDownTextLabel.text];
                 }
                 
             }
         }
     }
}

-(BOOL)validateVC {
	
    getHeadItem = [Validator headItem];
    
    //MAPD,PDP,DSNP 2019 plans
    if(![[AppConfig currentPlan] containsString:@"Supplement"] && ([[AppConfig enrollYear] isEqualToString:@"2019"] ||[[AppConfig enrollYear] isEqualToString:@"2020"])){
        
        if([[self anyCheckBoxSelectedArray]count]>0){
            return NO;
        }else {
            pleaseSelectLabel.textColor =  REDCOLOR;
            return YES;
        }
        
    }else {
        
        if([getHeadItem getActiveButton]!=nil){
            return NO;
            
        }else {
            pleaseSelectLabel.textColor =  REDCOLOR;
            return YES;
        }
    }
	
}

-(void)loadNextPage {
    
     if(![[AppConfig currentPlan] containsString:@"Supplement"] && ([[AppConfig enrollYear] isEqualToString:@"2019"] ||[[AppConfig enrollYear] isEqualToString:@"2020"])){
          //MAPD,PDP,DSNP 2019 plans
     }else {
          [self addCustomJsonValue]; //other plans & 2018 all plans
     }
   
}



-(void)viewWillAppear:(BOOL)animated {
    
    [AppConfig showLoaderGif];
    
    [ScopeBaseViewController populateCurrentItemValue];
    [self loadBackData];
    
     //MAPD,PDP,DSNP 2019 plans
    if(![[AppConfig currentPlan] containsString:@"Supplement"] && ([[AppConfig enrollYear] isEqualToString:@"2019"] ||[[AppConfig enrollYear] isEqualToString:@"2020"])){
        [self getAttesationSubViewItems]; //newly added
    }
  
    [super viewWillAppear:animated];
}

-(void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
    [AppConfig stopAnimatingGif];
    
}

-(void)getAttesationSubViewItems {
    
    if (groupedItemsArray==nil){
        groupedItemsArray = [[NSMutableArray alloc]init];
    }
    
    NSPredicate *shortNamePredicate = [NSPredicate predicateWithBlock:^BOOL(id evaluatedObject, NSDictionary *bindings) {
        return ([evaluatedObject isKindOfClass:[UICheckBoxGroupedButtonWithOptions class]] || [evaluatedObject isKindOfClass:[UICheckBoxGroupedWithButton class]]);
    }];
    
    groupedItemsArray = [NSMutableArray arrayWithArray:[self.radioButtonView.subviews filteredArrayUsingPredicate:shortNamePredicate]];
    
}


-(NSArray *)anyCheckBoxSelectedArray {
    
    
    NSPredicate *groupNamePredicate = [NSPredicate predicateWithFormat:@"SELF.checkBoxButton.isRadioButtonSelected == YES"];
    
    PRINTLOG(@"Selected checkBox Count :: %lu",[[groupedItemsArray filteredArrayUsingPredicate:groupNamePredicate]count]);
    
    return [groupedItemsArray filteredArrayUsingPredicate:groupNamePredicate];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
