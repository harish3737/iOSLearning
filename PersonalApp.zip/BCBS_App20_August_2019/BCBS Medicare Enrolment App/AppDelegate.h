//
//  AppDelegate.h
//  BCBS Medicare Enrolment App
//
//  Created by CSS Corp on 17/05/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>
#import "GAI.h"


@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong,nonatomic) DBHelper *appDelegateDBHelper;



@end

