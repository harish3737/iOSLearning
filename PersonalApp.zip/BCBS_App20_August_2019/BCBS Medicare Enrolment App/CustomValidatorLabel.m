//
//  CustomValidatorLabel.m
//  BCBS Medicare Enrolment App
//
//  Created by CSS CORP on 02/07/18.
//  Copyright © 2018 CSS Corp. All rights reserved.
//

#import "CustomValidatorLabel.h"
#import "AppConfig.h"

@implementation CustomValidatorLabel



- (void)drawRect:(CGRect)rect {
    // Drawing code
    [super drawRect:rect];
    
    
}

-(void)setCustomTextKey:(NSString *)customTextKey {
    
    super.customTextKey = customTextKey;
    
    NSString *contentString = ([customTextKey containsString:@"tempJSON"])?[AppConfig getValueFromXpath:[AppConfig tempCurrentPlanJSONDictionary] :customTextKey]:[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :customTextKey];
    self.text = (contentString.length>0)?contentString:@"-";
    
}



@end
