//
//  MedigapStaticInfoViewController.h
//  BCBS Medicare Enrolment App
//
//  Created by Ganesh on 03/08/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>

@interface MedigapStaticInfoViewController : UIBaseContainerViewController


@property (strong, nonatomic) IBOutlet ValidatorLabel *titleString;
//svk added  05/08
@property (strong, nonatomic) IBOutlet ValidatorLabel *readInfo;
@property (strong, nonatomic) IBOutlet ValidatorLabel *dontNeedMore;
@property (strong, nonatomic) IBOutlet ValidatorLabel *needMultipleCoverage;
@property (strong, nonatomic) IBOutlet ValidatorLabel *benefitsUnderMedicaid;
@property (weak, nonatomic) IBOutlet ValidatorLabel *afterPurchasingLabel;
@property (weak, nonatomic) IBOutlet ValidatorLabel *policyDisabilityLabel;
@property (weak, nonatomic) IBOutlet ValidatorLabel *counselingLabel;
@property (strong, nonatomic) IBOutlet ValidatorLabel *readInfoTitle;

//changeLocalizationKey 2020
@property (strong, nonatomic) IBOutlet ValidatorLabel *eligibleToApply;
@property (strong, nonatomic) IBOutlet ValidatorLabel *ifYouLost;

//Bulletins
@property (strong, nonatomic) IBOutlet UILabel *A;
@property (strong, nonatomic) IBOutlet UILabel *B;
@property (strong, nonatomic) IBOutlet UILabel *C;
@property (strong, nonatomic) IBOutlet UILabel *D;
@property (strong, nonatomic) IBOutlet UILabel *E;
@property (strong, nonatomic) IBOutlet UILabel *F;


//change constraint to 21
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *guaranteedAcceptanceConstraint;




@end
