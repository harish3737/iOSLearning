//
//  CheckListViewController.m
//  BCBS Medicare Enrolment App
//
//  Created by CSS Corp on 15/06/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "CheckListViewController.h"
#import "AppConfig.h"
#import "UINavigationHelper.h"
#import "ScopeBaseViewController.h"

static id headItem;

#define DETAILTEXTCOLOR [UIColor colorWithRed:(102.0/255.0) green:(102.0/255.0) blue:(102.0/255.0) alpha:1.0f]

@interface CheckListViewController ()

@property (nonatomic,strong) UIRadioButton *parentRadioBtn1;
@property (nonatomic,strong) UIRadioButton *parentRadioBtn2;
@property (nonatomic,strong) UIRadioButton *radioBtn1;
@property (nonatomic,strong) UIRadioButton *radioBtn2;

@end

@implementation CheckListViewController
@synthesize dateView,agentNameLabel,beneficiaryName;
@synthesize radioBtn1,radioBtn2,parentRadioBtn1,parentRadioBtn2;

- (void)viewDidLoad {
	[super viewDidLoad];
	// Do any additional setup after loading the view.
	
	_titleString.localizationKey = @"CHECKLIST_FORM";
	
	self.explanationTextView.layer.borderColor = [UIColor lightGrayColor].CGColor;
	self.explanationTextView.layer.borderWidth = 1.0f;
	
	dateView.dropDownImageView.hidden = YES;
	NSDate *todayDate = [NSDate date];
	NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
	dateFormatter.dateFormat = @"MM/dd/yyyy";
	[self.dateView setTitleString:[dateFormatter stringFromDate:todayDate]];
	
	self.agentSignature.validatorString =@"AlphabetValidator";
	
	[UIRenderer renderPlist:self plist:@"CheckListForm"];
	
	
	if([AppConfig planPlistArray].count>1){
        
        //old code
//        [self.sharedataObj setForwardNextButtonTitle:@"Next"];
//        [self.sharedataObj setNextProgressIndex:5];
        
        if([[AppConfig currentPlan] containsString:@"Supplement"] && [[AppConfig enrollYear] isEqualToString:@"2019"]){
            //new code for Preview section vrl
            [self.sharedataObj setForwardNextButtonTitle:@"Preview"];
        }else {
           [self.sharedataObj setForwardNextButtonTitle:@"Next"];
        }
        [self.sharedataObj setNextProgressIndex:5];
        //
		
		[self.sharedataObj setPreviousNextButtonTitle:@"Next"];
		[self.sharedataObj setBackProgressIndex:5];
		
		
	}else if([[AppConfig currentPlan] isEqualToString:@"DSNP"]) {
		//vrl added for new DsNP attestation
         if(([[AppConfig enrollYear] isEqualToString:@"2019"] ||[[AppConfig enrollYear] isEqualToString:@"2020"]) && [[AppConfig progressTitleArray]count]>4){
            [self.sharedataObj setForwardNextButtonTitle:@"Submit_application"];
            [self.sharedataObj setNextProgressIndex:4];
            
            [self.sharedataObj setPreviousNextButtonTitle:@"Next"];
            [self.sharedataObj setBackProgressIndex:4];
        }else {
            [self.sharedataObj setForwardNextButtonTitle:@"Submit_application"];
            [self.sharedataObj setNextProgressIndex:3];
            
            [self.sharedataObj setPreviousNextButtonTitle:@"Next"];
            [self.sharedataObj setBackProgressIndex:3];
        }
		
		
	}else {
		
        //old code
//        [self.sharedataObj setForwardNextButtonTitle:@"Submit_application"];
//        [self.sharedataObj setNextProgressIndex:5];
		
        if([[AppConfig currentPlan] containsString:@"Supplement"] && ([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"])){
            // new code for preview by vrl
            [self.sharedataObj setForwardNextButtonTitle:@"Preview"];
        }else {
            [self.sharedataObj setForwardNextButtonTitle:@"Submit_application"];
        }
        [self.sharedataObj setNextProgressIndex:5];
        
		[self.sharedataObj setPreviousNextButtonTitle:@"Next"];
		[self.sharedataObj setBackProgressIndex:5];
	}
	

	self.willBackPage = ^(id data){
		
		if([AppConfig planPlistArray].count>1){
			
			[AppConfig clearProgressInfo];
			[AppConfig DecrementPlanIndex];
			[AppConfig loadProgressInfo];
			
		}
	};
	
	self.willLoadNext = ^(id data){
		if([AppConfig planPlistArray].count>1){
			[AppConfig IncrementPlanIndex];
			[AppConfig loadProgressInfo];
			[UINavigationQueue deleteAfter:[ScopeBaseViewController class] container:[CheckListViewController class] xib:nil];
			[UINavigationHelper addSupplementScreens];
		}else {
			[UINavigationHelper addEmailSubmissionScreen];
		}
	};
	

	
	int i=0;
	while ([UIRenderer getComponentAtIndex:i]!=nil) {
		
		if([[UIRenderer getComponentAtIndex:i] isKindOfClass:[UIRadioButton class]]){
			
			if([[UIRenderer getComponentAtIndex:i]tag]==1){
				parentRadioBtn1 = [UIRenderer getComponentAtIndex:i];
			}else if([[UIRenderer getComponentAtIndex:i]tag]==2){
				parentRadioBtn2 = [UIRenderer getComponentAtIndex:i];
			}else if([[UIRenderer getComponentAtIndex:i]tag]==3){
				radioBtn1 = [UIRenderer getComponentAtIndex:i];
			}else if([[UIRenderer getComponentAtIndex:i]tag]==4){
				radioBtn2 = [UIRenderer getComponentAtIndex:i];
			}else {
				
			}
		}
		i++;
	}
    
	parentRadioBtn1.parent = self;
	
	parentRadioBtn1.actionblock = ^(id sender, id parent){
		
		[parent enableRadioButtonSubView];
		
	};
	
	
	parentRadioBtn2.parent = self;
	
	parentRadioBtn2.actionblock = ^(id sender, id parent){
		
		[parent disableRadioButtonSubView];
		
	};
	
	_view5.userInteractionEnabled = NO;
}

-(void)enableRadioButtonSubView {
	
	_view5.userInteractionEnabled = YES;
	[radioBtn1 setUserInteractionEnabled:YES];
	[radioBtn2 setUserInteractionEnabled:YES];
	
}

-(void)disableRadioButtonSubView{
	

	[radioBtn1 resetByGroupName:@"RADIOFORM"];
	
	_view5.userInteractionEnabled = NO;
	
	[radioBtn1 setUserInteractionEnabled:NO];
	[radioBtn2 setUserInteractionEnabled:NO];
	
	[self changeRadioBtnTextColor];

}

-(void)changeRadioBtnTextColor {
	
	UIView* radioBtn1SuperView =  [radioBtn1 superview];
	NSArray *superviewArray1 = [radioBtn1SuperView subviews];
	
	NSString *multilingualBtn1 = NSStringFromClass([[superviewArray1 objectAtIndex:1] class]);
	if([multilingualBtn1 isEqualToString:@"UIMultiLingualButton"]){
		UIMultiLingualButton *subcontentBtn1 = [superviewArray1 objectAtIndex:1];
		[subcontentBtn1 setTitleColor:DETAILTEXTCOLOR forState:UIControlStateNormal];
	}
	
	
	UIView* radioBtn2SuperView =  [radioBtn2 superview];
	NSArray *superviewArray2 = [radioBtn2SuperView subviews];
	
	
	NSString *multilingualBtn2 = NSStringFromClass([[superviewArray2 objectAtIndex:1] class]);
	if([multilingualBtn2 isEqualToString:@"UIMultiLingualButton"]){
		UIMultiLingualButton *subcontentBtn2 = [superviewArray2 objectAtIndex:1];
		[subcontentBtn2 setTitleColor:DETAILTEXTCOLOR forState:UIControlStateNormal];
	}
}



-(void)viewWillAppear:(BOOL)animated {
	
	[ScopeBaseViewController populateCurrentItemValue];
	[self loadBackData];
	[super viewWillAppear:animated];
	
	NSDictionary *dictionary = [AppConfig agentProfileInfo];
	NSString *firstLastName = [NSString stringWithFormat:@"%@ %@",[[dictionary valueForKey:@"first_name"]objectAtIndex:0],[[dictionary valueForKey:@"last_name"]objectAtIndex:0]];
	
	[agentNameLabel setLocalizationKey:firstLastName];
	
	NSString *beneficiaryNameValue = [NSString stringWithFormat:@"%@ %@ %@",[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:personal_info:first_name"],[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:personal_info:middle_initial"],[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:personal_info:last_name"]];
	

	
	beneficiaryName.text = beneficiaryNameValue;
}

- (void)didReceiveMemoryWarning {
	[super didReceiveMemoryWarning];
	// Dispose of any resources that can be recreated.
}

// remove copy,paste,select option for textfield text
- (BOOL)canPerformAction:(SEL)action withSender:(id)sender
{
    
    if (action == @selector(paste:) ||
        action == @selector(cut:) ||
        action == @selector(copy:) ||
        action == @selector(select:) ||
        action == @selector(selectAll:) ||
        action == @selector(delete:) ||
        action == @selector(makeTextWritingDirectionLeftToRight:) ||
        action == @selector(makeTextWritingDirectionRightToLeft:) ||
        action == @selector(toggleBoldface:) ||
        action == @selector(toggleItalics:) ||
        action == @selector(toggleUnderline:)
        ) {
        UIPasteboard *pb = [UIPasteboard generalPasteboard];
        [pb setValue:@"" forPasteboardType:UIPasteboardNameGeneral];
        
        return NO;
    }
    return [super canPerformAction:action withSender:sender];
    
}


- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
	
	[self.view endEditing:YES];
	[super touchesBegan:touches withEvent:event];
}


- (BOOL)textViewShouldBeginEditing:(UITextView *)textView{
	
	return YES;
}

- (void)textViewDidBeginEditing:(UITextView *)textView {
	
	if([textView.text isEqualToString:@"Enter Text here..."]){
		textView.text = @"";
	}
    
	self.explanationTextView = textView;
    // hide custom language keyboard letters in keyboard
    if([textView keyboardType]==UIKeyboardTypeNumberPad|| [textView keyboardType]==UIKeyboardTypePhonePad ){
    }else {
        textView.keyboardType = UIKeyboardTypeASCIICapable;
    }

}


- (BOOL)textViewShouldEndEditing:(UITextView *)textView{
	
	return YES;
}

- (void)textViewDidEndEditing:(UITextView *)textView{
	
	self.explanationTextView = nil;
}


- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
	
	
	return YES;
}
- (void)textViewDidChange:(UITextView *)textView{
	if([textView.text isEqualToString:@"Enter Text here..."]){
		textView.text = @"";
	}

}


- (void)textViewDidChangeSelection:(UITextView *)textView{
	
}



-(void)loadNextPage {
	
	
	UIRadioButton *parentRadioBtn = [parentRadioBtn1 getActiveButtonByGroupName:@"CHECKFORM"];
	
	 [AppConfig setTempJSONDictionary:[AppConfig setValue:[AppConfig tempCurrentPlanJSONDictionary] :@"tempJSON:data:attestation:soa_confirm_attached" :[NSString stringWithFormat:@"%ld",(long)parentRadioBtn.tag]]];
	
	
    UIRadioButton *getRadioBtn = [radioBtn1 getActiveButtonByGroupName:@"RADIOFORM"];
	
    [AppConfig setTempJSONDictionary:[AppConfig setValue:[AppConfig tempCurrentPlanJSONDictionary] :@"tempJSON:data:attestation:soa_confirm_selected" :[NSString stringWithFormat:@"%ld",(long)getRadioBtn.tag]]];
	
	if([_explanationTextView.text isEqualToString:@"Enter Text here..."]){
		
		[AppConfig setTempJSONDictionary:[AppConfig setValue:[AppConfig tempCurrentPlanJSONDictionary] :@"tempJSON:data:additional_info:explainText" :@""]];
	}else{		
		[AppConfig setTempJSONDictionary:[AppConfig setValue:[AppConfig tempCurrentPlanJSONDictionary] :@"tempJSON:data:additional_info:explainText" :_explanationTextView.text]];
	}
	
	
	[AppConfig setTempJSONDictionary:[AppConfig setValue:[AppConfig tempCurrentPlanJSONDictionary] :@"tempJSON:data:additional_info:agentsign" :_agentSignature.text]];

}

-(void)loadBackData {
	
	
	NSString *appointmentStr = [AppConfig getValueFromXpath:[AppConfig tempCurrentPlanJSONDictionary]:@"tempJSON:data:attestation:soa_confirm_attached"];
	
	
	if([appointmentStr isEqualToString:@"1"]){
		[parentRadioBtn1 setRadioButtonSelected:YES];
	}else if([appointmentStr isEqualToString:@"2"]){
		[parentRadioBtn2 setRadioButtonSelected:YES];
	}else {
		
	}

	
    NSString *radioBtnNumber = [AppConfig getValueFromXpath:[AppConfig tempCurrentPlanJSONDictionary]:@"tempJSON:data:attestation:soa_confirm_selected"];

	
    if([radioBtnNumber isEqualToString:@"3"]){
        [radioBtn1 setRadioButtonSelected:YES];
    }else if([radioBtnNumber isEqualToString:@"4"]){
        [radioBtn2 setRadioButtonSelected:YES];
    }else {
        
    }
	
	if([[AppConfig getValueFromXpath:[AppConfig tempCurrentPlanJSONDictionary] :@"tempJSON:data:additional_info:explainText"] isEqualToString:@""] || 
	   [AppConfig getValueFromXpath:[AppConfig tempCurrentPlanJSONDictionary] :@"tempJSON:data:additional_info:explainText"] == nil){

		_explanationTextView.text = @"Enter Text here...";
		
	}else{
		
_explanationTextView.text = [AppConfig getValueFromXpath:[AppConfig tempCurrentPlanJSONDictionary] :@"tempJSON:data:additional_info:explainText"];
	}
	
	if(![[AppConfig getValueFromXpath:[AppConfig tempCurrentPlanJSONDictionary] :@"tempJSON:data:additional_info:agentsign"] isEqualToString:@""]){
		_agentSignature.text = [AppConfig getValueFromXpath:[AppConfig tempCurrentPlanJSONDictionary] :@"tempJSON:data:additional_info:agentsign"];
	}else {
		_agentSignature.text = @"";
	}
	
}


@end
