//
//  ScopeView3.h
//  Autolayout
//
//  Created by CSS Corp on 02/05/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>

@interface ScopeView4 : UIView


@property (strong, nonatomic) IBOutlet ScopeView4 *scopeContentView4;

@end
