//
//  UIHeaderLabelEditButtonView.h
//  CSSUIFramwork
//
//  Created by CSS CORP on 27/06/18.
//  Copyright © 2018 csscorp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>

IB_DESIGNABLE

typedef void(^ActionBlock)(id sender, id parent);

@interface UIHeaderLabelEditButtonView : UIView

@property (strong, nonatomic) IBOutlet UIHeaderLabelEditButtonView *headerEditBtnView;
@property (strong, nonatomic) IBOutlet ValidatorLabel *headerLabel;


@property (strong, nonatomic) IBOutlet UIMultiLingualButton *editButton;

@property (nonatomic,strong)ActionBlock actionblock;
//@property (nonatomic, strong) id parent;

@property(nonatomic ,strong) NSString *titleLabel;

@property (nonatomic,strong) NSString *xPath;

@property (nonatomic,strong) NSString *comparator;
@property (nonatomic,weak) DataValidator dataValidator;
@property(nonatomic,strong) NSString *compareValue;

-(NSString *)getValueString;
-(NSString *)xPath;


@end
