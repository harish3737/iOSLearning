//
//  AttestationViewController.m
//  BCBS Medicare Enrolment App
//
//  Created by CSS Corp on 03/06/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "AttestationViewController.h"
#import "AppConfig.h"
#import "ScopeBaseViewController.h"

@interface AttestationViewController ()
{
    ValidatorLabel *relationshipEnrolleeTitleLabel;
}
@property (nonatomic,strong)UIDropDown *relationshipToEnrollee;
@end

@implementation AttestationViewController
@synthesize dateView,relationshipToEnrollee,authorizeCertifyLabel,replacementNoticeLabel;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    _checkboxBtnView2.checkBoxButton.parent = self;
    
    _checkboxBtnView2.checkBoxButton.actionblock = ^(id sender, id parent){
        
        [parent checkBoxButtonTapped];
        
    };
    
    _checkboxBtnView2.contentButton.parent = self;
    _checkboxBtnView2.contentButton.actionblock = ^(id sender,id parent){
        
        PRINTLOG(@"MultiLingual Button");
        [parent contentButtonTapped];
    };
    
    
    dateView.dropDownImageView.hidden = YES;
    [dateView setUserInteractionEnabled:NO];
    
    
    _titleString.text = [NSString stringWithFormat:@"%@ %@ - \n%@",[AppConfig enrollYear],[LanguageCentral languageSelectedString:[[AppConfig currentPlanDictionary] objectForKey:@"PlanTitle"]],[LanguageCentral languageSelectedString:[[[AppConfig currentPlanDictionary] objectForKey:NSStringFromClass([self class])]objectForKey:@"title"]]];
    
    if([[AppConfig currentPlan] isEqualToString:@"PDP"]||[[AppConfig currentPlan] isEqualToString:@"MAPD"]){
        [self.sharedataObj setForwardNextButtonTitle:@"Continue_to_checklist"];
        [self.sharedataObj setNextProgressIndex:5];
        
        [self.sharedataObj setPreviousNextButtonTitle:@"Next"];
        [self.sharedataObj setBackProgressIndex:5];
        
    }else if([[AppConfig currentPlan] isEqualToString:@"DSNP"]){
        //vrl added for new DSNP attestation
        if(([[AppConfig enrollYear] isEqualToString:@"2019"] ||[[AppConfig enrollYear] isEqualToString:@"2020"]) && [[AppConfig progressTitleArray]count]>4){
            [self.sharedataObj setForwardNextButtonTitle:@"Next"];
            [self.sharedataObj setNextProgressIndex:4]; //6
            
            [self.sharedataObj setPreviousNextButtonTitle:@"Next"];
            [self.sharedataObj setBackProgressIndex:4];
        }else {
            [self.sharedataObj setForwardNextButtonTitle:@"Next"];
            [self.sharedataObj setNextProgressIndex:3]; //6
            
            [self.sharedataObj setPreviousNextButtonTitle:@"Next"];
            [self.sharedataObj setBackProgressIndex:3];
        }
        
        
    }else {
        [self.sharedataObj setForwardNextButtonTitle:@"Next"];
        [self.sharedataObj setNextProgressIndex:4]; //6
        
        [self.sharedataObj setPreviousNextButtonTitle:@"Next"];
        [self.sharedataObj setBackProgressIndex:4];
    }
    
    _checkboxBtnView2.checkBoxButton.validatorString = @"NoValidation";
    
    
    _checkboxBtnView.checkBoxButton.validatorString = @"MandatoryValidator";
    _checkboxBtnView.contentButton.localizationKey = @"BY_CHECKING_THIS_BOX";
    
    
    self.signatureTextField.validatorString=@"EmptyValidator";
    
    self.attestationTextView.layer.borderWidth = 1.0f;
    self.attestationTextView.layer.borderColor = [[UIColor blackColor] CGColor];
    
    
    if(([[AppConfig currentPlan]isEqualToString:@"SupplementUnder50"]||[[AppConfig currentPlan]isEqualToString:@"Supplement Plan 50-64"])&&([[AppConfig enrollYear] isEqualToString:@"2019"]||[[AppConfig enrollYear] isEqualToString:@"2020"])){
        self.pleaseReadLabel.localizationKey = @"AUTHORIZATION_MUST_BE_COMPLETED";
    }else if([[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"] && ([[AppConfig enrollYear] isEqualToString:@"2019"]||[[AppConfig enrollYear] isEqualToString:@"2020"])){
        self.pleaseReadLabel.localizationKey = @"AGREEMENT_AUTHORIZATION_COMPLETED";
    }else {
        self.pleaseReadLabel.localizationKey = @"SELECT_ONE";
    }
    
    
    //    NSMutableArray *buttonArray = [AppConfig enrollmentFormArray];
    //    PRINTLOG(@"ButtonArray ::%@",buttonArray);
    
    if([[AppConfig currentPlan] isEqualToString:@"PDP"]){
        
        [UIRenderer renderPlist:self plist:@"Authorization"];
        self.attestationTextView.localizationKey = @"HBCBS_OF_NEWJERSEY";
        
        self.attestationTextView.font=[UIFont fontWithName:@"Arial" size:18];
        self.attestationTextView.textColor=[UIColor colorWithRed:(102/255.f) green:(102/255.f) blue:(102/255.f) alpha:1.0];
        [self enableSecondView:NO];
        
        
    }
    if([[AppConfig currentPlan] isEqualToString:@"MAPD"]){
        
        [UIRenderer renderPlist:self plist:@"Authorization"];
        self.attestationTextView.localizationKey = @"BY_COMPLETING_THIS";
        
        self.attestationTextView.font=[UIFont fontWithName:@"Arial" size:18];
        self.attestationTextView.textColor=[UIColor colorWithRed:(102/255.f) green:(102/255.f) blue:(102/255.f) alpha:1.0];
        [self enableSecondView:NO];
        
    }
    
    if([[AppConfig currentPlan] isEqualToString:@"DSNP"]){
        [UIRenderer renderPlist:self plist:@"Authorization"];
        
        if([[AppConfig enrollYear] isEqualToString:@"2019"]){
            self.attestationTextView.localizationKey=@"DSNP_BY_COMPLETING_THIS_2019";
        }else if([[AppConfig enrollYear] isEqualToString:@"2020"]) {
            self.attestationTextView.localizationKey=@"DSNP_BY_COMPLETING_THIS_2020";
        } else {
            self.attestationTextView.localizationKey=@"BY_COMPLETING_THIS";
        }
        
        
        self.attestationTextView.font=[UIFont fontWithName:@"Arial" size:18];
        self.attestationTextView.textColor=[UIColor colorWithRed:(102/255.f) green:(102/255.f) blue:(102/255.f) alpha:1.0];
        [self enableSecondView:NO];
        
        
    }
    //    if([[AppConfig currentPlan] isEqualToString:@"SupplementUnder50"]){
    //
    //        [_checkboxBtnView2 setUserInteractionEnabled:NO];
    //        [_checkboxBtnView2 removeFromSuperview];
    //        [_view1 removeFromSuperview];
    //
    //
    //        self.attestationTextView.localizationKey= @"I_UNDERSTAND_50";
    //
    //        self.attestationTextView.font=[UIFont fontWithName:@"Arial" size:18];
    //        self.attestationTextView.textColor=[UIColor colorWithRed:(102/255.f) green:(102/255.f) blue:(102/255.f) alpha:1.0];
    //
    //        _checkboxBtnView2.checkBoxButton.validatorString = @"NoValidation";
    //        [self enableSecondView:NO];
    //
    //    }
    //    if([[AppConfig currentPlan] isEqualToString:@"Supplement Plan 50-64"]){
    //
    //        [_checkboxBtnView2 setUserInteractionEnabled:NO];
    //        [_checkboxBtnView2 removeFromSuperview];
    //
    //        [_view1 removeFromSuperview];
    //
    //        self.attestationTextView.localizationKey=@"I_UNDERSTAND_50_64";
    //        self.attestationTextView.font=[UIFont fontWithName:@"Arial" size:18];
    //        self.attestationTextView.textColor=[UIColor colorWithRed:(102/255.f) green:(102/255.f) blue:(102/255.f) alpha:1.0];
    //         _checkboxBtnView2.checkBoxButton.validatorString = @"NoValidation";
    //        [self enableSecondView:NO];
    //
    //    }
    
    //svk added
    
    if([[AppConfig currentPlan] isEqualToString:@"Supplement Plan 65 and over"] ||[[AppConfig currentPlan] isEqualToString:@"Supplement Plan 50-64"] || [[AppConfig currentPlan] isEqualToString:@"SupplementUnder50"] ){
        
        if([[AppConfig currentPlan] isEqualToString:@"Supplement Plan 65 and over"] &&[[AppConfig enrollYear]isEqualToString:@"2019"])
        {
            [UIRenderer renderPlist:self plist:[NSString stringWithFormat:@"%@AuthorizationRepresentativeForm%@",[AppConfig currentPlan],[AppConfig enrollYear]]];
            self.attestationTextView.localizationKey = @"REVIEW_AGREEMENT_AUTHORIZATION_I_UNDERSTAND_65_2019";
        }
        else  if([[AppConfig enrollYear]isEqualToString:@"2020"]){
            //vrl added
            [UIRenderer renderPlist:self plist:[NSString stringWithFormat:@"%@AuthorizationRepresentativeForm%@",[AppConfig currentPlan],[AppConfig enrollYear]]];
            if([[AppConfig currentPlan] isEqualToString:@"Supplement Plan 50-64"])
            {
                self.attestationTextView.localizationKey=@"I_UNDERSTAND_50_64_2020";
            }
            else if([[AppConfig currentPlan] isEqualToString:@"Supplement Plan 65 and over"])
            {
                self.attestationTextView.localizationKey = @"REVIEW_AGREEMENT_AUTHORIZATION_I_UNDERSTAND_65_2019";
            }
            else
            {
                self.attestationTextView.localizationKey= @"I_UNDERSTAND_50_2020";
            }
        }else {
            [_checkboxBtnView2 setUserInteractionEnabled:NO];
            [_checkboxBtnView2 removeFromSuperview];
            [_view1 removeFromSuperview];
            if([[AppConfig currentPlan] isEqualToString:@"Supplement Plan 50-64"])
            {
                self.attestationTextView.localizationKey=@"I_UNDERSTAND_50_64";
            }
            else if([[AppConfig currentPlan] isEqualToString:@"Supplement Plan 65 and over"])
            {
                self.attestationTextView.localizationKey = @"REVIEW_AGREEMENT_AUTHORIZATION_I_UNDERSTAND_65_2019";
            }
            else
            {
                self.attestationTextView.localizationKey= @"I_UNDERSTAND_50";
            }
            _checkboxBtnView2.checkBoxButton.validatorString = @"NoValidation";
        }
        self.attestationTextView.font=[UIFont fontWithName:@"Arial" size:18];
        self.attestationTextView.textColor=[UIColor colorWithRed:(102/255.f) green:(102/255.f) blue:(102/255.f) alpha:1.0];
        [self enableSecondView:NO];
        
    }
    
    
    AttestationViewController *weakSelf = self;
    
    self.willLoadNext = ^(id object){
        
        [weakSelf addCustomJsonValue];
        
    };
    
    //svk added to get relationship to enrollee
    if([[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"])
    {
        relationshipToEnrollee = [UIRenderer getComponentAtIndex:13];
    }else
    {
        relationshipToEnrollee = [UIRenderer getComponentAtIndex:14];
    }
    
    // vrl added of supplement 65 over 2019 plan
    for(id getsubviews in relationshipToEnrollee.superview.subviews){
        
        if([getsubviews isKindOfClass:[ValidatorLabel class]]){
            relationshipEnrolleeTitleLabel = getsubviews;
        }
    }
    
    //svk added
    if((([[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"]|| [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 50-64"]))||[[AppConfig currentPlan] isEqualToString:@"SupplementUnder50"]){
        if([[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"])
        {
            relationshipEnrolleeTitleLabel.localizationKey = @"RELATIONSHIP_TO_ENROLLEE";
            _checkboxBtnView2.contentButton.localizationKey = @"IF_YOU_ARE_AUTHORIZED_REPRESENTATIVE";
            authorizeCertifyLabel.localizationKey = @"AUTHORIZED_INDIVIDUAL_CERTIFY";
            
            authorizeCertifyLabel.hidden = NO;
            replacementNoticeLabel.hidden = NO;
            replacementNoticeLabel.localizationKey = @"REPLACEMENT_NOTICE_COVERAGE";
        }
        else if(([[AppConfig currentPlan]isEqualToString:@"Supplement Plan 50-64"] || (([[AppConfig currentPlan]isEqualToString:@"SupplementUnder50"]) && [[AppConfig enrollYear]isEqualToString:@"2020"])))
        {
            
            relationshipEnrolleeTitleLabel.localizationKey = @"RELATIONSHIP_TO_ENROLLEE";
            _checkboxBtnView2.contentButton.localizationKey = @"IF_YOU_ARE_AUTHORIZED_REPRESENTATIVE";
            authorizeCertifyLabel.localizationKey = @"AUTHORIZED_INDIVIDUAL_CERTIFY";
            
            authorizeCertifyLabel.hidden = NO;
           replacementNoticeLabel.hidden = YES;

        }
        else
        {
            relationshipEnrolleeTitleLabel.localizationKey = @"RELATIONSHIP_TO_BENEFICIARY";
            _checkboxBtnView2.contentButton.localizationKey = @"AUTHORIZED_REPRESENTATIVE";
            authorizeCertifyLabel.localizationKey = @"";
            authorizeCertifyLabel.hidden = YES;
            replacementNoticeLabel.hidden = YES;
            replacementNoticeLabel.localizationKey = @"";
        }
        
    }else if(([[AppConfig currentPlan]isEqualToString:@"PDP"]||[[AppConfig currentPlan]isEqualToString:@"MAPD"]||[[AppConfig currentPlan]isEqualToString:@"DSNP"]) && ([[AppConfig enrollYear] isEqualToString:@"2019"] ||[[AppConfig enrollYear] isEqualToString:@"2020"])) {
        
        relationshipEnrolleeTitleLabel.localizationKey = @"RELATIONSHIP_TO_ENROLLEE";
        _checkboxBtnView2.contentButton.localizationKey = @"AUTHORIZED_REPRESENTATIVE";  
        authorizeCertifyLabel.localizationKey = @"";
        authorizeCertifyLabel.hidden = YES;
        replacementNoticeLabel.hidden = YES;
        replacementNoticeLabel.localizationKey = @"";
        
    }else {
        relationshipEnrolleeTitleLabel.localizationKey = @"RELATIONSHIP_TO_BENEFICIARY";
        _checkboxBtnView2.contentButton.localizationKey = @"AUTHORIZED_REPRESENTATIVE";
        authorizeCertifyLabel.localizationKey = @"";
        authorizeCertifyLabel.hidden = YES;
        replacementNoticeLabel.hidden = YES;
        replacementNoticeLabel.localizationKey = @"";
    }
    
    
    
    // vrl added
    if(![[AppConfig currentPlan]isEqualToString:@"SupplementUnder50"] && ![[AppConfig currentPlan]isEqualToString:@"Supplement Plan 50-64"] && ![[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"] && !(([[AppConfig enrollYear] isEqualToString:@"2019"])||[[AppConfig enrollYear]isEqualToString:@"2020"])){
        self.signatureTitleLabel.localizationKey = @"BENEFICIARY_SIGNATURE";
    }else {
        self.signatureTitleLabel.localizationKey = @"SIGNATURE";
    }
    
    
    
    
    
    // Do any additional setup after loading the view.
}

-(void)viewWillAppear:(BOOL)animated {
    
    [ScopeBaseViewController populateCurrentItemValue];
    [self loadBackData];
    [super viewWillAppear:animated];
    
    
    NSDate *todayDate = [NSDate date];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
    dateFormatter.dateFormat = @"MM/dd/yyyy";
    
    [dateView setTitleString:[dateFormatter stringFromDate:todayDate]];
    
    
}

-(void)contentButtonTapped{
    
    [self enableSecondView:_checkboxBtnView2.checkBoxButton.checkboxState];
}

-(void)checkBoxButtonTapped{
    
    [self enableSecondView:_checkboxBtnView2.checkBoxButton.checkboxState];
    
}



-(void)enableSecondView :(BOOL)enable{
    
    
    
    NSString *childViewString = @"view1";
    if(childViewString!=nil){
        id childObject = [self valueForKey:childViewString];
        
        [childObject setUserInteractionEnabled:enable];
        
        for (id subviewcontent in [childObject subviews]){
            
            [subviewcontent setEnabled:enable];
            [subviewcontent setUserInteractionEnabled:enable];
            
        }
    }
    
    
}





-(void)addCustomJsonValue {
    
    
    [AppConfig fillJSONDictionary:@"data:important_information:signature" value:_signatureTextField.text];
    [AppConfig fillJSONDictionary:@"data:important_information:signature_date" value:dateView.dropDownTextLabel.text];
    
    [AppConfig fillJSONDictionary:@"data:important_information:authorized_representative" value:_checkboxBtnView2.checkBoxButton.getValueString];
    
    [AppConfig fillJSONDictionary:@"data:authorization_section:signature" value:_signatureTextField.text];
    [AppConfig fillJSONDictionary:@"data:authorization_section:signature_date" value:dateView.dropDownTextLabel.text];
    
    
    //svk added
    if((relationshipEnrolleeTitleLabel != nil && ([[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"]|| [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 50-64"]))||[[AppConfig currentPlan] isEqualToString:@"SupplementUnder50"]){
        if([[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"] && [[AppConfig enrollYear]isEqualToString:@"2019"]&&[[AppConfig enrollYear]isEqualToString:@"2020"])
        {
            [AppConfig fillJSONDictionary:@"data:authorization_section:authorized_representative" value:_checkboxBtnView2.checkBoxButton.getValueString];
        }
        else if([[AppConfig enrollYear]isEqualToString:@"2020"])
        {
            [AppConfig fillJSONDictionary:@"data:authorization_section:authorized_representative" value:_checkboxBtnView2.checkBoxButton.getValueString];
        }
        if([_checkboxBtnView2.checkBoxButton.getValueString isEqualToString:@"Yes"]){
            [AppConfig fillJSONDictionary:@"data:authorization_section:representative:signature_date" value:dateView.dropDownTextLabel.text];
        }else {
            [AppConfig fillJSONDictionary:@"data:authorization_section:representative:signature_date" value:@""];
        }
        
    }
    
    
    // static value for medigap plans , this will remove in future
    [AppConfig fillJSONDictionary:@"data:acknowledgement:first_name" value:[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:customer_information:first_name"]];
    [AppConfig fillJSONDictionary:@"data:acknowledgement:last_name" value:[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:customer_information:last_name"]];
    [AppConfig fillJSONDictionary:@"data:acknowledgement:mi" value:[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:customer_information:mi"]];
    [AppConfig fillJSONDictionary:@"data:acknowledgement:todays_date" value:dateView.dropDownTextLabel.text];
    
    
    
    //for PDP,MAPD
    if(([[AppConfig currentPlan]isEqualToString:@"PDP"] || [[AppConfig currentPlan]isEqualToString:@"MAPD"] || [[AppConfig currentPlan]isEqualToString:@"DSNP"])){
        
        [AppConfig setTempJSONDictionary:[AppConfig setValue:[AppConfig tempCurrentPlanJSONDictionary] :@"tempJSON:data:important_information:authorize_checkbox" :[_checkboxBtnView.checkBoxButton getValueString]]];
    }else{
        [AppConfig setTempJSONDictionary:[AppConfig setValue:[AppConfig tempCurrentPlanJSONDictionary] :@"tempJSON:data:authorization_section:authorize_checkbox_other" :[_checkboxBtnView.checkBoxButton getValueString]]];
        
    }
    
    NSMutableString *companyPlan = [NSMutableString stringWithFormat:@"%@ %@",[AppConfig getValueFromXpath:[AppConfig tempCurrentPlanJSONDictionary] : @"tempJSON:data:other_health_insurance:plan_company"],[AppConfig getValueFromXpath:[AppConfig tempCurrentPlanJSONDictionary] : @"tempJSON:data:other_health_insurance:plan_name"]];
    
    
    
    NSMutableString *companyPolicy = [NSMutableString stringWithFormat:@"%@ %@",[AppConfig getValueFromXpath:[AppConfig tempCurrentPlanJSONDictionary] : @"tempJSON:data:other_health_insurance:policy_company"],[AppConfig getValueFromXpath:[AppConfig tempCurrentPlanJSONDictionary] : @"tempJSON:data:other_health_insurance:policy_name"]];
    
    
    
    [AppConfig fillJSONDictionary:@"data:other_health_insurance:what_company" value:companyPlan];
    
    [AppConfig fillJSONDictionary:@"data:other_health_insurance:what_kind_of_policy" value:companyPolicy];
    
    
    
}

-(void)loadBackData{
    
    PRINTLOG(@"%@",[AppConfig getValueFromXpath:[AppConfig tempCurrentPlanJSONDictionary] :@"tempJSON:data:important_information:authorize_checkbox"]);
    
    if([[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:important_information:authorized_representative"] isEqualToString:@"Yes"]){
        
        [_checkboxBtnView2.checkBoxButton setValueString:@"Yes"];
        [self contentButtonTapped];
    }else if([[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:authorization_section:authorized_representative"] isEqualToString:@"Yes"]){
        [_checkboxBtnView2.checkBoxButton setValueString:@"Yes"];
        [self contentButtonTapped];
    }else {
        [_checkboxBtnView2.checkBoxButton setValueString:@"No"];
    }
    
    
    
    
    
    
    //for Supplement plans
    if(![[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:authorization_section:signature"] isEqualToString:@""] && ([[AppConfig currentPlan]isEqualToString:@"SupplementUnder50"] || [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 50-64"] || [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"])){
        
        [_signatureTextField setValueString:[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:authorization_section:signature"]];
        
    }
    
    if(![[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:authorization_section:signature_date"] isEqualToString:@""]&& ([[AppConfig currentPlan]isEqualToString:@"SupplementUnder50"] || [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 50-64"] || [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"])){
        
        [dateView setValueString:[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:authorization_section:signature_date"]];
    }
    
    
    
    //for PDP,MAPD
    if(![[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:important_information:signature"] isEqualToString:@""] && ([[AppConfig currentPlan]isEqualToString:@"PDP"] || [[AppConfig currentPlan]isEqualToString:@"MAPD"] || [[AppConfig currentPlan]isEqualToString:@"DSNP"])){
        
        [_signatureTextField setValueString:[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:important_information:signature"]];
    }
    
    
    if(![[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:important_information:signature_date"] isEqualToString:@""] && ([[AppConfig currentPlan]isEqualToString:@"PDP"] || [[AppConfig currentPlan]isEqualToString:@"MAPD"] || [[AppConfig currentPlan]isEqualToString:@"DSNP"])){
        
        [dateView setValueString:[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:important_information:signature_date"]];
    }
    
    if(([[AppConfig getValueFromXpath:[AppConfig tempCurrentPlanJSONDictionary] :@"tempJSON:data:important_information:authorize_checkbox"] isEqualToString:@"Yes"] || [[AppConfig getValueFromXpath:[AppConfig tempCurrentPlanJSONDictionary] :@"tempJSON:data:authorization_section:authorize_checkbox_other"] isEqualToString:@"Yes"])){
        
        [_checkboxBtnView.checkBoxButton setChecked:YES];
    }else {
        [_checkboxBtnView.checkBoxButton setChecked:NO];
    }
    
    
    if([[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:important_information:representative:relationship"]isEqualToString:@""]){
        
        if([[LanguageCentral internalizeString] isEqualToString:@"en"]){
            [relationshipToEnrollee setValueString:@"Spouse"];
        }else {
            [relationshipToEnrollee setValueString:@"Esposa"];
        }
        
    }else {
        [relationshipToEnrollee setValueString: [AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:important_information:representative:relationship"]];
    }
    
    //svk addded
    if((relationshipEnrolleeTitleLabel != nil && ([[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"]|| [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 50-64"]))||[[AppConfig currentPlan] isEqualToString:@"SupplementUnder50"]){
        if([[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"] && [[AppConfig enrollYear]isEqualToString:@"2019"]&&[[AppConfig enrollYear]isEqualToString:@"2020"])
        {
            if([[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:authorization_section:representative:relationship"]isEqualToString:@""]){
                
                if([[LanguageCentral internalizeString] isEqualToString:@"en"]){
                    [relationshipToEnrollee setValueString:@"Spouse"];
                }else {
                    [relationshipToEnrollee setValueString:@"Esposa"];
                }
                
            }else {
                [relationshipToEnrollee setValueString: [AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:authorization_section:representative:relationship"]];
            }
        }
        else if([[AppConfig enrollYear]isEqualToString:@"2020"])
        {
            
            if([[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:authorization_section:representative:relationship"]isEqualToString:@""]){
                
                if([[LanguageCentral internalizeString] isEqualToString:@"en"]){
                    [relationshipToEnrollee setValueString:@"Spouse"];
                }else {
                    [relationshipToEnrollee setValueString:@"Esposa"];
                }
                
            }else {
                [relationshipToEnrollee setValueString: [AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:authorization_section:representative:relationship"]];
            }
            
        }
    }
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
