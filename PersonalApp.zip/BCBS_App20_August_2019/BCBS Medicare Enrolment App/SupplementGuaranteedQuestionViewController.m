//
//  SupplementGuaranteedQuestionViewController.m
//  BCBS Medicare Enrolment App
//
//  Created by CSS Admin on 6/22/18.
//  Copyright © 2018 CSS Corp. All rights reserved.
//

#import "SupplementGuaranteedQuestionViewController.h"
#import "AppConfig.h"
#import "ScopeBaseViewController.h"

@interface SupplementGuaranteedQuestionViewController ()
@property (nonatomic,strong) UIRadioButton *getHeadItem;
@end

@implementation SupplementGuaranteedQuestionViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
     _titleString.text = [NSString stringWithFormat:@"%@ %@ - \n%@",[AppConfig enrollYear],[LanguageCentral languageSelectedString:[[AppConfig currentPlanDictionary] objectForKey:@"PlanTitle"]],[LanguageCentral languageSelectedString:[[[AppConfig currentPlanDictionary] objectForKey:NSStringFromClass([self class])]objectForKey:@"title"]]];
    
    [self.sharedataObj setForwardNextButtonTitle:@"Next"];
    [self.sharedataObj setNextProgressIndex:3];
    
    [self.sharedataObj setPreviousNextButtonTitle:@"Next"];
    [self.sharedataObj setBackProgressIndex:3];
    
    [UIRenderer renderPlist:self plist:[NSString stringWithFormat:@"%@GuaranteedForm%@",[AppConfig currentPlan],[AppConfig enrollYear]]];
    
}

-(void)viewWillAppear:(BOOL)animated {
    
    [ScopeBaseViewController populateCurrentItemValue];
    [self loadBackData];
    [super viewWillAppear:animated];
}

-(void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
}

-(BOOL)validateVC {

    self.getHeadItem = [Validator headItem];
    
    return NO;
}

-(void)loadNextPage {
    
    [self addCustomJsonValue];
}

-(void)addCustomJsonValue {
    
    
}






- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
