//
//  DashboardViewController.h
//  dashboard flow
//
//  Created by CSS Corp on 04/05/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>


@interface DashboardViewController : UIBaseContainerViewController <UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout>
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;

- (IBAction)startenrollButton:(id)sender;

@end
