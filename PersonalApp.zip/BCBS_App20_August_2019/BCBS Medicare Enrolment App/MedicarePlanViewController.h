//
//  MedicarePlanViewController.h
//  BCBS Medicare Enrolment App
//
//  Created by CSS Corp on 01/06/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>
#import "AppConfig.h"

@interface MedicarePlanViewController : UIBaseContainerViewController
@property (strong, nonatomic) IBOutlet UICheckBox *pdpButton;
@property (strong, nonatomic) IBOutlet UICheckBox *advantagePlanButton;
@property (strong, nonatomic) IBOutlet UICheckBox *supplementPlanUnder50Button;
@property (strong, nonatomic) IBOutlet UICheckBox *supplementPlan50To64Button;
@property (strong, nonatomic) IBOutlet UICheckBox *supplementPlan65AndOverButton;

@property (strong, nonatomic) IBOutlet ValidatorLabel *titleString;
@property (weak, nonatomic) IBOutlet UICheckBox *dsnpPlanButton;
@property (strong, nonatomic) IBOutlet ValidatorLabel *SubTitle;


@end
