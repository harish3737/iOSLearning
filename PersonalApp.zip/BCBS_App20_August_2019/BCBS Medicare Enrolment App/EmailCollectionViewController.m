//
//  EmailCollectionViewController.m
//  BCBS Medicare Enrolment App
//
//  Created by CSS Corp on 04/07/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "EmailCollectionViewController.h"
#import "AppConfig.h"


#define REDCOLOR [UIColor colorWithRed:240.0/255.0 green:108.0/255.0 blue:108.0/255.0 alpha:1.0f]
#define TEXTCOLOR [UIColor colorWithRed:102.0/255.0 green:102.0/255.0 blue:102.0/255.0 alpha:1.0f]

static UIRadioButton *yesBtn;
static UIRadioButton *noBtn;
static UILabledTextField *emailAddressField;


@interface EmailCollectionViewController ()
@property (nonatomic,strong) NSMutableDictionary *xPathDict;
@end

@implementation EmailCollectionViewController
@synthesize firstView,secondView,xPathDict;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
	
	
//	[UIRenderer renderPlist:self plist:@"EmailCollection"];
	
	[UINavigationQueue showXibName:self];
    
    if([[AppConfig currentPlan] isEqualToString:@"DSNP"]){
        //vrl added for new DSNP attestation
         if(([[AppConfig enrollYear] isEqualToString:@"2019"] ||[[AppConfig enrollYear] isEqualToString:@"2020"]) && [[AppConfig progressTitleArray]count]>4){
            [self.sharedataObj setForwardNextButtonTitle:@"Back_to_dashboard"];
            [self.sharedataObj setNextProgressIndex:5]; //6
        }else {
            [self.sharedataObj setForwardNextButtonTitle:@"Back_to_dashboard"];
            [self.sharedataObj setNextProgressIndex:4]; //6
        }
       
    }else {
        
         if([[AppConfig currentPlan] containsString:@"Supplement"] && ([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"])){
             
             [self.sharedataObj setForwardNextButtonTitle:@"Preview"];
             [self.sharedataObj setNextProgressIndex:5];
             
            [self.sharedataObj setPreviousNextButtonTitle:@"Next"];
            [self.sharedataObj setBackProgressIndex:5];

        
             
         }else {
             [self.sharedataObj setForwardNextButtonTitle:@"Back_to_dashboard"];
             [self.sharedataObj setNextProgressIndex:6];
             
             [self.sharedataObj setPreviousNextButtonTitle:@"Next"];
             [self.sharedataObj setBackProgressIndex:5];
         }
    }
	
    
    NSMutableDictionary *pathDict = [[AppConfig currentPlanDictionary]objectForKey:@"XPathInfo"];
    
    xPathDict = [pathDict objectForKey:@"EmailCollectionViewController"];
   
    [self getEmailAddressFieldView];
}

-(void)getEmailAddressFieldView {
    
    for (id emailField in secondView.subviews) {
        
        if([emailField isKindOfClass:[UILabledTextField class]]){
            emailAddressField = emailField;
        }
    }
    
}


-(void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
      [self loadBackData];
}

-(void)didFinishContainerVC {
    
//    [ScopeBaseViewController populateCurrentItemValue];
  
	
	for (id questionviewObj in firstView.subviews){
		
		if([questionviewObj isKindOfClass:[UIQuestionView class]]){
			
			UIQuestionView *questionView = questionviewObj;
            yesBtn = questionView.yesButton;
            noBtn = questionView.noButton;
            
            if(questionView.yesButton.buttonSelected){
                [questionView enableSecondView:YES];
            }else {
                [questionView enableSecondView:NO];
            }
		}
	}
	
}

-(BOOL)validateVC {
    
	BOOL hasError = NO;
	for (id questionviewObj in firstView.subviews){
		
		if([questionviewObj isKindOfClass:[UIQuestionView class]]){
			
			UIQuestionView *questionView = questionviewObj;
            yesBtn = questionView.yesButton;
            noBtn = questionView.noButton;
			if(questionView.yesButton.buttonSelected||questionView.noButton.buttonSelected){
				questionView.detailLabel.textColor =  TEXTCOLOR;
				questionView.headingLabel.textColor = TEXTCOLOR;
				questionView.yesButton.layer.borderColor = [UIColor clearColor].CGColor;
				questionView.noButton.layer.borderColor =  [UIColor clearColor].CGColor;
				
				hasError = NO;
			}else {
				questionView.headingLabel.textColor = REDCOLOR;
				questionView.detailLabel.textColor = REDCOLOR;
				questionView.yesButton.layer.borderColor = REDCOLOR.CGColor;
				questionView.noButton.layer.borderColor =  REDCOLOR.CGColor;
				
				hasError = YES;
			}
			questionView.yesButton.layer.borderWidth = 1.0f;
			questionView.noButton.layer.borderWidth = 1.0f;
		}
	}
	return hasError;
}

-(void)loadNextPage {
    
    [self addCustomXPathValue];
}
-(void)addCustomXPathValue {
    
    
    if([[AppConfig currentPlan] containsString:@"Supplement"]){
        
        if(yesBtn.buttonSelected){
            
            [AppConfig fillJSONDictionary:[xPathDict objectForKey:@"receive_email_xPath"] value:@"Yes"];
        }
        
        if(noBtn.buttonSelected){
            [AppConfig fillJSONDictionary:[xPathDict objectForKey:@"receive_email_xPath"] value:@"No"];
            
        }
        
        [AppConfig fillJSONDictionary:[xPathDict objectForKey:@"email_address_xPath"] value:emailAddressField.textField.getValueString];
        
        if([AppConfig planPlistArray].count>1){
            
            [AppConfig setValue:[[AppConfig getPlanJSONDictionaries]objectForKey:[[AppConfig planPlistArray]objectAtIndex:0]] :@"data:important_information:email_address_available" :[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :[xPathDict objectForKey:@"receive_email_xPath"]]];
            
            [AppConfig setValue:[[AppConfig getPlanJSONDictionaries]objectForKey:[[AppConfig planPlistArray]objectAtIndex:0]] :@"data:important_information:email_address" :[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :[xPathDict objectForKey:@"email_address_xPath"]]];
        }
    }else {
        if(yesBtn.buttonSelected){
            
            [AppConfig fillJSONDictionary:[xPathDict objectForKey:@"receive_email_xPath"] value:@"Yes"];
        }
        
        if(noBtn.buttonSelected){
            [AppConfig fillJSONDictionary:[xPathDict objectForKey:@"receive_email_xPath"] value:@"No"];
            
        }
        
        [AppConfig fillJSONDictionary:[xPathDict objectForKey:@"email_address_xPath"] value:emailAddressField.textField.getValueString];
        
        if([AppConfig planPlistArray].count>1){
            
            [AppConfig setValue:[[AppConfig getPlanJSONDictionaries]objectForKey:[[AppConfig planPlistArray]objectAtIndex:0]] :@"data:important_information:email_address_available" :[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :[xPathDict objectForKey:@"receive_email_xPath"]]];
            
            [AppConfig setValue:[[AppConfig getPlanJSONDictionaries]objectForKey:[[AppConfig planPlistArray]objectAtIndex:0]] :@"data:important_information:email_address" :[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :[xPathDict objectForKey:@"email_address_xPath"]]];
        }
    }
    
    

}

-(void)loadBackData {
    
    NSString *yesBtnString = [AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :[xPathDict objectForKey:@"receive_email_xPath"]];

    if([yesBtnString isEqualToString:@"Yes"]){
        [yesBtn setRadioButtonSelected:YES];
    }else if([yesBtnString isEqualToString:@"No"]){
         [noBtn setRadioButtonSelected:YES];
    }else {
       
    }
    
    [emailAddressField.textField setText:[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :[xPathDict objectForKey:@"email_address_xPath"]]];
  
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}





/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
