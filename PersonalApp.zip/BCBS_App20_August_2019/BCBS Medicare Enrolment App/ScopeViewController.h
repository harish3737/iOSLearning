//
//  ScopeViewController.h
//  autolayout programmatically
//
//  Created by CSS Corp on 06/05/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>


@interface ScopeViewController : UIBaseContainerViewController


@property (strong, nonatomic) IBOutlet UIDropDown *beneficiaryView;
@property (strong, nonatomic) IBOutlet UIDropDown *dateView;

@property (strong, nonatomic) IBOutlet UICheckBox *PdpButton;
@property (strong, nonatomic) IBOutlet UICheckBox *advantagePlanButton;
@property (strong, nonatomic) IBOutlet UICheckBox *supplementPlanButton;
@property (strong, nonatomic) IBOutlet UICheckBox *dsnpPlanButton;

@property (strong, nonatomic) IBOutlet ValidatorTextField *beneficiaryTextField;
@property (strong, nonatomic) IBOutlet UICheckBoxWithButton *checkboxBtnView;

@property (strong, nonatomic) IBOutlet ValidatorLabel *SubTitle;
@property (strong, nonatomic) IBOutlet ValidatorLabel *titleString;

@property (strong, nonatomic) IBOutlet ValidatorLabel *selectTypeLabel;
@property (strong, nonatomic) IBOutlet ValidatorLabel *textLabel;
@property (strong, nonatomic) IBOutlet ValidatorTextField *representativeNameField;

@end
