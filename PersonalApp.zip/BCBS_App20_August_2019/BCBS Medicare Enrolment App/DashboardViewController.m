//
//  DashboardViewController.m
//  dashboard flow
//
//  Created by CSS Corp on 04/05/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "DashboardViewController.h"
#import "ContentCollectionViewCell.h"
#import "CustomCollectionViewLayout.h"
#import "DashboardBaseViewController.h"
#import "LanguageViewController.h"

#import "AppConfig.h"
#import <CacheLib/CacheLib.h>
#import <CacheLib/WebServiceWrapper.h>
#import <CacheLib/Callback.h>
#import <CacheLib/Global.h>

#define IsIOS8 (NSFoundationVersionNumber > NSFoundationVersionNumber_iOS_7_1)
static NSString * const reuseIdentifier = @"ContentCellIdentifier";
static CGSize screenSize ;
static float cellWidth = 50.0f;
static float cellHeight = 60.0f;
static NSMutableArray *dashboardArray;
static NSMutableArray *keyArray;


@interface DashboardViewController ()
{
    
    UIActivityIndicatorView* activity;
    UIView *errorview;
    
}
@property(nonatomic,strong)DashboardBaseViewController *dashboardbase;

@end

@implementation DashboardViewController

- (void)viewDidLoad {
    
    [AppConfig resetGeneralJSONDictionary];
    [AppConfig loadGeneralJSONPlist];
    
    dashboardArray = [[NSMutableArray alloc]init];
    
    keyArray = [NSMutableArray arrayWithObjects:@"confirmation_number",@"first_name",@"date_of_birth",@"plan_type",@"submitted_on", nil];
    
    if(activity!=nil){
        [self stopCustomActivityIndicator];
    }
    [AppConfig resetAppConfig];
    [AppConfig resetPlanListArray];
    
    //call dashboard webservice method
    [self dashboardWebService];
    
    
    [AppConfig setEditPageIndex:-1];
    [AppConfig setInsertPageIndex:-1];
    
    
    [self.collectionView registerNib:[UINib nibWithNibName:@"ContentCollectionViewCell" bundle:nil] forCellWithReuseIdentifier:@"ContentCellIdentifier"];
    
    [self.collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:@"cellIdentifier"];
    
    [self.collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:@"emptyIdentifier"];
    
    self.collectionView.layer.borderColor = [UIColor colorWithRed:(204.0/255.0) green:(204.0/255.0) blue:(204.0/255.0) alpha:1.0f].CGColor;
    self.collectionView.layer.borderWidth = 1.0f;
    
    screenSize =  [self currentScreenBoundsDependOnOrientation];
    
    cellWidth = (screenSize.width-70)/5.0;
    self.collectionView.delegate = self;
    self.collectionView.dataSource = self;
    
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.willLoadNext = ^(id object){
        
        DashboardBaseViewController *dashboard = (DashboardBaseViewController *)object;
        PRINTLOG(@"Dash board ::%@",dashboard);
        
        if(dashboard.currentViewController.class == DashboardViewController.class){
            dashboard.backButton.hidden = YES;
        }else {
            dashboard.backButton.hidden = NO;
        }
        
        _dashboardbase = dashboard;
        
    };
    
    
}



#pragma mark Custom methods

- (void)startActivityIndicator
{
    
    [AppConfig showLoaderGif];
    
    //    activity = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    //    [activity setHidesWhenStopped:TRUE];
    //    [activity setAlpha:1.0];
    //    [activity setFrame:CGRectMake((self.view.frame.origin.x+self.view.frame.size.width)/2.0, ((self.view.frame.origin.y+self.view.frame.size.height)/2.0)-100.0, activity.frame.size.width, activity.frame.size.height)];
    //    [self.view addSubview:activity];
    //    [activity startAnimating];
    
}

- (void)removeActivityIndicator
{
    
    [AppConfig stopAnimatingGif];
    
    //    [activity stopAnimating];/Users/csscorp/Documents/Medicare_SVN_2.0/BCBS_App/BCBS Medicare Enrolment App/DashboardViewController.m
    //    [activity removeFromSuperview];
}

#pragma mark WebService methods


-(void)dashboardWebService {
    
    if([AppConfig getNetworkStatus]){
        
        [self startActivityIndicator];
        
        __block DashboardViewController *weakSelf = self;
        
        Callback *cacheCallback = [[Callback alloc]initWithCallbacks:^(id response,id operation,id handler){
            
            PRINTLOG(@"Dashboard Response Success ::\n%@",response);
            
            NSError *jsonError;
            NSData *objectData = [response dataUsingEncoding:NSUTF8StringEncoding];
            id jsonDict = [NSJSONSerialization JSONObjectWithData:objectData options:NSJSONReadingMutableContainers error:&jsonError];
            
            if([jsonDict isKindOfClass:[NSDictionary class]]){
                [handler parseDashboardData:jsonDict];
            }else {
                [handler loadErrorView:@"No Records Found" detailText:@"No enrollment available for the user"];
            }
            [handler stopCustomActivityIndicator];
            
        }:^(id response,id operation,id handler){
            PRINTLOG(@"Response Failed ::\n%@",response);
            [handler stopCustomActivityIndicator];
            [handler loadErrorView:@"No Records Found" detailText:@"No enrollment available for the user"];
            
        }:weakSelf];
        
        
        //        [AppConfig testWrapper:DASHBOARD_URL query:@"" callback:cacheCallback];
        GENERATESERVICE(DASHBOARD_URL, @"", cacheCallback);
        
    }else{
        
//        [self errorMessageAlert:@"INFO" message:@"The Internet connection appears to be offline."];
        //anitha added
        [AppConfig errorMessageAlert:@"INFO" message:@"The Internet connection appears to be offline" class:self];
    }
    
}

-(void)stopCustomActivityIndicator {
    
    [self removeActivityIndicator];
}


-(void)parseDashboardData:(NSMutableDictionary *)jsonDict {
    
    NSMutableArray *dashboardRow;
    
    NSMutableArray *dashboardRowList = [[NSMutableArray alloc]init];
    
    for (NSString *key in jsonDict) {
        
        dashboardRow = [[NSMutableArray alloc]init];
        NSMutableArray *responseKeyArray = [[[jsonDict objectForKey:key]allKeys]copy];
        
        
        // new code for dashboard crash issue fixed
        for (int i=0; (i<keyArray.count && responseKeyArray.count==6); i++) {
            
            if([[[jsonDict objectForKey:key] objectForKey:[keyArray objectAtIndex:i]] isEqual:[NSNull null]]){
                [dashboardRow addObject:@""];
            }else {
                
                [dashboardRow addObject:[[jsonDict objectForKey:key] objectForKey:[keyArray objectAtIndex:i]]];
                
            }
        }
        
        // original code before add dashboard crash issue
        //        for (int i=0; i<keyArray.count; i++) {
        //
        //            if([[[jsonDict objectForKey:key] objectForKey:[keyArray objectAtIndex:i]] isEqual:[NSNull null]]){
        //                    [dashboardRow addObject:@""];
        //            }else {
        //                [dashboardRow addObject:[[jsonDict objectForKey:key] objectForKey:[keyArray objectAtIndex:i]]];
        //            }
        //        }
        if(dashboardRow.count>0){
            [dashboardRowList addObject:dashboardRow];
        }
        PRINTLOG(@"DashboarRowLISt  ::%@",dashboardRowList);
        
    }
    
    dashboardArray = dashboardRowList;
    PRINTLOG(@"Dashboard Array Count ::%d",dashboardArray.count);
    
    if(dashboardArray.count >0){
        [self removeErrorView];
        [self.collectionView reloadData];
    }else {
        [self loadErrorView:@"No Records Found" detailText:@"No enrollment available for the user"];
    }
}

#pragma mark  methods

-(void)loadErrorView:(NSString *)headingText detailText:(NSString *)detailText {
    
    self.collectionView.scrollEnabled = NO;
    self.collectionView.hidden = YES;
    
    [AppConfig stopAnimatingGif];
    
    errorview = [[UIView alloc]init];
    errorview.backgroundColor = [UIColor colorWithRed:227.0/255.0 green:234.0/255.0 blue:246.0/255.0 alpha:1.0];
    [self.view addSubview:errorview];
    
    
    ValidatorLabel *headingLabel = [[ValidatorLabel alloc]init];
    headingLabel.localizationKey = headingText;
    headingLabel.textColor = [UIColor colorWithRed:102.0/255.0 green:102.0/255.0 blue:102.0/255.0 alpha:1.0];
    //    headingLabel.font = [UIFont fontWithName:@"Arial-DemiBold" size:16.0];
    headingLabel.font = [AppConfig boldFontWithFont:[UIFont fontWithName:@"Arial" size:16.0] size:16.0];
    headingLabel.textAlignment = NSTextAlignmentLeft;
    headingLabel.numberOfLines = 1;
    [errorview addSubview:headingLabel];
    
    ValidatorLabel *detailLabel = [[ValidatorLabel alloc]init];
    detailLabel.localizationKey = detailText;
    detailLabel.textColor = [UIColor colorWithRed:102.0/255.0 green:102.0/255.0 blue:102.0/255.0 alpha:1.0];
    detailLabel.font = [UIFont fontWithName:@"Arial-Regular" size:14.0];
    detailLabel.textAlignment = NSTextAlignmentLeft;
    detailLabel.numberOfLines = 1;
    [errorview addSubview:detailLabel];
    
    
    UIImageView *infoImageView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"info_icon"]];
    infoImageView.clipsToBounds = YES;
    [errorview addSubview:infoImageView];
    
    [errorview setTranslatesAutoresizingMaskIntoConstraints:NO];
    [headingLabel setTranslatesAutoresizingMaskIntoConstraints:NO];
    [detailLabel setTranslatesAutoresizingMaskIntoConstraints:NO];
    [infoImageView setTranslatesAutoresizingMaskIntoConstraints:NO];
    
    
    [errorview addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-15-[infoImageView(36)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(infoImageView)]];
    
    [errorview addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-15-[headingLabel(21)]-15-[detailLabel(21)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(headingLabel,detailLabel)]];
    
    
    [errorview addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-15-[infoImageView(36)]-15-[headingLabel(>=21)]-15-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(infoImageView,headingLabel)]];
    
    [errorview addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-15-[infoImageView(36)]-15-[detailLabel(>=21)]-15-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(infoImageView,detailLabel)]];
    
    [errorview updateConstraints];
    [errorview layoutIfNeeded];
    
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-10-[errorview(>=21)]-10-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(errorview)]];
    
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-170-[errorview(90)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(errorview)]];
    
    [self.view updateConstraints];
    [self.view layoutIfNeeded];
    
}



-(void)removeErrorView {
    
    if(errorview!=nil){
        errorview.hidden = YES;
        [errorview removeFromSuperview];
    }
}


-(CGSize)currentScreenBoundsDependOnOrientation
{
    CGRect screenBounds = [UIScreen mainScreen].bounds ;
    
    if(IsIOS8){
        return screenBounds.size ;
    }
    CGFloat width = CGRectGetWidth(screenBounds)  ;
    CGFloat height = CGRectGetHeight(screenBounds) ;
    UIInterfaceOrientation interfaceOrientation = [UIApplication sharedApplication].statusBarOrientation;
    
    if(UIInterfaceOrientationIsPortrait(interfaceOrientation)){
        screenBounds.size = CGSizeMake(width, height);
    }else if(UIInterfaceOrientationIsLandscape(interfaceOrientation)){
        screenBounds.size = CGSizeMake(height, width);
    }
    return screenBounds.size ;
}

-(void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration {
    
    PRINTLOG(@"orient :%ld",(long)[UIDevice currentDevice].orientation);
    screenSize = [self currentScreenBoundsDependOnOrientation];
    [self.collectionView.collectionViewLayout invalidateLayout];
    //    [self.collectionView performBatchUpdates:nil completion:nil];
    
}

-(void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:YES];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



#pragma mark Table collection View

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    
    return 6;
    
}
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    
    if(dashboardArray.count>0){
        return dashboardArray.count+1;
    }
    return 0;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView
                  cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    UICollectionViewCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:@"cellIdentifier" forIndexPath:indexPath];
    
    UICollectionViewCell *emptycell=[collectionView dequeueReusableCellWithReuseIdentifier:@"emptyIdentifier" forIndexPath:indexPath];
    
    
    ContentCollectionViewCell *contentCell = [collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];
    
    
    contentCell.contentLabel.font=[UIFont fontWithName:@"Arial" size:16];
    contentCell.contentLabel.textColor = [UIColor colorWithRed:102/255.0 green:102.0/255.0 blue:102.0/255.0 alpha:1.0];
    
    UIImageView *recipeImageView = [[UIImageView alloc]initWithFrame:CGRectMake(10,20, 17, 17)];
    recipeImageView.image = [UIImage imageNamed:@"Confirmed"];
    
    [cell.contentView addSubview:recipeImageView];
    
    contentCell.contentLabel.numberOfLines = 0;
    
    if(indexPath.section%2==0) {
        if(indexPath.section==0){
            contentCell.backgroundColor = [UIColor whiteColor];
            cell.backgroundColor = [UIColor whiteColor];
            
            
        }else {
            contentCell.backgroundColor = [UIColor whiteColor];
            cell.backgroundColor = [UIColor whiteColor];
        }
        
    } else {
        
        contentCell.backgroundColor = [UIColor colorWithRed:(237/255.0) green:(245/255.0) blue:(253/255.0) alpha:1.0];
        cell.backgroundColor = [UIColor colorWithRed:(237/255.0) green:(245/255.0) blue:(253/255.0) alpha:1.0];
    }
    
    
    if (indexPath.section==0) {
        
        if (indexPath.section ==0 && indexPath.item ==0) {
            contentCell.contentLabel.text = @"";
        }
        
        if (indexPath.section ==0 && indexPath.item ==1) {
            contentCell.contentLabel.text = @"CONFIRMATION#";
        }
        if (indexPath.section ==0 && indexPath.item ==2) {
            contentCell.contentLabel.text = @"NAME";
        }
        if (indexPath.section ==0 && indexPath.item ==3) {
            contentCell.contentLabel.text = @"DOB";
        }
        if (indexPath.section ==0 && indexPath.item ==4) {
            contentCell.contentLabel.text = @"PLAN";
        }
        if (indexPath.section ==0 && indexPath.item ==5) {
            contentCell.contentLabel.text = @"SUBMITTED";
        }
        contentCell.borderLabel.hidden = NO;
        return contentCell;
        
    }else {
        
        if(indexPath.item==0){
            recipeImageView.hidden = NO;
            return cell;
        }else {
            contentCell.contentLabel.text = [[dashboardArray objectAtIndex:indexPath.section-1]objectAtIndex:indexPath.item-1];
            contentCell.borderLabel.hidden = YES;
            return contentCell;
        }
    }
    
    //    if(indexPath.item==0 && indexPath.section!=0){
    //        return cell;  //return confirm image
    //    }else if(indexPath.section==0 && indexPath.item==0){
    //        return emptycell; // return empty cell
    //    }
    //    return contentCell;
    
}

-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section {
    return 0;
}

-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section{
    return 0;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    //    cellWidth = ((screenSize.width-90)/5.0)-2;
    
    cellWidth = ((screenSize.width-70)/5.0)-5;
    
    if(indexPath.section ==0){
        
        if(indexPath.item == 0){
            //                return CGSizeMake(30,80);
            return CGSizeMake(34,cellHeight);
        }else if((dashboardArray.count-1) == indexPath.item){
            return CGSizeMake(cellWidth, cellHeight);
        }else {
            return CGSizeMake(cellWidth, cellHeight);
        }
    }else {
        if(indexPath.item == 0){
            return CGSizeMake(34,cellHeight);
        }else if((dashboardArray.count-1) == indexPath.item){
            return CGSizeMake(cellWidth, cellHeight);
        }else {
            return CGSizeMake(cellWidth, cellHeight);
        }
    }
}

- (IBAction)startenrollButton:(id)sender {
    
    if([AppConfig getNetworkStatus]){
        [self removeActivityIndicator];
        
        [UINavigationQueue deleteAfter:[DashboardViewController class] container:[DashboardViewController class] xib:nil];
        
        [UINavigationQueue pushClass:[DashboardBaseViewController class] containerVC:[LanguageViewController class] xibName:nil];
        
        [UINavigationQueue showNext:(UIBaseViewController *)self.parentViewController];
        
        self.willLoadNext(_dashboardbase);
        
    }else{
        
//        [self errorMessageAlert:@"INFO" message:@"The Internet connection appears to be offline."];
            //anitha added startenroll button tap
        [AppConfig errorMessageAlert:@"INFO" message:@"The Internet connection appears to be offline" class:self];
    }
    
}


//-(void)errorMessageAlert:(NSString *)title message:(NSString *)message {
//
//    [self removeActivityIndicator];
//
//
//
//    NSString *localizeTitle = [LanguageCentral languageSelectedString:title];
//    NSString *titleString = (localizeTitle.length>0)?localizeTitle:title;
//
//
//    NSString *localizeMessage = [LanguageCentral languageSelectedString:message];
//    NSString *msgString = (localizeMessage.length>0)?localizeMessage:message;
//
//
//
//    UIAlertController *alertController = [UIAlertController
//                                          alertControllerWithTitle:titleString
//                                          message:msgString
//                                          preferredStyle:UIAlertControllerStyleAlert];
//
//    UIAlertAction *okAction = [UIAlertAction
//                               actionWithTitle:NSLocalizedString(@"OK", @"OK action")
//                               style:UIAlertActionStyleDefault
//                               handler:^(UIAlertAction *action)
//                               {
//                                   PRINTLOG(@"ok action");
//                               }];
//
//    [alertController addAction:okAction];
//
//    [self presentViewController:alertController animated:YES completion:nil];
//
//}


@end
