//
//  UISingleLabelPreview.h
//  BCBS Medicare Enrolment App
//
//  Created by CSS Admin on 7/17/18.
//  Copyright © 2018 CSS Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>
#import "UILabelProperty.h"

IB_DESIGNABLE

@interface UISingleLabelPreview : UIView

@property (strong, nonatomic) IBOutlet UISingleLabelPreview *singleLabelPreview;
@property (strong, nonatomic) IBOutlet ValidatorLabel *contentLabel;

@property (nonatomic,strong) NSString *xPath;

@property (nonatomic,strong) NSString *comparator;
@property (nonatomic,weak) DataValidator dataValidator;
@property(nonatomic,strong) NSString *compareValue;

-(NSString *)getValueString;
-(NSString *)xPath;



@end
