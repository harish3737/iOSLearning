//
//  PlanPremiumViewController.m
//  BCBS Medicare Enrolment App
//
//  Created by CSS Corp on 20/09/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "PlanPremiumViewController.h"
#import "AppConfig.h"

@interface PlanPremiumViewController ()

@end

@implementation PlanPremiumViewController
@synthesize staticContent;

- (void)viewDidLoad {
    [super viewDidLoad];
	
	
	_titleString.text = [NSString stringWithFormat:@"%@ %@ - \n%@",[AppConfig enrollYear],[LanguageCentral languageSelectedString:[[AppConfig currentPlanDictionary] objectForKey:@"PlanTitle"]],[LanguageCentral languageSelectedString:[[[AppConfig currentPlanDictionary] objectForKey:NSStringFromClass([self class])]objectForKey:@"title"]]];
	
	
	[self.sharedataObj setForwardNextButtonTitle:@"Next"];
	[self.sharedataObj setNextProgressIndex:2];
	
	[self.sharedataObj setPreviousNextButtonTitle:@"Continue_to_health"];
	[self.sharedataObj setBackProgressIndex:2];
	


    if([[AppConfig currentPlan] isEqualToString:@"PDP"]){
        
        if([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"]){
            staticContent.localizationKey=@"YOUR_PLAN_PREMIUM_PDP_2019";
        }else{
            staticContent.localizationKey=@"YOUR_PLAN_PREMIUM_PDP_2016";
        }
        
    }else {
        
        if([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"]){
            staticContent.localizationKey=@"YOUR_PLAN_PREMIUM_MADP_2019";
        }else{
            staticContent.localizationKey=@"YOUR_PLAN_PREMIUM_MADP_2016";
        }
    }
	
	
	staticContent.layer.borderColor = [UIColor clearColor].CGColor;
	staticContent.font=[UIFont fontWithName:@"Arial" size:18];
	staticContent.textColor=[UIColor colorWithRed:(102/255.f) green:(102/255.f) blue:(102/255.f) alpha:1.0];

    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
