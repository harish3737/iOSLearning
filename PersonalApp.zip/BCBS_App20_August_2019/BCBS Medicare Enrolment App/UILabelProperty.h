//
//  UILabelProperty.h
//  BCBS Medicare Enrolment App
//
//  Created by CSS Admin on 7/18/18.
//  Copyright © 2018 CSS Corp. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface UILabelProperty : NSObject


@property (nonatomic,strong) NSString *fontName;
@property (nonatomic,strong) NSString *fontSize;

@end
