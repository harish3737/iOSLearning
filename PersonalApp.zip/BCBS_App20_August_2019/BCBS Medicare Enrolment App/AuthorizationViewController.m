//
//  AuthorizationViewController.m
//  BCBS Medicare Enrolment App
//
//  Created by CSS Corp on 15/06/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "AuthorizationViewController.h"
#import "AppConfig.h"
#import "ScopeBaseViewController.h"

#define BORDERCOLOR [UIColor colorWithRed:(204.0/255.0) green:(204.0/255.0) blue:(204.0/255.0) alpha:1.0f].CGColor

#define RED_BORDER_COLOR [UIColor colorWithRed:(240.0/255.0) green:(108.0/255.0) blue:(108.0/255.0) alpha:1.0f].CGColor

@interface AuthorizationViewController ()
{
	UIDropDown *effectiveDate;
    
	ValidatorTextField *npnNumber,*agentId,*phoneNumber;
    
    ValidatorTextField *opportunitId,*locationId,*consumerId,*eventId;
    
    ValidatorTextField *gaID,*brokerName,*emailID;
    UIDropDown *gaReceiptDate,*receiptDate;
    
	NSString *value;
    
    NSDictionary *profileDictionary;
}

@end

@implementation AuthorizationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
_titleString.text = [NSString stringWithFormat:@"%@ %@ - \n%@",[AppConfig enrollYear],[LanguageCentral languageSelectedString:[[AppConfig currentPlanDictionary] objectForKey:@"PlanTitle"]],[LanguageCentral languageSelectedString:[[[AppConfig currentPlanDictionary] objectForKey:NSStringFromClass([self class])]objectForKey:@"title"]]];

	[UIRenderer renderPlist:self plist:[NSString stringWithFormat:@"%@AuthorizationForm%@",[AppConfig currentPlan],[AppConfig enrollYear]]];

	
    if([[AppConfig currentPlan] isEqualToString:@"PDP"]||[[AppConfig currentPlan] isEqualToString:@"MAPD"]){
        
        [self.sharedataObj setForwardNextButtonTitle:@"Next"];
        [self.sharedataObj setNextProgressIndex:5];
        
        [self.sharedataObj setPreviousNextButtonTitle:@"Continue_to_checklist"];
        [self.sharedataObj setBackProgressIndex:5];
        
    }else if([[AppConfig currentPlan] isEqualToString:@"DSNP"]) {
        //vrl added for new DSNP attestation
         if(([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"]) && [[AppConfig progressTitleArray]count]>4){
            [self.sharedataObj setForwardNextButtonTitle:@"Next"];
            [self.sharedataObj setNextProgressIndex:4];
            
            [self.sharedataObj setPreviousNextButtonTitle:@"Next"];
            [self.sharedataObj setBackProgressIndex:4];
        }else {
            [self.sharedataObj setForwardNextButtonTitle:@"Next"];
            [self.sharedataObj setNextProgressIndex:3];
            
            [self.sharedataObj setPreviousNextButtonTitle:@"Next"];
            [self.sharedataObj setBackProgressIndex:3];
        }
        
        
    }else {
        
        NSString *otherHealthPolicy = [AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] : @"data:health_coverage:6d"];
        NSString *replaceCurrentMedicare = [AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] : @"data:health_coverage:6h"];
       
        
        if([[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"] && ([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear]isEqualToString:@"2020"])) {
            
            if([otherHealthPolicy isEqualToString:@"Yes"]||[replaceCurrentMedicare isEqualToString:@"Yes"]) {
                
                [self.sharedataObj setForwardNextButtonTitle:@"Next"];
                [self.sharedataObj setNextProgressIndex:4];
                
            }else {
                
                [self.sharedataObj setForwardNextButtonTitle:@"Preview"];
                [self.sharedataObj setNextProgressIndex:5];
            }
            
        }else {
            [self.sharedataObj setForwardNextButtonTitle:@"Next"];
            [self.sharedataObj setNextProgressIndex:4];
        }
        
        
        [self.sharedataObj setPreviousNextButtonTitle:@"Next"];
        [self.sharedataObj setBackProgressIndex:4];
           
        
    }
    
    // vrl added
    
//    if (([[AppConfig currentPlan]isEqualToString:@"SupplementUnder50"] || [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 50-64"]) && ([[AppConfig enrollYear]isEqualToString:@"2019"] || [[AppConfig enrollYear]isEqualToString:@"2020"])) {
    
    if (([[AppConfig currentPlan]isEqualToString:@"SupplementUnder50"] || [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 50-64"]) && ([[AppConfig enrollYear]isEqualToString:@"2019"])) {
        // new fields
        gaID = [UIRenderer getComponentAtIndex:1];
        gaReceiptDate = [UIRenderer getComponentAtIndex:2];
        npnNumber = [UIRenderer getComponentAtIndex:3];
        brokerName = [UIRenderer getComponentAtIndex:4];
        receiptDate = [UIRenderer getComponentAtIndex:5];
        phoneNumber = [UIRenderer getComponentAtIndex:6];
        effectiveDate = [UIRenderer getComponentAtIndex:7];
        agentId = [UIRenderer getComponentAtIndex:8];
        //DG Other Fields
        opportunitId = [UIRenderer getComponentAtIndex:9];
        consumerId = [UIRenderer getComponentAtIndex:10];
        eventId = [UIRenderer getComponentAtIndex:11];
        
    }else if ([[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"] || [[AppConfig currentPlan]isEqualToString:@"SupplementUnder50"] || [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 50-64"]){
        // new fields
        gaID = [UIRenderer getComponentAtIndex:1];
        gaReceiptDate = [UIRenderer getComponentAtIndex:2];
        npnNumber = [UIRenderer getComponentAtIndex:3];
        brokerName = [UIRenderer getComponentAtIndex:4];
        receiptDate = [UIRenderer getComponentAtIndex:5];
        phoneNumber = [UIRenderer getComponentAtIndex:6];
        effectiveDate = [UIRenderer getComponentAtIndex:7];
        //DG Other Fields
        locationId = [UIRenderer getComponentAtIndex:8];
       
    }else {
        // new fields
        gaID = [UIRenderer getComponentAtIndex:1];
        gaReceiptDate = [UIRenderer getComponentAtIndex:2];
         npnNumber = [UIRenderer getComponentAtIndex:3];
        brokerName = [UIRenderer getComponentAtIndex:4];
        receiptDate = [UIRenderer getComponentAtIndex:5];
         phoneNumber = [UIRenderer getComponentAtIndex:6];
        emailID = [UIRenderer getComponentAtIndex:7];
         effectiveDate = [UIRenderer getComponentAtIndex:8];
        agentId = [UIRenderer getComponentAtIndex:9];
        
        //DG Other Fields
        opportunitId = [UIRenderer getComponentAtIndex:10];
        locationId = [UIRenderer getComponentAtIndex:11];
        consumerId = [UIRenderer getComponentAtIndex:12];
        eventId = [UIRenderer getComponentAtIndex:13];
    }
    
	
	}

-(void)viewWillAppear:(BOOL)animated {
    
    [ScopeBaseViewController populateCurrentItemValue];
    [self loadBackData];
    [super viewWillAppear:animated];
	
	profileDictionary = [AppConfig agentProfileInfo];

	
	if ([[AppConfig currentPlan]isEqualToString:@"SupplementUnder50"] || [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 50-64"] || [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"]){
	
		value = [AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] : @"data:customer_information:effective_date"];

	}else{
		value = [AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] : @"data:plan_details:effective_date"];
	}
		
	if([value length]){
		[effectiveDate setTitleString:value];
		[effectiveDate setUserInteractionEnabled:NO];
        [effectiveDate setValueString:value];
	}
    
	[npnNumber setUserInteractionEnabled:NO]; // old
  
    // trimming alphabet character only in NPN value
//    NSString *npnNumberOnly = [[[[profileDictionary valueForKey:@"npn_id"]objectAtIndex:0] componentsSeparatedByCharactersInSet:
//                            [[NSCharacterSet decimalDigitCharacterSet] invertedSet]]
//                           componentsJoinedByString:@""];
//    PRINTLOG(@"newString ::%@",npnNumberOnly);
//    [npnNumber setLocalizationKey:npnNumberOnly];
    
	[npnNumber setLocalizationKey:[[profileDictionary valueForKey:@"npn_id"]objectAtIndex:0]];
	[agentId setLocalizationKey:[[profileDictionary valueForKey:@"agent_id"]objectAtIndex:0]];
	[phoneNumber setLocalizationKey:[[profileDictionary valueForKey:@"mobile"]objectAtIndex:0]];

	
	NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
	[dateFormatter setDateFormat:@"MM/dd/yyyy"];
	
//	receiptDate.dropDownTextLabel.text = [dateFormatter stringFromDate:[NSDate date]];

	[receiptDate setValueString:[dateFormatter stringFromDate:[NSDate date]]];
	[receiptDate setUserInteractionEnabled:NO];
	
}

-(BOOL)validateVC {
    
    npnNumber.layer.borderWidth = 1.0f;
    if(npnNumber.text.length > 0){
        
        npnNumber.layer.borderColor = BORDERCOLOR;
        return NO;
    }else {
         npnNumber.layer.borderColor = RED_BORDER_COLOR;
//        return YES;
        return NO; // npn number development purpose only , don't enable this when release IPA
    }
}


-(void)loadNextPage {
    
    NSString *gaReceiptDateString = [AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] : @"data:important_information:broker_agent:ga_receipt_date"];
    
     NSString *gaIDString = [AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] : @"data:important_information:broker_agent:ga_id"];
    
     NSString *npnID = [AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] : @"data:important_information:broker_agent:npn_id"];
    
     NSString *receiptdate = [AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] : @"data:important_information:broker_agent:receipt_date"];
    
     NSString *gaPhoneNo = [AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] : @"data:important_information:broker_agent:ga_phone_number"];
    
     NSString *gaEmailID = [AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] : @"data:important_information:broker_agent:ga_email_address"];
    

     [AppConfig fillJSONDictionary:@"data:important_information:broker_agent:effective_date" value:[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] : @"data:plan_details:effective_date"]];
    
    if(gaReceiptDateString.length>0 ||gaIDString.length>0||npnID.length>0 ||receiptdate.length>0 ||gaPhoneNo.length>0 || gaEmailID.length>0){
         [AppConfig fillJSONDictionary:@"data:important_information:authorized_broker_agent" value:@"Yes"];
    }else {
         [AppConfig fillJSONDictionary:@"data:important_information:authorized_broker_agent" value:@"No"];
    }
    
    
    
    if ([[AppConfig currentPlan]isEqualToString:@"SupplementUnder50"] || [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 50-64"] || [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"]){
        
        if(![[AppConfig enrollYear]isEqualToString:@"2019"]){
            NSString *firstLastName = [NSString stringWithFormat:@"%@ %@",[[profileDictionary valueForKey:@"first_name"]objectAtIndex:0],[[profileDictionary valueForKey:@"last_name"]objectAtIndex:0]];
            
            [AppConfig fillJSONDictionary:@"data:agent_broker_info:name" value:firstLastName];
            
//            [AppConfig fillJSONDictionary:@"data:agent_broker_info:phone_number" value:phoneNumber.text]; // old code
        }
      
         [AppConfig fillJSONDictionary:@"data:agent_broker_info:phone_number" value:phoneNumber.text];
        
    }
    
}
	

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillDisappear:(BOOL)animated {
    
    [super viewWillDisappear:animated];
    [self removeAllView];
    
}

-(void)removeAllView {
    
    for (UIView *v in _authorizationView.subviews) {
        [v removeFromSuperview];
    }
}

@end
