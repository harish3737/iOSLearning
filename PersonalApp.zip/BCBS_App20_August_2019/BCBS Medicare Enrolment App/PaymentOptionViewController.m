//
//  PaymentOptionViewController.m
//  BCBS Medicare Enrolment App
//
//  Created by CSS Corp on 27/05/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "PaymentOptionViewController.h"
#import "AppConfig.h"
#import "ScopeBaseViewController.h"

@interface PaymentOptionViewController (){
    
    UIDropDown *accountType;
    BOOL isLandscape;
    BOOL isViewAppear;
    
    NSString *currentEnrollYear;
    UIDropDown *dateView;
}

@end

@implementation PaymentOptionViewController
@synthesize myLabel,eftView,mailButton,phoneButton,eftButton,rrbButton,SubTitle,contentView;

@synthesize addNewButton;


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    _titleString.text = [NSString stringWithFormat:@"%@ %@ - \n%@",[AppConfig enrollYear],[LanguageCentral languageSelectedString:[[AppConfig currentPlanDictionary] objectForKey:@"PlanTitle"]],[LanguageCentral languageSelectedString:[[[AppConfig currentPlanDictionary] objectForKey:NSStringFromClass([self class])]objectForKey:@"title"]]];
    
    [self.sharedataObj setForwardNextButtonTitle:@"Next"];
    [self.sharedataObj setNextProgressIndex:2];
    
    [self.sharedataObj setPreviousNextButtonTitle:@"Continue_to_health"];
    [self.sharedataObj setBackProgressIndex:2];
    
    UIInterfaceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation;
    if(orientation == UIInterfaceOrientationLandscapeRight || orientation == UIInterfaceOrientationLandscapeLeft)
        isLandscape = YES;
    else
        isLandscape = NO;
    
    
    myLabel = [[ValidatorLabel alloc]init];
    
    if ([[AppConfig currentPlan] isEqualToString:@"MAPD"] && [[AppConfig enrollYear] isEqualToString:@"2017"]) {
        
        [eftButton loadImage:[UIImage imageNamed:@"Online_Electronic_transfer"]];
        [eftButton setBtnSelectedImage:[UIImage imageNamed:@"Online_Electronic_transfer_active"]];
        [eftButton setBtnUnSelectedImage:[UIImage imageNamed:@"Online_Electronic_transfer"]];
        
        [myLabel setLocalizationKey: @"PAY_BY_MAIL_2017"];
        
    }else if(([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"]) && [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"]){
        
        [eftButton loadImage:[UIImage imageNamed:@"Electronic_transfer"]];
        [eftButton setBtnSelectedImage:[UIImage imageNamed:@"Electronic_transfer_active"]];
        [eftButton setBtnUnSelectedImage:[UIImage imageNamed:@"Electronic_transfer"]];
        [myLabel setLocalizationKey: @"PAY_BY_MAIL_2018"];  //note(need to add this in SVN cource)
        
    }
    
    //svk added
    else if(([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"]) && [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 50-64"]){
        
        [eftButton loadImage:[UIImage imageNamed:@"Electronic_transfer"]];
        [eftButton setBtnSelectedImage:[UIImage imageNamed:@"Electronic_transfer_active"]];
        [eftButton setBtnUnSelectedImage:[UIImage imageNamed:@"Electronic_transfer"]];
        [myLabel setLocalizationKey: @"PAY_BY_MAIL_2018"];  //note(need to add this in SVN cource)
        
    }
    else if(([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"]) && [[AppConfig currentPlan]isEqualToString:@"SupplementUnder50"]){
        
        [eftButton loadImage:[UIImage imageNamed:@"Electronic_transfer"]];
        [eftButton setBtnSelectedImage:[UIImage imageNamed:@"Electronic_transfer_active"]];
        [eftButton setBtnUnSelectedImage:[UIImage imageNamed:@"Electronic_transfer"]];
        [myLabel setLocalizationKey: @"PAY_BY_MAIL_2018"];  //note(need to add this in SVN cource)
        
    }
    
    
    else {
        // 2016
        //    [eftButton loadImage:[UIImage imageNamed:@"Electronic_transfer"]];
        //    [eftButton setBtnSelectedImage:[UIImage imageNamed:@"Electronic_transfer_active"]];
        //    [eftButton setBtnUnSelectedImage:[UIImage imageNamed:@"Electronic_transfer"]];
        //    [myLabel setLocalizationKey: @"PAY_BY_MAIL_2018"];  //note(need to add this in SVN cource)
        
        //2018
        [eftButton loadImage:[UIImage imageNamed:@"Online_Electronic_transfer"]];
        [eftButton setBtnSelectedImage:[UIImage imageNamed:@"Online_Electronic_transfer_active"]];
        [eftButton setBtnUnSelectedImage:[UIImage imageNamed:@"Online_Electronic_transfer"]];
        [myLabel setLocalizationKey: @"PAY_BY_MAIL_2018"]; // display the text when view did load
        
    }
    
    myLabel.font = [UIFont fontWithName:@"Arial" size:18];
    
    myLabel.textColor = [UIColor colorWithRed:(102/255.f) green:(102/255.f) blue:(102/255.f) alpha:1.0];
    myLabel.textAlignment =NSTextAlignmentCenter;
    myLabel.lineBreakMode = NSLineBreakByWordWrapping;
    
    myLabel.numberOfLines = 0;
    
    myLabel.hidden = NO;
    
    [self.contentView addSubview:myLabel];
    
    
    [myLabel setTranslatesAutoresizingMaskIntoConstraints:NO];
    
    //set the width
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-10-[myLabel(>=30)]-10-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(myLabel)]];
    
    // set the height
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-10-[myLabel(>=21)]->=10-|" options:NSLayoutFormatAlignAllCenterY metrics:nil views:NSDictionaryOfVariableBindings(myLabel)]];
    
    [self.contentView updateConstraints];
    [self.contentView layoutIfNeeded];
    
    [eftView removeFromSuperview];
    
    
    PaymentOptionViewController *weakSelf = self;
    self.willLoadNext = ^(id object){
        
        [weakSelf addCustomJsonValue];
        
    };
    
    //vrl added
    if(([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"])&& [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"] ){
        self.headTitleLabel.localizationKey = @"";
        self.SubTitle.localizationKey = @"PLEASE_SELECT_PAY_BILL";
    }
    
    //svk added
    else if(([[AppConfig enrollYear] isEqualToString:@"2019"]|| [[AppConfig enrollYear] isEqualToString:@"2020"]) && [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 50-64"] )
    {
        self.headTitleLabel.localizationKey = @"";
        self.SubTitle.localizationKey = @"PLEASE_SELECT_PAY_BILL";
    }
    else if(([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"]) && [[AppConfig currentPlan]isEqualToString:@"SupplementUnder50"] )
    {
        self.headTitleLabel.localizationKey = @"";
        self.SubTitle.localizationKey = @"PLEASE_SELECT_PAY_BILL";
    }
    
    
    else {
        self.headTitleLabel.localizationKey = @"IF_APPLICATION_APPROVED";
        self.SubTitle.localizationKey = @"CHOOSE_PAYMENT_SCHEDULE";
    }
    
    if([[AppConfig enrollYear] isEqualToString:@"2017"] && [[AppConfig currentPlan]isEqualToString:@"PDP"]){
        
        [self loadPaymentButtons]; //For PDP
        
    }else  if([[AppConfig enrollYear] isEqualToString:@"2017"] && [[AppConfig currentPlan]isEqualToString:@"MAPD"]){
        
        [Validator ValidationDone];
        [self paymentButtonOrientation]; //For MAPD
        
    }else  if(([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"]) && [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"]){
        // vrl added
        [Validator ValidationDone];
        [self load2019SupplementPaymentButtonOrientation];
        
    }
    //svk added
    else if(([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"]) && [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 50-64"] )
    {
        [Validator ValidationDone];
        [self load2019SupplementPaymentButtonOrientation];
    }
    
    else if(([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"])&& [[AppConfig currentPlan]isEqualToString:@"SupplementUnder50"] )
    {
        [Validator ValidationDone];
        [self load2019SupplementPaymentButtonOrientation];
    }
    
    else if([[AppConfig currentPlan]isEqualToString:@"PDP"]){
        
        [Validator ValidationDone];
        [self PDPButtonPayment2018Orientation]; //For PDP
        
    }else {
        [Validator ValidationDone];
        [self load2018PaymentButtonOrientation]; //2018
    }
    
}


-(void)viewWillAppear:(BOOL)animated{
    
    
    [ScopeBaseViewController populateCurrentItemValue];
    [self loadBackData];
    isViewAppear = YES;
    
    currentEnrollYear = [AppConfig enrollYear];
    
    [super viewWillAppear:animated];
}


-(void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration{
    
    if (toInterfaceOrientation == UIInterfaceOrientationPortrait || toInterfaceOrientation == UIInterfaceOrientationPortraitUpsideDown) {
        
        isLandscape = NO;
        
    }
    else if (toInterfaceOrientation == UIInterfaceOrientationLandscapeRight||toInterfaceOrientation == UIInterfaceOrientationLandscapeLeft) {
        
        isLandscape = YES;
        
    }
    self.view.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin |  UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin;
    
    if([[AppConfig enrollYear] isEqualToString:@"2017"] && [[AppConfig currentPlan]isEqualToString:@"PDP"]){
        [self loadPaymentButtons];
        
    }else  if([[AppConfig enrollYear] isEqualToString:@"2017"] && [[AppConfig currentPlan]isEqualToString:@"MAPD"]){
        
        [Validator ValidationDone];
        [self paymentButtonOrientation]; //For MAPD
        
    }else if(([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"])&& [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"]){
        //vrl added
        [Validator ValidationDone];
        [self load2019SupplementPaymentButtonOrientation];
        
    }
    
    //SVK ADDED
    else if(([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"]) && [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 50-64"])
    {
        [Validator ValidationDone];
        [self load2019SupplementPaymentButtonOrientation];
    }
    
    else if(([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"]) && [[AppConfig currentPlan]isEqualToString:@"SupplementUnder50"])
    {
        [Validator ValidationDone];
        [self load2019SupplementPaymentButtonOrientation];
    }
    
    else if([[AppConfig currentPlan]isEqualToString:@"PDP"]){
        
        [Validator ValidationDone];
        [self PDPButtonPayment2018Orientation]; // For PDP
        
    }else {
        [Validator ValidationDone];
        [self load2018PaymentButtonOrientation];
        
    }
    
    [self.view updateConstraints];
    [self.view layoutIfNeeded];
    
}

// 2017 PDP payment button layout
-(void)loadPaymentButtons {
    
    [addNewButton removeFromSuperview];
    
    [eftButton removeFromSuperview];
    
    [mailButton setTranslatesAutoresizingMaskIntoConstraints:NO];
    [phoneButton setTranslatesAutoresizingMaskIntoConstraints:NO];
    [rrbButton setTranslatesAutoresizingMaskIntoConstraints:NO];
    [contentView setTranslatesAutoresizingMaskIntoConstraints:NO];
    
    
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:mailButton
                                                          attribute:NSLayoutAttributeWidth
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:nil
                                                          attribute:NSLayoutAttributeNotAnAttribute
                                                         multiplier:1.0
                                                           constant:203]];
    
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:phoneButton
                                                          attribute:NSLayoutAttributeWidth
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:nil
                                                          attribute:NSLayoutAttributeNotAnAttribute
                                                         multiplier:1.0
                                                           constant:203]];
    
    
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:rrbButton
                                                          attribute:NSLayoutAttributeWidth
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:nil
                                                          attribute:NSLayoutAttributeNotAnAttribute
                                                         multiplier:1.0
                                                           constant:203]];
    
    
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:mailButton attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterX multiplier:1 constant:-243.0]];
    
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:phoneButton attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterX multiplier:1 constant:1.0]];
    
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:rrbButton attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterX multiplier:1 constant:243.0]];
    
    
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[SubTitle(21)]-40-[mailButton(203)]-20-[contentView(180@250)]-20@250-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(SubTitle,mailButton,contentView)]];
    
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[SubTitle(21)]-40-[phoneButton(203)]-20-[contentView(180@250)]-20@250-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(SubTitle,phoneButton,contentView)]];
    
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[SubTitle(21)]-40-[rrbButton(203)]-20-[contentView(180@250)]-20@250-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(SubTitle,rrbButton,contentView)]];
    
    [self.view updateConstraints];
    [self.view layoutIfNeeded];
    
}

-(void)addCustomJsonValue {
    
    
    NSString *value = [AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] : @"data:premium_payment_schedule:account_type"];
    
    PRINTLOG(@"Value ::%@",value);
    
    if([value isEqualToString:@"Checking Account"]|| [value isEqualToString:@"0"]){
        
        [AppConfig fillJSONDictionary:@"data:premium_payment_schedule:account_type" value:@"0"];
        
    }else if([value isEqualToString:@"Savings Account"]||[value isEqualToString:@"1"]){
        [AppConfig fillJSONDictionary:@"data:premium_payment_schedule:account_type" value:@"1"];
        
    }else {
        [AppConfig fillJSONDictionary:@"data:premium_payment_schedule:account_type" value:@""];
        
    }
    
    
    if(eftButton.buttonSelected){
        if ([[AppConfig currentPlan] isEqualToString:@"MAPD"] && [[AppConfig enrollYear] isEqualToString:@"2017"]){
            [AppConfig fillJSONDictionary:@"data:premium_payment_schedule:options" value:@"Pay Online"];
            [self emptyOtherFieldsXPathValue];
            
        }else if(([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"]) && [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"]){
            
            [AppConfig fillJSONDictionary:@"data:payment_mode:options" value:@"eft"];
            
        }
        //svk added
        else if(([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"])&& [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 50-64"])
        {
            [AppConfig fillJSONDictionary:@"data:payment_mode:options" value:@"eft"];
        }
        
        else if(([[AppConfig enrollYear] isEqualToString:@"2019"]|| [[AppConfig enrollYear] isEqualToString:@"2020"]) && [[AppConfig currentPlan]isEqualToString:@"SupplementUnder50"])
        {
            [AppConfig fillJSONDictionary:@"data:payment_mode:options" value:@"eft"];
        }
        else {
            //2016 - comment below line
            //            [AppConfig fillJSONDictionary:@"data:premium_payment_schedule:options" value:@"Electronic Funds Transfer"];
            
            //2018
            [AppConfig fillJSONDictionary:@"data:premium_payment_schedule:options" value:@"Pay Online"];
            [self emptyOtherFieldsXPathValue];
            
        }
        
        
    }else if(mailButton.buttonSelected){
        
        if(([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"])&& [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"]){
            
            [AppConfig fillJSONDictionary:@"data:payment_mode:options" value:@"mail"];
        }
        
        //svk added
        else if(([[AppConfig enrollYear] isEqualToString:@"2019"]|| [[AppConfig enrollYear] isEqualToString:@"2020"]) && [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 50-64"])
        {
            [AppConfig fillJSONDictionary:@"data:payment_mode:options" value:@"mail"];
        }
        else if(([[AppConfig enrollYear] isEqualToString:@"2019"]|| [[AppConfig enrollYear] isEqualToString:@"2020"]) && [[AppConfig currentPlan]isEqualToString:@"SupplementUnder50"])
        {
            [AppConfig fillJSONDictionary:@"data:payment_mode:options" value:@"mail"];
        }
        
        
        else {
            [AppConfig fillJSONDictionary:@"data:premium_payment_schedule:options" value:@"Get a bill monthly"];
        }
        
        
        [self emptyOtherFieldsXPathValue];
        
    }else if(phoneButton.buttonSelected){
        [AppConfig fillJSONDictionary:@"data:premium_payment_schedule:options" value:@"Pay by phone monthly"];
        [self emptyOtherFieldsXPathValue];
        
    }else if(rrbButton.buttonSelected){
        
        if([currentEnrollYear isEqualToString:@"2018"]){
            [AppConfig fillJSONDictionary:@"data:premium_payment_schedule:options" value:@"SSA"];
        }else {
            //2017
            //            [AppConfig fillJSONDictionary:@"data:premium_payment_schedule:options" value:@"Automatic deduction"];
            
            //2019
            [AppConfig fillJSONDictionary:@"data:premium_payment_schedule:options" value:@"SSA"];
        }
        
        [self emptyOtherFieldsXPathValue];
        
    }else if(addNewButton.buttonSelected){
        
        [AppConfig fillJSONDictionary:@"data:premium_payment_schedule:options" value:@"RRB"];
        [self emptyOtherFieldsXPathValue];
    }
    
}


-(void)loadBackData {
    
    NSString *paymentOptions;
    
    if(([[AppConfig enrollYear] isEqualToString:@"2019"]|| [[AppConfig enrollYear] isEqualToString:@"2020"]) && [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"]){
        paymentOptions = [AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:payment_mode:options"];
    }
    //svk added
    else if(([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"])&& [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 50-64"])
    {
        paymentOptions = [AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:payment_mode:options"];
    }
    else if(([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"]) && [[AppConfig currentPlan]isEqualToString:@"SupplementUnder50"])
    {
        paymentOptions = [AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:payment_mode:options"];
    }
    else {
        paymentOptions = [AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:premium_payment_schedule:options"];
    }
    
    
    PRINTLOG(@"Paymentoptions ::%@",paymentOptions);
    
    if(paymentOptions.length == 0){
        
        if(([[AppConfig enrollYear] isEqualToString:@"2019"]||[[AppConfig enrollYear] isEqualToString:@"2020"] )&& [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"]){
            [AppConfig fillJSONDictionary:@"data:payment_mode:options" value:@"mail"];
            paymentOptions = @"mail";
        }else {
            [AppConfig fillJSONDictionary:@"data:premium_payment_schedule:options" value:@"Get a bill monthly"];
            paymentOptions = @"Get a bill monthly";
        }
        
    }
    
    if ([[AppConfig currentPlan] isEqualToString:@"MAPD"] && [[AppConfig enrollYear] isEqualToString:@"2017"]) {
        
        [eftButton loadImage:[UIImage imageNamed:@"Online_Electronic_transfer"]];
        [eftButton setBtnSelectedImage:[UIImage imageNamed:@"Online_Electronic_transfer_active"]];
        [eftButton setBtnUnSelectedImage:[UIImage imageNamed:@"Online_Electronic_transfer"]];
        [myLabel setLocalizationKey: @"PAY_BY_MAIL_2017"];
        
    }else if(([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"])&& [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"]){
        
        [eftButton loadImage:[UIImage imageNamed:@"Electronic_transfer"]];
        [eftButton setBtnSelectedImage:[UIImage imageNamed:@"Electronic_transfer_active"]];
        [eftButton setBtnUnSelectedImage:[UIImage imageNamed:@"Electronic_transfer"]];
        [myLabel setLocalizationKey: @"PAY_BY_MAIL_2018"];  //note(need to add this in SVN cource)
        
    }
    
    //svk added
    else if(([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"])&& [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 50-64"])
    {
        [eftButton loadImage:[UIImage imageNamed:@"Electronic_transfer"]];
        [eftButton setBtnSelectedImage:[UIImage imageNamed:@"Electronic_transfer_active"]];
        [eftButton setBtnUnSelectedImage:[UIImage imageNamed:@"Electronic_transfer"]];
        [myLabel setLocalizationKey: @"PAY_BY_MAIL_2018"];
        
    }
    else if(([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"])&& [[AppConfig currentPlan]isEqualToString:@"SupplementUnder50"])
    {
        [eftButton loadImage:[UIImage imageNamed:@"Electronic_transfer"]];
        [eftButton setBtnSelectedImage:[UIImage imageNamed:@"Electronic_transfer_active"]];
        [eftButton setBtnUnSelectedImage:[UIImage imageNamed:@"Electronic_transfer"]];
        [myLabel setLocalizationKey: @"PAY_BY_MAIL_2018"];
        
    }
    
    else{
        // 2016
        //        [eftButton loadImage:[UIImage imageNamed:@"Electronic_transfer"]];
        //        [eftButton setBtnSelectedImage:[UIImage imageNamed:@"Electronic_transfer_active"]];
        //        [eftButton setBtnUnSelectedImage:[UIImage imageNamed:@"Electronic_transfer"]];
        //
        //        [myLabel setLocalizationKey: @"PAY_BY_MAIL_2018"];  //note(need to add this in SVN cource)
        
        //2018
        [eftButton loadImage:[UIImage imageNamed:@"Online_Electronic_transfer"]];
        [eftButton setBtnSelectedImage:[UIImage imageNamed:@"Online_Electronic_transfer_active"]];
        [eftButton setBtnUnSelectedImage:[UIImage imageNamed:@"Online_Electronic_transfer"]];
        
        [myLabel setLocalizationKey: @"PAY_BY_MAIL_2018"];
        
    }
    
    
    if([paymentOptions isEqualToString:@"Get a bill monthly"]){
        
        [mailButton setRadioButtonSelected:YES];
        [myLabel setLocalizationKey: @"PAY_BY_MAIL_2018"];
        
        
    }
    
    if([paymentOptions isEqualToString:@"mail"]){
        
        [mailButton setRadioButtonSelected:YES];
        [myLabel setLocalizationKey: @"PAY_BY_MAIL_2018"];
        
        
    }
    
    if([paymentOptions isEqualToString:@"Pay by phone monthly"]){
        
        [phoneButton setRadioButtonSelected:YES];
        [myLabel setLocalizationKey:@"CALL_CUSTOMER_SERVICE"];
        
    }
    
    
    
    if([paymentOptions isEqualToString:@"Electronic Funds Transfer"]||[paymentOptions isEqualToString:@"Pay Online"]){
        
        [eftButton setRadioButtonSelected:YES];
        
        if ([[AppConfig currentPlan] isEqualToString:@"MAPD"] && [[AppConfig enrollYear] isEqualToString:@"2017"]){
            self.myLabel.hidden = NO;
            
            [myLabel setLocalizationKey:@"PAY_ONLINE_MAPD_2017"];
            
            [self enableEFTView:NO];
            [eftView removeFromSuperview];
            
        }else if(([[AppConfig enrollYear] isEqualToString:@"2019"]|| [[AppConfig enrollYear] isEqualToString:@"2020"]) && [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"]){
            
            self.myLabel.hidden = NO;
            [myLabel setLocalizationKey:@"PAY_BY_EFT_2019"];
            [self loadMultipleView];
            
        }
        //svk added
        else if(([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"])&& [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 50-64"])
        {
            self.myLabel.hidden = NO;
            [myLabel setLocalizationKey:@"PAY_BY_EFT_2019"];
        }
        else if(([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"])&& [[AppConfig currentPlan]isEqualToString:@"SupplementUnder50"])
        {
            self.myLabel.hidden = NO;
            [myLabel setLocalizationKey:@"PAY_BY_EFT_2019"];
        }
        else {
            //2016
            //            self.myLabel.hidden = YES;
            //            [self loadMultipleView];
            
            //2018
            self.myLabel.hidden = NO;
            [myLabel setLocalizationKey:@"PAY_ONLINE_MAPD_2017"];
            [self enableEFTView:NO];
            [eftView removeFromSuperview];
        }
    }
    
    if([paymentOptions isEqualToString:@"eft"]){
        
        [eftButton setRadioButtonSelected:YES];
        
        if(([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"])&& [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"]){
            
            self.myLabel.hidden = NO;
            [myLabel setLocalizationKey:@"PAY_BY_EFT_2019"];
            [self loadMultipleView];
            
        }
        //svk added SupplementUnder50
        else if(([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"])&& [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 50-64"])
        {
            self.myLabel.hidden = NO;
            [myLabel setLocalizationKey:@"PAY_BY_EFT_2019"];
            //            [self loadMultipleView];
        }
        else if(([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"])&& [[AppConfig currentPlan]isEqualToString:@"SupplementUnder50"])
        {
            self.myLabel.hidden = NO;
            [myLabel setLocalizationKey:@"PAY_BY_EFT_2019"];
            //            [self loadMultipleView];
        }
        
        else {
            
            //2018
            self.myLabel.hidden = NO;
            [myLabel setLocalizationKey:@"PAY_ONLINE_MAPD_2017"];
            [self enableEFTView:NO];
            [eftView removeFromSuperview];
        }
    }
    
    
    
    // original code
    //    if([paymentOptions isEqualToString:@"Automatic deduction"]){
    //
    //        [rrbButton setRadioButtonSelected:YES];
    //        if([currentEnrollYear isEqualToString:@"2018"]){
    //            [myLabel setLocalizationKey:@"SOCIAL_SECURITY_2018"];
    //        }else {
    //            [myLabel setLocalizationKey:@"SOCIAL_SECURITY_RRB"];
    //        }
    //
    //    }
    
    if([paymentOptions isEqualToString:@"Automatic deduction"]){
        
        [rrbButton setRadioButtonSelected:YES];
        [myLabel setLocalizationKey:@"SOCIAL_SECURITY_RRB"];
    }
    
    if([paymentOptions isEqualToString:@"SSA"]){
        
        [rrbButton setRadioButtonSelected:YES];
        [myLabel setLocalizationKey:@"SOCIAL_SECURITY_2018"];
        
    }
    
    if([paymentOptions isEqualToString:@"RRB"]){
        
        [addNewButton setRadioButtonSelected:YES];
        [myLabel setLocalizationKey:@"RRB_2018"];
        
    }
    
    
}

-(void)emptyOtherFieldsXPathValue {
    
    [AppConfig fillJSONDictionary:@"data:premium_payment_schedule:account_holder_name" value:@""];
    [AppConfig fillJSONDictionary:@"data:premium_payment_schedule:bank_routing_number" value:@""];
    [AppConfig fillJSONDictionary:@"data:premium_payment_schedule:account_type" value:@""];
    [AppConfig fillJSONDictionary:@"data:premium_payment_schedule:bank_account_number" value:@""];
}


-(void)enableEFTView:(BOOL)enable{
    
    for (id currentItem in self.eftView.subviews) {
        [currentItem setUserInteractionEnabled:enable];
    }
}


- (IBAction)mailMeBillButton:(id)sender {
    
    [self removeEftview];
    self.myLabel.hidden = NO;
    
    if ([[AppConfig currentPlan] isEqualToString:@"MAPD"] && [[AppConfig enrollYear] isEqualToString:@"2017"]) {
        [myLabel setLocalizationKey: @"PAY_BY_MAIL_2017"];
    }else{
        [myLabel setLocalizationKey: @"PAY_BY_MAIL_2018"];  //note(need to add this in SVN cource)
    }
    
    // Reset the values of EFT View , when we clicked Mail Button in Medigap 65+ 2019
    if(([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"] )&& [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"]){
        [self medigap65ResetEFTViewJSONValues];
    }
    
    
}

- (IBAction)payByPhoneButton:(id)sender {
    
    [self removeEftview];
    self.myLabel.hidden = NO;
    [myLabel setLocalizationKey:@"CALL_CUSTOMER_SERVICE"];
    
}

- (IBAction)rrbButton:(id)sender {
    
    [self removeEftview];
    self.myLabel.hidden = NO;
    if([currentEnrollYear isEqualToString:@"2018"]){
        [myLabel setLocalizationKey:@"SOCIAL_SECURITY_2018"];
    }else {
        //2017
        //        [myLabel setLocalizationKey:@"SOCIAL_SECURITY_RRB"];
        
        //2019
        [myLabel setLocalizationKey:@"SOCIAL_SECURITY_2018"];
    }
}

- (IBAction)eftButton:(id)sender {
    
    [self removeEftview];
    
    if ([[AppConfig currentPlan] isEqualToString:@"MAPD"] && [[AppConfig enrollYear] isEqualToString:@"2017"]){
        self.myLabel.hidden = NO;
        [myLabel setLocalizationKey:@"PAY_ONLINE_MAPD_2017"];
        [eftButton setBtnSelectedImage:[UIImage imageNamed:@"Online_Electronic_transfer_active"]];
        
    }else if(([[AppConfig enrollYear] isEqualToString:@"2019"]|| [[AppConfig enrollYear] isEqualToString:@"2020"]) && [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"]){
        
        self.myLabel.hidden = NO;
        [myLabel setLocalizationKey:@"PAY_BY_EFT_2019"];
        [self loadMultipleView];
        
    }
    //svk added
    else if(([[AppConfig enrollYear] isEqualToString:@"2019"]|| [[AppConfig enrollYear] isEqualToString:@"2020"]) && [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 50-64"])
    {
        self.myLabel.hidden = NO;
        [myLabel setLocalizationKey:@"PAY_BY_EFT_2019"];
        //        [self loadMultipleView];
    }
    else if(([[AppConfig enrollYear] isEqualToString:@"2019"]|| [[AppConfig enrollYear] isEqualToString:@"2020"]) && [[AppConfig currentPlan]isEqualToString:@"SupplementUnder50"])
    {
        self.myLabel.hidden = NO;
        [myLabel setLocalizationKey:@"PAY_BY_EFT_2019"];
        //        [self loadMultipleView];
    }
    else {
        //2016
        //        self.myLabel.hidden = YES;
        //        [self loadMultipleView];
        
        //2018
        self.myLabel.hidden = NO;
        [myLabel setLocalizationKey:@"PAY_ONLINE_MAPD_2017"];
        [eftButton setBtnSelectedImage:[UIImage imageNamed:@"Online_Electronic_transfer_active"]];
    }
}

- (IBAction)addNewButtonAction:(id)sender {
    
    [self removeEftview];
    self.myLabel.hidden = NO;
    [myLabel setLocalizationKey:@"RRB_2018"];
    
}

-(void)loadMultipleView {
    
    [Validator ValidationDone];
    
    eftView = [[UIView alloc]init];
    self.eftView.hidden = NO;
    [self enableEFTView:YES];
    [self.contentView addSubview:eftView];
    
    [eftView setTranslatesAutoresizingMaskIntoConstraints:NO];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[eftView]|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(eftView)]];
    
    if(([[AppConfig enrollYear] isEqualToString:@"2019"]||[[AppConfig enrollYear] isEqualToString:@"2020"]) && [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"]){
        [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-50-[eftView]|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(eftView)]];
    }else {
        [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[eftView]|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(eftView)]];
    }
    
    
    [UIRenderer renderPlist:self plist:[NSString stringWithFormat:@"%@PaymentOptionForm%@",[AppConfig currentPlan],[AppConfig enrollYear]]];
    
    [ScopeBaseViewController populateCurrentItemValue];
    
    // testing purpose
    //    int i=0;
    //
    //    while ([UIRenderer getComponentAtIndex:i]!=nil) {
    //
    //        PRINTLOG(@"Render EFT view :::%ld ---- %@",i,[UIRenderer getComponentAtIndex:i]);
    //        i++;
    //    }
    
    if(([[AppConfig enrollYear] isEqualToString:@"2019"]||[[AppConfig enrollYear] isEqualToString:@"2020"]) && [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"]){
        
        
        PRINTLOG(@"account type ::%@",[UIRenderer getComponentAtIndex:14]);
        
        dateView = [UIRenderer getComponentAtIndex:14];
        dateView.dropDownImageView.hidden = YES;
        NSDate *todayDate = [NSDate date];
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
        dateFormatter.dateFormat = @"MM/dd/yyyy";
        [dateView setTitleString:[dateFormatter stringFromDate:todayDate]];
        [dateView setValueString:[dateFormatter stringFromDate:todayDate]];
        dateView.userInteractionEnabled = NO;
        
        
    }else {
        accountType = [UIRenderer getComponentAtIndex:9];
        NSString *value = [AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] : @"data:premium_payment_schedule:account_type"];
        
        
        if([value isEqualToString:@"0"]){
            [accountType setTitleString:@"Checking Account"];
        }else if([value isEqualToString:@"1"]) {
            [accountType setTitleString:@"Savings Account"];
        }else {
            [accountType setTitleString:@"Select"];
        }
    }
}


//2017 - MAPD
-(void)paymentButtonOrientation {
    
    [addNewButton removeFromSuperview];
    
    [SubTitle setTranslatesAutoresizingMaskIntoConstraints:NO];
    [contentView setTranslatesAutoresizingMaskIntoConstraints:NO];
    
    
    id horizontalLandscape,horizontalLandscape1,horizontalLandscape2,horizontalLandscape3,verticalLS1,verticalLS2,verticalLS3,verticalLS4;
    
    
    id horizontalPortrait1;
    id horizontalPortrait2;
    
    id horizontalPortrait3;
    id horizontalPortrait4;
    id verticalPortrait1 ;
    id verticalPortrait2;
    
    
    [self resetButton];
    
    if (isLandscape){
        
        
        mailButton = [[UIRadioButton alloc]init];
        mailButton.groupName = @"PAYMENT";
        mailButton.tag = 4;
        [mailButton loadImage:[UIImage imageNamed:@"Mail_bill"]];
        [mailButton setBtnSelectedImage:[UIImage imageNamed:@"Mail_bill_active"]];
        [mailButton setBtnUnSelectedImage:[UIImage imageNamed:@"Mail_bill"]];
        [self.view addSubview:mailButton];
        
        
        
        phoneButton = [[UIRadioButton alloc]init];
        phoneButton.groupName = @"PAYMENT";
        phoneButton.tag = 5;
        [phoneButton loadImage:[UIImage imageNamed:@"Pay_by_phone"]];
        [phoneButton setBtnSelectedImage:[UIImage imageNamed:@"Pay_by_phone_active"]];
        [phoneButton setBtnUnSelectedImage:[UIImage imageNamed:@"Pay_by_phone"]];
        [self.view addSubview:phoneButton];
        
        
        eftButton = [[UIRadioButton alloc]init];
        eftButton.groupName = @"PAYMENT";
        eftButton.tag = 6;
        //2016
        //        [eftButton loadImage:[UIImage imageNamed:@"Electronic_transfer"]];
        //        [eftButton setBtnSelectedImage:[UIImage imageNamed:@"Electronic_transfer_active"]];
        //        [eftButton setBtnUnSelectedImage:[UIImage imageNamed:@"Electronic_transfer"]];
        
        //2017
        [eftButton loadImage:[UIImage imageNamed:@"Online_Electronic_transfer"]];
        [eftButton setBtnSelectedImage:[UIImage imageNamed:@"Online_Electronic_transfer_active"]];
        [eftButton setBtnUnSelectedImage:[UIImage imageNamed:@"Online_Electronic_transfer"]];
        
        [self.view addSubview:eftButton];
        
        
        rrbButton = [[UIRadioButton alloc]init];
        rrbButton.groupName = @"PAYMENT";
        rrbButton.tag = 7;
        [rrbButton loadImage:[UIImage imageNamed:@"Deduct_from_social1"]];
        [rrbButton setBtnSelectedImage:[UIImage imageNamed:@"Deduct_from_social_active"]];
        [rrbButton setBtnUnSelectedImage:[UIImage imageNamed:@"Deduct_from_social1"]];
        [self.view addSubview:rrbButton];
        
        
        [mailButton setTranslatesAutoresizingMaskIntoConstraints:NO];
        [phoneButton setTranslatesAutoresizingMaskIntoConstraints:NO];
        [eftButton setTranslatesAutoresizingMaskIntoConstraints:NO];
        [rrbButton setTranslatesAutoresizingMaskIntoConstraints:NO];
        
        
        verticalLS1 = [NSLayoutConstraint constraintsWithVisualFormat:@"V:[SubTitle(40)]-40-[mailButton(203)]-40-[contentView(50@250)]-20-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(SubTitle,mailButton,contentView)];
        
        verticalLS2 = [NSLayoutConstraint constraintsWithVisualFormat:@"V:[SubTitle(40)]-40-[phoneButton(203)]-40-[contentView(50@250)]-20-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(SubTitle,phoneButton,contentView)];
        
        verticalLS3 = [NSLayoutConstraint constraintsWithVisualFormat:@"V:[SubTitle(40)]-40@250-[eftButton(203)]-40-[contentView(50@250)]-20-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(SubTitle,eftButton,contentView)];
        
        verticalLS4 = [NSLayoutConstraint constraintsWithVisualFormat:@"V:[SubTitle(40)]-40@250-[rrbButton(203)]-40-[contentView(50@250)]-20-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(SubTitle,rrbButton,contentView)];
        
        
        
        horizontalLandscape = @[[NSLayoutConstraint constraintWithItem:mailButton
                                                             attribute:NSLayoutAttributeCenterX
                                                             relatedBy:NSLayoutRelationEqual
                                                                toItem:self.view
                                                             attribute:NSLayoutAttributeCenterX
                                                            multiplier:1.f constant:-380.f]
                                ];
        
        horizontalLandscape1 = @[[NSLayoutConstraint constraintWithItem:rrbButton
                                                              attribute:NSLayoutAttributeCenterX
                                                              relatedBy:NSLayoutRelationEqual
                                                                 toItem:self.view
                                                              attribute:NSLayoutAttributeCenterX
                                                             multiplier:1.f constant:380.f]
                                 ];
        
        horizontalLandscape2 = @[[NSLayoutConstraint constraintWithItem:phoneButton
                                                              attribute:NSLayoutAttributeCenterX
                                                              relatedBy:NSLayoutRelationEqual
                                                                 toItem:self.view
                                                              attribute:NSLayoutAttributeCenterX
                                                             multiplier:1.f constant:-120.f]
                                 ];
        
        horizontalLandscape3 = @[[NSLayoutConstraint constraintWithItem:eftButton
                                                              attribute:NSLayoutAttributeCenterX
                                                              relatedBy:NSLayoutRelationEqual
                                                                 toItem:self.view
                                                              attribute:NSLayoutAttributeCenterX
                                                             multiplier:1.f constant:120.f]
                                 ];
        
        
        [self.view removeConstraints:horizontalPortrait1];
        [self.view removeConstraints:horizontalPortrait2];
        [self.view removeConstraints:verticalPortrait1];
        [self.view removeConstraints:verticalPortrait2];
        
        [self.view removeConstraints:horizontalPortrait3];
        [self.view removeConstraints:horizontalPortrait4];
        
        [self.view addConstraints:horizontalLandscape];
        [self.view addConstraints:horizontalLandscape1];
        [self.view addConstraints:horizontalLandscape2];
        [self.view addConstraints:horizontalLandscape3];
        
        [self.view addConstraints:verticalLS1];
        [self.view addConstraints:verticalLS2];
        [self.view addConstraints:verticalLS3];
        [self.view addConstraints:verticalLS4];
        
    }else {
        
        mailButton = [[UIRadioButton alloc]init];
        mailButton.groupName = @"PAYMENT";
        mailButton.tag = 4;
        [mailButton loadImage:[UIImage imageNamed:@"Mail_bill"]];
        [mailButton setBtnSelectedImage:[UIImage imageNamed:@"Mail_bill_active"]];
        [mailButton setBtnUnSelectedImage:[UIImage imageNamed:@"Mail_bill"]];
        [self.view addSubview:mailButton];
        
        phoneButton = [[UIRadioButton alloc]init];
        phoneButton.groupName = @"PAYMENT";
        phoneButton.tag = 5;
        [phoneButton loadImage:[UIImage imageNamed:@"Pay_by_phone"]];
        [phoneButton setBtnSelectedImage:[UIImage imageNamed:@"Pay_by_phone_active"]];
        [phoneButton setBtnUnSelectedImage:[UIImage imageNamed:@"Pay_by_phone"]];
        [self.view addSubview:phoneButton];
        
        
        
        eftButton = [[UIRadioButton alloc]init];
        eftButton.groupName = @"PAYMENT";
        eftButton.tag = 6;
        //2016
        //        [eftButton loadImage:[UIImage imageNamed:@"Electronic_transfer"]];
        //        [eftButton setBtnSelectedImage:[UIImage imageNamed:@"Electronic_transfer_active"]];
        //        [eftButton setBtnUnSelectedImage:[UIImage imageNamed:@"Electronic_transfer"]];
        
        //2017
        [eftButton loadImage:[UIImage imageNamed:@"Online_Electronic_transfer"]];
        [eftButton setBtnSelectedImage:[UIImage imageNamed:@"Online_Electronic_transfer_active"]];
        [eftButton setBtnUnSelectedImage:[UIImage imageNamed:@"Online_Electronic_transfer"]];
        
        [self.view addSubview:eftButton];
        
        
        rrbButton = [[UIRadioButton alloc]init];
        rrbButton.groupName = @"PAYMENT";
        rrbButton.tag = 7;
        [rrbButton loadImage:[UIImage imageNamed:@"Deduct_from_social1"]];
        [rrbButton setBtnSelectedImage:[UIImage imageNamed:@"Deduct_from_social_active"]];
        [rrbButton setBtnUnSelectedImage:[UIImage imageNamed:@"Deduct_from_social1"]];
        
        [self.view addSubview:rrbButton];
        
        [mailButton setTranslatesAutoresizingMaskIntoConstraints:NO];
        [phoneButton setTranslatesAutoresizingMaskIntoConstraints:NO];
        [eftButton setTranslatesAutoresizingMaskIntoConstraints:NO];
        [rrbButton setTranslatesAutoresizingMaskIntoConstraints:NO];
        
        
        horizontalPortrait1 = @[[NSLayoutConstraint constraintWithItem:mailButton
                                                             attribute:NSLayoutAttributeCenterX
                                                             relatedBy:NSLayoutRelationEqual
                                                                toItem:self.view
                                                             attribute:NSLayoutAttributeCenterX
                                                            multiplier:1.f constant:-150.f]
                                ];
        
        horizontalPortrait2 = @[[NSLayoutConstraint constraintWithItem:phoneButton
                                                             attribute:NSLayoutAttributeCenterX
                                                             relatedBy:NSLayoutRelationEqual
                                                                toItem:self.view
                                                             attribute:NSLayoutAttributeCenterX
                                                            multiplier:1.f constant:150.f]
                                ];
        
        horizontalPortrait3 = @[[NSLayoutConstraint constraintWithItem:eftButton
                                                             attribute:NSLayoutAttributeCenterX
                                                             relatedBy:NSLayoutRelationEqual
                                                                toItem:self.view
                                                             attribute:NSLayoutAttributeCenterX
                                                            multiplier:1.f constant:-150.f]
                                ];
        
        horizontalPortrait4 = @[[NSLayoutConstraint constraintWithItem:rrbButton
                                                             attribute:NSLayoutAttributeCenterX
                                                             relatedBy:NSLayoutRelationEqual
                                                                toItem:self.view
                                                             attribute:NSLayoutAttributeCenterX
                                                            multiplier:1.f constant:150.f]
                                ];
        
        
        verticalPortrait1 = [NSLayoutConstraint constraintsWithVisualFormat:@"V:[SubTitle(40)]-40-[mailButton(203)]-40-[eftButton(203)]-40-[contentView(50@250)]-20-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(SubTitle,mailButton,eftButton,contentView)];
        
        verticalPortrait2 = [NSLayoutConstraint constraintsWithVisualFormat:@"V:[SubTitle(40)]-40-[phoneButton(203)]-40-[rrbButton(203)]-40-[contentView(50@250)]-20-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(SubTitle,phoneButton,rrbButton,contentView)];
        
        [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|-(>=20)-[mailButton(==203)]-(>=20)-|" options: NSLayoutFormatAlignAllCenterX | NSLayoutFormatAlignAllCenterY
                                                                          metrics:nil views:NSDictionaryOfVariableBindings(mailButton)]];
        
        [self.view removeConstraints:horizontalLandscape];
        
        [self.view removeConstraints:horizontalLandscape1];
        [self.view removeConstraints:horizontalLandscape2];
        [self.view removeConstraints:horizontalLandscape3];
        
        [self.view removeConstraints:verticalLS1];
        [self.view removeConstraints:verticalLS2];
        [self.view removeConstraints:verticalLS3];
        [self.view removeConstraints:verticalLS4];
        
        
        [self.view addConstraints:verticalPortrait1];
        [self.view addConstraints:verticalPortrait2];
        [self.view addConstraints:horizontalPortrait1];
        [self.view addConstraints:horizontalPortrait2];
        [self.view addConstraints:horizontalPortrait3];
        [self.view addConstraints:horizontalPortrait4];
        
        
    }
    
    [mailButton addTarget:self action:@selector(mailButtonSelected) forControlEvents:UIControlEventTouchUpInside];
    [phoneButton addTarget:self action:@selector(phoneButtonSelected) forControlEvents:UIControlEventTouchUpInside];
    [eftButton addTarget:self action:@selector(eftButtonSelected) forControlEvents:UIControlEventTouchUpInside];
    [rrbButton addTarget:self action:@selector(rrbButtonSelected) forControlEvents:UIControlEventTouchUpInside];
    
    
    [self.view setNeedsUpdateConstraints];
    [self.view updateConstraints];
    [self.view layoutIfNeeded];
    
    if(isViewAppear){
        [self showSelectedPaymentButton];
    }
    
    
}


//2018 - MAPD
-(void)load2018PaymentButtonOrientation {
    
    [SubTitle setTranslatesAutoresizingMaskIntoConstraints:NO];
    [contentView setTranslatesAutoresizingMaskIntoConstraints:NO];
    
    
    id horizontalPortrait1;
    id horizontalPortrait2;
    id horizontalPortrait3;
    id horizontalPortrait4;
    id horizontalPortrait5;
    id verticalPortrait1 ;
    id verticalPortrait2;
    id verticalPortrait3 ;
    id verticalPortrait4;
    id verticalPortrait5;
    
    
    [self resetButton];
    
    
    
    mailButton = [[UIRadioButton alloc]init];
    mailButton.groupName = @"PAYMENT";
    mailButton.tag = 4;
    [mailButton loadImage:[UIImage imageNamed:@"Mail_bill"]];
    [mailButton setBtnSelectedImage:[UIImage imageNamed:@"Mail_bill_active"]];
    [mailButton setBtnUnSelectedImage:[UIImage imageNamed:@"Mail_bill"]];
    [self.view addSubview:mailButton];
    
    phoneButton = [[UIRadioButton alloc]init];
    phoneButton.groupName = @"PAYMENT";
    phoneButton.tag = 5;
    [phoneButton loadImage:[UIImage imageNamed:@"Pay_by_phone"]];
    [phoneButton setBtnSelectedImage:[UIImage imageNamed:@"Pay_by_phone_active"]];
    [phoneButton setBtnUnSelectedImage:[UIImage imageNamed:@"Pay_by_phone"]];
    [self.view addSubview:phoneButton];
    
    
    
    eftButton = [[UIRadioButton alloc]init];
    eftButton.groupName = @"PAYMENT";
    eftButton.tag = 6;
    //2016
    //    [eftButton loadImage:[UIImage imageNamed:@"Electronic_transfer"]];
    //    [eftButton setBtnSelectedImage:[UIImage imageNamed:@"Electronic_transfer_active"]];
    //    [eftButton setBtnUnSelectedImage:[UIImage imageNamed:@"Electronic_transfer"]];
    
    //2018
    [eftButton loadImage:[UIImage imageNamed:@"Online_Electronic_transfer"]];
    [eftButton setBtnSelectedImage:[UIImage imageNamed:@"Online_Electronic_transfer_active"]];
    [eftButton setBtnUnSelectedImage:[UIImage imageNamed:@"Online_Electronic_transfer"]];
    
    [self.view addSubview:eftButton];
    
    
    rrbButton = [[UIRadioButton alloc]init];
    rrbButton.groupName = @"PAYMENT";
    rrbButton.tag = 7;
    
    [rrbButton loadImage:[UIImage imageNamed:@"Deduct_from_social_2018"]];
    [rrbButton setBtnSelectedImage:[UIImage imageNamed:@"Deduct_from_social_active_2018"]];
    [rrbButton setBtnUnSelectedImage:[UIImage imageNamed:@"Deduct_from_social_2018"]];
    
    [self.view addSubview:rrbButton];
    
    
    
    addNewButton = [[UIRadioButton alloc]init];
    addNewButton.groupName = @"PAYMENT";
    addNewButton.tag = 8;
    [addNewButton loadImage:[UIImage imageNamed:@"Deduct_from_rrb_2018"]];
    [addNewButton setBtnSelectedImage:[UIImage imageNamed:@"Deduct_from_rrb_active_2018"]];
    [addNewButton setBtnUnSelectedImage:[UIImage imageNamed:@"Deduct_from_rrb_2018"]];
    [self.view addSubview:addNewButton];
    
    [mailButton setTranslatesAutoresizingMaskIntoConstraints:NO];
    [phoneButton setTranslatesAutoresizingMaskIntoConstraints:NO];
    [eftButton setTranslatesAutoresizingMaskIntoConstraints:NO];
    [rrbButton setTranslatesAutoresizingMaskIntoConstraints:NO];
    [addNewButton setTranslatesAutoresizingMaskIntoConstraints:NO];
    
    
    horizontalPortrait1 = @[[NSLayoutConstraint constraintWithItem:mailButton
                                                         attribute:NSLayoutAttributeCenterX
                                                         relatedBy:NSLayoutRelationEqual
                                                            toItem:self.view
                                                         attribute:NSLayoutAttributeCenterX
                                                        multiplier:1.f constant:-243.0f]
                            ];
    
    horizontalPortrait2 = @[[NSLayoutConstraint constraintWithItem:phoneButton
                                                         attribute:NSLayoutAttributeCenterX
                                                         relatedBy:NSLayoutRelationEqual
                                                            toItem:self.view
                                                         attribute:NSLayoutAttributeCenterX
                                                        multiplier:1.f constant:1.0f]
                            ];
    
    horizontalPortrait3 = @[[NSLayoutConstraint constraintWithItem:eftButton
                                                         attribute:NSLayoutAttributeCenterX
                                                         relatedBy:NSLayoutRelationEqual
                                                            toItem:self.view
                                                         attribute:NSLayoutAttributeCenterX
                                                        multiplier:1.f constant:243.0f]
                            ];
    
    horizontalPortrait4 = @[[NSLayoutConstraint constraintWithItem:rrbButton
                                                         attribute:NSLayoutAttributeCenterX
                                                         relatedBy:NSLayoutRelationEqual
                                                            toItem:self.view
                                                         attribute:NSLayoutAttributeCenterX
                                                        multiplier:1.f constant:-123.0f]
                            ];
    
    
    horizontalPortrait5 = @[[NSLayoutConstraint constraintWithItem:addNewButton
                                                         attribute:NSLayoutAttributeCenterX
                                                         relatedBy:NSLayoutRelationEqual
                                                            toItem:self.view
                                                         attribute:NSLayoutAttributeCenterX
                                                        multiplier:1.f constant:123.0f]
                            ];
    
    
//          verticalPortrait1 = [NSLayoutConstraint constraintsWithVisualFormat:@"V:[SubTitle(40)]-40-[mailButton(203)]-40-[eftButton(203)]-40-[contentView(50@250)]-20-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(SubTitle,mailButton,eftButton,contentView)];
    //
//         verticalPortrait2 = [NSLayoutConstraint constraintsWithVisualFormat:@"V:[SubTitle(40)]-40-[phoneButton(203)]-40-[rrbButton(203)]-40-[contentView(50@250)]-20-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(SubTitle,phoneButton,rrbButton,contentView)];
    
    
    verticalPortrait1 = [NSLayoutConstraint constraintsWithVisualFormat:@"V:[SubTitle(40)]-40-[mailButton(203)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(SubTitle,mailButton,eftButton,contentView)];
    
    verticalPortrait2 = [NSLayoutConstraint constraintsWithVisualFormat:@"V:[SubTitle(40)]-40-[phoneButton(203)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(SubTitle,phoneButton,rrbButton,contentView)];
    
    verticalPortrait3 = [NSLayoutConstraint constraintsWithVisualFormat:@"V:[SubTitle(40)]-40-[eftButton(203)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(SubTitle,eftButton,contentView)];
    
    
    verticalPortrait4 = [NSLayoutConstraint constraintsWithVisualFormat:@"V:[SubTitle(40)]-40-[phoneButton(203)]-40-[rrbButton(203)]-40-[contentView(50@250)]-20-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(SubTitle,phoneButton,rrbButton,contentView)];
    
    verticalPortrait5 = [NSLayoutConstraint constraintsWithVisualFormat:@"V:[SubTitle(40)]-40-[mailButton(203)]-40-[addNewButton(203)]-40-[contentView(50@250)]-20-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(SubTitle,mailButton,addNewButton,contentView)];
    
    
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|-(>=20)-[mailButton(==203)]-(>=20)-|" options: NSLayoutFormatAlignAllCenterX | NSLayoutFormatAlignAllCenterY
                                                                      metrics:nil views:NSDictionaryOfVariableBindings(mailButton)]];
    
    
    
    [self.view addConstraints:verticalPortrait1];
    [self.view addConstraints:verticalPortrait2];
    [self.view addConstraints:verticalPortrait3];
    [self.view addConstraints:verticalPortrait4];
    [self.view addConstraints:verticalPortrait5];
    
    [self.view addConstraints:horizontalPortrait1];
    [self.view addConstraints:horizontalPortrait2];
    [self.view addConstraints:horizontalPortrait3];
    [self.view addConstraints:horizontalPortrait4];
    [self.view addConstraints:horizontalPortrait5];
    
    
    [mailButton addTarget:self action:@selector(mailButtonSelected) forControlEvents:UIControlEventTouchUpInside];
    [phoneButton addTarget:self action:@selector(phoneButtonSelected) forControlEvents:UIControlEventTouchUpInside];
    [eftButton addTarget:self action:@selector(eftButtonSelected) forControlEvents:UIControlEventTouchUpInside];
    [rrbButton addTarget:self action:@selector(rrbButtonSelected) forControlEvents:UIControlEventTouchUpInside];
    
    [addNewButton addTarget:self action:@selector(addNewBtnSelected) forControlEvents:UIControlEventTouchUpInside];
    
    
    [self.view setNeedsUpdateConstraints];
    [self.view updateConstraints];
    [self.view layoutIfNeeded];
    
    if(isViewAppear){
        [self showSelectedPaymentButton];
    }
}


-(void)showSelectedPaymentButton{
    
    NSString *optionString;
    if(([[AppConfig enrollYear] isEqualToString:@"2019"] ||[[AppConfig enrollYear] isEqualToString:@"2020"])&& [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"]){
        optionString = [AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:payment_mode:options"];
    }else {
        optionString = [AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:premium_payment_schedule:options"];
    }
    
    if([optionString isEqualToString:@"Get a bill monthly"]){
        [mailButton setRadioButtonSelected:YES];
    }else if([optionString isEqualToString:@"Pay by phone monthly"]){
        [phoneButton setRadioButtonSelected:YES];
    }else  if([optionString isEqualToString:@"Electronic Funds Transfer"]||[optionString isEqualToString:@"Pay Online"]){
        [eftButton setRadioButtonSelected:YES];
    }else  if([optionString isEqualToString:@"Automatic deduction"]){
        [rrbButton setRadioButtonSelected:YES];
    }else  if([optionString isEqualToString:@"SSA"]){
        [rrbButton setRadioButtonSelected:YES];
    }else  if([optionString isEqualToString:@"RRB"]){
        [addNewButton setRadioButtonSelected:YES];
    }if([optionString isEqualToString:@"mail"]){
        [mailButton setRadioButtonSelected:YES];
    }if([optionString isEqualToString:@"eft"]){
        [eftButton setRadioButtonSelected:YES];
    }else {
        
    }
}


-(void)resetButton {
    
    NSArray *subviewArray = [self.view subviews];
    
    for (id subviewObj in subviewArray){
        
        if([subviewObj isKindOfClass:[UIRadioButton class]]){
            
            [subviewObj removeFromSuperview];
        }
    }
}


-(void)mailButtonSelected {
    
    
    if(([[AppConfig enrollYear] isEqualToString:@"2019"] ||[[AppConfig enrollYear] isEqualToString:@"2020"]) && [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"]){
        [AppConfig fillJSONDictionary:@"data:payment_mode:options" value:@"mail"];
    }else {
        [AppConfig fillJSONDictionary:@"data:premium_payment_schedule:options" value:@"Get a bill monthly"];
    }
    
    [self mailMeBillButton:mailButton];
    
    
}

-(void)phoneButtonSelected {
    
    [AppConfig fillJSONDictionary:@"data:premium_payment_schedule:options" value:@"Pay by phone monthly"];
    
    [self payByPhoneButton:phoneButton];
    
    
}

-(void)eftButtonSelected {
    
    
    if ([[AppConfig currentPlan] isEqualToString:@"MAPD"] && [[AppConfig enrollYear] isEqualToString:@"2017"]){
        [AppConfig fillJSONDictionary:@"data:premium_payment_schedule:options" value:@"Pay Online"];
    }else if(([[AppConfig enrollYear] isEqualToString:@"2019"] ||[[AppConfig enrollYear] isEqualToString:@"2020"])&& [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"]){
        [AppConfig fillJSONDictionary:@"data:payment_mode:options" value:@"eft"];
    }else {
        // 2016 - comment below line for 2016 plans
        //        [AppConfig fillJSONDictionary:@"data:premium_payment_schedule:options" value:@"Electronic Funds Transfer"];
        
        //2018 - we display Pay Online
        [AppConfig fillJSONDictionary:@"data:premium_payment_schedule:options" value:@"Pay Online"];
    }
    [self eftButton:eftButton];
    
}

-(void)rrbButtonSelected {
    
    if([currentEnrollYear isEqualToString:@"2018"]){
        
        [AppConfig fillJSONDictionary:@"data:premium_payment_schedule:options" value:@"SSA"];
    }else {
        
        [AppConfig fillJSONDictionary:@"data:premium_payment_schedule:options" value:@"Automatic deduction"];
    }
    [self rrbButton:rrbButton];
}

-(void)addNewBtnSelected {
    
    [AppConfig fillJSONDictionary:@"data:premium_payment_schedule:options" value:@"RRB"];
    [self addNewButtonAction:addNewButton];
}

-(void)removeEftview {
    
    [Validator ValidationDone];
    self.eftView.hidden = YES;
    [eftView removeFromSuperview];
    eftView = nil;
}


-(void)viewWillDisappear:(BOOL)animated {
    
    isViewAppear = NO;
    [super viewWillDisappear:YES];
}


//vrl added
-(void)load2019SupplementPaymentButtonOrientation {
    
    [SubTitle setTranslatesAutoresizingMaskIntoConstraints:NO];
    [contentView setTranslatesAutoresizingMaskIntoConstraints:NO];
    
    
    id horizontalPortrait1;
    id horizontalPortrait3;
    id verticalPortrait1 ;
    id verticalPortrait3 ;
    
    [self resetButton];
    
    
    
    mailButton = [[UIRadioButton alloc]init];
    mailButton.groupName = @"PAYMENT";
    mailButton.tag = 4;
    [mailButton loadImage:[UIImage imageNamed:@"Pay_by_Mail"]];
    [mailButton setBtnSelectedImage:[UIImage imageNamed:@"Pay_by_Mail_active"]];
    [mailButton setBtnUnSelectedImage:[UIImage imageNamed:@"Pay_by_Mail"]];
    [self.view addSubview:mailButton];
    
    
    
    eftButton = [[UIRadioButton alloc]init];
    eftButton.groupName = @"PAYMENT";
    eftButton.tag = 5;
    [eftButton loadImage:[UIImage imageNamed:@"Electronic_transfer"]];
    [eftButton setBtnSelectedImage:[UIImage imageNamed:@"Electronic_transfer_active"]];
    [eftButton setBtnUnSelectedImage:[UIImage imageNamed:@"Electronic_transfer"]];
    [self.view addSubview:eftButton];
    
    
    [mailButton setTranslatesAutoresizingMaskIntoConstraints:NO];
    [eftButton setTranslatesAutoresizingMaskIntoConstraints:NO];
    
    
    
    horizontalPortrait1 = @[[NSLayoutConstraint constraintWithItem:mailButton
                                                         attribute:NSLayoutAttributeCenterX
                                                         relatedBy:NSLayoutRelationEqual
                                                            toItem:self.view
                                                         attribute:NSLayoutAttributeCenterX
                                                        multiplier:1.f constant:-123.0f]
                            ];
    
    horizontalPortrait3 = @[[NSLayoutConstraint constraintWithItem:eftButton
                                                         attribute:NSLayoutAttributeCenterX
                                                         relatedBy:NSLayoutRelationEqual
                                                            toItem:self.view
                                                         attribute:NSLayoutAttributeCenterX
                                                        multiplier:1.f constant:123.0f]
                            ];
    
    
    
    
    verticalPortrait1 = [NSLayoutConstraint constraintsWithVisualFormat:@"V:[SubTitle(40)]-40-[mailButton(203)]-40-[contentView(50@250)]-20-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(SubTitle,mailButton,eftButton,contentView)];
    
    verticalPortrait3 = [NSLayoutConstraint constraintsWithVisualFormat:@"V:[SubTitle(40)]-40-[eftButton(203)]-40-[contentView(50@250)]-20-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(SubTitle,eftButton,contentView)];
    
    
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|-(>=20)-[mailButton(==203)]-(>=20)-|" options: NSLayoutFormatAlignAllCenterX | NSLayoutFormatAlignAllCenterY metrics:nil views:NSDictionaryOfVariableBindings(mailButton)]];
    
    
    [self.view addConstraints:verticalPortrait1];
    [self.view addConstraints:verticalPortrait3];
    
    [self.view addConstraints:horizontalPortrait1];
    [self.view addConstraints:horizontalPortrait3];
    
    
    [mailButton addTarget:self action:@selector(mailButtonSelected) forControlEvents:UIControlEventTouchUpInside];
    
    [eftButton addTarget:self action:@selector(eftButtonSelected) forControlEvents:UIControlEventTouchUpInside];
    
    
    [self.view setNeedsUpdateConstraints];
    [self.view updateConstraints];
    [self.view layoutIfNeeded];
    
    if(isViewAppear){
        [self showSelectedPaymentButton];
    }
}

//2017 - PDP
-(void)PDPButtonPayment2018Orientation {
    
    [eftButton removeFromSuperview];
    
    [SubTitle setTranslatesAutoresizingMaskIntoConstraints:NO];
    [contentView setTranslatesAutoresizingMaskIntoConstraints:NO];
    
    
    id horizontalLandscape,horizontalLandscape1,horizontalLandscape2,horizontalLandscape3,verticalLS1,verticalLS2,verticalLS3,verticalLS4;
    
    
    id horizontalPortrait1;
    id horizontalPortrait2;
    
    id horizontalPortrait3;
    id horizontalPortrait4;
    id verticalPortrait1 ;
    id verticalPortrait2;
    
    
    [self resetButton];
    
    if (isLandscape){
        
        
        mailButton = [[UIRadioButton alloc]init];
        mailButton.groupName = @"PAYMENT";
        mailButton.tag = 4;
        [mailButton loadImage:[UIImage imageNamed:@"Mail_bill"]];
        [mailButton setBtnSelectedImage:[UIImage imageNamed:@"Mail_bill_active"]];
        [mailButton setBtnUnSelectedImage:[UIImage imageNamed:@"Mail_bill"]];
        [self.view addSubview:mailButton];
        
        
        
        phoneButton = [[UIRadioButton alloc]init];
        phoneButton.groupName = @"PAYMENT";
        phoneButton.tag = 5;
        [phoneButton loadImage:[UIImage imageNamed:@"Pay_by_phone"]];
        [phoneButton setBtnSelectedImage:[UIImage imageNamed:@"Pay_by_phone_active"]];
        [phoneButton setBtnUnSelectedImage:[UIImage imageNamed:@"Pay_by_phone"]];
        [self.view addSubview:phoneButton];
        
        
        rrbButton = [[UIRadioButton alloc]init];
        rrbButton.groupName = @"PAYMENT";
        rrbButton.tag = 6;
        
        [rrbButton loadImage:[UIImage imageNamed:@"Deduct_from_social_2018"]];
        [rrbButton setBtnSelectedImage:[UIImage imageNamed:@"Deduct_from_social_active_2018"]];
        [rrbButton setBtnUnSelectedImage:[UIImage imageNamed:@"Deduct_from_social_2018"]];
        
        [self.view addSubview:rrbButton];
        
        
        
        addNewButton = [[UIRadioButton alloc]init];
        addNewButton.groupName = @"PAYMENT";
        addNewButton.tag = 7;
        [addNewButton loadImage:[UIImage imageNamed:@"Deduct_from_rrb_2018"]];
        [addNewButton setBtnSelectedImage:[UIImage imageNamed:@"Deduct_from_rrb_active_2018"]];
        [addNewButton setBtnUnSelectedImage:[UIImage imageNamed:@"Deduct_from_rrb_2018"]];
        [self.view addSubview:addNewButton];
        
        [mailButton setTranslatesAutoresizingMaskIntoConstraints:NO];
        [phoneButton setTranslatesAutoresizingMaskIntoConstraints:NO];
        [rrbButton setTranslatesAutoresizingMaskIntoConstraints:NO];
        [addNewButton setTranslatesAutoresizingMaskIntoConstraints:NO];
        
        
        verticalLS1 = [NSLayoutConstraint constraintsWithVisualFormat:@"V:[SubTitle(40)]-40-[mailButton(203)]-40-[contentView(50@250)]-20-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(SubTitle,mailButton,contentView)];
        
        verticalLS2 = [NSLayoutConstraint constraintsWithVisualFormat:@"V:[SubTitle(40)]-40-[phoneButton(203)]-40-[contentView(50@250)]-20-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(SubTitle,phoneButton,contentView)];
        
        verticalLS3 = [NSLayoutConstraint constraintsWithVisualFormat:@"V:[SubTitle(40)]-40@250-[rrbButton(203)]-40-[contentView(50@250)]-20-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(SubTitle,rrbButton,contentView)];
        
        verticalLS4 = [NSLayoutConstraint constraintsWithVisualFormat:@"V:[SubTitle(40)]-40@250-[addNewButton(203)]-40-[contentView(50@250)]-20-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(SubTitle,addNewButton,contentView)];
        
        
        
        horizontalLandscape = @[[NSLayoutConstraint constraintWithItem:mailButton
                                                             attribute:NSLayoutAttributeCenterX
                                                             relatedBy:NSLayoutRelationEqual
                                                                toItem:self.view
                                                             attribute:NSLayoutAttributeCenterX
                                                            multiplier:1.f constant:-380.f]
                                ];
        
        horizontalLandscape1 = @[[NSLayoutConstraint constraintWithItem:addNewButton
                                                              attribute:NSLayoutAttributeCenterX
                                                              relatedBy:NSLayoutRelationEqual
                                                                 toItem:self.view
                                                              attribute:NSLayoutAttributeCenterX
                                                             multiplier:1.f constant:380.f]
                                 ];
        
        horizontalLandscape2 = @[[NSLayoutConstraint constraintWithItem:phoneButton
                                                              attribute:NSLayoutAttributeCenterX
                                                              relatedBy:NSLayoutRelationEqual
                                                                 toItem:self.view
                                                              attribute:NSLayoutAttributeCenterX
                                                             multiplier:1.f constant:-120.f]
                                 ];
        
        horizontalLandscape3 = @[[NSLayoutConstraint constraintWithItem:rrbButton
                                                              attribute:NSLayoutAttributeCenterX
                                                              relatedBy:NSLayoutRelationEqual
                                                                 toItem:self.view
                                                              attribute:NSLayoutAttributeCenterX
                                                             multiplier:1.f constant:120.f]
                                 ];
        
        
        [self.view removeConstraints:horizontalPortrait1];
        [self.view removeConstraints:horizontalPortrait2];
        [self.view removeConstraints:verticalPortrait1];
        [self.view removeConstraints:verticalPortrait2];
        
        [self.view removeConstraints:horizontalPortrait3];
        [self.view removeConstraints:horizontalPortrait4];
        
        [self.view addConstraints:horizontalLandscape];
        [self.view addConstraints:horizontalLandscape1];
        [self.view addConstraints:horizontalLandscape2];
        [self.view addConstraints:horizontalLandscape3];
        
        [self.view addConstraints:verticalLS1];
        [self.view addConstraints:verticalLS2];
        [self.view addConstraints:verticalLS3];
        [self.view addConstraints:verticalLS4];
        
    }else {
        
        mailButton = [[UIRadioButton alloc]init];
        mailButton.groupName = @"PAYMENT";
        mailButton.tag = 4;
        [mailButton loadImage:[UIImage imageNamed:@"Mail_bill"]];
        [mailButton setBtnSelectedImage:[UIImage imageNamed:@"Mail_bill_active"]];
        [mailButton setBtnUnSelectedImage:[UIImage imageNamed:@"Mail_bill"]];
        [self.view addSubview:mailButton];
        
        phoneButton = [[UIRadioButton alloc]init];
        phoneButton.groupName = @"PAYMENT";
        phoneButton.tag = 5;
        [phoneButton loadImage:[UIImage imageNamed:@"Pay_by_phone"]];
        [phoneButton setBtnSelectedImage:[UIImage imageNamed:@"Pay_by_phone_active"]];
        [phoneButton setBtnUnSelectedImage:[UIImage imageNamed:@"Pay_by_phone"]];
        [self.view addSubview:phoneButton];
        
        
        
        rrbButton = [[UIRadioButton alloc]init];
        rrbButton.groupName = @"PAYMENT";
        rrbButton.tag = 6;
        [rrbButton loadImage:[UIImage imageNamed:@"Deduct_from_social_2018"]];
        [rrbButton setBtnSelectedImage:[UIImage imageNamed:@"Deduct_from_social_active_2018"]];
        [rrbButton setBtnUnSelectedImage:[UIImage imageNamed:@"Deduct_from_social_2018"]];
        [self.view addSubview:rrbButton];
        
        
        addNewButton = [[UIRadioButton alloc]init];
        addNewButton.groupName = @"PAYMENT";
        addNewButton.tag = 7;
        [addNewButton loadImage:[UIImage imageNamed:@"Deduct_from_rrb_2018"]];
        [addNewButton setBtnSelectedImage:[UIImage imageNamed:@"Deduct_from_rrb_active_2018"]];
        [addNewButton setBtnUnSelectedImage:[UIImage imageNamed:@"Deduct_from_rrb_2018"]];
        [self.view addSubview:addNewButton];
        
        [mailButton setTranslatesAutoresizingMaskIntoConstraints:NO];
        [phoneButton setTranslatesAutoresizingMaskIntoConstraints:NO];
        [rrbButton setTranslatesAutoresizingMaskIntoConstraints:NO];
        [addNewButton setTranslatesAutoresizingMaskIntoConstraints:NO];
        
        
        horizontalPortrait1 = @[[NSLayoutConstraint constraintWithItem:mailButton
                                                             attribute:NSLayoutAttributeCenterX
                                                             relatedBy:NSLayoutRelationEqual
                                                                toItem:self.view
                                                             attribute:NSLayoutAttributeCenterX
                                                            multiplier:1.f constant:-150.f]
                                ];
        
        horizontalPortrait2 = @[[NSLayoutConstraint constraintWithItem:phoneButton
                                                             attribute:NSLayoutAttributeCenterX
                                                             relatedBy:NSLayoutRelationEqual
                                                                toItem:self.view
                                                             attribute:NSLayoutAttributeCenterX
                                                            multiplier:1.f constant:150.f]
                                ];
        
        horizontalPortrait3 = @[[NSLayoutConstraint constraintWithItem:rrbButton
                                                             attribute:NSLayoutAttributeCenterX
                                                             relatedBy:NSLayoutRelationEqual
                                                                toItem:self.view
                                                             attribute:NSLayoutAttributeCenterX
                                                            multiplier:1.f constant:-150.f]
                                ];
        
        horizontalPortrait4 = @[[NSLayoutConstraint constraintWithItem:addNewButton
                                                             attribute:NSLayoutAttributeCenterX
                                                             relatedBy:NSLayoutRelationEqual
                                                                toItem:self.view
                                                             attribute:NSLayoutAttributeCenterX
                                                            multiplier:1.f constant:150.f]
                                ];
        
        
        verticalPortrait1 = [NSLayoutConstraint constraintsWithVisualFormat:@"V:[SubTitle(40)]-40-[mailButton(203)]-40-[rrbButton(203)]-40-[contentView(50@250)]-20-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(SubTitle,mailButton,rrbButton,contentView)];
        
        verticalPortrait2 = [NSLayoutConstraint constraintsWithVisualFormat:@"V:[SubTitle(40)]-40-[phoneButton(203)]-40-[addNewButton(203)]-40-[contentView(50@250)]-20-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(SubTitle,phoneButton,addNewButton,contentView)];
        
        [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|-(>=20)-[mailButton(==203)]-(>=20)-|" options: NSLayoutFormatAlignAllCenterX | NSLayoutFormatAlignAllCenterY
                                                                          metrics:nil views:NSDictionaryOfVariableBindings(mailButton)]];
        
        [self.view removeConstraints:horizontalLandscape];
        
        [self.view removeConstraints:horizontalLandscape1];
        [self.view removeConstraints:horizontalLandscape2];
        [self.view removeConstraints:horizontalLandscape3];
        
        [self.view removeConstraints:verticalLS1];
        [self.view removeConstraints:verticalLS2];
        [self.view removeConstraints:verticalLS3];
        [self.view removeConstraints:verticalLS4];
        
        
        [self.view addConstraints:verticalPortrait1];
        [self.view addConstraints:verticalPortrait2];
        [self.view addConstraints:horizontalPortrait1];
        [self.view addConstraints:horizontalPortrait2];
        [self.view addConstraints:horizontalPortrait3];
        [self.view addConstraints:horizontalPortrait4];
        
        
    }
    
    [mailButton addTarget:self action:@selector(mailButtonSelected) forControlEvents:UIControlEventTouchUpInside];
    [phoneButton addTarget:self action:@selector(phoneButtonSelected) forControlEvents:UIControlEventTouchUpInside];
    [rrbButton addTarget:self action:@selector(rrbButtonSelected) forControlEvents:UIControlEventTouchUpInside];
    [addNewButton addTarget:self action:@selector(addNewBtnSelected) forControlEvents:UIControlEventTouchUpInside];
    
    
    [self.view setNeedsUpdateConstraints];
    [self.view updateConstraints];
    [self.view layoutIfNeeded];
    
    if(isViewAppear){
        [self showSelectedPaymentButton];
    }
}


// Reset the values of EFT View , when we clicked Mail Button in Medigap 65+ 2019
-(void)medigap65ResetEFTViewJSONValues{
    
    [AppConfig fillJSONDictionary:@"data:payment_mode:eft:bank_account_holder_signature" value:@""];
    [AppConfig fillJSONDictionary:@"data:payment_mode:eft:bank_account_number" value:@""];
    [AppConfig fillJSONDictionary:@"data:payment_mode:eft:bank_account_type" value:@""];
    [AppConfig fillJSONDictionary:@"data:payment_mode:eft:bank_name" value:@""];
    [AppConfig fillJSONDictionary:@"data:payment_mode:eft:bank_routing_number" value:@""];
    [AppConfig fillJSONDictionary:@"data:payment_mode:eft:city" value:@""];
    [AppConfig fillJSONDictionary:@"data:payment_mode:eft:date" value:@""];
    [AppConfig fillJSONDictionary:@"data:payment_mode:eft:member_address" value:@""];
    [AppConfig fillJSONDictionary:@"data:payment_mode:eft:member_email" value:@""];
    [AppConfig fillJSONDictionary:@"data:payment_mode:eft:member_name" value:@""];
    [AppConfig fillJSONDictionary:@"data:payment_mode:eft:member_number" value:@""];
    [AppConfig fillJSONDictionary:@"data:payment_mode:eft:name_on_the_account" value:@""];
    [AppConfig fillJSONDictionary:@"data:payment_mode:eft:state" value:@""];
    [AppConfig fillJSONDictionary:@"data:payment_mode:eft:zip_code" value:@""];
    
}

// Testing Purpose
-(void)checkEFTView {
    
    //    NSMutableDictionary *getHealtStmtDict = [[[AppConfig currentPlanJSONDictionary] objectForKey:@"data"]objectForKey:@"payment_mode"];
    //    PRINTLOG(@"health stmt ::%@",getHealtStmtDict);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




@end
