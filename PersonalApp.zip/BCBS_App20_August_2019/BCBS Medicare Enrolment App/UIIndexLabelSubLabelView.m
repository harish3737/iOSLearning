//
//  UIIndexLabelSubLabelView.m
//  BCBS Medicare Enrolment App
//
//  Created by CSS Admin on 7/19/18.
//  Copyright © 2018 CSS Corp. All rights reserved.
//

#import "UIIndexLabelSubLabelView.h"

@implementation UIIndexLabelSubLabelView

@synthesize xPath;

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    
    [super drawRect:rect];
}



-(instancetype)initWithCoder:(NSCoder *)aDecoder {
    
    self = [super initWithCoder:aDecoder];
    
    if(self){
        
        [self loadXibFile];
        
    }
    
    return self;
    
}

-(instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if(self){
        
        [self loadXibFile];
        
    }
    return self;
    
}

-(void)loadXibFile {
    
    //1. Load a Xib file
    [[NSBundle mainBundle]loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
    
    //    //2adjust bounds
    self.bounds = self.indexSubLabeledView.bounds;
    //
    //    //3. Add a subview
    [self addSubview:self.indexSubLabeledView];
}

-(NSString *)xPath {
    return xPath;
}

-(NSString *)getValueString{
    
    return @"-";
}

-(void)awakeFromNib {
    
    [super awakeFromNib];
    _dataValidator = [Validator NoValidation];
    _callback = [UICallback getDummyUICallback];
    
    [self linkChain];
}


-(void)linkChain {
    
    if([Validator tailItem]!=nil) {
        
        [[Validator tailItem] setNextField:self];
    }
    [Validator tailItem:self];
}

-(void)setComparator:(NSString *)Comparator {
    
    _comparator = Comparator;
    _dataValidator = [Validator getValidator:_comparator];
    PRINTLOG(@"BlocK ::%@",_dataValidator);
    //    [self callBackInitialize];
}

-(void)setCompareValue:(NSString *)compareValue {
    
    _compareValue = compareValue;
}

//-(void)callBackInitialize {
//
//    _callback = [[UICallback alloc]initWithUICallbacks:^(id data){
////        PRINTLOG(@"callback sucess dropDown:%@",data);
//    } :^(id data){
////        PRINTLOG(@"callback failed dropDown:%@",data);
//    }];
//}

@end
