//
//  ViewController.h
//  BcBs
//
//  Created by CSS Corp on 09/05/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>
#import "GAI.h"

@interface LoginViewController : UIBaseViewController<UIAlertViewDelegate,UITextFieldDelegate>

@property (strong, nonatomic) IBOutlet UIImageView *loaderImage;
- (IBAction)signIn:(id)sender;
- (IBAction)resetPassword:(id)sender;

@property (weak, nonatomic) IBOutlet ValidatorTextField *usernameTextField;
@property (weak, nonatomic) IBOutlet ValidatorTextField *passwordTextField;
@property (strong, nonatomic) IBOutlet UIScrollView *scrollView;
@property (strong, nonatomic) IBOutlet UILabel *appversionTextLabel;

+(void) loadDBLocal:(id)url;

@end

