//
//  CustomCollectionViewLayout.h
//  Brightec
//
//  Created by JOSE MARTINEZ on 03/09/2014.
//  Copyright (c) 2014 Brightec. All rights reserved.
//

#import <UIKit/UIKit.h>

// NOTE: This class is not used in this project - actually it is removed from the target. I added it just in case you need to compare the code between Objective-C and Swift

@interface CustomCollectionViewLayout : UICollectionViewLayout
@end
