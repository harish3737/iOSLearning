//
//  EFTDiscountViewController.h
//  BCBS Medicare Enrolment App
//
//  Created by CSS CORP on 28/06/18.
//  Copyright © 2018 CSS Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>

@interface EFTDiscountViewController : UIBaseContainerViewController
@property (strong, nonatomic) IBOutlet ValidatorLabel *titleString;
@property (strong, nonatomic) IBOutlet UIView *view1;
@property (strong, nonatomic) IBOutlet UIView *view2;
@property (strong, nonatomic) IBOutlet ValidatorLabel *withdrawInfoLabel;
@property (strong, nonatomic) IBOutlet UIView *view3;

@end
