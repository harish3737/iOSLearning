//
//  PersonalFormViewController.h
//  SampleBCBSPOC
//
//  Created by CSS Admin on 5/24/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>

@interface PersonalFormViewController : UIBaseContainerViewController



@property (weak, nonatomic) IBOutlet UIView *view1;
@property (weak, nonatomic) IBOutlet UIView *view4;
@property (strong, nonatomic) IBOutlet ValidatorLabel *titleString;
@property (strong, nonatomic) IBOutlet ValidatorLabel *medicalDisabilityTitle;
@property (strong, nonatomic) IBOutlet UIView *view5;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *emailLabelHeightConstant;
@property (strong, nonatomic) IBOutlet ValidatorLabel *medicalInfoLabel;

@end
