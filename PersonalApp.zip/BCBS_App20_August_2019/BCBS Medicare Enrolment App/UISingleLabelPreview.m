//
//  UISingleLabelPreview.m
//  BCBS Medicare Enrolment App
//
//  Created by CSS Admin on 7/17/18.
//  Copyright © 2018 CSS Corp. All rights reserved.
//

#import "UISingleLabelPreview.h"

@implementation UISingleLabelPreview

@synthesize xPath;


- (void)drawRect:(CGRect)rect {
    // Drawing code
    [super drawRect:rect];
}



-(instancetype)initWithCoder:(NSCoder *)aDecoder {
    
    
    self = [super initWithCoder:aDecoder];
    if(self){
        
        [self setUpXibFile];
        
    }
    return self;
}

-(instancetype)initWithFrame:(CGRect)frame {
    
    
    self = [super initWithFrame:frame];
    if(self){
        
        [self setUpXibFile];
    }
    return self;
    
}

-(void)setUpXibFile {
    
    //1. Load a Xib
    [[NSBundle mainBundle]loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
    
    self.bounds = self.singleLabelPreview.bounds;
    //3.Add as a subviw
    [self addSubview:self.singleLabelPreview];
    
    self.singleLabelPreview.backgroundColor = [UIColor whiteColor];
    
}

-(NSString *)xPath {
    return xPath;
}

-(NSString *)getValueString{
    
    return @"-";
}

-(void)awakeFromNib {
    
    [super awakeFromNib];
    _dataValidator = [Validator NoValidation];
  
    
    [self linkChain];
}

-(void)linkChain {
    
    if([Validator tailItem]!=nil) {
        
        [[Validator tailItem] setNextField:self];
    }
    [Validator tailItem:self];
}

-(void)setComparator:(NSString *)Comparator {
    
    _comparator = Comparator;
    _dataValidator = [Validator getValidator:_comparator];
}

-(void)setCompareValue:(NSString *)compareValue {
    
    _compareValue = compareValue;
}

@end
