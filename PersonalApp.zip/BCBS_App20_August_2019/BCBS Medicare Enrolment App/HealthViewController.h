//
//  HealthViewController.h
//  BCBS Medicare Enrolment App
//
//  Created by CSS Corp on 03/06/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>

@interface HealthViewController : UIBaseContainerViewController
@property (strong, nonatomic) IBOutlet ValidatorLabel *titleString;

@property (strong, nonatomic) IBOutlet UIRadioButton *spanishButton;
@property (strong, nonatomic) IBOutlet UIRadioButton *largerPrintButton;
@property (strong, nonatomic) IBOutlet ValidatorLabel *contentLabel;

@end
