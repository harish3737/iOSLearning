//
//  LanguageViewController.h
//  BcBs
//
//  Created by CSS Corp on 11/05/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>
#import "AppConfig.h"


@interface LanguageViewController : UIBaseContainerViewController
- (IBAction)englishButtonAction:(id)sender;
- (IBAction)spanishButtonAction:(id)sender;

@end
