//
//  BasePlanValidator.h
//  BCBS Medicare Enrolment App
//
//  Created by Dheena on 27/05/19.
//  Copyright © 2019 CSS Corp. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PlanValidatorProtocol.h"

NS_ASSUME_NONNULL_BEGIN
typedef enum : NSUInteger {
    
    DATE_GREATER_THAN_VALIDATOR,
    DATE_LESSER_THAN_VALIDATOR,
    DATE_SIX_MONTH_VALIDATOR,
    NO_VALIDATION
    
    
}DateValidatorType;

typedef bool(^DateValidator)(id, id);


@interface BasePlanValidator : NSObject <PlanValidatorProtocol>

@property BasePlanValidator *next;
@property (nonatomic, strong) DateValidator operator;
@property BasePlanValidator *lastItem;

-(id) initWithValidator:(DateValidatorType)operator compareDate:(NSDate *)compareDate withDate:(nullable NSDate *)withDate;
-(id) addValidator:(DateValidatorType)operator compareDate:(NSDate *)compareDate withDate:(nullable NSDate  *)withDate;
-(BOOL)validate:(NSDate *)partBEffectiveDate;

+ (DateValidator) GreaterThanDateValidator;
+ (DateValidator) LessThanDateValidator;
+ (DateValidator) NoValidator;

+ (DateValidator) LessThanSixMonthValidator;

@end

NS_ASSUME_NONNULL_END

