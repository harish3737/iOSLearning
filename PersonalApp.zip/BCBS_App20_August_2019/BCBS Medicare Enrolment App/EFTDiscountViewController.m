//
//  EFTDiscountViewController.m
//  BCBS Medicare Enrolment App
//
//  Created by CSS CORP on 28/06/18.
//  Copyright © 2018 CSS Corp. All rights reserved.
//

#import "EFTDiscountViewController.h"
#import "AppConfig.h"
#import "ScopeBaseViewController.h"

@interface EFTDiscountViewController ()

@end

@implementation EFTDiscountViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    _titleString.text = [NSString stringWithFormat:@"%@ %@ - \n%@",[AppConfig enrollYear],[LanguageCentral languageSelectedString:[[AppConfig currentPlanDictionary] objectForKey:@"PlanTitle"]],[LanguageCentral languageSelectedString:[[[AppConfig currentPlanDictionary] objectForKey:NSStringFromClass([self class])]objectForKey:@"title"]]];
    
    [UIRenderer renderPlist:self plist:[NSString stringWithFormat:@"EFTDiscountForm"]];
    
    self.withdrawInfoLabel.localizationKey = @"MONTHLY_WITHDRAWAL_AMOUNT";
    
    [self.sharedataObj setForwardNextButtonTitle:@"Next"];
    [self.sharedataObj setNextProgressIndex:2];
    
    [self.sharedataObj setPreviousNextButtonTitle:@"Continue_to_health"];
    [self.sharedataObj setBackProgressIndex:2];
}

-(void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    [self loadBackData];
}
-(void)loadNextPage {
}

-(void)loadBackData {
    
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
