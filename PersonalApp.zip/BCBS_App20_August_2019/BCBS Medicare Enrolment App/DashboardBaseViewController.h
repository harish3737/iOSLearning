//
//  DashboardBaseViewController.h
//  dashboard flow
//
//  Created by CSS Corp on 04/05/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>

@protocol DashboardBaseViewControllerDelegate <NSObject>

//-(void)loadChildViewController:(id)viewcontroller;

@end

@interface DashboardBaseViewController :UIBaseViewController <DashboardBaseViewControllerDelegate>




@property(nonatomic,assign)id<DashboardBaseViewControllerDelegate> delegate;

- (IBAction)backToDashboardPage:(id)sender;

- (IBAction)logoutAction:(id)sender;

+(void)errorMessageAlert:(NSString *)title message:(NSString *)message;

@property (nonatomic, retain) IBOutlet UILabel *welcomeLbl;
@property (strong, nonatomic) IBOutlet UIButton *backButton;


@end

