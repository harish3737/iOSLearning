//
//  AuthorizationViewController.h
//  BCBS Medicare Enrolment App
//
//  Created by CSS Corp on 15/06/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>

@interface AuthorizationViewController : UIBaseContainerViewController
@property (weak, nonatomic) IBOutlet UIView *authorizationView;
@property (strong, nonatomic) IBOutlet ValidatorLabel *titleString;

@end
