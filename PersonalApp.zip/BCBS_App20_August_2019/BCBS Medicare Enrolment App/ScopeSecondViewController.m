//
//  ScopeSecondViewController.m
//  BcBs
//
//  Created by CSS Corp on 12/05/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "ScopeSecondViewController.h"
#import "ScopeView.h"
#import "ScopeView2.h"
#import "ScopeView3.h"
#import "ScopeViewController.h"
@interface ScopeSecondViewController (){
	ScopeView3 *view3;
	ScopeView2 *view2;
	ScopeView *view1;
	
}

@end

@implementation ScopeSecondViewController
@synthesize isView1,isView2,isView3;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
	
	[self.sharedataObj setForwardNextButtonTitle:@"Start_appointment"];
	[self.sharedataObj setNextProgressIndex:-1];
	
	[self.sharedataObj setPreviousNextButtonTitle:@"Next"];
	[self.sharedataObj setBackProgressIndex:-1];
	

	[UINavigationQueue showXibName:self];
	
}




-(void)viewWillLayoutSubviews {
	
	
	
	
}
-(void)viewWillAppear:(BOOL)animated{
	
	[super viewWillAppear:YES];
	
	[self.view layoutIfNeeded]; //cecil
    
    [self.view updateConstraintsIfNeeded]; //cecil
	
}


- (IBAction)nextView:(id)sender {
	
	if (isView1) {
		
		isView2 = YES;
		isView3 = NO;
		isView1 = NO;
		

		
		view2 = [[ScopeView2 alloc]init];
		
		
		[self.parentView addSubview:view2];
		
		[view2 setTranslatesAutoresizingMaskIntoConstraints:NO];
		
		[self.parentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[view2]|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(view2)]];
		[self.parentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[view2]|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(view2)]];
		[self.parentView setNeedsUpdateConstraints];
		[self.parentView updateConstraints];
        [self.parentView updateConstraintsIfNeeded]; //cecil
		
        
        [view1 removeFromSuperview];

	}
	else if (isView2)
	{
		isView3 = YES;
		isView2 = NO;
		isView1 = NO;
		
		view3 = [[ScopeView3 alloc]init];
		
		
		[self.parentView addSubview:view3];
		
		[view3 setTranslatesAutoresizingMaskIntoConstraints:NO];
		
		[self.parentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[view3]|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(view3)]];
		[self.parentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[view3]|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(view3)]];
		[self.parentView setNeedsUpdateConstraints];
		[self.parentView updateConstraints];
        [self.parentView updateConstraintsIfNeeded]; //cecil

		
		
		[view2 removeFromSuperview];
		
	}
	
	
	
}

- (IBAction)previousView:(id)sender {
	
	
	if (view3){
		
		isView2 = YES;
		isView3 = NO;
		isView1 = NO;
		
		view2 = [[ScopeView2 alloc]init];
//        view2.frame = CGRectMake(50, 30, 300, 300);   cecil
		
		[self.parentView addSubview:view2];
        
        //cecil
        [view2 setTranslatesAutoresizingMaskIntoConstraints:NO];
        
        [self.parentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[view2]|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(view2)]];
        [self.parentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[view2]|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(view2)]];
        [self.parentView setNeedsUpdateConstraints];
        [self.parentView updateConstraints];
        [self.parentView updateConstraintsIfNeeded];
        //cecil
		
        [view3 removeFromSuperview];
	}
	
	else if (isView2) {
		
		isView3 = NO;
		isView2 = NO;
		isView1 = YES;
		
		view1 = [[ScopeView alloc]init];
//        view1.frame = CGRectMake(50, 30, 300, 300);  cecil
		[self.parentView addSubview:view1];
        
        //cecil
        [view1 setTranslatesAutoresizingMaskIntoConstraints:NO];
        
        [self.parentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[view1]|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(view1)]];
        [self.parentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[view1]|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(view1)]];
        [self.parentView setNeedsUpdateConstraints];
        [self.parentView updateConstraints];
        [self.parentView updateConstraintsIfNeeded]; //cecil
		//cecil
		[view2 removeFromSuperview];
	}
	
	
	
	
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
