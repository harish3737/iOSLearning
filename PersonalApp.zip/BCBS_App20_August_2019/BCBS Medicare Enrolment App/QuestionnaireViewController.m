//
//  QuestionnaireViewController.m
//  BCBS Medicare Enrolment App
//
//  Created by CSS Corp on 02/06/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "QuestionnaireViewController.h"
#import "AppConfig.h"
#import "ScopeBaseViewController.h"
#import "SupplementGuaranteedQuestionViewController.h"
#import "GuaranteedIssueRightsViewController.h"
#import "SupplementNoticeViewController.h"
#import "AppConfig.h"


#define REDCOLOR [UIColor colorWithRed:240.0/255.0 green:108.0/255.0 blue:108.0/255.0 alpha:1.0f]
#define TEXTCOLOR [UIColor colorWithRed:102.0/255.0 green:102.0/255.0 blue:102.0/255.0 alpha:1.0f]

static UIRadioButton *yesBtn;
static UIRadioButton *noBtn;
static NSArray *getCurrentVCInfo;

static NSInteger effectiveDate_day;
static NSInteger effectiveDate_month;
static NSInteger effectiveDate_year;

static NSInteger diff_month_of_65;
static NSInteger diff_year_of_65;
static NSInteger diff_day_of_65;

@interface QuestionnaireViewController ()
{
	UIDropDown *startDate,*endDate;
    
    UIDropDown *effectiveDate;
    UIRadioButton *yesQuesBtn, *noQuesBtn;

    
}

@end

@implementation QuestionnaireViewController
@synthesize firstView;
@synthesize secondView;
@synthesize yesQuestion,noQuestion,nextQuestion,trailingScreen;

@synthesize isShowDenialAlert;


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
	
    _titleString.text = [NSString stringWithFormat:@"%@ %@ - \n%@",[AppConfig enrollYear],[LanguageCentral languageSelectedString:[[AppConfig currentPlanDictionary] objectForKey:@"PlanTitle"]],[LanguageCentral languageSelectedString:[[[AppConfig currentPlanDictionary] objectForKey:NSStringFromClass([self class])]objectForKey:@"title"]]];
    
	[UINavigationQueue showXibName:self];
	
    if([[AppConfig currentPlan] isEqualToString:@"DSNP"]){
        [self.sharedataObj setForwardNextButtonTitle:@"Next"];
        [self.sharedataObj setNextProgressIndex:2];
        
        [self.sharedataObj setPreviousNextButtonTitle:@"Next"];
        [self.sharedataObj setBackProgressIndex:2];
    }else {
        [self.sharedataObj setForwardNextButtonTitle:@"Next"];
        [self.sharedataObj setNextProgressIndex:3];
        
        [self.sharedataObj setPreviousNextButtonTitle:@"Next"];
        [self.sharedataObj setBackProgressIndex:3];
    }

	
    QuestionnaireViewController *weakSelf = self;
    
    self.willBackPage = ^(id object){
        
        [weakSelf hiddenBackbutton];
    };
	
	
//	[UIRenderer renderPlist:self plist:@"QuestionForm6"];
	
	
}

-(void)hiddenBackbutton {
    
}


-(void)viewWillAppear:(BOOL)animated {
	

//    [ScopeBaseViewController populateCurrentItemValue];
//    [self loadBackData];
    
    [super viewWillAppear:animated];
    
    isShowDenialAlert = NO; //new code vrl BR2.0
 
}

-(void)viewDidAppear:(BOOL)animated {
	
	[super viewDidAppear:animated];
}


-(void)didFinishContainerVC {
	
    PRINTLOG(@"Questionarie DidFinish");
    
    [ScopeBaseViewController populateCurrentItemValue];
    [self loadBackData];
    

    for (id questionviewObj in firstView.subviews){
        
        if([questionviewObj isKindOfClass:[UIQuestionView class]]){
            
            UIQuestionView *questionView = questionviewObj;
            PRINTLOG(@"QuestionYES ::%d",questionView.yesButton.buttonSelected);
            PRINTLOG(@"questionNO ::%d",questionView.noButton.buttonSelected);
            NSArray *vcArrayInfo = [UINavigationQueue getCurrentVCInfo];
            
            if([[vcArrayInfo objectAtIndex:2] containsString:@"SupplementUnder506E2017"]||[[vcArrayInfo objectAtIndex:2] containsString:@"SupplementUnder506E2018"]||[[vcArrayInfo objectAtIndex:2] containsString:@"SupplementUnder506E2019"]||[[vcArrayInfo objectAtIndex:2] containsString:@"SupplementUnder506E2020"]){
                
                if(questionView.noButton.buttonSelected){
                    [questionView enableSecondView:YES];
                }else {
                    [questionView enableSecondView:NO];
                }
            }else if([[vcArrayInfo objectAtIndex:2] containsString:@"Supplement Plan 65 and over5B2019"]||[[vcArrayInfo objectAtIndex:2] containsString:@"Supplement Plan 65 and over5B2020"]){
                
                [questionView enableSecondView:YES];
                
            }else {
                if(questionView.yesButton.buttonSelected){
                    [questionView enableSecondView:YES];
                }else {
                    [questionView enableSecondView:NO];
                }
            }
        }else if([questionviewObj isKindOfClass:[UIQuestionViewCustomLabel class]]){
            
            UIQuestionViewCustomLabel *questionViewLabel = questionviewObj;
//            PRINTLOG(@"QuestionYES ::%d",questionView.yesButton.buttonSelected);
//            PRINTLOG(@"questionNO ::%d",questionView.noButton.buttonSelected);
            NSArray *vcArrayInfo = [UINavigationQueue getCurrentVCInfo];
            
            if([[vcArrayInfo objectAtIndex:2] containsString:@"SupplementUnder506E2017"]||[[vcArrayInfo objectAtIndex:2] containsString:@"SupplementUnder506E2018"]||[[vcArrayInfo objectAtIndex:2] containsString:@"SupplementUnder506E2019"]||[[vcArrayInfo objectAtIndex:2] containsString:@"SupplementUnder506E2020"]){
                
                if(questionViewLabel.noButton.buttonSelected){
                    [questionViewLabel enableSecondView:YES];
                }else {
                    [questionViewLabel enableSecondView:NO];
                }
            }else if([[vcArrayInfo objectAtIndex:2] containsString:@"Supplement Plan 65 and over5B2019"]||[[vcArrayInfo objectAtIndex:2] containsString:@"Supplement Plan 65 and over5B2020"]){
                
                [questionViewLabel enableSecondView:YES];
                
            }else {
                if(questionViewLabel.yesButton.buttonSelected){
                    [questionViewLabel enableSecondView:YES];
                }else {
                    [questionViewLabel enableSecondView:NO];
                }
            }
        }
    }
    
    
    // Populate the effective date from Personal form effective date
    NSArray *currentVC = [UINavigationQueue getCurrentVCInfo];
    
    //BRD2.0
    if([[currentVC objectAtIndex:2] containsString:@"Supplement Plan 65 and over1A2019"]||[[currentVC objectAtIndex:2] containsString:@"Supplement Plan 65 and over1A2020"]){
    
        yesQuesBtn = [UIRenderer getComponentAtIndex:1];
        
        noQuesBtn = [UIRenderer getComponentAtIndex:2];
    
        [yesQuesBtn reset]; // reset the Radio Button value
        [self calculateAge65Date:[AppConfig birthDateString]];
        
        
        if(diff_year_of_65 == 0 && ((diff_month_of_65<=0 && diff_month_of_65>=-5 && diff_day_of_65<=0)||(diff_month_of_65==-6 && diff_day_of_65==0))) { //65 yrs within last 6 months, "-" indicate to previous months
            PRINTLOG(@"65 within Last 6 months");
            [yesQuesBtn setRadioButtonSelected:YES];
            [AppConfig setIsTurn65InAfter3monthsFuture:NO];
            
        }else if((diff_year_of_65==0 && (diff_month_of_65<=-6 && diff_day_of_65<=0)) || diff_year_of_65<0) { //65 yrs before last 6 months
            PRINTLOG(@"65 before last 6 months");
            [noQuesBtn setRadioButtonSelected:YES];
             [AppConfig setIsTurn65InAfter3monthsFuture:NO];
        }else if(diff_year_of_65==0 && ((diff_month_of_65>=0 && diff_month_of_65<=2 && diff_day_of_65>=0) ||(diff_month_of_65==3 && diff_day_of_65==0))){ //65 yrs within next 3 months  "+" indicate to future months
            PRINTLOG(@"65 within next 3 months");

            [yesQuesBtn setRadioButtonSelected:YES];
             [AppConfig setIsTurn65InAfter3monthsFuture:NO];  //latest(23/7/2019) reverted
        }else {
            PRINTLOG(@"65 above next 3 months"); //65 yrs after next 3 months
            [noQuesBtn setRadioButtonSelected:YES];
            [AppConfig setIsTurn65InAfter3monthsFuture:YES];
        }
        
        yesQuesBtn.userInteractionEnabled = NO;
        noQuesBtn.userInteractionEnabled =  NO;
    
    }else if([[currentVC objectAtIndex:2] containsString:@"Supplement Plan 65 and over1B2019"]||[[currentVC objectAtIndex:2] containsString:@"Supplement Plan 65 and over1B2020"]){

       
        yesQuesBtn = [UIRenderer getComponentAtIndex:1];
        
        noQuesBtn = [UIRenderer getComponentAtIndex:2];
        
        effectiveDate = [UIRenderer getComponentAtIndex:3];
        
        //BRD2.0
        [yesQuesBtn reset]; // reset the Radio Button value
        
        NSString *effectiveDateString = [AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:medicare_information:part_b_effective_date"];
         [self effectiveDateCalcuation:effectiveDateString];
        
        //Based on Components month -> - indicate before last 6 months ( compare Effective Date from current Date )
        if(effectiveDate_year==0 && ((effectiveDate_month<=0 && effectiveDate_month>=-5 && effectiveDate_day<=0) || (effectiveDate_month==-6 && effectiveDate_day==0))) { // within Last 6 months
            PRINTLOG(@"Part B within Last 6  months");
            [yesQuesBtn setRadioButtonSelected:YES];
            [self populateEffectiveDate:yesQuesBtn];
            
        }else if((effectiveDate_year==0 && (effectiveDate_month<=-6 && effectiveDate_day<=0)) || effectiveDate_year<0) { // before last 6 months
            PRINTLOG(@"Part B before Last 6  months");
            [noQuesBtn setRadioButtonSelected:YES];
            [self populateEffectiveDate:noQuesBtn];
            
        }else if(effectiveDate_year==0 && ((effectiveDate_month>=0 && effectiveDate_month<=2 && effectiveDate_day>=0) ||(effectiveDate_month==3 && effectiveDate_day==0))){   // next 3 months
            PRINTLOG(@"part B within next 3 months");

            [yesQuesBtn setRadioButtonSelected:YES];
            [self populateEffectiveDate:yesQuesBtn];
            
        }else {     // above next 3 months
            PRINTLOG(@"Part B after next 3 months");
            [noQuesBtn setRadioButtonSelected:YES];
            [self populateEffectiveDate:noQuesBtn];
        }
        
        __block QuestionnaireViewController *weakself = self;
        yesQuesBtn.parent = weakself;
        yesQuesBtn.actionblock = ^(id address,id parent){
            [parent populateEffectiveDate:address];
        };
        
        noQuesBtn.parent = weakself;
        noQuesBtn.actionblock = ^(id address,id parent){
            
            [parent populateEffectiveDate:address];
        };
        
        // fixed the issue -> Back to this screen with "No" option enabled the "Medicare (Part B) Effective Date"
        if(yesQuesBtn.buttonSelected){
            [effectiveDate setenabled];
        }else {
             [effectiveDate setdisabled];
        }
         effectiveDate.userInteractionEnabled = NO;
        
        yesQuesBtn.userInteractionEnabled = NO;
        noQuesBtn.userInteractionEnabled =  NO;
       
    }else if([[currentVC objectAtIndex:2] containsString:@"Supplement Plan 65 and over5B2019"]||[[currentVC objectAtIndex:2] containsString:@"Supplement Plan 65 and over5B2020"]) {
        
        yesQuesBtn = [UIRenderer getComponentAtIndex:1];
        
        noQuesBtn = [UIRenderer getComponentAtIndex:2];
        
        startDate = [UIRenderer getComponentAtIndex:3];
        
        endDate = [UIRenderer getComponentAtIndex:4];
        
        effectiveDate = nil;
        
    
        __block QuestionnaireViewController *weakself = self;
        
        yesQuesBtn.parent = weakself;
        yesQuesBtn.actionblock = ^(id address,id parent){
            [parent checkStartDateValidation:address];
        };
        
        noQuesBtn.parent = weakself;
        noQuesBtn.actionblock = ^(id address,id parent){
            
            [parent checkStartDateValidation:address];
        };
        
        // fixed the issue -> Back to this screen with "No" option
        [startDate setenabled];
        [endDate setenabled];
        
        // BRD2.0 - 7c & 7g questions - click no button we showed denial message with "Back to Plan" & "Continue" button
        
//        else if(([[currentVC objectAtIndex:2] containsString:@"Supplement Plan 65 and over3B2019"] ||[[currentVC objectAtIndex:2] containsString:@"Supplement Plan 65 and over3B2020"] ) || ([[currentVC objectAtIndex:2] containsString:@"Supplement Plan 65 and over4B2019"] ||[[currentVC objectAtIndex:2] containsString:@"Supplement Plan 65 and over4B2020"]))
        
//        else if([[currentVC objectAtIndex:2] containsString:@"Supplement Plan 65 and over4B2019"] ||[[currentVC objectAtIndex:2] containsString:@"Supplement Plan 65 and over4B2020"])
    }else if([[currentVC objectAtIndex:2] containsString:@"Supplement Plan 65 and over4B2019"] || [[currentVC objectAtIndex:2] containsString:@"Supplement Plan 65 and over4B2020"]){
        
        yesQuesBtn = [UIRenderer getComponentAtIndex:1];
        
        noQuesBtn = [UIRenderer getComponentAtIndex:2];
        
        __block QuestionnaireViewController *weakself = self;
        
        yesQuesBtn.parent = weakself;
        yesQuesBtn.actionblock = ^(id address,id parent){
            [parent checkStartDateValidation:address];
        };
        
        if (![yesQuesBtn isRadioButtonSelected] && ![noQuesBtn isRadioButtonSelected]) {
            
            self.isShowDenialAlert = YES;
            
        }else {
            isShowDenialAlert = NO;
        }
        
        
        noQuesBtn.parent = weakself;
        noQuesBtn.actionblock = ^(id address,id parent){
            
    
            if(weakself.isShowDenialAlert) {
                
                [self showAlertView:@"Alert" message:@"We will not be able to issue you coverage if you do not intend to replace your current coverage with this new Medicare Blue Supplement plan.  If you wish to replace your current plan, click 'Yes' to this question." class:weakself actionBlock:^(id data,id handler)
                 {
                     [handler disableDenialAlert];                }];
                
                
//                [AppConfig showAlertView:@"Alert" message:@"We will not be able to issue you coverage if you do not intend to replace your current coverage with this new Medicare Blue Supplement plan.  If you wish to replace your current plan, click 'Yes' to this question." OkTitle:@"Continue" CanelTitle:nil class:weakself okAction:^(id data,id handler){
//                    PRINTLOG(@"7c Continue button pressed");
//                    [handler disableDenialAlert];
//
//                }
//                            cancelAction:^(id data,id handler){
//                    PRINTLOG(@"7c Back To Plan page pressed");
//                              }];
            }
            
        };
        
    }else {
        
    }
}

// BRD2.0
-(void)disableDenialAlert {
    
    self.isShowDenialAlert = NO;
}
-(void)moveToPlanHomePage:(id)handler {
    
    PRINTLOG(@"handler :: %@",handler);
    
    // Set index which page move to edit
    [AppConfig setEditPageIndex:[AppConfig editPageIndexBasedOnString:@"MedicarePlanViewController" pageArray:[UINavigationQueue getPushlistArray]]];
    
    id baseVC= [UIApplication sharedApplication].keyWindow.rootViewController;
    
    ScopeBaseViewController *baseView;
    
    if([baseVC isKindOfClass:[UINavigationController class]]){
        baseView = (ScopeBaseViewController *)[baseVC visibleViewController];
    }
    
    //set the Bool to YES when move to Medicare Plan page and then de-selected the plan button
    [AppConfig setIsFromQuestionPage:YES];
    
    PRINTLOG(@"baseView :: %@",baseView);
    [UINavigationQueue gotoScreen:[AppConfig editPageIndex] BaseVC:baseView];
    if(baseView!=nil){
        [baseView backButton:nil];
    }
    
    
}

-(void)checkStartDateValidation:(id)btnValue {
    

    for (id questionviewObj2 in firstView.subviews){

            if([questionviewObj2 isKindOfClass:[UIQuestionView class]]){

                UIQuestionView *questionView2 = questionviewObj2;
                [questionView2 enableSecondView:YES];
            }
    }
    
    // fixed the issue -> Back to this screen with "No" option
    [startDate setenabled];
    [endDate setenabled];

}

-(void)populateEffectiveDate :(id)value {
    
    PRINTLOG(@"value getString ::%@",[value getValueString]);
    if([[value getValueString] isEqualToString:@"Yes"]||[[value getValueString] isEqualToString:@"Sí"]){

        NSString *effectiveDateValue = [AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:medicare_information:part_b_effective_date"];

        if(effectiveDateValue.length>0){
            effectiveDate.selectedString = effectiveDateValue;
            effectiveDate.titleString = effectiveDateValue;
            [effectiveDate setenabled];
        }else {
            effectiveDate.selectedString = @"";
            effectiveDate.titleString = @"Select";
            [effectiveDate setdisabled];
        }
        
    }
    else{
        effectiveDate.selectedString = @"";
        effectiveDate.titleString = @"Select";
        [effectiveDate setdisabled];
    }
}


-(BOOL)validateVC {
	
    BOOL hasError = NO;
    
    for (id questionviewObj in firstView.subviews){
        //added svk 21/June/2019
//        NSArray *vcInfo = [UINavigationQueue getCurrentVCInfo];
//        if([[vcInfo objectAtIndex:2]containsString:@"SupplementUnder506A2019"])
//        {
//            hasError = NO;
//        }
//        else
//        {
        if([questionviewObj isKindOfClass:[UIQuestionView class]]){
            
            UIQuestionView *questionView = questionviewObj;
           //svk added 25/06
            if(questionView.yesButton.dataValidator(questionView.yesButton)){
                questionView.detailLabel.textColor =  TEXTCOLOR;
                questionView.headingLabel.textColor = TEXTCOLOR;
                questionView.yesButton.layer.borderColor = [UIColor clearColor].CGColor;
                questionView.noButton.layer.borderColor =  [UIColor clearColor].CGColor;
				
				yesBtn = questionView.yesButton;
				noBtn = questionView.noButton;
                
                // hasError = NO;
               hasError = [self showAlertView];
            }else {
                questionView.headingLabel.textColor = REDCOLOR;
                questionView.detailLabel.textColor = REDCOLOR;
                questionView.yesButton.layer.borderColor = REDCOLOR.CGColor;
                questionView.noButton.layer.borderColor =  REDCOLOR.CGColor;
               
                hasError = YES;
            }
             questionView.yesButton.layer.borderWidth = 1.0f;
             questionView.noButton.layer.borderWidth = 1.0f;
            
        }else if([questionviewObj isKindOfClass:[UIQuestionViewCustomLabel class]]){
            
            UIQuestionViewCustomLabel *questionViewLabel = questionviewObj;
            
            //svk added 25/06
                   if(questionViewLabel.yesButton.dataValidator(questionViewLabel.yesButton)){
                questionViewLabel.detailLabel.textColor =  TEXTCOLOR;
                questionViewLabel.headingLabel.textColor = TEXTCOLOR;
                questionViewLabel.yesButton.layer.borderColor = [UIColor clearColor].CGColor;
                questionViewLabel.noButton.layer.borderColor =  [UIColor clearColor].CGColor;
                
                yesBtn = questionViewLabel.yesButton;
                noBtn = questionViewLabel.noButton;
                
                // hasError = NO;
                hasError = [self showAlertView];
            }else {
                questionViewLabel.headingLabel.textColor = REDCOLOR;
                questionViewLabel.detailLabel.textColor = REDCOLOR;
                questionViewLabel.yesButton.layer.borderColor = REDCOLOR.CGColor;
                questionViewLabel.noButton.layer.borderColor =  REDCOLOR.CGColor;
                
                hasError = YES;
            }
            
            questionViewLabel.yesButton.layer.borderWidth = 1.0f;
            questionViewLabel.noButton.layer.borderWidth = 1.0f;
        }
    }
//    }
	if(!hasError){
		
		NSArray *vcInfo = [UINavigationQueue getCurrentVCInfo];
        
		if([[vcInfo objectAtIndex:2] containsString:@"SupplementUnder503A2017"] ||([[vcInfo objectAtIndex:2] containsString:@"SupplementUnder506E2017"] && !yesBtn.buttonSelected) || [[vcInfo objectAtIndex:2] containsString:@"Supplement Plan 50-643A2017"] || [[vcInfo objectAtIndex:2] containsString:@"Supplement Plan 65 and over3A2017"] || [[vcInfo objectAtIndex:2] containsString:@"SupplementUnder503A2018"] ||([[vcInfo objectAtIndex:2] containsString:@"SupplementUnder506E2018"] && !yesBtn.buttonSelected )|| [[vcInfo objectAtIndex:2] containsString:@"Supplement Plan 50-643A2018"] || [[vcInfo objectAtIndex:2] containsString:@"Supplement Plan 65 and over3A2018"]  || [[vcInfo objectAtIndex:2] containsString:@"SupplementUnder505B2017"] || [[vcInfo objectAtIndex:2] containsString:@"SupplementUnder505B2018"]
		   || [[vcInfo objectAtIndex:2] containsString:@"Supplement Plan 65 and over5B2017"] ||  [[vcInfo objectAtIndex:2] containsString:@"Supplement Plan 65 and over5B2018"] ||  [[vcInfo objectAtIndex:2] containsString:@"Supplement Plan 50-645B2017"]||  [[vcInfo objectAtIndex:2] containsString:@"Supplement Plan 50-645B2018"] ||  [[vcInfo objectAtIndex:2] containsString:@"SupplementUnder503A2019"] ||  [[vcInfo objectAtIndex:2] containsString:@"SupplementUnder503A2020"]||([[vcInfo objectAtIndex:2] containsString:@"SupplementUnder506E2019"] && !yesBtn.buttonSelected )||([[vcInfo objectAtIndex:2] containsString:@"SupplementUnder506E2020"] && !yesBtn.buttonSelected )|| [[vcInfo objectAtIndex:2] containsString:@"Supplement Plan 50-643A2019"] || [[vcInfo objectAtIndex:2] containsString:@"Supplement Plan 50-643A2020"]|| [[vcInfo objectAtIndex:2] containsString:@"Supplement Plan 65 and over3A2019"] || [[vcInfo objectAtIndex:2] containsString:@"Supplement Plan 65 and over3A2020"]||[[vcInfo objectAtIndex:2] containsString:@"SupplementUnder505B2019"]||[[vcInfo objectAtIndex:2] containsString:@"SupplementUnder505B2020"]||[[vcInfo objectAtIndex:2] containsString:@"Supplement Plan 65 and over5B2019"]||[[vcInfo objectAtIndex:2] containsString:@"Supplement Plan 65 and over5B2020"]||[[vcInfo objectAtIndex:2] containsString:@"Supplement Plan 50-645B2019"]||[[vcInfo objectAtIndex:2] containsString:@"Supplement Plan 50-645B2020"]){
            
           
			
			startDate = [UIRenderer getComponentAtIndex:3];
			endDate = [UIRenderer getComponentAtIndex:4];
			
			NSDate *stDate = [[NSDate alloc]init];	
			NSDate *enDate = [[NSDate alloc]init];
			NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
			[dateFormatter setDateFormat:@"MM/dd/yyyy"];
			stDate = [dateFormatter dateFromString:startDate.selectedString];
			enDate = [dateFormatter dateFromString:endDate.selectedString];
            
			if([stDate compare:enDate] == NSOrderedSame && stDate != nil && enDate != nil){
				
				UIDropDown *successDropdown = startDate;
				successDropdown.layer.borderWidth = 1.0f;
				successDropdown.layer.borderColor = [UIColor colorWithRed:(240.0/255.0) green:(108.0/255.0) blue:(108.0/255.0) alpha:1.0f].CGColor;
				successDropdown.confirmImgView.hidden = YES;
				
				
				UIDropDown *failedDropdown = endDate;
				failedDropdown.layer.borderWidth = 1.0f;
				failedDropdown.layer.borderColor = [UIColor colorWithRed:(240.0/255.0) green:(108.0/255.0) blue:(108.0/255.0) alpha:1.0f].CGColor;
				failedDropdown.confirmImgView.hidden = YES;
				//[failedDropdown changeFontColor:failedDropdown color:REDCOLOR];
				
				return hasError=YES;
			}else if([stDate compare:enDate] == NSOrderedAscending){
				
				UIDropDown *successDropdown = startDate;
				successDropdown.layer.borderWidth = 1.0f;
				successDropdown.layer.borderColor = [UIColor colorWithRed:(204.0/255.0) green:(204.0/255.0) blue:(204.0/255.0) alpha:1.0f].CGColor;
				successDropdown.confirmImgView.hidden = NO;
				//[successDropdown changeFontColor:successDropdown color:TEXTCOLOR];
				
				UIDropDown *failedDropdown = endDate;
				failedDropdown.layer.borderWidth = 1.0f;
				failedDropdown.layer.borderColor = [UIColor colorWithRed:(204.0/255.0) green:(204.0/255.0) blue:(204.0/255.0) alpha:1.0f].CGColor;
				failedDropdown.confirmImgView.hidden = NO;
				
				
				return hasError = NO;
				
			}else if([stDate compare:enDate] == NSOrderedDescending){
				
				UIDropDown *successDropdown = startDate;
				successDropdown.layer.borderWidth = 1.0f;
				successDropdown.layer.borderColor = [UIColor colorWithRed:(240.0/255.0) green:(108.0/255.0) blue:(108.0/255.0) alpha:1.0f].CGColor;
				successDropdown.confirmImgView.hidden = YES;
				
				
				UIDropDown *failedDropdown = endDate;
				failedDropdown.layer.borderWidth = 1.0f;
				failedDropdown.layer.borderColor = [UIColor colorWithRed:(240.0/255.0) green:(108.0/255.0) blue:(108.0/255.0) alpha:1.0f].CGColor;
				failedDropdown.confirmImgView.hidden = YES;
				//[failedDropdown changeFontColor:failedDropdown color:REDCOLOR];
				
				return hasError = YES;
                
            }else {
				return hasError = NO;
			}

	}
			
		}
	
    return hasError;
}

-(BOOL)showAlertView{
    
    NSArray *vcInfo = [UINavigationQueue getCurrentVCInfo];
    if(([[vcInfo objectAtIndex:2] containsString:@"SupplementUnder506G"] && noBtn.buttonSelected) || ([[vcInfo objectAtIndex:2] containsString:@"Supplement Plan 50-641A"] && noBtn.buttonSelected) ){
        [self errorMessageAlert:@"" message:@"You must be eligible for Medicare to enroll in this plan, please speak to agent for more options"];
        return YES;
        
    }else {
        return NO;
    }

}

//added new alert
-(void)showAlertView :( NSString *)title message :( NSString *)message class :( id)classVC actionBlock :( AlertActionBlock)actionBlock {
    
    UIAlertController *alertController;
    UIAlertAction *alertOKAction;
    
    PRINTLOG(@"Show Alert View");
    alertController = nil;
    alertOKAction = nil;
    
    alertActionBlock = actionBlock;
    
    NSString *localizeTitle = [LanguageCentral languageSelectedString:title];
    NSString *displayTitle = (localizeTitle.length>0)? localizeTitle : title;
    
    NSString *localizeMsg = [LanguageCentral languageSelectedString:message];
    NSString *displayMsg = (localizeTitle.length>0)? localizeMsg : message;
    
    
    if (alertController == nil) {
        
        alertController = [UIAlertController alertControllerWithTitle :displayTitle message :displayMsg preferredStyle:UIAlertControllerStyleAlert];
    }
    
    if(alertOKAction== nil) {
        alertOKAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Continue",@"Continue action") style:UIAlertActionStyleDefault handler:^(UIAlertAction *okAction){
            alertActionBlock(okAction,classVC);
            [classVC dismissViewControllerAnimated:YES completion:nil];
        }];
    }
    
    [alertController addAction:alertOKAction];
    [classVC presentViewController:alertController animated:YES completion:nil];
}


-(void)errorMessageAlert:(NSString *)title message:(NSString *)message {

    
    NSString *localizeTitle = [LanguageCentral languageSelectedString:title];
    NSString *titleString = (localizeTitle.length>0)?localizeTitle:title;
    
    
    NSString *localizeMessage = [LanguageCentral languageSelectedString:message];
    NSString *msgString = (localizeMessage.length>0)?localizeMessage:message;

    
    
    UIAlertController *alertController = [UIAlertController
                                          alertControllerWithTitle:titleString
                                          message:msgString
                                          preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *okAction = [UIAlertAction
                               actionWithTitle:NSLocalizedString(@"OK", @"OK action")
                               
                               style:UIAlertActionStyleDefault
                               handler:^(UIAlertAction *action)
                               {
                                   [self disableSubViewField];
                                   
                               }];
    
    [alertController addAction:okAction];
    
    [self presentViewController:alertController animated:YES completion:nil];
}

-(void)disableSubViewField{
    
    for (id questionviewObj in firstView.subviews){
        
        if([questionviewObj isKindOfClass:[UIQuestionView class]]){
            
            UIQuestionView *questionView = questionviewObj;
            [questionView.noButton reset];
            [questionView enableSecondView:NO];
            
        }else if([questionviewObj isKindOfClass:[UIQuestionViewCustomLabel class]]){
            
            UIQuestionViewCustomLabel *questionView2 = questionviewObj;
            [questionView2.noButton reset];
            [questionView2 enableSecondView:NO];
            
        }
    }
}

-(void)loadNextPage {
    
	getCurrentVCInfo = [UINavigationQueue getCurrentVCInfo];
    
	yesQuestion = nil;
	noQuestion = nil;
	nextQuestion = nil;
	
    if(![self.sharedataObj.forwardNextButtonTitle isEqualToString:@"Next"]){
        self.sharedataObj.forwardNextButtonTitle = @"Next";
    }
    
	[self reloadPlistFile];
	
    
    [UINavigationQueue deleteAfter:[getCurrentVCInfo objectAtIndex:0] container:[getCurrentVCInfo objectAtIndex:1] xib:[getCurrentVCInfo objectAtIndex:2]];
    
 
    if([yesBtn buttonSelected] && yesQuestion!=nil){
        
        
        [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[QuestionnaireViewController class] xibName:[NSString stringWithFormat:@"%@%@%@",[AppConfig currentPlan],yesQuestion,[AppConfig enrollYear]]];
        if(![self.sharedataObj.forwardNextButtonTitle isEqualToString:@"Next"]){
            self.sharedataObj.forwardNextButtonTitle = @"Next";
        }
		yesQuestion = nil;
        
    }else if([noBtn buttonSelected] && noQuestion!=nil){
        
        
        if ([[AppConfig currentPlan]containsString:@"65 and over"] && ([[AppConfig enrollYear] isEqualToString:@"2019"] ||[[AppConfig enrollYear] isEqualToString:@"2020"] )) {
            
            NSString *get65Value = [AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:acceptance_guaranteed:turn_age_65"];
            
            [self calculateAge65Date:[AppConfig birthDateString]];
            
            if([[getCurrentVCInfo objectAtIndex:2]containsString:@"1B2019"]||[[getCurrentVCInfo objectAtIndex:2]containsString:@"1B2020"]) {
                
                /* // original code
                // 65 within last 6 months
                if( [get65Value isEqualToString:@"Yes"]){
                    
                    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[QuestionnaireViewController class] xibName:[NSString stringWithFormat:@"%@%@%@",[AppConfig currentPlan],@"2A",[AppConfig enrollYear]]];
                    
                    // 65 after next 3 months
                }else if(diff_year_of_65>=0 && diff_month_of_65>3){
                    
                    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[QuestionnaireViewController class] xibName:[NSString stringWithFormat:@"%@%@%@",[AppConfig currentPlan],@"2A",[AppConfig enrollYear]]];
                    
                    // Part B in next 3 months  || Part B in after next 3 months
                }else if ((effectiveDate_year==0 && effectiveDate_month<4) || (effectiveDate_year>=0 && effectiveDate_month>3)){
                    
                    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[QuestionnaireViewController class] xibName:[NSString stringWithFormat:@"%@%@%@",[AppConfig currentPlan],@"2A",[AppConfig enrollYear]]];
                    
                    // age 65 in next 3 months
                }else if (diff_year_of_65==0 && diff_month_of_65<4){
                    
                    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[QuestionnaireViewController class] xibName:[NSString stringWithFormat:@"%@%@%@",[AppConfig currentPlan],@"2A",[AppConfig enrollYear]]];
                }else {
                    
                    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[QuestionnaireViewController class] xibName:[NSString stringWithFormat:@"%@%@%@",[AppConfig currentPlan],noQuestion,[AppConfig enrollYear]]];
                }
                 */
                
                // 65 within last 6 months
                if( [get65Value isEqualToString:@"Yes"]){
                    
                    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[QuestionnaireViewController class] xibName:[NSString stringWithFormat:@"%@%@%@",[AppConfig currentPlan],@"2A",[AppConfig enrollYear]]];
                     [AppConfig fillJSONDictionary:@"data:acceptance_guaranteed:other_health_coverage" value:@""];
                    
                    // age 65 in next 3 months
                }else if (diff_year_of_65==0 && ((diff_month_of_65>=0 && diff_month_of_65<=2 && diff_day_of_65>=0)||(diff_month_of_65==3 && diff_day_of_65==0))){
                    
                    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[QuestionnaireViewController class] xibName:[NSString stringWithFormat:@"%@%@%@",[AppConfig currentPlan],@"2A",[AppConfig enrollYear]]];
                     [AppConfig fillJSONDictionary:@"data:acceptance_guaranteed:other_health_coverage" value:@""];
                    
                    // 65 after next 3 months
                }else if(diff_year_of_65>=0 && ((diff_month_of_65>3 && diff_day_of_65>=0) || (diff_month_of_65==3 && diff_day_of_65>0))){
                    
                    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[QuestionnaireViewController class] xibName:[NSString stringWithFormat:@"%@%@%@",[AppConfig currentPlan],@"2A",[AppConfig enrollYear]]];
                     [AppConfig fillJSONDictionary:@"data:acceptance_guaranteed:other_health_coverage" value:@""];
                    
                    // Part B in next 3 months
                }else if ((effectiveDate_year==0 && ((effectiveDate_month>=0 && effectiveDate_month<=2 && effectiveDate_day>=0) ||
                                                     (effectiveDate_month==3 && effectiveDate_day==0)))){
                    
                    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[QuestionnaireViewController class] xibName:[NSString stringWithFormat:@"%@%@%@",[AppConfig currentPlan],@"2A",[AppConfig enrollYear]]];
                     [AppConfig fillJSONDictionary:@"data:acceptance_guaranteed:other_health_coverage" value:@""];
                    
                    //Part B in after next 3 months
                }else if(effectiveDate_year>=0 && ((effectiveDate_month>3 && effectiveDate_day>=0) || (effectiveDate_month==3 && effectiveDate_day>0))){
                    
                    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[QuestionnaireViewController class] xibName:[NSString stringWithFormat:@"%@%@%@",[AppConfig currentPlan],@"2A",[AppConfig enrollYear]]];
                     [AppConfig fillJSONDictionary:@"data:acceptance_guaranteed:other_health_coverage" value:@""];
                    
                    
                }else {
                    
                    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[QuestionnaireViewController class] xibName:[NSString stringWithFormat:@"%@%@%@",[AppConfig currentPlan],noQuestion,[AppConfig enrollYear]]];
                }
                
            }else {
                 [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[QuestionnaireViewController class] xibName:[NSString stringWithFormat:@"%@%@%@",[AppConfig currentPlan],noQuestion,[AppConfig enrollYear]]];
            }
        }else {
               [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[QuestionnaireViewController class] xibName:[NSString stringWithFormat:@"%@%@%@",[AppConfig currentPlan],noQuestion,[AppConfig enrollYear]]];
        }

        if(![self.sharedataObj.forwardNextButtonTitle isEqualToString:@"Next"]){
            self.sharedataObj.forwardNextButtonTitle = @"Next";
        }
		noQuestion = nil;
    }
      [self addNextQuestionPage];

}

-(void)addNextQuestionPage {
    
    if(nextQuestion!=nil){
        
        [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[QuestionnaireViewController class] xibName:[NSString stringWithFormat:@"%@%@%@",[AppConfig currentPlan],nextQuestion,[AppConfig enrollYear]]];
		nextQuestion = nil;
		
    }
    [self addTrailingScreens];
}

-(void)addTrailingScreens {
    

    if( [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"] && ([[AppConfig enrollYear] isEqualToString:@"2019"]||[[AppConfig enrollYear] isEqualToString:@"2020"] )) {
        
        // 7f answer -> 4A2019
        if([[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] : @"data:health_coverage:6g"] isEqualToString:@"No"]){
            
            [AppConfig fillJSONDictionary:@"data:health_coverage:6h" value:@""]; // 7g is hidden , ->4B2019
        }
        
        // 7h answer -> 5A2019
        if([[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] : @"data:health_coverage:6i"] isEqualToString:@"No"]){
            
            [AppConfig setTempJSONDictionary:[AppConfig setValue:[AppConfig tempCurrentPlanJSONDictionary] :@"tempJSON:data:health_coverage:other_policy_start" :@""]];
            
            // 7i is hidden , ->5B2019
            [AppConfig fillJSONDictionary:@"data:health_coverage:6j_start" value:@""]; // 7g is hidden , ->4B2019
            
            [AppConfig fillJSONDictionary:@"data:health_coverage:6j_end" value:@""]; // 7g is hidden , ->4B2019
        }
        
    }
    
    
    

    NSString *otherHealthPolicy = [AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] : @"data:health_coverage:6d"];
    PRINTLOG(@"7c answer ::%@",otherHealthPolicy);
    
    NSString *replaceCurrentMedicare = [AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] : @"data:health_coverage:6h"];
    PRINTLOG(@"7g answer ::%@",replaceCurrentMedicare);
    
    
    if(([otherHealthPolicy isEqualToString:@"Yes"]||[replaceCurrentMedicare isEqualToString:@"Yes"])){
        // store the temporary value for display edit button Under notice section in Preview page
        [AppConfig setTempJSONDictionary:[AppConfig setValue:[AppConfig tempCurrentPlanJSONDictionary] :@"tempJSON:data:health_coverage:preview_edit" :@"Yes"]];
    }else {
        // store the temporary value for display edit button Under notice section in Preview page
         [AppConfig setTempJSONDictionary:[AppConfig setValue:[AppConfig tempCurrentPlanJSONDictionary] :@"tempJSON:data:health_coverage:preview_edit" :@"No"]];
        
        [AppConfig fillJSONDictionary:@"data:notice:options" value:@""];
    }
    

    if(trailingScreen.count>1){
        
        
        if([AppConfig isFromPreview]){

            [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[[[NSClassFromString(@"PreviewViewController") alloc] init] class] xibName:nil];
        }
            for (id trailingVC in trailingScreen){
                
                id classObj= [[NSClassFromString(trailingVC) alloc] init];
                
                if([trailingVC isEqualToString:@"EmailCollectionViewController"]){
                    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[classObj class] xibName:@"EmailCollection"];
                    
                }else if([trailingVC isEqualToString:@"AuthorizationViewController"] && [[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"] && ([[AppConfig enrollYear] isEqualToString:@"2019"]||[[AppConfig enrollYear] isEqualToString:@"2020"]) && ([otherHealthPolicy isEqualToString:@"Yes"]||[replaceCurrentMedicare isEqualToString:@"Yes"])){
                    
                    
                    // added the notice page based on 7c - yes & 7g - yes for 65+ 2019
                    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[classObj class] xibName:nil];
                    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[SupplementNoticeViewController class] xibName:nil];
                    
                    if ([AppConfig isFromPreview]){
                        
                        [AppConfig setIsAddNoticePage:YES];
                        
                         [UINavigationQueue RemoveClassAtIndex:[AppConfig pageIndex:@"PreviewViewController" pageArray:[UINavigationQueue getPushlistArray]]];
                        
                         [UINavigationQueue RemoveClassAtIndex:[AppConfig pageIndex:@"AuthorizationViewController" pageArray:[UINavigationQueue getPushlistArray]]];
                        
                        // set index after which page inserting the preview VC.  - it get name from index 1
                        [AppConfig setInsertPageIndex:[AppConfig editPageIndexBasedOnString:@"SupplementNoticeViewController" pageArray:[UINavigationQueue getPushlistArray]]];
                        
                        
                        // set preview vc class
//                          [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[[[NSClassFromString(@"PreviewViewController") alloc] init] class] xibName:nil];
                        
                        // set preview vc class
                        [UINavigationQueue InsertClass:[ScopeBaseViewController class] containerVC:[[[NSClassFromString(@"PreviewViewController") alloc] init] class] xibName:nil index:[AppConfig insertPageIndex]];
                    }
                    //vrl added this code for new attestation page for DSNP
                }else if([trailingVC isEqualToString:@"HealthViewController"] && [[AppConfig currentPlan]isEqualToString:@"DSNP"] && ([[AppConfig enrollYear] isEqualToString:@"2019"]||[[AppConfig enrollYear] isEqualToString:@"2020"])) {
                    
                     //add this code in addTrailingScreens method for adding new attestation for DSNP
                    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[classObj class] xibName:nil];
                    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[[[NSClassFromString(@"AttestationRadioButtonViewController") alloc] init] class] xibName:nil];
                }else {
                    [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[classObj class] xibName:nil];
                    // store the temporary value for display edit button Under notice section in Preview page
                   
                }
            }
        
    }else  {

    }
    
    if(([[getCurrentVCInfo objectAtIndex:2]containsString:@"1C2019"]||[[getCurrentVCInfo objectAtIndex:2]containsString:@"1C2020"] )&& [noBtn buttonSelected]){
        
        [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[GuaranteedIssueRightsViewController class] xibName:nil];
        [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[SupplementGuaranteedQuestionViewController class] xibName:nil];
        [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[QuestionnaireViewController class] xibName:[NSString stringWithFormat:@"%@%@%@",[AppConfig currentPlan],@"2A",[AppConfig enrollYear]]];
//
//        if([AppConfig isFromPreview]) {
//            [AppConfig incrementEditIndex];
//            [AppConfig incrementEditIndex];
//            [AppConfig incrementEditIndex];
//            [AppConfig incrementInsertIndex];
//            [AppConfig incrementInsertIndex];
//            [AppConfig incrementInsertIndex];
//
//        }
    }
    
    trailingScreen = nil;
    
 
     if((([[getCurrentVCInfo objectAtIndex:2] containsString:@"Supplement Plan 65 and over1B2019"] ||[[getCurrentVCInfo objectAtIndex:2] containsString:@"Supplement Plan 65 and over1B2020"])&& [yesBtn buttonSelected]) || (([[getCurrentVCInfo objectAtIndex:2] containsString:@"Supplement Plan 65 and over1C2019"]||[[getCurrentVCInfo objectAtIndex:2] containsString:@"Supplement Plan 65 and over1C2020"]) && [yesBtn buttonSelected])){
         
         
//         data:acceptance_guaranteed:other_health_coverage  -- 1c
         
//         data:acceptance_guaranteed:enroll_medicare - 1b
         
         if(([[getCurrentVCInfo objectAtIndex:2] containsString:@"Supplement Plan 65 and over1B2019"]||[[getCurrentVCInfo objectAtIndex:2] containsString:@"Supplement Plan 65 and over1B2020"]) && [yesBtn buttonSelected]){
             [AppConfig fillJSONDictionary:@"data:acceptance_guaranteed:other_health_coverage" value:@""];
         }
         
          [AppConfig fillJSONDictionary:@"data:health_statements:5a" value:@""];
          [AppConfig fillJSONDictionary:@"data:health_statements:5b" value:@""];
          [AppConfig fillJSONDictionary:@"data:health_statements:5c1" value:@""];
          [AppConfig fillJSONDictionary:@"data:health_statements:5c2" value:@""];
          [AppConfig fillJSONDictionary:@"data:health_statements:5c3" value:@""];
          [AppConfig fillJSONDictionary:@"data:health_statements:5c4" value:@""];
          [AppConfig fillJSONDictionary:@"data:health_statements:5c5" value:@""];
          [AppConfig fillJSONDictionary:@"data:health_statements:5c6" value:@""];
          [AppConfig fillJSONDictionary:@"data:health_statements:5c7" value:@""];
          [AppConfig fillJSONDictionary:@"data:health_statements:5c8" value:@""];
          [AppConfig fillJSONDictionary:@"data:health_statements:5c9" value:@""];
          [AppConfig fillJSONDictionary:@"data:health_statements:5c10" value:@""];
          [AppConfig fillJSONDictionary:@"data:health_statements:5c11" value:@""];
          [AppConfig fillJSONDictionary:@"data:health_statements:5d1" value:@""];
          [AppConfig fillJSONDictionary:@"data:health_statements:5d2" value:@""];
          [AppConfig fillJSONDictionary:@"data:health_statements:5d3" value:@""];
          [AppConfig fillJSONDictionary:@"data:health_statements:5d4" value:@""];
          [AppConfig fillJSONDictionary:@"data:health_statements:5e1" value:@""];
          [AppConfig fillJSONDictionary:@"data:health_statements:5e2" value:@""];
          [AppConfig fillJSONDictionary:@"data:health_statements:5f" value:@""];
          [AppConfig fillJSONDictionary:@"data:health_statements:5g" value:@""];
         
     }
   //added svk 21/June/2019
//    if([[getCurrentVCInfo objectAtIndex:2]containsString:@"SupplementUnder506A2019"])
//    {
//         for (id questionviewObj in firstView.subviews){
//        if([questionviewObj isKindOfClass:[UIQuestionViewCustomLabel class]]){
//
//            UIQuestionViewCustomLabel *questionViewLabel = questionviewObj;
//             if((!questionViewLabel.yesButton.buttonSelected)&&(!questionViewLabel.noButton.buttonSelected)){
//                 [AppConfig fillJSONDictionary:@"data:persons_age_50_64:receive_a_retroactive" value:@""];
//
//            }
//            else
//            {
//                [AppConfig fillJSONDictionary:@"data:persons_age_50_64:receive_a_retroactive" value:[yesBtn getValueString]];
//            }
//    }
//         }
//}
}


-(void)reloadPlistFile {
	
		NSString *plistFileName = [NSString stringWithFormat:@"%@.plist",[getCurrentVCInfo objectAtIndex:2]];
		NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask,YES);
		NSString *documentsDirectory = [paths objectAtIndex:0];
		NSString *path = [documentsDirectory stringByAppendingPathComponent:plistFileName];
		
		if(![[NSFileManager defaultManager] fileExistsAtPath:path]){
			
			path = [[NSBundle mainBundle]pathForResource:[getCurrentVCInfo objectAtIndex:2] ofType:@"plist"];

		}
		NSMutableDictionary *data = [[NSMutableDictionary alloc]initWithContentsOfFile:path];
		
		
		for (NSString *objString in data) {
			
			if([objString isEqualToString:@"objNavigation"]){
				NSMutableDictionary *VCConfigDict = [data valueForKey:@"objNavigation"];
				if(VCConfigDict!=nil){
					[self childPlist:self plistDictionary:VCConfigDict];
				}
				
			}
			
		}
}


-(void)childPlist:(id)baseObject plistDictionary:(NSMutableDictionary *)plistDict {
	
        PRINTLOG(@"base Object::%@ ---- Dict ::%@",baseObject,plistDict);
	for(NSString *keyString in [plistDict allKeys]){
	
		id childObject = [plistDict valueForKey:keyString];
                PRINTLOG(@"content object ::%@",childObject);
		
		if(![childObject isKindOfClass:[NSDictionary class]]){
			
			[baseObject setValue:childObject forKey:keyString];
		}else {
			[self childPlist:[baseObject valueForKey:keyString] plistDictionary:childObject];
		}
	}
	
	
}

-(BOOL)addDSNPAttestationScreenAfter1Jan2019 {
    
    //old code , this code will added in addTrailingScreens method for DSNP 2019 with date restriction
//    else if([self addDSNPAttestationScreenAfter1Jan2019] && [trailingVC isEqualToString:@"HealthViewController"] && [[AppConfig currentPlan]isEqualToString:@"DSNP"] && [[AppConfig enrollYear] isEqualToString:@"2019"]) {
//
//        //add this code in addTrailingScreens method for adding new attestation for DSNP
//        [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[classObj class] xibName:nil];
//        [UINavigationQueue pushClass:[ScopeBaseViewController class] containerVC:[[[NSClassFromString(@"AttestationRadioButtonViewController") alloc] init] class] xibName:nil];
//    }
    
    // logic for showing alert for date restriction
    BOOL value;
    
    NSDate *currentDate = [NSDate date];
    
    // enable attestation page from 1/1/2019
    NSDateComponents *dateComps = [[NSDateComponents alloc] init];
    [dateComps setDay:1];
    [dateComps setMonth:1];
    [dateComps setYear:2019];
    
    NSDate *dateJan2019 = [[NSCalendar currentCalendar] dateFromComponents:dateComps];
    
    // simplified logic code
    if([currentDate compare:dateJan2019] == NSOrderedSame) {
        value = YES; // date is same to 1/1/2019 -> Enable
    }else if([currentDate compare:dateJan2019] == NSOrderedDescending){
        value = YES; // date is greater than 1/1/2019 -> Enable
    }else {
        value = NO;  // -> Disable
    }
    
    return value;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)calculateAge65Date :(NSString *)birthDateString {
    
    PRINTLOG(@"birthday :: %@",birthDateString);
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
    [dateFormatter setDateFormat:@"MM/dd/yyyy"];
    [dateFormatter setTimeZone:[NSTimeZone timeZoneWithName:@"EST"]];
    
    //convert string to date
    NSDate *birthDate=[dateFormatter dateFromString:birthDateString];
    
    //calculate 65 age year & month
    NSDateComponents *futureComponent = [[NSDateComponents alloc]init];
    [futureComponent setYear:65];
    
    NSDate *date_65 = [[NSCalendar currentCalendar]dateByAddingComponents:futureComponent toDate:birthDate options:0];

    
//    NSDateFormatter *estFormatter = [[NSDateFormatter alloc]init];
//    [estFormatter setDateFormat:@"MM/dd/yyyy"];
//    [estFormatter setTimeZone:[NSTimeZone timeZoneWithName:@"EST"]];
    
    NSString *dateStr = [dateFormatter stringFromDate:[NSDate date]];
    
    PRINTLOG(@"current est date string ::%@\n",dateStr);
    
    NSDate *getEstDate = [dateFormatter dateFromString:dateStr];
    
    PRINTLOG(@"current est date :: %@\n",getEstDate);
    
    NSDateComponents* futureComp= [[NSCalendar currentCalendar]
                                   components:NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay
                                   fromDate:getEstDate
                                   toDate:date_65
                                   options:0];
  
    diff_year_of_65 = [futureComp year];
    diff_month_of_65 = [futureComp month];
    diff_day_of_65 = [futureComp day];
    
    PRINTLOG(@"diff year :: %ld",(long)diff_year_of_65);
    PRINTLOG(@"diff month :: %ld",(long)diff_month_of_65);
    PRINTLOG(@"diff day :: %ld",(long)diff_day_of_65);
    
    

    //logic based on date components year,month & day
//    if(diff_year_of_65 == 0 && (diff_month_of_65<=0 && diff_month_of_65>=-6)) { //65 yrs within last 6 months, "-" indicate to previous months
//        PRINTLOG(@"65 within Last 6 months");
//    }else if((diff_year_of_65==0 && diff_month_of_65<=-7) || diff_year_of_65<0) { //65 yrs before last 6 months
//        PRINTLOG(@"65 before last 6 months");
//    }else if(diff_year_of_65==0 && diff_month_of_65<4){ //65 yrs within next 3 months  "+" indicate to future months
//        PRINTLOG(@"65 within next 3 months");
//    }else {
//        PRINTLOG(@"65 above next 3 months"); //65 yrs after next 3 months
//    }
 
}

-(void)effectiveDateCalcuation:(NSString *)effectiveDateString {
    
    PRINTLOG(@"EffectiveDate String :: %@",effectiveDateString);
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
    [dateFormatter setDateFormat:@"MM/dd/yyyy"];
    [dateFormatter setTimeZone:[NSTimeZone timeZoneWithName:@"EST"]];
    
    NSDate *effectiveDate = [dateFormatter dateFromString:effectiveDateString];
    
    NSString *dateStrValue = [dateFormatter stringFromDate:[NSDate date]];
    
    PRINTLOG(@"current est date string ::%@\n",dateStrValue);
    
    NSDate *getEstDateValue = [dateFormatter dateFromString:dateStrValue];
    
    PRINTLOG(@"current est date :: %@\n",getEstDateValue);
    
    
    NSDateComponents* dateComponents = [[NSCalendar currentCalendar]
                                        components:NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay
                                        fromDate:getEstDateValue
                                        toDate:effectiveDate
                                        options:0];

    effectiveDate_year = [dateComponents year];
    effectiveDate_month = [dateComponents month];
    effectiveDate_day = [dateComponents day];
    
    
    PRINTLOG(@"part b year :: %ld",(long)effectiveDate_year);
    PRINTLOG(@"part b month :: %ld",(long)effectiveDate_month);
    PRINTLOG(@"part b day :: %ld",(long)effectiveDate_day);
    
    //Based on Components month -> - indicate before last 6 months ( compare Effective Date from current Date )
//    if(effectiveDate_year==0 && (effectiveDate_month<=0 && effectiveDate_month>=-6)) { // within Last 6 months
//        PRINTLOG(@"Part B within Last 6  months");
//    }else if((effectiveDate_year==0 && effectiveDate_month<=-7) || effectiveDate_year<0) { // before last 6 months
//        PRINTLOG(@"Part B before Last 6  months");
//    }else if(effectiveDate_year==0 && effectiveDate_month<4){   // next 3 months
//        PRINTLOG(@"part B within next 3 months");
//    }else {     // above next 3 months
//        PRINTLOG(@"Part B after next 3 months");
//    }
    
    
}

@end
