//
//  DataEncryptor.m
//  BCBS Medicare Enrolment App
//
//  Created by CSS Admin on 8/22/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "DataEncryptor.h"

@implementation DataEncryptor

/*
+(void)getEncryptData:(id)dataString{
    
    NSLog(@"before encrypt ::%@",dataString);
     NSError *error = nil;
    NSString *password = @"mypassword";
    
    //convert NSString to NSData
    NSData* data = [dataString dataUsingEncoding:NSUTF8StringEncoding];
    
    
//    NSData *ciphertext = [RNCryptor encryptData:data password:password];
    
   NSData *cipherData = [RNCryptor encryptData:<#(NSData * _Nonnull)#> password:<#(NSString * _Nonnull)#>]
   
    NSLog(@"Get Encrypted String ::%@",ciphertext);
    
    [self getDecryptData:ciphertext];
    
    
    
    
    
}

+(void)getDecryptData:(id)encryptedData{
    
    NSString *password = @"Secret password";
    // Decryption
    NSError *error = nil;
    NSData *plaintext = [RNCryptor decryptData:encryptedData password:password error:&error];
    if (error != nil) {
        NSLog(@"ERROR:%@", error);
        return;
    }
    
    NSString *decryptString = [[NSString alloc] initWithData:plaintext
                                                    encoding:NSUTF8StringEncoding];
    NSLog(@"DecryptString ::%@",decryptString);
    
    
}
 
 */

@end
