//
//  BasePlanValidator.m
//  BCBS Medicare Enrolment App
//
//  Created by Dheena on 27/05/19.
//  Copyright © 2019 CSS Corp. All rights reserved.
//

#import "BasePlanValidator.h"


@implementation BasePlanValidator


//@synthesize planTitle;

@synthesize compareDate, withDate;


static DateValidator greaterThanDateValidator;
static DateValidator lessThanDateValidator;
static DateValidator lessThanSixMonthValidator;
static DateValidator noValidator;

+ (DateValidator)GreaterThanDateValidator{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        greaterThanDateValidator = ^bool(BasePlanValidator *validator, NSDate *effectiveDate){
            PRINTLOG(@"eDate:%@ > startDate:%@", validator.compareDate, (validator.withDate == nil)? effectiveDate:validator.withDate);
            
            if([validator.compareDate compare:(validator.withDate == nil)? effectiveDate:validator.withDate] == NSOrderedDescending)
                return true;
            
            return false;
            
        };
    });
    return greaterThanDateValidator;
}

+ (DateValidator)LessThanDateValidator{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        lessThanDateValidator = ^bool(BasePlanValidator *validator, NSDate *effectiveDate){
            PRINTLOG(@"eDate:%@ < endDate:%@", validator.compareDate, (validator.withDate == nil)? effectiveDate:validator.withDate);
            if([validator.compareDate compare:(validator.withDate == nil)? effectiveDate:validator.withDate] == NSOrderedAscending)
                return true;
            
            return false;
            
        };
    });
    return lessThanDateValidator;
}

+ (DateValidator)LessThanSixMonthValidator{
    PRINTLOG(@"six");
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        
        lessThanSixMonthValidator = ^bool(BasePlanValidator *validator, NSDate *effectiveDate){
            PRINTLOG(@"six block");
            NSCalendar *calender = [NSCalendar currentCalendar];
            
            NSDateComponents *components = [[NSDateComponents alloc] init];
            components.day = 0;
            components.month = 6;
            components.year = 0;
            components.hour = 24;
            
            NSDate *sixMonthDate = [calender dateByAddingComponents:components toDate:effectiveDate options:0];
            
//            NSDate *sixMonthDate = [calender dateByAddingUnit:NSCalendarUnitMonth value:6 toDate:effectiveDate options:0];
            //            NSRange currentRange = [calender rangeOfUnit:NSCalendarUnitDay inUnit:NSCalendarUnitMonth forDate:sixMonthDate];
            components = [calender components: NSCalendarUnitYear | NSCalendarUnitMonth |  NSCalendarUnitDay fromDate:sixMonthDate];
            
            [components setDay:1];
            sixMonthDate = [[NSCalendar currentCalendar] dateFromComponents:components];
            PRINTLOG(@"Today:%@ < sDate:%@", validator.compareDate, sixMonthDate);
            if([validator.compareDate compare:sixMonthDate] == NSOrderedAscending) {
                PRINTLOG(@"Today:%@ < sixMonthDate:%@", validator.compareDate, sixMonthDate);
                return true;
            }
            
            return false;
            
        };
    });
    return lessThanSixMonthValidator;
}
+ (DateValidator)NoValidator{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        noValidator = ^bool(BasePlanValidator *validator, NSDate *effectiveDate){
            return true;
        };
    });
    return noValidator;
}

-(id)    initWithValidator:(DateValidatorType)operator compareDate:(NSDate *)compareDate  withDate:(NSDate *)withDate{
    switch (operator) {
        case DATE_GREATER_THAN_VALIDATOR:
            self.operator = BasePlanValidator.GreaterThanDateValidator;
            //            NSLog(@"greater than");
            break;
        case DATE_LESSER_THAN_VALIDATOR:
            self.operator = BasePlanValidator.LessThanDateValidator;
            //            NSLog(@"lesser than");
            break;
        case DATE_SIX_MONTH_VALIDATOR:
            self.operator = BasePlanValidator.LessThanSixMonthValidator;
            break;
            
        default:
            self.operator = BasePlanValidator.NoValidator;
            break;
    }
    
    self.compareDate = compareDate;
    self.withDate = withDate;
    
    self.lastItem = self;
    
    return self;
    
}

-(id)addValidator:(DateValidatorType)operator compareDate:(NSDate *)compareDate withDate:(NSDate *)withDate{
    self.next = [[BasePlanValidator alloc]initWithValidator:operator compareDate:compareDate withDate:withDate];
    //    self.next = self.lastItem;
    return self.next;
}

-(BOOL)validate:(NSDate *)partBEffectiveDate{
    BasePlanValidator *currentItem = self;
    while (currentItem != nil) {
        PRINTLOG(@"validate");
        if(!currentItem.operator(currentItem, partBEffectiveDate))
            return false;
        currentItem = currentItem.next;
    }
    return true;
}

@end


