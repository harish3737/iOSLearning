//
//  HealthViewController.m
//  BCBS Medicare Enrolment App
//
//  Created by CSS Corp on 03/06/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "HealthViewController.h"
#import "AppConfig.h"
#import "ScopeBaseViewController.h"
#define REDCOLOR [UIColor colorWithRed:(240.0/255.0) green:(108.0/255.0) blue:(108.0/255.0) alpha:1.0f]
#define TEXTCOLOR [UIColor colorWithRed:(153.0/255.0) green:(153.0/255.0) blue:(153.0/255.0) alpha:1.0f]
#define BORDERCOLOR [UIColor colorWithRed:(204.0/255.0) green:(204.0/255.0) blue:(204.0/255.0) alpha:1.0f].CGColor

@interface HealthViewController ()

@end

@implementation HealthViewController
@synthesize contentLabel;

- (void)viewDidLoad {
    [super viewDidLoad];
	
    _titleString.text = [NSString stringWithFormat:@"%@ %@ - \n%@",[AppConfig enrollYear],[LanguageCentral languageSelectedString:[[AppConfig currentPlanDictionary] objectForKey:@"PlanTitle"]],[LanguageCentral languageSelectedString:[[[AppConfig currentPlanDictionary] objectForKey:NSStringFromClass([self class])]objectForKey:@"title"]]];
    
//    _spanishButton.validatorString = @"MandatoryValidator";
//    _largerPrintButton.validatorString =@"MandatoryValidator";
    _spanishButton.groupName = @"PREFERENCE";
    _largerPrintButton.groupName = @"PREFERENCE";
    
    
    if([[AppConfig currentPlan] isEqualToString:@"DSNP"]){
        
        [self.sharedataObj setForwardNextButtonTitle:@"Next"];
        [self.sharedataObj setNextProgressIndex:2];
        
        [self.sharedataObj setPreviousNextButtonTitle:@"Continue_to_authorization"];
        [self.sharedataObj setBackProgressIndex:2];
    }else {
        
        [self.sharedataObj setForwardNextButtonTitle:@"Continue_to_authorization"];
        [self.sharedataObj setNextProgressIndex:3];
        
        if([[AppConfig currentPlan] isEqualToString:@"PDP"]||[[AppConfig currentPlan] isEqualToString:@"MAPD"]){
            [self.sharedataObj setPreviousNextButtonTitle:@"continue_to_attestation"];
            [self.sharedataObj setBackProgressIndex:3];
        }else {
            [self.sharedataObj setPreviousNextButtonTitle:@"Continue_to_authorization"];
            [self.sharedataObj setBackProgressIndex:3];
        }
        
    }
    
    self.contentLabel.localizationKey = (([[AppConfig enrollYear] isEqualToString:@"2019"] ||[[AppConfig enrollYear] isEqualToString:@"2020"]))?@"PLEASE_SELECT_ONE_2019":@"PLEASE_SELECT_ONE";
   
    
    // Do any additional setup after loading the view.
}

-(void)viewWillAppear:(BOOL)animated {
    
    [ScopeBaseViewController populateCurrentItemValue];
    [self loadBackData];
    [super viewWillAppear:animated];
}

-(void)loadNextPage {

    
	if([_spanishButton buttonSelected]){
		
		[AppConfig fillJSONDictionary:@"data:read_and_answer:communications_preference:preference" value:@"Spanish"];
	}else if([_largerPrintButton buttonSelected]){
		[AppConfig fillJSONDictionary:@"data:read_and_answer:communications_preference:preference" value:@"Large Print"];
		
	}else {
		[AppConfig fillJSONDictionary:@"data:read_and_answer:communications_preference:preference" value:@""];
	}
    
    NSMutableString *companyPlan = [NSMutableString stringWithFormat:@"%@ %@",[AppConfig getValueFromXpath:[AppConfig tempCurrentPlanJSONDictionary] : @"tempJSON:data:other_health_insurance:plan_company"],[AppConfig getValueFromXpath:[AppConfig tempCurrentPlanJSONDictionary] : @"tempJSON:data:other_health_insurance:plan_name"]];
    
    
    NSMutableString *companyPolicy = [NSMutableString stringWithFormat:@"%@ %@",[AppConfig getValueFromXpath:[AppConfig tempCurrentPlanJSONDictionary] : @"tempJSON:data:other_health_insurance:policy_company"],[AppConfig getValueFromXpath:[AppConfig tempCurrentPlanJSONDictionary] : @"tempJSON:data:other_health_insurance:policy_name"]];
    
    
    [AppConfig fillJSONDictionary:@"data:other_health_insurance:what_company" value:companyPlan];
    
    [AppConfig fillJSONDictionary:@"data:other_health_insurance:what_kind_of_policy" value:companyPolicy];
    
    
    NSString *getValue = [AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] : @"data:persons_age_50_64:continuation_was_available_to_you"];
    
    if([getValue isEqualToString:@"Yes"]){
        [AppConfig fillJSONDictionary:@"data:persons_age_50_64:continuation_was_available_to_you" value:@"No"];
    }else {
        [AppConfig fillJSONDictionary:@"data:persons_age_50_64:continuation_was_available_to_you" value:@"Yes"];
    }
}

-(void)loadBackData {
    
    
    if([[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:read_and_answer:communications_preference:preference"] isEqualToString:@"Spanish"]){
        
        [_spanishButton setRadioButtonSelected:YES];
    }else if([[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:read_and_answer:communications_preference:preference"] isEqualToString:@"Large Print"]){
        [_largerPrintButton setRadioButtonSelected:YES];
    }else {
        
    }
}
//-(BOOL)validateVC {
//    
//    BOOL hasError = NO;
//    if([_largerPrintButton buttonSelected] || [_spanishButton buttonSelected])
//    {
//        hasError = NO;
//    }
//    else
//    {
//         contentLabel.textColor = REDCOLOR;
//        _largerPrintButton.layer.borderColor = BORDERCOLOR;
//        _spanishButton.layer.borderColor = BORDERCOLOR;
//        hasError = YES;
//    }
//    return hasError;
//}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
