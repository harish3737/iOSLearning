//
//  SubmissionViewController.h
//  BCBS Medicare Enrolment App
//
//  Created by CSS Corp on 08/06/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>
#import "GAIHelper.h"

@interface SubmissionViewController : UIBaseContainerViewController<UIAlertViewDelegate>
@property (weak, nonatomic) IBOutlet UILabel *messageContent;
@property (weak, nonatomic) IBOutlet UILabel *pdpConfirmationNumberLabel;
@property (weak, nonatomic) IBOutlet UILabel *spConfirmationNumberLabel;
@property (weak, nonatomic) IBOutlet ValidatorLabel *pdpTitleLabel;
@property (weak, nonatomic) IBOutlet ValidatorLabel *spTitleLabel;

@property (strong, nonatomic) IBOutlet ValidatorLabel *titleString;
@property (strong, nonatomic) IBOutlet UIView *firstView;

@property (strong, nonatomic) IBOutlet UIView *secondView;

@property (strong, nonatomic) IBOutlet UITextView *responseTextView;

@property (strong,nonatomic) NSMutableString *textViewString;
@property (strong,nonatomic) NSMutableDictionary *responseDict;
@property (strong,nonatomic) NSMutableArray *responseArray;

@property (strong, nonatomic) IBOutlet ValidatorLabel *disclaimerMsgLabel;

@end
