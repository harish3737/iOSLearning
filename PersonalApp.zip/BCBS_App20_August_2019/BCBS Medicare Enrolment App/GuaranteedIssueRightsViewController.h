//
//  GuaranteedIssueRightsViewController.h
//  BCBS Medicare Enrolment App
//
//  Created by CSS CORP on 22/06/18.
//  Copyright © 2018 CSS Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>

@interface GuaranteedIssueRightsViewController : UIBaseContainerViewController

@property (strong, nonatomic) IBOutlet ValidatorLabel *titleString;
//svk added change localization 05/08
@property (strong, nonatomic) IBOutlet ValidatorLabel *medicareBlueSupplement;

@property (strong, nonatomic) IBOutlet ValidatorLabel *medicareBlueSupplement1;


@end
