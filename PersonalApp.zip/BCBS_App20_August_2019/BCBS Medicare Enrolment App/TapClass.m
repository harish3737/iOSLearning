

//
//  TapClass.m
//  GestureSample
//
//  Created by Ganesh on 19/07/16.
//  Copyright © 2016 CSS. All rights reserved.
//

#import "TapClass.h"
#import "AppConfig.h"
#import "DashboardBaseViewController.h"
#import <CacheLib/CacheLib.h>


static NSTimer *idleTimer,*alertTimer;
static NSTimeInterval maxIdleTime,maxAlertTime;

static TapClass *_sharedMySingleton = nil;

@implementation TapClass
@synthesize alertController,timeOutAlert,userAlert,bgSessionAlert;
//{
//    //UIAlertView *timeOutAlert,*userAlert; 
//    
////    UIAlertController *alertController,*timeOutAlert,*userAlert;
//}

-(id)init {
    self = [super init];
    _sharedMySingleton = self;
 return self; 
}

+(instancetype)sharedInstance {
    
    @synchronized([TapClass class]) {
        if (!_sharedMySingleton)
            _sharedMySingleton = [[self alloc] init];
        return _sharedMySingleton;
    }
    return nil;
}

// get touch event from window,viewcontroller,view & also entire application
- (void)sendEvent:(UIEvent *)event {
	[super sendEvent:event];
        // Only want to reset the timer on a Began touch or an Ended touch, to reduce the number of timer resets.
	NSSet *allTouches = [event allTouches];
	if ([allTouches count] > 0) {
        
//        PRINTLOG(@"send event all touches");
		// allTouches count only ever seems to be 1, so anyObject works here.
		UITouchPhase phase = ((UITouch *)[allTouches anyObject]).phase;
		if (phase == UITouchPhaseBegan || phase == UITouchPhaseEnded)
			[self resetIdleTimer];
	}
}


// Initiating the idle timer & start timer
- (void)resetIdleTimer {
//    PRINTLOG(@"reset Idle timer");
    
    if([AppConfig getUserLoginStatus]){
		
		if (idleTimer) {
			[idleTimer invalidate];
		}
//        PRINTLOG(@"Timer Set on LAST TOUCH");
//        maxIdleTime = 270;  //time in seconds .. 4min 30 sec
        
        //original code
//        maxIdleTime = 150;  //time in seconds .. 2min 30 sec
        
        //update code for background session timer
        maxIdleTime = 1;  //time in seconds
    _remainingTime = LOGOUT_TIMER; // time in seconds .. 4min 30 sec
		idleTimer = [NSTimer scheduledTimerWithTimeInterval:maxIdleTime target:self selector:@selector(idleTimerExceeded) userInfo:nil repeats:YES];
        [[NSRunLoop mainRunLoop] addTimer:idleTimer forMode:NSRunLoopCommonModes];
    
    }
	
}

//method for when the timer is exceeded
- (void)idleTimerExceeded {

//     PRINTLOG(@"Timer idleTimerExceeded -- %d",_remainingTime);
	
	//	alertTimer = [NSTimer scheduledTimerWithTimeInterval:maxAlertTime target:self selector:@selector(closeAlert) userInfo:nil repeats:NO];
	
    _remainingTime = _remainingTime-1;
    
    if(_remainingTime>0){
        
        return;
    }
	
    [idleTimer invalidate];
    
    // to dismiss the plan restriction alert popup
    id basevcMainRoot = [[[UIApplication sharedApplication]keyWindow]rootViewController];
    id vcAlertVC = [basevcMainRoot visibleViewController];
    
    if([vcAlertVC isKindOfClass:[UIAlertController class]]){
        
        if([vcAlertVC view].tag == 100 || [vcAlertVC view].tag == 200){
            [vcAlertVC dismissViewControllerAnimated:YES completion:nil];
        }
    }
    
	timeOutAlert = [UIAlertController alertControllerWithTitle:@"TimeOut Alert"
														  message:@"Your Session going to expire" preferredStyle:UIAlertControllerStyleAlert];
	
	UIAlertAction *okAction = [UIAlertAction
							   actionWithTitle:NSLocalizedString(@"Extend my session", @"OK action")
							   style:UIAlertActionStyleDefault
							   handler:^(UIAlertAction *action)
							   {
								   //								   [self closeAlert];
								   [self resetIdleTimer];
                                   PRINTLOG(@"OK action");
							   }];
	
	[timeOutAlert addAction:okAction];
	
	id basevc = [[[UIApplication sharedApplication]keyWindow]rootViewController];
	id vc = [basevc visibleViewController];
	if([vc isKindOfClass:[UIPopOverContentViewController class]]){
		[vc dismissViewControllerAnimated:YES completion:nil];
	}
	
	[basevc presentViewController:timeOutAlert animated:YES completion:nil];
	
	dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(30.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
		
		[timeOutAlert dismissViewControllerAnimated:YES completion:^{
			
			
			userAlert = [UIAlertController alertControllerWithTitle:@"Logout"
															message:@"Your Session has expired" preferredStyle:UIAlertControllerStyleAlert];
			
			
			[basevc presentViewController:userAlert animated:YES completion:nil];
			
			
			
			dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
				
				[userAlert dismissViewControllerAnimated:YES completion:^{
					
					[self logoutAction];
					
				}];
				
			});
			
		}];
		
	});
	
}

-(void)sessionLogoutFromAppDelegate {
    
     PRINTLOG(@"Session Logout Timer idleTimerExceeded -- %d",_remainingTime);
    
    if([AppConfig getUserLoginStatus]){
        
        // disable the user interaction for whole screen or UI
        [[UIApplication sharedApplication] beginIgnoringInteractionEvents];
        
        [idleTimer invalidate];
        
        bgSessionAlert = [UIAlertController alertControllerWithTitle:@"Session Expire Alert"
                                                           message:@"Your Session going to expire" preferredStyle:UIAlertControllerStyleAlert];
        
        
        [self logoutAlertPopup];
    }else {
        PRINTLOG(@"invalidate timer logout");
        _remainingTime = 0;
          [idleTimer invalidate];
        idleTimer = nil;
        // enable the user interaction for whole screen or UI
        [[UIApplication sharedApplication] endIgnoringInteractionEvents];
    }
    
    
}

-(void)disableTimeOutAlertView {
    PRINTLOG(@"disabletimeOut alert view ");
    
    [timeOutAlert dismissViewControllerAnimated:YES completion:nil];
    timeOutAlert = nil;
    
    [bgSessionAlert dismissViewControllerAnimated:YES completion:nil];
    bgSessionAlert = nil;
    
    [idleTimer invalidate];
    idleTimer = nil;
}

-(void)logoutAlertPopup {
    
    PRINTLOG(@"logout alert popup ");
    
    id basevc = [[[UIApplication sharedApplication]keyWindow]rootViewController];
    id vc = [basevc visibleViewController];
    if([vc isKindOfClass:[UIPopOverContentViewController class]]){
        [vc dismissViewControllerAnimated:YES completion:nil];
    }
    
    [basevc presentViewController:bgSessionAlert animated:YES completion:nil];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(10.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        
        [bgSessionAlert dismissViewControllerAnimated:YES completion:^{
            
            
            userAlert = [UIAlertController alertControllerWithTitle:@"Logout"
                                                            message:@"Your Session has expired" preferredStyle:UIAlertControllerStyleAlert];
            
            
            [basevc presentViewController:userAlert animated:YES completion:nil];
            
            
            
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                
                [userAlert dismissViewControllerAnimated:YES completion:^{
                    
                    [self logoutAction];
                    
                }];
                
            });
            
        }];
        
    });
}

-(void)logoutAction{
	
    _remainingTime = 0;
	if([AppConfig getNetworkStatus]){
		
		//[userAlert dismissWithClickedButtonIndex:-1 animated:YES];
		
		__block DashboardBaseViewController *weakSelf = self;
		
		Callback *cacheCallback = [[Callback alloc]initWithCallbacks: ^(id response,id operation,id handler){
            
			
			NSError *jsonError;
			NSData *objectData = [response dataUsingEncoding:NSUTF8StringEncoding];
			NSMutableDictionary *jsonData = [NSJSONSerialization JSONObjectWithData:objectData
                                                                options:NSJSONReadingMutableContainers
																			  error:&jsonError];
			[AppConfig setUserLoggedIn:NO];
            PRINTLOG(@"Timer Logout Response ::%@",jsonData);
			[handler logoutSuccessAction];
			
			
		}:^(id response,id operation,id handler){
            PRINTLOG(@"Timer logout Response Failed ::\n%@",response);
            [handler stopTimerInvalidate];
			[handler errorMessageAlert:@"Error" message:[[AppConfig ErrorResponseJSONSerialization:response]objectAtIndex:0]];
			
		}:weakSelf];
		
		
		Cache *cache = [[Cache alloc]init];
		[cache setService: [[WebServiceWrapper alloc] init]];
		[cache settimeoutInMin:1.0];
		
		[cache registerTask:LOGOUT_URL :@"NoData" :cacheCallback :NO_CACHE];
		[cache setHeaders:LOGOUT_URL  :@"NoData" :[AppConfig headerList]];
		[cache execute : LOGOUT_URL :@"NoData"];
		
	}else{
		
		[self errorMessageAlert:@"INFO" message:@"The Internet connection appears to be offline."];
            [TapClass disableTimer];
	}
	
}

-(void)logoutSuccessAction {
    
    // enable the user interaction for whole screen or UI
    [[UIApplication sharedApplication] endIgnoringInteractionEvents];
	
    [AppConfig stopAnimatingGif];
	[Validator ValidationDone];
	[AppConfig resetAppConfig];
	[UINavigationQueue clearNavigationQueue:-1];
	
	CATransition* transition = [CATransition animation];
	transition.duration = 0.25f;
	transition.type = kCATransitionFade;
	transition.subtype = kCATransitionFromTop;
	
	id baseVC= [UIApplication sharedApplication].keyWindow.rootViewController;
	[[baseVC view].layer addAnimation:transition forKey:kCATransition];
	[baseVC popToRootViewControllerAnimated:NO];
	
	[TapClass disableTimer];
}

-(void)stopTimerInvalidate {
    
    // enable the user interaction for whole screen or UI
    [[UIApplication sharedApplication] endIgnoringInteractionEvents];
    
    [idleTimer invalidate];
}

+(void) disableTimer{
	
    // enable the user interaction for whole screen or UI
    [[UIApplication sharedApplication] endIgnoringInteractionEvents];
    
     PRINTLOG(@"Timer disable");
	[idleTimer invalidate];
}

-(void)errorMessageAlert:(NSString *)title message:(NSString *)message {
	
    // enable the user interaction for whole screen or UI
    [[UIApplication sharedApplication] endIgnoringInteractionEvents];
    
    NSString *localizeTitle = [LanguageCentral languageSelectedString:title];
    NSString *titleString = (localizeTitle.length>0)?localizeTitle:title;
    
    
    NSString *localizeMessage = [LanguageCentral languageSelectedString:message];
    NSString *msgString = (localizeMessage.length>0)?localizeMessage:message;

    
	alertController = [UIAlertController alertControllerWithTitle:titleString
														  message:msgString preferredStyle:UIAlertControllerStyleAlert];
	
	
	
	UIAlertAction *okAction = [UIAlertAction
							   actionWithTitle:NSLocalizedString(@"OK", @"OK action")
							   style:UIAlertActionStyleDefault
							   handler:^(UIAlertAction *action)
							   {
                                   PRINTLOG(@"OK action");
							   }];
	
	[alertController addAction:okAction];
	[[[[UIApplication sharedApplication]keyWindow]rootViewController] presentViewController:alertController animated:YES completion:nil];
}






@end
