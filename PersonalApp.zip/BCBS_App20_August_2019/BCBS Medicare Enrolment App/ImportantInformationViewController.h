//
//  ImportantInformationViewController.h
//  BCBS Medicare Enrolment App
//
//  Created by CSS Corp on 31/08/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>

@interface ImportantInformationViewController : UIBaseContainerViewController

@property (strong, nonatomic) IBOutlet ValidatorTextView *staticContent;
@property (strong, nonatomic) IBOutlet UILabel *titleString;

@end
