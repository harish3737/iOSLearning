//
//  ContentCollectionViewCell.m
//  CustomCollectionLayout
//
//  Created by CSS Corp on 22/04/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "ContentCollectionViewCell.h"

@implementation ContentCollectionViewCell

- (void)awakeFromNib {
    // Initialization code
}

@end
