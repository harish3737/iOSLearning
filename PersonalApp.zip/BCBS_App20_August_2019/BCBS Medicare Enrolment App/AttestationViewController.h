//
//  AttestationViewController.h
//  BCBS Medicare Enrolment App
//
//  Created by CSS Corp on 03/06/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>

@interface AttestationViewController : UIBaseContainerViewController

@property (strong, nonatomic) IBOutlet ValidatorTextView *attestationTextView;

@property (strong, nonatomic) IBOutlet ValidatorLabel *pleaseReadLabel;

@property (strong, nonatomic) IBOutlet ValidatorTextField *signatureTextField;
@property (strong, nonatomic) IBOutlet UICheckBoxWithButton *checkboxBtnView;
@property (strong, nonatomic) IBOutlet UIDropDown *dateView;
@property (strong, nonatomic) IBOutlet UICheckBoxWithButton *checkboxBtnView2;

@property (strong, nonatomic) IBOutlet UIView *view1;
@property (weak, nonatomic) IBOutlet ValidatorLabel *signatureTitleLabel;

@property (strong, nonatomic) IBOutlet ValidatorLabel *titleString;

@property (weak, nonatomic) IBOutlet ValidatorLabel *authorizeCertifyLabel;
@property (weak, nonatomic) IBOutlet ValidatorLabel *replacementNoticeLabel;

@end
