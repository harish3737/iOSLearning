//
//  SupplementNoticeViewController.m
//  BCBS Medicare Enrolment App
//
//  Created by Ganesh on 04/08/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "SupplementNoticeViewController.h"
#import "AppConfig.h"
#import "ScopeBaseViewController.h"

#define DETAILTEXTCOLOR [UIColor colorWithRed:(102.0/255.0) green:(102.0/255.0) blue:(102.0/255.0) alpha:1.0f]
static id headItem;
@interface SupplementNoticeViewController (){
    

     UIRadioButton *radioBtn1;
     UIRadioButton *radioBtn2;
    UIRadioButton *radioBtn3;
    UIRadioButton *radioBtn4;
    UIRadioButton *radioBtn5;
    UIRadioButton *radioBtn6;
    
    UIMultiLingualButton *multiLingualBtn1;
    UIMultiLingualButton *multiLingualBtn2;
    UIMultiLingualButton *multiLingualBtn3;
    UIMultiLingualButton *multiLingualBtn4;
    UIMultiLingualButton *multiLingualBtn5;
    UIMultiLingualButton *multiLingualBtn6;
}

@end

@implementation SupplementNoticeViewController
@synthesize dateView;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
	
//        [Validator ValidationDone];
    
    _titleString.text = [NSString stringWithFormat:@"%@ %@ - \n%@",[AppConfig enrollYear],[LanguageCentral languageSelectedString:[[AppConfig currentPlanDictionary] objectForKey:@"PlanTitle"]],[LanguageCentral languageSelectedString:[[[AppConfig currentPlanDictionary] objectForKey:NSStringFromClass([self class])]objectForKey:@"title"]]];
    
     if([[AppConfig currentPlan] containsString:@"Supplement"]){
         
         [self.sharedataObj setForwardNextButtonTitle:@"Preview"];
         [self.sharedataObj setNextProgressIndex:5];
         
     }else {
         [self.sharedataObj setForwardNextButtonTitle:@"Submit_application"];
         [self.sharedataObj setNextProgressIndex:5];
     }
    
    [self.sharedataObj setPreviousNextButtonTitle:@"Next"];
    [self.sharedataObj setBackProgressIndex:5];
	
 [UIRenderer renderPlist:self plist:[NSString stringWithFormat:@"%@NoticeForm%@",[AppConfig currentPlan],[AppConfig enrollYear]]];
    
	dateView.dropDownImageView.hidden = YES;
	NSDate *todayDate = [NSDate date];
	NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
	dateFormatter.dateFormat = @"MM/dd/yyyy";
	[self.dateView setTitleString:[dateFormatter stringFromDate:todayDate]];
    [self.dateView setValueString:[dateFormatter stringFromDate:todayDate]];
    self.dateView.validatorString = @"MandatoryValidator";
    headItem = [Validator headItem];
    

	if([[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"]){
       
    }else {
        [AppConfig fillJSONDictionary:@"data:notice:reviewed_and_understood" value:@"Yes"];
    }
    
    //vrl added
    self.agentSignatureLabel.localizationKey = @"AGENT_BROKER_SIGNATURE";
    

    self.applicantSignatureLabel.localizationKey = @"APPLICANT_SIGNATURE";

    self.applicantDateView.dropDownImageView.hidden = YES;
    NSDate *applicanttodayDate = [NSDate date];
    NSDateFormatter *applicantdateFormatter = [[NSDateFormatter alloc]init];
    applicantdateFormatter.dateFormat = @"MM/dd/yyyy";
    [self.applicantDateView setTitleString:[applicantdateFormatter stringFromDate:applicanttodayDate]];
    [self.applicantDateView setValueString:[applicantdateFormatter stringFromDate:applicanttodayDate]];
    self.applicantDateView.validatorString = @"MandatoryValidator";
//    headItem = [Validator headItem];
    
    self.applicantSignatureTextField.validatorString = @"AlphabetValidator";
    self.agentSignatureTextField.validatorString = @"AlphabetValidator";
    
    //vrl added
    if([[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"]){
        self.agentDateLabel.hidden = NO;
        self.dateView.hidden = NO;
        self.saveNoticeLabel.localizationKey = @"SAVE_THE_NOTICE_65_OVER_2019";
        self.accordingApplicationLabel.localizationKey = @"ACCORDING_TO_YOUR_APPLICATION_65_OVER_2019";
        self.statementApplicantLabel.localizationKey = @"STATEMENT_TO_APPLICANT_65_OVER_2019";
        self.reviewInsuranceLabel.localizationKey = @"WE_REVIEWED_YOUR_CURRENT_MEDICAL_65_OVER_2019";
         self.applicantDateView.dropDownImageView.hidden = YES;
    }else if([[AppConfig enrollYear]isEqualToString:@"2020"] &&([[AppConfig currentPlan]isEqualToString:@"Supplement Plan 50-64"] || [[AppConfig currentPlan]isEqualToString:@"SupplementUnder50"]))
    {
        self.agentDateLabel.hidden = NO;
        self.dateView.hidden = NO;
        self.saveNoticeLabel.localizationKey = @"SAVE_THE_NOTICE";
        self.accordingApplicationLabel.localizationKey = @"ACCORDING_TO_YOUR_APPLICATION";
        self.statementApplicantLabel.localizationKey = @"STATEMENT_TO_APPLICANT";
        self.reviewInsuranceLabel.localizationKey = @"WE_REVIEWED_YOUR_CURRENT_MEDICAL_2020";
        self.applicantDateView.dropDownImageView.hidden = YES;
        
    }
    else {
        self.agentDateLabel.hidden = YES;
        self.dateView.hidden = YES;
        self.saveNoticeLabel.localizationKey = @"SAVE_THE_NOTICE";
        self.accordingApplicationLabel.localizationKey = @"ACCORDING_TO_YOUR_APPLICATION";
        self.statementApplicantLabel.localizationKey = @"STATEMENT_TO_APPLICANT";
        self.reviewInsuranceLabel.localizationKey = @"WE_REVIEWED_YOUR_CURRENT_MEDICAL";
         self.applicantDateView.dropDownImageView.hidden = YES;
    }
    
    int i=0;
    while ([UIRenderer getComponentAtIndex:i]!=nil) {
        
        
        if([[UIRenderer getComponentAtIndex:i] isKindOfClass:[UIRadioButton class]] && [[[UIRenderer getComponentAtIndex:i] groupName] isEqualToString:@"ATTESTATION"]){
            
            if([[UIRenderer getComponentAtIndex:i]tag]==1){
                radioBtn1 = [UIRenderer getComponentAtIndex:i];
                multiLingualBtn1 = [[[radioBtn1 superview]subviews]objectAtIndex:1];
            }else if ([[UIRenderer getComponentAtIndex:i]tag]==2) {
                 radioBtn2 = [UIRenderer getComponentAtIndex:i];
                 multiLingualBtn2 = [[[radioBtn2 superview]subviews]objectAtIndex:1];
            }else if ([[UIRenderer getComponentAtIndex:i]tag]==3) {
                 radioBtn3 = [UIRenderer getComponentAtIndex:i];
                 multiLingualBtn3 = [[[radioBtn3 superview]subviews]objectAtIndex:1];
            }else if ([[UIRenderer getComponentAtIndex:i]tag]==4) {
                 radioBtn4 = [UIRenderer getComponentAtIndex:i];
                 multiLingualBtn4 = [[[radioBtn4 superview]subviews]objectAtIndex:1];
            }else if ([[UIRenderer getComponentAtIndex:i]tag]==5) {
                 radioBtn5 = [UIRenderer getComponentAtIndex:i];
                 multiLingualBtn5 = [[[radioBtn5 superview]subviews]objectAtIndex:1];
            }else if ([[UIRenderer getComponentAtIndex:i]tag]==6) {
                radioBtn6 = [UIRenderer getComponentAtIndex:i];
                 multiLingualBtn6 = [[[radioBtn6 superview]subviews]objectAtIndex:1];
            }else {
                
            }
        }
        i++;
    }
   
}

-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
}

-(void)viewDidAppear:(BOOL)animated {
    
    [super viewDidAppear:animated];
    
    [ScopeBaseViewController populateCurrentItemValue];
    [self loadBackData];
    
    __block SupplementNoticeViewController *weakself = self;
    radioBtn1.parent = weakself;
    radioBtn1.actionblock = ^(id address,id parent){
        [parent noticeRadioBtnSelected:address];
    };
    
    radioBtn2.parent = weakself;
    radioBtn2.actionblock = ^(id address,id parent){
        [parent noticeRadioBtnSelected:address];
    };
    
    radioBtn3.parent = weakself;
    radioBtn3.actionblock = ^(id address,id parent){
        [parent noticeRadioBtnSelected:address];
    };
    
    radioBtn4.parent = weakself;
    radioBtn4.actionblock = ^(id address,id parent){
        [parent noticeRadioBtnSelected:address];
    };
    
    radioBtn5.parent = weakself;
    radioBtn5.actionblock = ^(id address,id parent){
        [parent noticeRadioBtnSelected:address];
    };
    
    radioBtn6.parent = weakself;
    radioBtn6.actionblock = ^(id address,id parent){
        [parent noticeRadioBtnSelected:address];
    };
    
}

-(void)noticeRadioBtnSelected:(id)data {
    
    [multiLingualBtn1 setTitleColor:DETAILTEXTCOLOR forState:UIControlStateNormal];
    [multiLingualBtn2 setTitleColor:DETAILTEXTCOLOR forState:UIControlStateNormal];
    [multiLingualBtn3 setTitleColor:DETAILTEXTCOLOR forState:UIControlStateNormal];
    [multiLingualBtn4 setTitleColor:DETAILTEXTCOLOR forState:UIControlStateNormal];
    [multiLingualBtn5 setTitleColor:DETAILTEXTCOLOR forState:UIControlStateNormal];
    [multiLingualBtn6 setTitleColor:DETAILTEXTCOLOR forState:UIControlStateNormal];
    
}

-(void)loadNextPage {
    
//    UIRadioButton  *getRadioBtn ;
//
//    while (headItem!=nil) {
//
//        if([headItem isKindOfClass:[UIRadioButton class]] && [[headItem groupName] isEqualToString:@"ATTESTATION"]){
//
//            getRadioBtn = headItem;
//        }
//        headItem = [headItem getNextField];
//
//    }
//
    UIRadioButton *activeBtn = [radioBtn1 getActiveButton];
  
    
    if(activeBtn.tag!=5){
        
         [AppConfig fillJSONDictionary:@"data:notice:reason_for_disenrollment" value:@""];
    }
    
    if(activeBtn.tag!=6) {
        
         [AppConfig fillJSONDictionary:@"data:notice:other_specifications" value:@""];
    }
    
    [AppConfig fillJSONDictionary:@"data:notice:options" value:[NSString stringWithFormat:@"%ld",(long)activeBtn.tag]];
    
    [AppConfig setTempJSONDictionary:[AppConfig setValue:[AppConfig tempCurrentPlanJSONDictionary] :@"tempJSON:data:notice:agent_signature" :_agentSignatureTextField.text]];

    
      [AppConfig setTempJSONDictionary:[AppConfig setValue:[AppConfig tempCurrentPlanJSONDictionary] :@"tempJSON:data:notice:applicant_signature" :_applicantSignatureTextField.text]];
    
//    [AppConfig setTempJSONDictionary:[AppConfig setValue:[AppConfig tempCurrentPlanJSONDictionary] :@"tempJSON:data:notice:dateView" :dateView.getValueString]];
//
//      [AppConfig setTempJSONDictionary:[AppConfig setValue:[AppConfig tempCurrentPlanJSONDictionary] :@"tempJSON:data:notice:applicant_dateView" :_applicantDateView.getValueString]];
    

    if([[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"] && [[AppConfig enrollYear] isEqualToString:@"2019"]){
        
         [AppConfig fillJSONDictionary:@"data:notice:date" value:dateView.getValueString];
         [AppConfig fillJSONDictionary:@"data:notice:signature_of_agent_broker_or_other_representative" value:_agentSignatureTextField.text];
         [AppConfig fillJSONDictionary:@"data:notice:applicant_signature" value:_applicantSignatureTextField.text];
    }
    
}


-(void)loadBackData {
    
    
    int tagValue = [[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:notice:options"]intValue];
    
    if(tagValue==1){
        [radioBtn1 setRadioButtonSelected:YES];
    }else if (tagValue==2) {
       [radioBtn2 setRadioButtonSelected:YES];
    }else if (tagValue==3) {
        [radioBtn3 setRadioButtonSelected:YES];
    }else if (tagValue==4) {
      [radioBtn4 setRadioButtonSelected:YES];
    }else if (tagValue==5) {
        [radioBtn5 setRadioButtonSelected:YES];
    }else if (tagValue==6) {
        [radioBtn6 setRadioButtonSelected:YES];
    }else {
        
    }

    if(![[AppConfig getValueFromXpath:[AppConfig tempCurrentPlanJSONDictionary] :@"tempJSON:data:notice:agent_signature"] isEqualToString:@""]){
        _agentSignatureTextField.text = [AppConfig getValueFromXpath:[AppConfig tempCurrentPlanJSONDictionary] :@"tempJSON:data:notice:agent_signature"];
    }else {
         _agentSignatureTextField.text = @"";
    }
    
    
    if(![[AppConfig getValueFromXpath:[AppConfig tempCurrentPlanJSONDictionary] :@"tempJSON:data:notice:applicant_signature"] isEqualToString:@""]){
        _applicantSignatureTextField.text = [AppConfig getValueFromXpath:[AppConfig tempCurrentPlanJSONDictionary] :@"tempJSON:data:notice:applicant_signature"];
    }else {
        _applicantSignatureTextField.text = @"";
    }
    


   
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self removeAllView];
    radioBtn1 = nil;
    radioBtn2 = nil;
    radioBtn3 = nil;
    radioBtn4 = nil;
    radioBtn5 = nil;
    radioBtn6 = nil;
    
}

-(void)removeAllView {
    
    for (UIView *v in self.view.subviews) {
        [v removeFromSuperview];
    }
}

@end
