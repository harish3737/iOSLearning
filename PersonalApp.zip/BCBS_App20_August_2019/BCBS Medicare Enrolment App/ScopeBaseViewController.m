//
//  ViewController.m
//  autolayout programmatically
//
//  Created by CSS Corp on 03/05/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "ScopeBaseViewController.h"
#import "ScopeViewController.h"
#import "DashboardBaseViewController.h"
#import "DashboardViewController.h"
#import "AppConfig.h"
#import "EmailCollectionViewController.h"
#import "SubmissionViewController.h"
#import "ScopeSecondViewController.h"
#import "QuestionnaireViewController.h"

#import <CacheLib/CacheLib.h>
#import <CacheLib/WebServiceWrapper.h>
#import <CacheLib/Callback.h>
#import <CacheLib/Global.h>
#import "GAIHelper.h"

#import "PreviewViewController.h"



#define IsIOS8 (NSFoundationVersionNumber > NSFoundationVersionNumber_iOS_7_1)
static CGSize windowSize;

@interface ScopeBaseViewController (){
	
	NSUInteger i ;
	
	BOOL isLandscape;
	NSArray *titleArray;
	NSArray *centerXArray;
	NSNumber *width;
	NSNumber *centerx;
	NSMutableDictionary *metrics;
	NSUInteger currentProgressIndex;
	
	id currentItem;
	
	UIActivityIndicatorView* activity;
}




@end

@implementation ScopeBaseViewController
@synthesize progressView;

- (void)viewDidLoad {
	
	
	self.skipButton.hidden = NO;
	
	currentProgressIndex = 1;
	
	UIInterfaceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation;
	
	if(orientation == UIInterfaceOrientationLandscapeRight || orientation == UIInterfaceOrientationLandscapeLeft)
		isLandscape = YES;
	else
		isLandscape = NO;

	
	
	windowSize = [self currentScreenBoundsDependOnOrientation];
	
	width = [NSNumber new];
	centerx = [NSNumber new];
	centerXArray = [NSArray arrayWithObjects:@"-35",@"-40",@"-35",@"-30",@"-46",@"-50",@"-38", nil];
	metrics = [NSMutableDictionary new];
	titleArray =[NSArray arrayWithObjects:@"SCOPE",@"PERSONAL",@"BILLING",@"HEALTH",@"ATTESTATION",@"AUTHORIZATION",@"COMPLETE",nil];
	
	
	//[self loadMutipleProgressView:1 totalPage:titleArray.count]; //load multiple progressview
	
	[self loadMutipleProgressView:-1 totalPage:[AppConfig progressTitleArray].count];//based on plan change progress title in future
	[UINavigationQueue showInitialContainerViewcontroller:self];
	
	
	NSString * welcomeString = [NSString stringWithFormat:@"WELCOME, %@",[AppConfig getUserName]];
	
	[_welcomeLbl setText:[welcomeString uppercaseString]];
	
	[super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
	
	UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTap)];
	singleTap.cancelsTouchesInView = NO;
	[self.containerView addGestureRecognizer:singleTap];
	
}

-(void)handleTap{
	[self.view endEditing:YES];
	
}

- (void)addSubview:(UIView *)subView toView:(UIView*)parentView {
	[parentView addSubview:subView];
	
	NSDictionary * views = @{@"subView" : subView,};
	NSArray *constraints = [NSLayoutConstraint constraintsWithVisualFormat:@"H:|[subView]|"
																   options:0
																   metrics:0
																	 views:views];
	[parentView addConstraints:constraints];
	constraints = [NSLayoutConstraint constraintsWithVisualFormat:@"V:|[subView]|"
														  options:0
														  metrics:0
															views:views];
	[parentView addConstraints:constraints];
}




- (void)didReceiveMemoryWarning {
	[super didReceiveMemoryWarning];
	// Dispose of any resources that can be recreated.
}

- (IBAction)backButton:(id)sender {
	
	
	
	[Validator ValidationDone];
	
	
	if (self.currentViewController.class == ScopeViewController.class ) {
		[[NSUserDefaults standardUserDefaults]setBool:YES forKey:@"DashboardView"];
		[[NSUserDefaults standardUserDefaults]synchronize];
		
		[UINavigationQueue deleteAfter:[ScopeBaseViewController class] container:[ScopeViewController class] xib:nil];
	}
	
	self.currentViewController.willBackPage(self.currentViewController);
	[UINavigationQueue showPrevious:self];
	
	[self.nextButton setImage:[UIImage imageNamed:self.currentViewController.sharedataObj.previousNextButtonTitle] forState:UIControlStateNormal];
	
	
	[self clearProgressView];
	
	
	
	[self loadMutipleProgressView:self.currentViewController.sharedataObj.backProgressIndex totalPage:[AppConfig progressTitleArray].count]; //based on plan,change progress title in future
	
	currentProgressIndex = self.currentViewController.sharedataObj.backProgressIndex;
	
	if ([self.currentViewController respondsToSelector:NSSelectorFromString(@"titleString")]) {
		
        PRINTLOG(@"titleString   ****   %@" ,[[self.currentViewController valueForKey:@"titleString"] text]);
        
		[GAIHelper sendScreenWithName:[NSString stringWithFormat:@"%@ %@",[AppConfig enrollYear],[[[AppConfig currentPlanDictionary] objectForKey:NSStringFromClass([self.currentViewController class])]objectForKey:@"GA_Screen_Name"]]];
		
        PRINTLOG(@"GA Screen Name :::%@",[NSString stringWithFormat:@"%@ %@",[AppConfig enrollYear],[[[AppConfig currentPlanDictionary] objectForKey:NSStringFromClass([self.currentViewController class])]objectForKey:@"GA_Screen_Name"]]);
		
	}
    
//    [ScopeBaseViewController populateCurrentItemValue];
//    [self.currentViewController loadBackData];
	
	if (self.currentViewController.class == ScopeViewController.class ) {
		
		self.skipButton.hidden = NO;
		
		[AppConfig resetAppConfig];
	}
	
	//  [UINavigationQueue showPrevious:self];
	
	//    self.currentViewController.willBackPage(self.currentViewController);
	self.scrollView.contentOffset = CGPointMake(0,0);
    
    PRINTLOG(@"previous info ::%@",[UINavigationQueue getPreviousVCInfo]);
    
    if([AppConfig isFromPreview]){
        NSMutableArray *getArray = [UINavigationQueue getPreviousVCInfo];
        NSString *classNameString = [NSString stringWithFormat:@"%@",NSStringFromClass([getArray objectAtIndex:1])];
        
        if([classNameString isEqualToString:@"MedigapStaticInfoViewController"] || [classNameString isEqualToString:@"SupplementPaymentOptionViewController"]){
            self.backButton.hidden = YES;
        }else if([classNameString isEqualToString:@"SupplementNoticeViewController"]) {
            [self.nextButton setImage:[UIImage imageNamed:@"Preview"] forState:UIControlStateNormal];
        }
    }
	
}

- (IBAction)skipButtonAction:(id)sender {
	
	[Validator ValidationDone];
	
	self.currentViewController.willSkipTouch(self.currentViewController);
	
	[UINavigationQueue showNext:self];
	
	
	self.skipButton.hidden = YES;
	
	
}

#pragma mark Custom methods

- (void)startActivityIndicator
{
	//    activity = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
	//    [activity setHidesWhenStopped:TRUE];
	//    [activity setAlpha:1.0];
	//    [activity setFrame:CGRectMake((self.view.frame.origin.x+self.view.frame.size.width)/2.0, ((self.view.frame.origin.y+self.view.frame.size.height)/2.0)-100.0, activity.frame.size.width, activity.frame.size.height)];
	//    [self.view addSubview:activity];
	//    [activity startAnimating];
    
	[AppConfig showLoaderGif];
	
}

- (void)removeActivityIndicator
{
	//    [activity stopAnimating];
	//    [activity removeFromSuperview];
    
	[AppConfig stopAnimatingGif];
}


- (IBAction)logoutAction:(id)sender {
	
	if([AppConfig getNetworkStatus]){
		
		[self startActivityIndicator];
		
		__block ScopeBaseViewController *weakSelf = self;
		
		Callback *cacheCallback = [[Callback alloc]initWithCallbacks: ^(id response,id operation,id handler){
            PRINTLOG(@"scope logout Response Success ::\n%@",response);
			
			NSError *jsonError;
			NSData *objectData = [response dataUsingEncoding:NSUTF8StringEncoding];
			NSMutableDictionary *jsonData = [NSJSONSerialization JSONObjectWithData:objectData
																			options:NSJSONReadingMutableContainers
																			  error:&jsonError];
			
             [AppConfig setUserLoggedIn:NO];
            PRINTLOG(@"Logout Response ::%@",jsonData);
			[handler logoutSuccessAction];
			
			
		}:^(id response,id operation,id handler){
            PRINTLOG(@"scope logout Response Failed ::\n%@",response);
            [AppConfig errorMessageAlert:@"Error" message:[[AppConfig ErrorResponseJSONSerialization:response]objectAtIndex:0] class:self];
			[handler errorMessageAlert:@"Error" message:[[AppConfig ErrorResponseJSONSerialization:response]objectAtIndex:0]];
			PRINTLOG(@"scope logout Response Error ::\n%@",[[AppConfig ErrorResponseJSONSerialization:response]objectAtIndex:0]);
		}:weakSelf];
		
		
		Cache *cache = [[Cache alloc]init];
		[cache setService: [[WebServiceWrapper alloc] init]];
		[cache settimeoutInMin:1.0];
        
		[cache registerTask:LOGOUT_URL :@"NoData" :cacheCallback :NO_CACHE];
		[cache setHeaders:LOGOUT_URL  :@"NoData" :[AppConfig headerList]];
		[cache execute : LOGOUT_URL :@"NoData"];
		
	}else{
		
//        [self errorMessageAlert:@"INFO" message:@"The Internet connection appears to be offline."];
        [AppConfig errorMessageAlert:@"INFO" message:@"The Internet connection appears to be offline." class:self];
	}
}

-(void)logoutSuccessAction {
	
	[self removeActivityIndicator];
	[Validator ValidationDone];
	[AppConfig resetAppConfig]; 
	
	[UINavigationQueue clearNavigationQueue:-1];
	
	CATransition* transition = [CATransition animation];
	transition.duration = 0.5f;
	transition.type = kCATransitionFade;
	transition.subtype = kCATransitionFromTop;
	[self.navigationController.view.layer addAnimation:transition
												forKey:kCATransition];
	[self.navigationController popToRootViewControllerAnimated:NO];
	
}

//-(void)errorMessageAlert:(NSString *)title message:(NSString *)message {
//
//    [self removeActivityIndicator];
//
//
//    NSString *localizeTitle = [LanguageCentral languageSelectedString:title];
//    NSString *titleString = (localizeTitle.length>0)?localizeTitle:title;
//
//
//    NSString *localizeMessage = [LanguageCentral languageSelectedString:message];
//    NSString *msgString = (localizeMessage.length>0)?localizeMessage:message;
//
//
//
//    UIAlertController *alertController = [UIAlertController
//                                          alertControllerWithTitle:titleString
//                                          message:msgString
//                                          preferredStyle:UIAlertControllerStyleAlert];
//
//    UIAlertAction *okAction = [UIAlertAction
//                               actionWithTitle:NSLocalizedString(@"OK", @"OK action")
//                               style:UIAlertActionStyleDefault
//                               handler:^(UIAlertAction *action)
//                               {
//                                   PRINTLOG(@"ok action");
//                               }];
//
//    [alertController addAction:okAction];
//
//    [self presentViewController:alertController animated:YES completion:nil];
//
//}


- (IBAction)nextButton:(id)sender {
	
    if([Validator Validate]) {
		
		if(![self.currentViewController validateVC]){
			
			[self fillJSONDictionary];
			
			[Validator ValidationDone]; // headItem
			[self.currentViewController loadNextPage];
			
			if([[[UINavigationQueue getNextVCInfo]objectAtIndex:1] isEqual:[ScopeSecondViewController class]]){
				
				[self.nextButton setImage:[UIImage imageNamed:@"Next"] forState:UIControlStateNormal];
				
			}else {
                unsigned long newNumber = [UINavigationQueue getCurrentVCIndex];
                PRINTLOG(@"%lu",newNumber);
                NSArray *vcArrayInfo = [UINavigationQueue getNextVCInfo];
                PRINTLOG(@"next VC Info ::%@",vcArrayInfo);
                NSString *className = NSStringFromClass([vcArrayInfo objectAtIndex:1]);
                if([className containsString:@"PreviewViewController"]){
                     [self.nextButton setImage:[UIImage imageNamed:@"Submit_application"] forState:UIControlStateNormal];
                }else {
                     [self.nextButton setImage:[UIImage imageNamed:self.currentViewController.sharedataObj.forwardNextButtonTitle] forState:UIControlStateNormal];
                }
			}
			
			[self clearProgressView];
			
			
			[self submitDatasuccess];
			[self loadMutipleProgressView:self.currentViewController.sharedataObj.nextProgressIndex totalPage:[AppConfig progressTitleArray].count]; //based on plan, change progress title in future
			
			currentProgressIndex = self.currentViewController.sharedataObj.nextProgressIndex;
			
			// old code
			if ((self.currentViewController.class == EmailCollectionViewController.class) ||(self.currentViewController.class ==  SubmissionViewController.class)|| (self.currentViewController.class == PreviewViewController.class)){
                self.backButton.hidden=YES;
			}
			else{
				self.backButton.hidden=NO;
			}
		}else {
            PRINTLOG(@"has validation VC error");
		}
    }else {
        [self.currentViewController validateVC];
    }
}

-(void)fillJSONDictionary {
    
	JsonOperation *jsonOperation = [[JsonOperation alloc]init];
	id currentHeadItem = [Validator headItem];
	while (currentHeadItem!=nil) {
		
                PRINTLOG(@"Xpath ::%@",[currentHeadItem xPath]);
                PRINTLOG(@"nextfield ::%@",[currentHeadItem getValueString]);
		
    
		if([currentHeadItem xPath]!=nil && [AppConfig currentPlan]!=nil){
            
            if([[currentHeadItem xPath] containsString:@"tempJSON"]){
                [AppConfig setTempJSONDictionary:[AppConfig setValue:[AppConfig tempCurrentPlanJSONDictionary] :[currentHeadItem xPath] :[currentHeadItem getValueString]]];
            }else if([[currentHeadItem xPath] containsString:@"general"]){
                 [AppConfig setGeneralJSONDictioanry:[AppConfig setValue:[AppConfig generalJSONDictionary] :[currentHeadItem xPath] :[currentHeadItem getValueString]]];
            }else {
                [AppConfig setRequestJSONDictionary:[jsonOperation setValue:[AppConfig currentPlanJSONDictionary] :[currentHeadItem xPath] :[currentHeadItem getValueString]]];
            }
			
        }else if([currentHeadItem xPath]!=nil && [AppConfig currentPlan]==nil){
            
            if([[currentHeadItem xPath] containsString:@"tempJSON"]){
                [AppConfig setTempJSONDictionary:[AppConfig setValue:[AppConfig tempCurrentPlanJSONDictionary] :[currentHeadItem xPath] :[currentHeadItem getValueString]]];
            }else if([[currentHeadItem xPath] containsString:@"general"]){
                [AppConfig setGeneralJSONDictioanry:[AppConfig setValue:[AppConfig generalJSONDictionary] :[currentHeadItem xPath] :[currentHeadItem getValueString]]];
            }else {
                [AppConfig setRequestJSONDictionary:[jsonOperation setValue:[AppConfig currentPlanJSONDictionary] :[currentHeadItem xPath] :[currentHeadItem getValueString]]];
            }

            
        }
		currentHeadItem = [currentHeadItem getNextField];
		
	}
	
	if([AppConfig currentPlan]!=nil){
        PRINTLOG(@"jsonString ::%@",[jsonOperation getJsonStringByDictionary:[AppConfig currentPlanJSONDictionary]]);
    }
}


+(void)populateCurrentItemValue {
    
    JsonOperation *jsonOperation = [[JsonOperation alloc]init];
    id currentHeadItem = [Validator headItem];
    while (currentHeadItem!=nil) {
        
        if([currentHeadItem xPath]!=nil && [AppConfig currentPlan]!=nil){
            
            if([[currentHeadItem xPath] containsString:@"tempJSON"]){
               
                
                [AppConfig populateValue:[AppConfig tempCurrentPlanJSONDictionary] :currentHeadItem];
                
            }else if([[currentHeadItem xPath] containsString:@"general"]){
                
                [AppConfig populateValue:[AppConfig generalJSONDictionary] :currentHeadItem];
                
            }else {
               
                
                [AppConfig populateValue:[AppConfig currentPlanJSONDictionary] :currentHeadItem];
            }
            
        }else  if([currentHeadItem xPath]!=nil && [AppConfig currentPlan]==nil){
            
            
            if([[currentHeadItem xPath] containsString:@"tempJSON"]){
                
                [AppConfig populateValue:[AppConfig tempCurrentPlanJSONDictionary] :currentHeadItem];
                
            }else if([[currentHeadItem xPath] containsString:@"general"]){
                
                [AppConfig populateValue:[AppConfig generalJSONDictionary] :currentHeadItem];
                
            }else {
               
                
                [AppConfig populateValue:[AppConfig currentPlanJSONDictionary] :currentHeadItem];
            }
        }
        currentHeadItem = [currentHeadItem getNextField];
    }
    
    if([AppConfig currentPlan]!=nil){
        PRINTLOG(@"Populate value jsonString ::%@",[jsonOperation getJsonStringByDictionary:[AppConfig currentPlanJSONDictionary]]);
    }
    
    
}




-(void)fillJSONDictionary :(NSString *)xPath value:(id)value{
	
	JsonOperation *jsonOperation = [[JsonOperation alloc]init];
	
	[AppConfig setRequestJSONDictionary:[jsonOperation setValue:[AppConfig currentPlanJSONDictionary] :xPath :value]];
	
}


-(NSString *)getValueFromXpath:(NSDictionary *)requestDict :(NSString *)xPath{
	
	NSDictionary *tmpDict = requestDict;
	NSArray *keysArray = [xPath componentsSeparatedByString:@":"];
	
	for(int iteration=0; iteration<[keysArray count]-1; iteration++)
	{
		tmpDict = [tmpDict objectForKey:[keysArray objectAtIndex:iteration]];
	}
	
	return [tmpDict valueForKey:[keysArray objectAtIndex:[keysArray count]-1]];
	
}

-(void)submitDatasuccess{
	
    PRINTLOG(@"self.currentViewController%@",self.currentViewController);
    
    PRINTLOG(@"Push Array :: %@",[UINavigationQueue getPushlistArray]);
    unsigned long j = [[UINavigationQueue getPushlistArray]count];
    PRINTLOG(@"PUSH ARRAY INDEX %lu",j);
    	
	self.currentViewController.willLoadNext(self.currentViewController);
	
	[UINavigationQueue showNext:self];
	
	
	if ([self.currentViewController respondsToSelector:NSSelectorFromString(@"titleString")]) {
		
        PRINTLOG(@"titleString   ****   %@" ,[[self.currentViewController valueForKey:@"titleString"] text]);
		[GAIHelper sendScreenWithName:[NSString stringWithFormat:@"%@ %@",[AppConfig enrollYear],[[[AppConfig currentPlanDictionary] objectForKey:NSStringFromClass([self.currentViewController class])]objectForKey:@"GA_Screen_Name"]]];
		
        PRINTLOG(@"GA Screen Name :::%@",[NSString stringWithFormat:@"%@ %@",[AppConfig enrollYear],[[[AppConfig currentPlanDictionary] objectForKey:NSStringFromClass([self.currentViewController class])]objectForKey:@"GA_Screen_Name"]]);
	}
	
	self.skipButton.hidden = YES;
	self.scrollView.contentOffset = CGPointMake(0,0);
	
}


- (void)cycleFromViewController:(UIViewController*) currentViewController
			   toViewController:(UIViewController*) nextViewController {
	[currentViewController willMoveToParentViewController:nil];
	[self addChildViewController:nextViewController];
	[self addSubview:nextViewController.view toView:self.containerView];
	[nextViewController.view layoutIfNeeded];
	
	// set starting state of the transition
	nextViewController.view.alpha = 0;
	
	[UIView animateWithDuration:0.5
					 animations:^{
						 nextViewController.view.alpha = 1;
						 currentViewController.view.alpha = 0;
					 }
					 completion:^(BOOL finished) {
						 [currentViewController.view removeFromSuperview];
						 [currentViewController removeFromParentViewController];
						 [nextViewController didMoveToParentViewController:self];
					 }];
}

-(void)loadMutipleProgressView :(NSInteger)currentPage totalPage:(NSInteger)totalPage{
	
    PRINTLOG(@"Current Page ::%ld",currentPage);
     PRINTLOG(@"totalPage ::%ld",totalPage);
    
	if(currentPage<0){
		[self clearProgressView];
		return;
	}
	
	//    currentPage -=1;
	titleArray = [AppConfig progressTitleArray]; // based on plan,change progress title in future..
	
    PRINTLOG(@"Title Array ::%@",titleArray);
	UIImageView *tempImgView = nil;
	
	NSMutableDictionary *progressDict = nil;
	progressDict = [AppConfig progressBarInfoDict];
	
	if(isLandscape){
		width =  @([[progressDict valueForKey:@"LandscapeWidth"] integerValue]);
	}else {
		width =  @([[progressDict valueForKey:@"PortraitWidth"] integerValue]);;
	}
    PRINTLOG(@"Width ::%ld",(long)[width integerValue]);
	//    width = (isLandscape)?[NSNumber numberWithInt:133]:[NSNumber numberWithInt:90];
	
	NSUInteger j=1;
	
	
	int leadingValue = windowSize.width-((15 * totalPage) +([width integerValue] * (totalPage-1)));
    PRINTLOG(@"Leading space ::%f",((leadingValue)/2.0));
	
	NSNumber *leadingSpace = [NSNumber numberWithDouble:(leadingValue/2.0)];
	
	metrics  = [NSMutableDictionary dictionaryWithObjectsAndKeys:width,@"width",leadingSpace,@"leading",nil];
	
	//    tempImgView.image = [UIImage imageNamed:@"selected-line"];
	tempImgView.image = [UIImage imageNamed:[progressDict objectForKey:@"selected-line"]];
	
	UIImageView *roundImage = [[UIImageView alloc]init];
	
	[progressView addSubview:roundImage];
	[roundImage setTranslatesAutoresizingMaskIntoConstraints:NO];
	
	
	UIImageView *nonSelectedLineImage = [[UIImageView alloc]init];
	
	[progressView addSubview:nonSelectedLineImage];
	[nonSelectedLineImage setTranslatesAutoresizingMaskIntoConstraints:NO];
	
	
	UILabel *textLabel = [[UILabel alloc]init];
	textLabel.text = [titleArray objectAtIndex:0];
	textLabel.font = [UIFont fontWithName:@"Helvetica Bold" size:12.0];
	textLabel.textColor = [UIColor colorWithRed:0/255.0 green:82.0/255.0 blue:155.0/255.0 alpha:1.0];
	textLabel.numberOfLines = 1;
	textLabel.adjustsFontSizeToFitWidth = YES;
	textLabel.textAlignment = NSTextAlignmentCenter;
	textLabel.minimumScaleFactor = 1.0;
	
	
	NSNumber *firstIndex =[NSNumber numberWithDouble:-((textLabel.intrinsicContentSize.width/2.0)+8)];
	[metrics setObject:firstIndex forKey:@"CenterX"];
	
	[progressView addSubview:textLabel];
	
	[textLabel setTranslatesAutoresizingMaskIntoConstraints:NO];
	
	
	
	[progressView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[roundImage(15)]-[textLabel(25)]-10-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(roundImage,textLabel)]];
	
	
	roundImage.image = [UIImage imageNamed:@"selected-circle"];
	nonSelectedLineImage.image= [UIImage imageNamed:[progressDict objectForKey:@"non-selected-line"]];

	
	[progressView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-leading-[roundImage(15)]-0-[nonSelectedLineImage(width)]" options:0 metrics:metrics views:NSDictionaryOfVariableBindings(roundImage,nonSelectedLineImage)]];
	
	
	[progressView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:[roundImage]-CenterX-[textLabel(>=50)]" options:NSLayoutFormatAlignAllCenterY metrics:metrics views:NSDictionaryOfVariableBindings(roundImage,textLabel)]];
	
	[progressView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-30-[roundImage(15)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(roundImage)]];
	//
	[progressView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-35-[nonSelectedLineImage(3)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(nonSelectedLineImage)]];
	
	tempImgView = nonSelectedLineImage;
	tempImgView.image = [UIImage imageNamed:[progressDict objectForKey:@"selected-line"]];
	
	for ( ;(j<=currentPage-1&&j!=totalPage-1);j++) {
		
		metrics  = [NSMutableDictionary dictionaryWithObjectsAndKeys:width,@"width",nil];
		
		tempImgView.image = [UIImage imageNamed:[progressDict objectForKey:@"selected-line"]];
		
		UIImageView *roundImage = [[UIImageView alloc]init];
		
		[progressView addSubview:roundImage];
		[roundImage setTranslatesAutoresizingMaskIntoConstraints:NO];
		
		
		UIImageView *nonSelectedLineImage = [[UIImageView alloc]init];
		
		[progressView addSubview:nonSelectedLineImage];
		[nonSelectedLineImage setTranslatesAutoresizingMaskIntoConstraints:NO];
		
		
		UILabel *textLabel = [[UILabel alloc]init];
		textLabel.text = [titleArray objectAtIndex:j];
		textLabel.font = [UIFont fontWithName:@"Helvetica Bold" size:12.0];
		textLabel.textColor = [UIColor colorWithRed:0/255.0 green:82.0/255.0 blue:155.0/255.0 alpha:1.0];
		textLabel.numberOfLines = 1;
		textLabel.adjustsFontSizeToFitWidth = YES;
		textLabel.textAlignment = NSTextAlignmentCenter;
		textLabel.minimumScaleFactor = 1.0;
		
		
		NSNumber *secondIndex =[NSNumber numberWithDouble:-((textLabel.intrinsicContentSize.width/2.0)+5)];
		[metrics setObject:secondIndex forKey:@"CenterX"];
		
		[progressView addSubview:textLabel];
		
		[textLabel setTranslatesAutoresizingMaskIntoConstraints:NO];
		
		[progressView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[roundImage(15)]-[textLabel(25)]-10-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(roundImage,textLabel)]];
		
		
		roundImage.image = [UIImage imageNamed:@"selected-circle"];
		nonSelectedLineImage.image= [UIImage imageNamed:[progressDict objectForKey:@"non-selected-line"]];
		
		
		//        if(j==0){
		//
		//            [progressView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-50-[roundImage(15)]-0-[nonSelectedLineImage(width)]" options:0 metrics:metrics views:NSDictionaryOfVariableBindings(roundImage,nonSelectedLineImage)]];
		//
		//        }else {
		[progressView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:[tempImgView(width)]-0-[roundImage(15)]-0-[nonSelectedLineImage(width)]->=20-|" options:0 metrics:metrics views:NSDictionaryOfVariableBindings(nonSelectedLineImage,tempImgView,roundImage)]];
		//        }
		
		[progressView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:[roundImage]-CenterX-[textLabel(>=50)]" options:NSLayoutFormatAlignAllCenterY metrics:metrics views:NSDictionaryOfVariableBindings(roundImage,textLabel)]];
		
		[progressView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-30-[roundImage(15)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(roundImage)]];
		//
		[progressView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-35-[nonSelectedLineImage(3)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(nonSelectedLineImage)]];
		
		tempImgView = nonSelectedLineImage;
		tempImgView.image = [UIImage imageNamed:[progressDict objectForKey:@"selected-line"]];
	}
	
	
	j=currentPage;
	
	for (;j<totalPage-1;j++) {
		
		
		metrics  = [NSMutableDictionary dictionaryWithObjectsAndKeys:width,@"width",nil];
		
		
		UIImageView *roundImage = [[UIImageView alloc]init];
		
		[progressView addSubview:roundImage];
		[roundImage setTranslatesAutoresizingMaskIntoConstraints:NO];
		
		
		UIImageView *nonSelectedLineImage = [[UIImageView alloc]init];
		
		[progressView addSubview:nonSelectedLineImage];
		[nonSelectedLineImage setTranslatesAutoresizingMaskIntoConstraints:NO];
		
		
		UILabel *textLabel = [[UILabel alloc]init];
		textLabel.text = [titleArray objectAtIndex:j];
		textLabel.font = [UIFont fontWithName:@"Helvetica Bold" size:12.0];
		textLabel.textColor = [UIColor colorWithRed:153.0/255.0 green:153.0/255.0 blue:153.0/255.0 alpha:1.0];
		textLabel.numberOfLines = 1;
		textLabel.adjustsFontSizeToFitWidth = YES;
		textLabel.textAlignment = NSTextAlignmentCenter;
		textLabel.minimumScaleFactor = 1.0;
		
		NSNumber *thirdIndex =[NSNumber numberWithDouble:-((textLabel.intrinsicContentSize.width/2.0)+5)];
		[metrics setObject:thirdIndex forKey:@"CenterX"];
		
		[progressView addSubview:textLabel];
		
		[textLabel setTranslatesAutoresizingMaskIntoConstraints:NO];
		
		[progressView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[roundImage(15)]-[textLabel(25)]-10-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(roundImage,textLabel)]];
		
		tempImgView.image = [UIImage imageNamed:[progressDict objectForKey:@"non-selected-line"]];
		
		
		roundImage.image = [UIImage imageNamed:@"non-selected-circle"];
		nonSelectedLineImage.image= [UIImage imageNamed:[progressDict objectForKey:@"non-selected-line"]];
		
		[progressView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:[tempImgView(width)]-0-[roundImage(15)]-0-[nonSelectedLineImage(width)]->=20-|" options:0 metrics:metrics views:NSDictionaryOfVariableBindings(nonSelectedLineImage,tempImgView,roundImage)]];
		
		[progressView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:[roundImage]-CenterX-[textLabel(>=50)]" options:NSLayoutFormatAlignAllCenterY metrics:metrics views:NSDictionaryOfVariableBindings(roundImage,textLabel)]];
		
		
		[progressView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-30-[roundImage(15)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(roundImage)]];
		//
		[progressView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-35-[nonSelectedLineImage(3)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(nonSelectedLineImage)]];
		tempImgView = nonSelectedLineImage;
		
	}
	
	if(totalPage == titleArray.count){
		
		
		
		metrics  = [NSMutableDictionary dictionaryWithObjectsAndKeys:width,@"width",nil];
		
		UIImageView *roundImage = [[UIImageView alloc]init];
		
		[progressView addSubview:roundImage];
		[roundImage setTranslatesAutoresizingMaskIntoConstraints:NO];
		
		
		UILabel *textLabel = [[UILabel alloc]init];
		textLabel.text = [titleArray objectAtIndex:(totalPage-1)];
		textLabel.font = [UIFont fontWithName:@"Helvetica Bold" size:12.0];
		
		textLabel.numberOfLines = 1;
		textLabel.adjustsFontSizeToFitWidth = YES;
		textLabel.textAlignment = NSTextAlignmentCenter;
		textLabel.minimumScaleFactor = 1.0;
		
		NSNumber *fourthIndex =[NSNumber numberWithDouble:-((textLabel.intrinsicContentSize.width/2.0)+3)];
		[metrics setObject:fourthIndex forKey:@"CenterX"];
		[progressView addSubview:textLabel];
		
		[textLabel setTranslatesAutoresizingMaskIntoConstraints:NO];
		
		
		if(currentPage==titleArray.count){
			textLabel.textColor = [UIColor colorWithRed:0/255.0 green:82.0/255.0 blue:155.0/255.0 alpha:1.0];
			tempImgView.image = [UIImage imageNamed:[progressDict objectForKey:@"selected-line"]];
			roundImage.image = [UIImage imageNamed:@"selected-circle"];
		}else {
			textLabel.textColor = [UIColor colorWithRed:153.0/255.0 green:153.0/255.0 blue:153.0/255.0 alpha:1.0];
			tempImgView.image =[UIImage imageNamed:[progressDict objectForKey:@"non-selected-line"]];
			roundImage.image = [UIImage imageNamed:@"non-selected-circle"];
		}
		
		[progressView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:[tempImgView(width)]-0-[roundImage(15)]-75@550-|" options:0 metrics:metrics views:NSDictionaryOfVariableBindings(tempImgView,roundImage)]]; //55
		
		[progressView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:[roundImage]-CenterX-[textLabel(>=50)]" options:NSLayoutFormatAlignAllCenterY metrics:metrics views:NSDictionaryOfVariableBindings(roundImage,textLabel)]];
		[progressView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-30-[roundImage(15)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(roundImage)]];
		
		[progressView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[roundImage(15)]-[textLabel(25)]-10-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(roundImage,textLabel)]];
	}
	
	
	[progressView setNeedsUpdateConstraints];
	[progressView layoutIfNeeded];
	
	
}

-(CGSize)currentScreenBoundsDependOnOrientation
{
	CGRect screenBounds = [UIScreen mainScreen].bounds ;
	
	if(IsIOS8){
		return screenBounds.size ;
	}
	CGFloat screenwidth = CGRectGetWidth(screenBounds)  ;
	CGFloat screenheight = CGRectGetHeight(screenBounds) ;
	UIInterfaceOrientation interfaceOrientation = [UIApplication sharedApplication].statusBarOrientation;
	
	if(UIInterfaceOrientationIsPortrait(interfaceOrientation)){
		screenBounds.size = CGSizeMake(screenwidth, screenheight);
	}else if(UIInterfaceOrientationIsLandscape(interfaceOrientation)){
		screenBounds.size = CGSizeMake(screenheight, screenwidth);
	}
	return screenBounds.size ;
}




-(void)viewWillLayoutSubviews {
	
	[super viewWillLayoutSubviews];
	//    [progressView updateConstraints];
}

-(void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration{
	
//    PRINTLOG(@"Rotate");
	
	//    if (toInterfaceOrientation == UIInterfaceOrientationPortrait || toInterfaceOrientation == UIInterfaceOrientationPortraitUpsideDown) {
	//        //Code
	//        //PRINTLOG(@"Another portrait");
	//        isLandscape = NO;
	//        [self clearProgressView];
	//        [self loadMutipleProgressView:1 totalPage:6];
	//
	//    }
	//    else if (toInterfaceOrientation == UIInterfaceOrientationLandscapeRight||toInterfaceOrientation == UIInterfaceOrientationLandscapeLeft) {
	//        //Code
	//        //PRINTLOG(@"Another landscape");
	//        isLandscape = YES;
	//    }
	
}

-(void)clearProgressView {
	
	for(id subviewcontent in progressView.subviews){
		
		[subviewcontent removeFromSuperview];
	}
    PRINTLOG(@"final subview Array ::%@",progressView.subviews);
}

-(BOOL)shouldAutorotate {
	return YES;
}

-(void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration {
	
    PRINTLOG(@"orient :%ld",(long)[UIDevice currentDevice].orientation);
    PRINTLOG(@"current ProgressIndex ::%lu",(unsigned long)currentProgressIndex);
	windowSize = [self currentScreenBoundsDependOnOrientation];
	if (toInterfaceOrientation == UIInterfaceOrientationPortrait || toInterfaceOrientation == UIInterfaceOrientationPortraitUpsideDown) {
		//Code
        PRINTLOG(@"Another portrait");
		isLandscape = NO;
		[self clearProgressView];
		
		[self loadMutipleProgressView:currentProgressIndex totalPage:[AppConfig progressTitleArray].count]; // based on plan,change progress title in future
		
	}
	else if (toInterfaceOrientation == UIInterfaceOrientationLandscapeRight||toInterfaceOrientation == UIInterfaceOrientationLandscapeLeft) {
		//Code
        PRINTLOG(@"Another landscape");
		isLandscape = YES;
		[self clearProgressView];
		
		[self loadMutipleProgressView:currentProgressIndex totalPage:[AppConfig progressTitleArray].count]; // based on plan,change progres title in future
	}
	
    PRINTLOG(@"isLandscape ::%d",isLandscape);
	[progressView updateConstraints];
	[progressView layoutIfNeeded];
}









@end
