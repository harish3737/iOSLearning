//
//  SupplementPlanViewController.m
//  BCBS Medicare Enrolment App
//
//  Created by CSS Corp on 08/06/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "SupplementPlanViewController.h"
#import "AppDelegate.h"
#import "AppConfig.h"
#import "ScopeBaseViewController.h"
#import "UIImage+animatedGIF.h"
#import "BasePlanValidator.h"


#define PLAN_UNDER_50_MINAGE 1
#define PLAN_UNDER_50_MAXAGE 50

#define PLAN_50_64_MINAGE 50
#define PLAN_50_64_MAXAGE 64

#define PLAN_ABOVE_65_BETWEEN_64_69_MINAGE 65
#define PLAN_ABOVE_65_BETWEEN_64_69_MAXAGE 69

#define PLAN_ABOVE_65_BETWEEN_70_74_MINAGE 70
#define PLAN_ABOVE_65_BETWEEN_70_74_MAXAGE 74

#define PLAN_ABOVE_65_BETWEEN_75_79_MINAGE 75
#define PLAN_ABOVE_65_BETWEEN_75_79_MAXAGE 79

#define PLAN_ABOVE_65_GREATER_THAN_80_MINAGE 80
#define PLAN_ABOVE_65_GREATER_THAN_80_MAXAGE 80

#define TEXT_COLOR [UIColor colorWithRed:153.0/255.0 green:153.0/255.0 blue:153.0/255.0 alpha:1.0]
#define BORDER_COLOR [UIColor colorWithRed:(204.0/255.0) green:(204.0/255.0) blue:(204.0/255.0) alpha:1.0f]
#define RED_COLOR [UIColor colorWithRed:(240/255.f) green:(108/255.f) blue:(108/255.f) alpha:1.0]


static AgeValidator medigap_Under_50_Validator;
static AgeValidator medigap_50_64_Validator;
static AgeValidator medigap_Above_65_Validator;

static NSMutableDictionary *ageValidatorDict;
static NSMutableDictionary *planMonthDictionary;
static NSInteger currentMonth;
static NSInteger currentYear;
static NSInteger currentDay;
static NSInteger enrollYear;
static NSInteger month_of_65;
static NSInteger year_of_65;
static NSInteger day_of_65;


static NSMutableArray *emptyArray;



@interface SupplementPlanViewController (){
    NSMutableArray *effectiveDateArray;
    float age;
    NSInteger attainedYear,attainMonth,presentYear,cacheYear;
    float ageOnDecember;
    
    Cache *cache;
    

    UIImageView *loader;
    UIView *currentBaseView;
    
}
@property (nonatomic,strong)DBHelper *dbHelper;
@property (nonatomic,strong)NSMutableArray *planEnrollArray;
@property (nonatomic,strong)NSMutableArray *getPlanArray;
@property (nonatomic,strong)NSMutableArray *otherPlanEffectiveDateArray;
@property (nonatomic)BOOL isFromBackAction;

@property (nonatomic) NSMutableDictionary *planValidators; //anitha added

@property (nonatomic,strong) NSMutableArray *getCurrentPlanArray;
@end

@implementation SupplementPlanViewController
@synthesize planEnrollArray,planEnrolView,birthdayView,effectiveDateView;
@synthesize getPlanArray;
@synthesize birthdateLabel,planEnrollLabel,effectiveDateLabel;
@synthesize otherPlanEffectiveDateArray,isFromBackAction;
@synthesize getCurrentPlanArray;

//svk
@synthesize partALabel,partBLabel;
@synthesize partBView,partAView;
NSInteger effectiveDate_year;
NSInteger effectiveDate_month;
NSInteger effectiveDate_day;
@synthesize planEnrollLabelTop,planEnrollGenderTop,partAViewTop,partALabelTop,partBViewTop,partBLabelTop;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
   
    
    [SupplementPlanViewController currentDate];
    [SupplementPlanViewController enrollYearValue];
    getPlanArray = [[NSMutableArray alloc]init];
    
    planEnrollArray = [[NSMutableArray alloc]init];
    effectiveDateArray = [[NSMutableArray alloc]init];
    otherPlanEffectiveDateArray = [[NSMutableArray alloc]init];
    
    
    birthdayView.validatorString=@"MandatoryValidator";
    planEnrolView.validatorString=@"MandatoryValidator";
    effectiveDateView.validatorString=@"MandatoryValidator";
    partAView.validatorString=@"MandatoryValidator";
    partBView.validatorString=@"MandatoryValidator";
    planEnrolView.isPlanDropDown = YES;
    birthdayView.isBirthDate = YES;
    
    
    //svk
//    if([[AppConfig currentPlan] isEqualToString:@"Supplement Plan 65 and over"]){
//
//        partAView.validatorString=@"NoValidation";
//        partBView.validatorString=@"NoValidation";
//
//    }else{
//        partAView.validatorString=@"MandatoryValidator";
//        partBView.validatorString=@"MandatoryValidator";
//    }
    
//    partAView.validatorString=@"MandatoryValidator";
//    partBView.validatorString=@"MandatoryValidator";
    
    if([[AppConfig currentPlan] isEqualToString:@"SupplementUnder50"] || [[AppConfig currentPlan] isEqualToString:@"Supplement Plan 50-64"]){
        partAView.validatorString=@"MandatoryValidator";
        partBView.validatorString=@"MandatoryValidator";
    }
    
    partAView.isDatePickerShow = YES;
    partBView.isDatePickerShow = YES;
    partALabel.textColor = TEXT_COLOR;
    partBLabel.textColor = TEXT_COLOR;
    partAView.titleString = @"Select partA Effective Date";
    partBView.titleString = @"Select partB Effective Date";
    partAView.xPath = @"data:medicare_information:part_a_effective_date";
    partBView.xPath = @"data:medicare_information:part_b_effective_date";
    

    
    
    if([[AppConfig enrollYear] isEqualToString:@"2019"]){
        birthdateLabel.localizationKey = @"DATE_OF_BIRTH";
        self.genderLabel.localizationKey = @"SEX";
    }else {
        birthdateLabel.localizationKey = @"BIRTH_DATE";
        self.genderLabel.localizationKey = @"GENDER";
        
    }
    
    self.rateAmountLabel.text = [AppConfig rateAmount];
    
    effectiveDateArray = [[NSMutableArray alloc]init];
    
    _titleString.text = [NSString stringWithFormat:@"%@ %@ - \n%@",[AppConfig enrollYear],[LanguageCentral languageSelectedString:[[AppConfig currentPlanDictionary] objectForKey:@"PlanTitle"]],[LanguageCentral languageSelectedString:[[[AppConfig currentPlanDictionary] objectForKey:NSStringFromClass([self class])]objectForKey:@"title"]]];
    
    [self.sharedataObj setForwardNextButtonTitle:@"Continue_to_billing_active"];
    [self.sharedataObj setNextProgressIndex:1];
    
    [self.sharedataObj setPreviousNextButtonTitle:@"Next"];
    [self.sharedataObj setBackProgressIndex:1];
    
    self.effectiveDateView.delegate = self;
    self.effectiveDateView.tag = 2;
    effectiveDateView.contentArray =emptyArray;
    
    self.birthdayView.tag =0;
    self.birthdayView.delegate=self;
    
    self.planEnrolView.delegate = self;
    self.planEnrolView.tag = 1;
    
    //vrl
    self.genderView.delegate = self;
    self.genderView.tag = 3;
    
    //anitha
    self.partBView.delegate = self;
    self.partBView.tag = 4;
    
    
    [self resetPlanEnrollView];
    [self resetEffectiveDate];
    
    AppDelegate *appDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    self.dbHelper = appDelegate.appDelegateDBHelper;
    
    [planEnrolView setTitleString:@"Select a Plan"];
    [effectiveDateView setTitleString:@"Select a Date"];
    
    
    
    effectiveDateView.xPath = @"data:customer_information:effective_date";
    
    
    self.birthdayView.isDatePickerShow = YES;
    self.birthdayView.isBirthDate = YES;
    
    SupplementPlanViewController *weakSelf = self;
    
    self.willLoadNext = ^(id object){
        
        [weakSelf addCustomJsonValue];
        
    };
    
    self.willBackPage = ^(id object){
        
        [AppConfig DecrementPlanIndex];
        
    };
    
    
    static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken, ^{
        
        planMonthDictionary = [NSMutableDictionary dictionaryWithObjectsAndKeys:planEnrollArray,@"PlanList",effectiveDateArray,@"MonthForPlanC",otherPlanEffectiveDateArray,@"MonthForOtherPlans",nil];
        emptyArray = [NSMutableArray arrayWithObject:@""];
        
    });
    
    // Testing Purpose, please delete this code when Send IPA to client or QA
//  [AppConfig setIsCallRateAPI:YES];
//    NSMutableDictionary *rateParamsDict = [NSMutableDictionary dictionaryWithObjectsAndKeys:birthdayView.getValueString,@"dateofbirth",_genderView.getValueString,@"gender",@"B2280",@"coveragecode",effectiveDateView.getValueString,@"coverageeffectivedate",effectiveDateView.getValueString,@"rateeffectivedate",@"true",@"eftindicator",@"true",@"preferredindicator",@"false",@"tobaccouseindicator",nil];
//    [AppConfig setRateAPIParams:rateParamsDict];

}

-(void)viewWillAppear:(BOOL)animated {
    
    isFromBackAction = YES;
    
    //vrl added
    _genderView.xPath = @"data:customer_information:sex";
    _genderView.titleString = @"Select Gender";
    _genderView.isDatePickerShow = NO;
    _genderView.isMultipleSelection = NO;
    _genderView.contentArray = [NSMutableArray arrayWithObjects:@"MALE",@"FEMALE",nil];
    
    
    [ScopeBaseViewController populateCurrentItemValue];
    [self loadBackData];
    [super viewWillAppear:animated];
    
   
    
    if([[AppConfig enrollYear] isEqualToString:@"2019"] || [[AppConfig enrollYear] isEqualToString:@"2020"]){
        
        
        _genderView.validatorString = @"MandatoryValidator";
        
        self.subtitleLabel.localizationKey = @"PLANS_DIFFER_BY_AGE_SEX_TOBACCO";
        self.rateContentLabel.hidden = NO;
        self.rateLabel.hidden = NO;
         self.rateAmountLabel.hidden = NO;
         self.genderLabel.hidden = NO;
         self.genderView.hidden = NO;
        self.rateDisclaimerLabel.hidden = NO;
        self.rateDisclaimerLabel.localizationKey = @"RATES_DISPLAYED_DO_NO_INCLUDE_HEALTH";
        
        self.genderVerticalConstraint.constant = 20.0;
        self.planVerticalConstraint.constant = 20.0;
        self.genderLabelHeightConstraint.constant = 23.0;
        self.genderViewHeightConstraint.constant = 50.0;
        
        self.rateLabelHeightConstraint.constant = 23.0;
       self.rateContentHeightConstraint.constant = 30.0;
       self.rateAmountHeightConstraint.constant = 30.0;
       self.rateLabelVerticalConstraint.constant = 20.0;
       self.effectiveDateVerticalConstraint.constant = 20.0;
//        self.rateDisclaimerVerticalConstraint.constant = 20.0;
//        self.rateDisclaimerHeightConstraint.constant = 30.0;
        
        
        //vrl BR2.0
        //Hide As low as* & Rate disclaimer content for Horizonblue supplement Plan C for Medigap 50 & 50-64
        if([[AppConfig currentPlan] isEqualToString:@"SupplementUnder50"] || [[AppConfig currentPlan] isEqualToString:@"Supplement Plan 50-64"]) {
            
            self.rateContentLeadingConstraint.constant = 100.0;
            self.rateContentWidthConstraint.constant = 0.0;
            self.rateAmountLeadingConstraint.constant = 0.0;
            self.rateContentLabel.hidden = YES;
            self.rateDisclaimerLabel.hidden = YES;
            self.rateDisclaimerLabel.hidden = YES;
        }else {
            self.rateContentLeadingConstraint.constant = 100.0;
            self.rateContentWidthConstraint.constant = 120.0;
            self.rateAmountLeadingConstraint.constant = 10.0;
            self.rateContentLabel.hidden = NO;
            self.rateDisclaimerLabel.hidden = NO;
        }
        

    }else {
        
        _genderView.validatorString = @"NoValidation";
        self.subtitleLabel.localizationKey = @"ENTER_YOUR_BIRTHDATE";
        self.rateContentLabel.hidden = YES;
        self.rateLabel.hidden = YES;
        self.rateAmountLabel.hidden = YES;
        self.genderLabel.hidden = YES;
        self.genderView.hidden = YES;
         self.rateDisclaimerLabel.hidden = YES;
        
        self.genderVerticalConstraint.constant = 0.0;
                self.planVerticalConstraint.constant = 30.0;
        self.genderLabelHeightConstraint.constant = 0.0;
        self.genderViewHeightConstraint.constant = 0.0;
        
        self.rateLabelHeightConstraint.constant = 0.0;
        self.rateContentHeightConstraint.constant = 0.0;
        self.rateAmountHeightConstraint.constant = 0.0;
        self.rateLabelVerticalConstraint.constant = 0.0;
        self.effectiveDateVerticalConstraint.constant = 30.0;
//        self.rateDisclaimerVerticalConstraint.constant = 20.0;
//        self.rateDisclaimerHeightConstraint.constant = 30.0;
    }
}

-(BOOL)validateVC {
    
    BOOL hasError = NO;
    
    birthdayView.layer.borderWidth = 1.0f;
    planEnrolView.layer.borderWidth = 1.0f;
    effectiveDateView.layer.borderWidth = 1.0f;
    
    if(birthdayView.selectedString.length>0){
        birthdateLabel.textColor = [UIColor colorWithRed:(153/255.f) green:(153/255.f) blue:(153/255.f) alpha:1.0];
        birthdayView.layer.borderColor = [UIColor colorWithRed:(204.0/255.0) green:(204.0/255.0) blue:(204.0/255.0) alpha:1.0f].CGColor;
    }else {
        birthdateLabel.textColor = [UIColor colorWithRed:(240/255.f) green:(108/255.f) blue:(108/255.f) alpha:1.0];
        birthdayView.layer.borderColor = [UIColor colorWithRed:(240/255.f) green:(108/255.f) blue:(108/255.f) alpha:1.0].CGColor;
        birthdayView.confirmImgView.hidden = YES;
    }
    
    if(_genderView.selectedString.length>0){
        
        _genderLabel.textColor = [UIColor colorWithRed:(153/255.f) green:(153/255.f) blue:(153/255.f) alpha:1.0];
        _genderView.layer.borderColor = [UIColor colorWithRed:(204.0/255.0) green:(204.0/255.0) blue:(204.0/255.0) alpha:1.0f].CGColor;
    }else {
        _genderLabel.textColor = [UIColor colorWithRed:(240/255.f) green:(108/255.f) blue:(108/255.f) alpha:1.0];
        _genderView.layer.borderColor = [UIColor colorWithRed:(240/255.f) green:(108/255.f) blue:(108/255.f) alpha:1.0].CGColor;
        _genderView.confirmImgView.hidden = YES;
    }
    
    if(planEnrolView.selectedString.length>0){
        planEnrollLabel.textColor = [UIColor colorWithRed:(153/255.f) green:(153/255.f) blue:(153/255.f) alpha:1.0];
        planEnrolView.layer.borderColor = [UIColor colorWithRed:(204.0/255.0) green:(204.0/255.0) blue:(204.0/255.0) alpha:1.0f].CGColor;
    }else {
        planEnrollLabel.textColor = [UIColor colorWithRed:(240/255.f) green:(108/255.f) blue:(108/255.f) alpha:1.0];
        planEnrolView.layer.borderColor = [UIColor colorWithRed:(240/255.f) green:(108/255.f) blue:(108/255.f) alpha:1.0].CGColor;
        planEnrolView.confirmImgView.hidden = YES;
    }
    
    if(effectiveDateView.selectedString.length>0){
        effectiveDateLabel.textColor = [UIColor colorWithRed:(153/255.f) green:(153/255.f) blue:(153/255.f) alpha:1.0];
        effectiveDateView.layer.borderColor = [UIColor colorWithRed:(204.0/255.0) green:(204.0/255.0) blue:(204.0/255.0) alpha:1.0f].CGColor;
    }else {
        effectiveDateLabel.textColor = [UIColor colorWithRed:(240/255.f) green:(108/255.f) blue:(108/255.f) alpha:1.0];
        effectiveDateView.layer.borderColor = [UIColor colorWithRed:(240/255.f) green:(108/255.f) blue:(108/255.f) alpha:1.0].CGColor;
        effectiveDateView.confirmImgView.hidden = YES;
    }
    
    if ([[AppConfig currentPlan] containsString:@"Supplement Plan 65 and over"] || [[AppConfig currentPlan] containsString:@"SupplementUnder50"] || [[AppConfig currentPlan] containsString:@"Supplement Plan 50-64"]) {
        
        NSString *effectiveDateValue = self.partBView.selectedString;
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
        [dateFormatter setDateFormat:@"MM/dd/yyyy"];
        [dateFormatter setTimeZone:[NSTimeZone timeZoneWithName:@"EST"]]; // add timezone because we get difference in months , days.
        
        NSDate *partBDate = [dateFormatter dateFromString:effectiveDateValue];
        
        NSString *dateStrValue = [dateFormatter stringFromDate:[NSDate date]];
        
        NSDate *getEstDateValue = [dateFormatter dateFromString:dateStrValue];
        
        
        
        NSDateComponents* dateComponents = [[NSCalendar currentCalendar]
                                            components:NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay
                                            fromDate:getEstDateValue
                                            toDate:partBDate
                                            options:0];
        
        effectiveDate_year = [dateComponents year];
        effectiveDate_month = [dateComponents month];
        effectiveDate_day = [dateComponents day];
        
        if(![effectiveDateValue isEqualToString:@"Select"] && effectiveDateValue!=nil) {
            
            [self planArray:effectiveDateValue];
            // effective date greater than 3  months from current date
            if(effectiveDate_year>=0 && ((effectiveDate_month>3 && effectiveDate_day>=0) || (effectiveDate_month==3 && effectiveDate_day>0))) {
                
                
                self.partBView.confirmImgView.hidden = YES;
                
                __block SupplementPlanViewController *weakself = self;
                [AppConfig showAlertView:@"Error" message:@"The Medical Insurance (Part B) Effective Date you entered was invalid. It cannot be greater than 3 months from current date. Please select a valid Medical Insurance (Part B) Effective Date" class:weakself actionBlock:^(id data,id handler){
                    PRINTLOG(@"button pressed");
                }];
                
                return hasError = YES;
            }
        }
    }
    
    
    if(birthdayView.selectedString.length>0&&planEnrolView.selectedString.length>0 && effectiveDateView.selectedString.length>0){
        hasError = NO;
    }else {
        hasError = YES;
//        hasError = NO; // development purpose only , don't enable this when release IPA
    }
    
    return hasError;
}


-(void)addCustomJsonValue {
    
    //svk
    [AppConfig fillJSONDictionary:@"data:medicare_information:part_a_effective_date" value:partAView.selectedString];
    [AppConfig fillJSONDictionary:@"data:medicare_information:part_b_effective_date" value:partBView.selectedString];
    
    isFromBackAction = NO;
    [AppConfig fillJSONDictionary:@"data:customer_information:birth_date" value:birthdayView.selectedString];
    
    
    int index=0;
    
    if([self.planEnrolView.contentArray containsObject:self.planEnrolView.selectedString]) {
        
//        [AppConfig fillJSONDictionary:@"data:customer_information:csv_plan_name" value:self.planEnrolView.selectedString];
        index = [self.planEnrolView.contentArray indexOfObject: self.planEnrolView.selectedString];

        if(getPlanArray.count>0){
            //            [AppConfig fillJSONDictionary:@"data:customer_information:plan_name" value:[[getPlanArray objectAtIndex:index]objectAtIndex:0]];
            [AppConfig fillJSONDictionary:@"data:customer_information:csv_plan_name" value:[[getPlanArray objectAtIndex:index]objectAtIndex:2]];

            if([[AppConfig currentPlan] isEqualToString:@"Supplement Plan 65 and over"]){
                 [AppConfig fillJSONDictionary:@"data:customer_information:plan_name" value:[[getPlanArray objectAtIndex:index]objectAtIndex:2]];
            }
            PRINTLOG(@"fill plan:%@",[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:customer_information:plan_name"]);
            PRINTLOG(@"fill csv plan:%@",[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:customer_information:csv_plan_name"]);
        }
        
    } else {

        [AppConfig fillJSONDictionary:@"data:customer_information:csv_plan_name" value:@""];
    }
    
    [AppConfig fillJSONDictionary:@"data:customer_information:plan_year" value:[AppConfig enrollYear]];
    
    [AppConfig fillJSONDictionary:@"data:customer_information:effective_date" value:[effectiveDateView selectedString]];
    
    
    // store the temporary value for display rate value
    [AppConfig setTempJSONDictionary:[AppConfig setValue:[AppConfig tempCurrentPlanJSONDictionary] :@"tempJSON:data:customer_information:rate_amount" :self.rateAmountLabel.text]];
    
    [AppConfig setRateAmount:self.rateAmountLabel.text];
    
}

-(void)loadBackData {
    
    
    
    
    
    if(![[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:customer_information:birth_date"] isEqualToString:@""]){
        
        [birthdayView setValueString:[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:customer_information:birth_date"]];
        
        [self dropDownLabelText :[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:customer_information:birth_date"] tag:birthdayView.tag];
        
      
        
    }else {
        
        [birthdayView setTitleString:@"Select"];
    }
    
    if(![[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:customer_information:sex"] isEqualToString:@""]) {
        
        [_genderView setValueString:[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:customer_information:sex"]];
        
    } else {
        
        [_genderView setTitleString:@"Select Gender"];
    }
    if(![[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:medicare_information:part_a_effective_date"] isEqualToString:@""]) {

        [partAView setValueString:[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:medicare_information:part_a_effective_date"]];
    }
    else {
//            [partAView setTitleString:@"Select partA Effective Date"];
        [partAView resetTitle];
    }
    if(![[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:medicare_information:part_b_effective_date"] isEqualToString:@""]) {

        [self dropDownLabelText :[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:customer_information:part_b_effective_date"] tag:partBView.tag];
        [partBView setValueString:[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:medicare_information:part_b_effective_date"]];
        
    }
    else {
//            [partBView setTitleString:@"Select partB Effective Date"];
        [partBView resetTitle];
    }
    if(![[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:customer_information:csv_plan_name"] isEqualToString:@""]){
        [planEnrolView setValueString: [AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:customer_information:csv_plan_name"]];
        PRINTLOG(@"selected plan:%@",[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:customer_information:csv_plan_name"]);
        PRINTLOG(@"selected plan name:%@",[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:customer_information:plan_name"]);
        for(NSArray *planArray in [AppConfig medigapPlanEnrollArray]){

            if([planArray containsObject:[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:customer_information:csv_plan_name"]]){
                NSString *planEnrollString = [NSString stringWithFormat:@"%@",[planArray objectAtIndex:0]];
                PRINTLOG(@"passed plan:%@", planEnrollString);

                if ([[AppConfig currentPlan] isEqualToString:@"Supplement Plan 65 and over"]) {
                    [self planArray: birthdayView.selectedString];
                } else
                    [self planArray: partBView.selectedString];
                
                [planEnrolView setValueString:planEnrollString];
            }
        }
        
    } else {
        [planEnrolView setTitleString:@"Select a Plan"];
        planEnrolView.selectedString = @"";
        planEnrolView.contentArray = [NSMutableArray new];
        
        
        

    }
    

    
//    if(![[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:customer_information:csv_plan_name"] isEqualToString:@""]){
////        [planEnrolView setValueString: [AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:customer_information:csv_plan_name"]];
//
//        for(NSArray *planArray in [AppConfig medigapPlanEnrollArray]){
//
//            if([planArray containsObject:[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:customer_information:csv_plan_name"]]){
//                NSString *planEnrollString = [NSString stringWithFormat:@"%@",[planArray objectAtIndex:0]];
//
//
//                [planEnrolView setValueString:planEnrollString];
//            }
//        }
//        if(![[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:medicare_information:part_a_effective_date"] isEqualToString:@""])
//        {
//
//            [partAView setValueString:[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:medicare_information:part_a_effective_date"]];
//        }
//        else
//        {
////            [partAView setTitleString:@"Select partA Effective Date"];
//            [partAView resetTitle];
//        }
//
//        if(![[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:medicare_information:part_b_effective_date"] isEqualToString:@""])
//        {
//
//            [partBView setValueString:[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:medicare_information:part_b_effective_date"]];
//        }
//        else
//        {
////            [partBView setTitleString:@"Select partB Effective Date"];
//            [partBView resetTitle];
//        }
//
//
//        NSMutableArray *EnrollArray =[[NSMutableArray alloc]init];
//
//        if ([AppConfig medigapPlanEnrollArray].count>0) {
//
//            for(NSArray *arrayValues in [AppConfig medigapPlanEnrollArray]){
//
//                NSString *planString = [NSString stringWithFormat:@"%@",[arrayValues objectAtIndex:0]];
//
//                [EnrollArray addObject:planString];
//            }
//            getPlanArray = [AppConfig medigapPlanEnrollArray];
//        }else {
//            [EnrollArray addObject:@""];
//            [planEnrolView setTitleString:@"Select a Plan"];
//            planEnrolView.selectedString = @"";
//            [AppConfig setMedigapPlanEnrollArray:nil];
//        }
////        self.planEnrolView.contentArray = EnrollArray;
//
//
//    }else {
//        [planEnrolView setTitleString:@"Select a Plan"];
//        planEnrolView.selectedString = @"";
//        planEnrolView.contentArray = [NSMutableArray new];
//
//    }
    
    
    if(![[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:customer_information:effective_date"] isEqualToString:@""]){
        [effectiveDateView setValueString:[AppConfig getValueFromXpath:[AppConfig currentPlanJSONDictionary] :@"data:customer_information:effective_date"]];
        
        if([AppConfig medigapEffectiveArray]!=nil){
            effectiveDateView.contentArray = [AppConfig medigapEffectiveArray];
        }else {
            [effectiveDateView setTitleString:@"Select a Date"];
            effectiveDateView.selectedString = @"";
            effectiveDateView.contentArray = emptyArray;
            [AppConfig setmedigapEffectiveArray:nil];
        }
        
    }else {
        [effectiveDateView setTitleString:@"Select a Date"];
        effectiveDateView.selectedString = @"";
        effectiveDateView.contentArray = [NSMutableArray new];
    }
    
    //retaining the rate value when click back & next button
    NSString *getRateValue = [AppConfig getValueFromXpath:[AppConfig tempCurrentPlanJSONDictionary] :@"tempJSON:data:customer_information:rate_amount"];
    
    if([getRateValue isEqualToString:@"(null)"] || [getRateValue isEqualToString:@"-"]||[getRateValue containsString:@"null"] || getRateValue.length==0){
        self.rateAmountLabel.text = @"$0.00";
    }else {
        self.rateAmountLabel.customTextKey = @"tempJSON:data:customer_information:rate_amount";
        self.rateAmountLabel.text = (![self.rateAmountLabel.text isEqualToString:@"-"])?self.rateAmountLabel.text:@"$0.00";
    }
//    [self hideEffectiveDateDropDowns:[AppConfig getShowEffectiveDateDropDownsFor65]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void) buildPlanValidator{
    
    NSString *birthDate = birthdayView.selectedString;
    NSDateFormatter *dateFormat1 = [[NSDateFormatter alloc] init];
    [dateFormat1 setDateFormat:@"MM/dd/yyyy"];
    NSDate *birthDayDate = [dateFormat1 dateFromString:birthDate];
    PRINTLOG(@"Plan date ::%@",birthDayDate);
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDateComponents *components = [[NSDateComponents alloc] init];
    components.day = 0;
    components.month = 0;
    components.year = 65;
    components.hour = 0;
    NSDate *newDate = [calendar dateByAddingComponents:components toDate:birthDayDate options:0];
    PRINTLOG(@"newDate: %@", newDate);
    
    if(_planValidators != nil)
        [_planValidators removeAllObjects];
    else
        _planValidators = [[NSMutableDictionary alloc]init];
    
    
    
    NSDateComponents *comps = [[NSDateComponents alloc]init];
    comps.year = 2020;
    comps.month = 1;
    comps.day = 1;
    comps.hour = 12;
    
    NSCalendar *calender = [NSCalendar currentCalendar];
    NSDate *planCEndDate = [calender dateFromComponents:comps];
    comps.year = 2019;
    comps.month = 12;
    comps.day = 31;
    comps.hour = 12;
    
    NSDate *endOf2019 = [calender dateFromComponents:comps];
    
    comps.year = 2020;
    comps.month = 1;  //12
    comps.day = 1;
    comps.hour = 12;
    
    NSDate *endDate = [calender dateFromComponents:comps];
    
    comps.year = 2020;
    comps.month = 6;  //12
    comps.day = 1;
    comps.hour = 12;
    
    NSDate *end65 = [calender dateFromComponents:comps];
    
    comps.year = 2019;
    comps.month = 9;  //12
    comps.day = 30;
    comps.hour = 12;
    
    NSDate *planDStartDate = [calender dateFromComponents:comps];
    NSDate *todayDate = [NSDate date];
    PRINTLOG(@"todayDate:%@", todayDate);
    
    //
    
    BasePlanValidator *planDateValidator;
    planDateValidator = [[BasePlanValidator alloc]initWithValidator:DATE_SIX_MONTH_VALIDATOR compareDate:todayDate withDate:nil];
    [_planValidators setValue:planDateValidator forKey:@"Horizon Medicare Blue Supplement Plan C (Under 50)"];
    [planDateValidator addValidator:DATE_LESSER_THAN_VALIDATOR compareDate:todayDate withDate:end65];
    
//    planDateValidator = [[BasePlanValidator alloc]initWithValidator:DATE_GREATER_THAN_VALIDATOR compareDate:todayDate withDate:planDStartDate];
    planDateValidator = [[BasePlanValidator alloc]initWithValidator:NO_VALIDATION compareDate:nil withDate:nil];
    [_planValidators setValue:planDateValidator forKey:@"Horizon Medicare Blue Supplement Plan D (Under 50)"];
    
    //50-64
    
    planDateValidator = [[BasePlanValidator alloc]initWithValidator:DATE_SIX_MONTH_VALIDATOR compareDate:todayDate withDate:nil];
    [_planValidators setValue:planDateValidator forKey:@"Horizon Medicare Blue Supplement Plan C (50-64)"];
    [planDateValidator addValidator:DATE_LESSER_THAN_VALIDATOR compareDate:todayDate withDate:end65];
    
//    planDateValidator = [[BasePlanValidator alloc]initWithValidator:DATE_GREATER_THAN_VALIDATOR compareDate:todayDate withDate:planDStartDate];
    planDateValidator = [[BasePlanValidator alloc]initWithValidator:NO_VALIDATION compareDate:nil withDate:nil];
    [_planValidators setValue:planDateValidator forKey:@"Horizon Medicare Blue Supplement Plan D (50-64)"];
    
    //65+
    
//    if([newDate compare:endDate] == NSOrderedDescending){
//        planDateValidator = [[BasePlanValidator alloc]initWithValidator:DATE_LESSER_THAN_VALIDATOR compareDate:todayDate withDate:planCEndDate];
//        [_planValidators setValue:planDateValidator forKey:@"Horizon Medicare Blue Supplement Plan C (Over 65)"];
//        [_planValidators setValue:planDateValidator forKey:@"Horizon Medicare Blue Supplement Plan F"];
//    } else {
//        planDateValidator = [[BasePlanValidator alloc]initWithValidator:DATE_LESSER_THAN_VALIDATOR compareDate:todayDate withDate:end65];
//        [_planValidators setValue:planDateValidator forKey:@"Horizon Medicare Blue Supplement Plan C (Over 65)"];
//        [_planValidators setValue:planDateValidator forKey:@"Horizon Medicare Blue Supplement Plan F"];
//    }
    
//    if(newDate > endDate){
    if([newDate compare:endDate] == NSOrderedAscending){
        PRINTLOG(@"newData:%@ > endDate=%@",newDate, endDate);
        if([[AppConfig currentPlan]isEqualToString:@"Supplement Plan 65 and over"])
        {
        partAView.validatorString=@"NoValidation";
        partBView.validatorString=@"NoValidation";
        [self hideEffectiveDateDropDowns:YES];
        }
        planDateValidator = [[BasePlanValidator alloc]initWithValidator:DATE_LESSER_THAN_VALIDATOR compareDate:todayDate withDate:end65];
        [_planValidators setValue:planDateValidator forKey:@"Horizon Medicare Blue Supplement Plan C (Over 65)"];
        [_planValidators setValue:planDateValidator forKey:@"Horizon Medicare Blue Supplement Plan C (65 and Over)"];
        [_planValidators setValue:planDateValidator forKey:@"Horizon Medicare Blue Supplement Plan F"];
//        [planDateValidator addValidator:DATE_SIX_MONTH_VALIDATOR compareDate:todayDate withDate:nil];

    }else{
        partAView.validatorString=@"MandatoryValidator";
        partBView.validatorString=@"MandatoryValidator";
        [self hideEffectiveDateDropDowns:NO];
        planDateValidator = [[BasePlanValidator alloc]initWithValidator:DATE_LESSER_THAN_VALIDATOR compareDate:todayDate withDate:endOf2019];
        [_planValidators setValue:planDateValidator forKey:@"Horizon Medicare Blue Supplement Plan C (Over 65)"];
        [_planValidators setValue:planDateValidator forKey:@"Horizon Medicare Blue Supplement Plan C (65 and Over)"];
        [_planValidators setValue:planDateValidator forKey:@"Horizon Medicare Blue Supplement Plan F"];
    }
    //    planDateValidator = [[BasePlanValidator alloc]initWithValidator:DATE_SIX_MONTH_VALIDATOR compareDate:todayDate withDate:nil];
    //    [_planValidators setValue:planDateValidator forKey:@"Horizon Medicare Blue Supplement Plan C (Over 65)"];
    //    [planDateValidator addValidator:DATE_LESSER_THAN_VALIDATOR compareDate:planCEndDate withDate:nil];
    planDateValidator = [[BasePlanValidator alloc]initWithValidator:NO_VALIDATION compareDate:nil withDate:nil];
    [_planValidators setValue:planDateValidator forKey:@"Horizon Medicare Blue Supplement Plan A"];
    
//    planDateValidator = [[BasePlanValidator alloc]initWithValidator:DATE_GREATER_THAN_VALIDATOR compareDate:todayDate withDate:planDStartDate];
    planDateValidator = [[BasePlanValidator alloc]initWithValidator:NO_VALIDATION compareDate:nil withDate:nil];
    [_planValidators setValue:planDateValidator forKey:@"Horizon Medicare Blue Supplement Plan D (65 and Over)"];
    
    //    planDateValidator = [[BasePlanValidator alloc]initWithValidator:DATE_SIX_MONTH_VALIDATOR compareDate:todayDate withDate:nil];
    //    [_planValidators setValue:planDateValidator forKey:@"Horizon Medicare Blue Supplement Plan F"];
//    [planDateValidator addValidator:DATE_LESSER_THAN_VALIDATOR compareDate:planCEndDate withDate:nil];
    
    planDateValidator = [[BasePlanValidator alloc]initWithValidator:NO_VALIDATION compareDate:nil withDate:nil];
    [_planValidators setValue:planDateValidator forKey:@"Horizon Medicare Blue Supplement Plan G"];
    planDateValidator = [[BasePlanValidator alloc]initWithValidator:NO_VALIDATION compareDate:nil withDate:nil];
    [_planValidators setValue:planDateValidator forKey:@"Horizon Medicare Blue Supplement Plan K"];
    planDateValidator = [[BasePlanValidator alloc]initWithValidator:NO_VALIDATION compareDate:nil withDate:nil];
    [_planValidators setValue:planDateValidator forKey:@"Horizon Medicare Blue Supplement Plan N"];
    
    
}

-(void)hideEffectiveDateDropDowns:(BOOL)hide
{
    [AppConfig showEffectiveDateDropDownsFor65:hide];
    partALabel.hidden = hide;
    partAView.hidden = hide;
    partBLabel.hidden = hide;
    partBView.hidden = hide;
 
    
    if(hide==YES)
    {
      
       self.partALabelTop.constant = 0;
        self.planEnrollGenderTop.constant = 20.0;
        
        

        
        
    }else
    {
        self.planEnrollGenderTop.constant = 217.0;
        self.partALabelTop.constant = 20;

    }
    
}

-(void)dropDownLabelText:(NSString *)selectedString tag:(long)tag{
    
    
    if (tag== 0) {
        
        age = [self ageCalculation:selectedString];
        
        // BRD2.0
         [AppConfig setBirthDate:selectedString];
        
        SupplementPlanViewController *weakSelf = self;
        
        [self validateAge:[[SupplementPlanViewController AgeValidatorDictionary] valueForKey:[AppConfig currentPlan]] Data:selectedString parent:weakSelf];
        
        birthdateLabel.textColor = TEXT_COLOR;
        birthdayView.layer.borderColor = BORDER_COLOR.CGColor;
        planEnrollLabel.textColor = TEXT_COLOR;
        effectiveDateLabel.textColor = TEXT_COLOR;
        
        planEnrolView.layer.borderColor = BORDER_COLOR.CGColor;
        planEnrolView.layer.borderWidth = 1.0f;
        
        effectiveDateView.layer.borderColor = BORDER_COLOR.CGColor;
        effectiveDateView.layer.borderWidth = 1.0f;
        
        //vrl
        _genderLabel.textColor = TEXT_COLOR;
        _genderView.layer.borderColor = BORDER_COLOR.CGColor;
        _genderView.layer.borderWidth = 1.0f;
        
        [self resetPlanEnrollView];
        [self resetEffectiveDate];
        
        if(![[[planMonthDictionary objectForKey:@"PlanList"]objectAtIndex:0] isEqualToString:@""]){
            
            if ([[AppConfig currentPlan] isEqualToString:@"Supplement Plan 65 and over"]) {
                [self planArray:selectedString];
            }
            
//            self.planEnrolView.contentArray = [planMonthDictionary objectForKey:@"PlanList"];
            effectiveDateView.contentArray = emptyArray;
            
        }else {
            
            [self resetPlanEnrollView];
            [self resetEffectiveDate];
//            [self resetPartBEffectiveDate];
        }
        
    }else if(tag==1){
        
        [self resetEffectiveDate];
        if(![selectedString isEqualToString:@""]){
            
            [planEnrolView setValueString:selectedString];
            
            planEnrollLabel.textColor = TEXT_COLOR;
        
            planEnrolView.layer.borderColor = BORDER_COLOR.CGColor;
            planEnrolView.layer.borderWidth = 1.0f;
            
            
            
            if([selectedString containsString:@"Plan C"]){
                
                if(isFromBackAction && [[[planMonthDictionary objectForKey:@"MonthForPlanC"]objectAtIndex:0] isEqualToString:@""]){
                    
                    effectiveDateView.contentArray = [[AppConfig medigapPlanMetaDict]objectForKey:@"MonthForPlanC"];
                }else {
                    effectiveDateView.contentArray = [planMonthDictionary objectForKey:@"MonthForPlanC"];
                }
               
                
            }else {
                
                if(isFromBackAction && [[[planMonthDictionary objectForKey:@"MonthForOtherPlans"]objectAtIndex:0] isEqualToString:@""]){
                      effectiveDateView.contentArray = [[AppConfig medigapPlanMetaDict]objectForKey:@"MonthForOtherPlans"];
                }else {
                    effectiveDateView.contentArray = [planMonthDictionary objectForKey:@"MonthForOtherPlans"];
                }
                
                
                //vrl BR2.0
                //Hide As low as* & Rate disclaimer content for Horizonblue supplement Plan C for Medigap 50 & 50-64
                if(([[AppConfig currentPlan] isEqualToString:@"SupplementUnder50"] || [[AppConfig currentPlan] isEqualToString:@"Supplement Plan 50-64"])) {
                    
                    self.rateContentLeadingConstraint.constant = 100.0;
                    self.rateContentWidthConstraint.constant = 0.0;
                    self.rateAmountLeadingConstraint.constant = 0.0;
                    self.rateContentLabel.hidden = YES;
                    self.rateDisclaimerLabel.hidden = YES;
                }else {
                    self.rateContentLeadingConstraint.constant = 100.0;
                    self.rateContentWidthConstraint.constant = 120.0;
                    self.rateAmountLeadingConstraint.constant = 10.0;
                    self.rateContentLabel.hidden = NO;
                    self.rateDisclaimerLabel.hidden = NO;
                }
                
            }
        
        }else {
            [self resetPlanEnrollView];
            [self resetEffectiveDate];
            
        }
        
        
    }else if(tag == 2){
        
        if(![selectedString isEqualToString:@""]){
            
            [effectiveDateView setValueString:selectedString];
            [AppConfig setmedigapEffectiveArray:effectiveDateView.contentArray];
            
           
            effectiveDateLabel.textColor = TEXT_COLOR;
            
            effectiveDateView.layer.borderColor = BORDER_COLOR.CGColor;
            effectiveDateView.layer.borderWidth = 1.0f;
            
//            
//            if([[AppConfig enrollYear] isEqualToString:@"2019"]){
////                 vrl added for Rate API Logic
            
            
                [self startActivityIndicator];
                [self rateAPIWebService];
//            }
          
        }
        else {
            [self resetEffectiveDate];
        }
    }else if(tag == 3) { //vrl
        
        // reset the plan text & effective date when changed the Gender field
        [planEnrolView setTitleString:@"Select a Plan"];
        planEnrolView.selectedString = @"";
        effectiveDateView.selectedString = @"";
        [effectiveDateView setTitleString:@"Select a Date"];
        // anitha added
        if(partAView != NULL && partBView != NULL){
            partAView.selectedString = @"";
            partBView.selectedString = @"";
            [partAView setTitleString:@"Select"];
            [partBView setTitleString:@"Select"];
        }
        

        
        // reset the rate value when effective date is empty
        self.rateAmountLabel.text = @"$0.00";
        
        if(![selectedString isEqualToString:@""]){
            
            _genderLabel.textColor = TEXT_COLOR;
            _genderView.layer.borderColor = BORDER_COLOR.CGColor;
            _genderView.layer.borderWidth = 1.0f;
        }
        
    }else if(tag == 4){
        
        
      
        if (![[AppConfig currentPlan] isEqualToString:@"Supplement Plan 65 and over"]) 
            [self planArray:selectedString];
        PRINTLOG(@"plan selectedString:: %@", selectedString);
    }
        else {
        
    }
    
}

-(void)resetEffectiveDate {
    
    effectiveDateView.selectedString = @"";
    [effectiveDateView setTitleString:@"Select a Date"];
    effectiveDateView.contentArray =emptyArray;
    
    // reset the rate value when effective date is empty
     self.rateAmountLabel.text = @"$0.00";
    
}

-(void)resetPlanEnrollView{
    
    [planEnrolView setTitleString:@"Select a Plan"];
    planEnrolView.selectedString = @"";
    planEnrolView.contentArray = emptyArray;
    
}



-(NSMutableArray *)planTypeArray:(int)minAge maxAge:(int)maxAge{
    
    NSArray *valueArray ;
    if(minAge>0 && maxAge>0){
        
        NSString *queryString = [NSString stringWithFormat:@"Select Plan_Name,Monthly_Premium,CSV_Plan_Name,Coverage_Code from bcbs_medigap_plan where Min_Age_Range >= '%d' and Max_Age_Range <= '%d' and Plan_Year like '%@%%'",minAge,maxAge,[AppConfig enrollYear]];
        
        valueArray  = [self.dbHelper loadDataFromDB:queryString];
        PRINTLOG(@"valueArray:%@", valueArray);
        
        
    }else {
        
        valueArray = nil;
    }
    
    [planEnrollArray removeAllObjects];
    NSMutableArray *EnrollArray =[[NSMutableArray alloc]init];
    
    if (valueArray.count>0) {
        
        for(NSArray *arrayValues in valueArray){
            
            NSString *planString = [NSString stringWithFormat:@"%@",[arrayValues objectAtIndex:0]];
            
            [EnrollArray addObject:planString];
            self.rateAmountLabel.localizationKey = [arrayValues objectAtIndex:1];
            
        }
        getPlanArray = [valueArray copy];
        [AppConfig setMedigapPlanEnrollArray:getPlanArray];
        
    }else {
        [EnrollArray addObject:@""];
        //        effectiveDateArray = [[NSMutableArray alloc]init];
        //        [effectiveDateArray addObject:@""];
        //        effectiveDateView.contentArray = effectiveDateArray;
        //        //[getPlanArray removeAllObjects];
        //        [planEnrolView setTitleString:@"Select a Plan"];
        //        planEnrolView.selectedString = @"";
        //        effectiveDateView.selectedString = @"";
        //        [effectiveDateView setTitleString:@"Select a Date"];
        [AppConfig setMedigapPlanEnrollArray:nil];
    }
   
    planEnrollArray = EnrollArray;
    PRINTLOG(@"Plan array ::%@",planEnrollArray);
    return planEnrollArray;
    
}



-(NSMutableArray *)planArray: (NSString *)selectedString{
    
    
    
    NSString *effectivePartBDate = selectedString;
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"MM/dd/yyyy"];
    NSDate *partBDate = [dateFormat dateFromString:effectivePartBDate];
    PRINTLOG(@"Plan date ::%@",partBDate);
    

//    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
//    [dateFormatter setDateFormat:@"MM/dd/yyyy"];
//    [dateFormatter setTimeZone:[NSTimeZone timeZoneWithName:@"EST"]]; // add timezone because we get difference in months , days.
//
//    NSDate *partBDate = [dateFormatter dateFromString:effectivePartBDate];
//
//    NSString *dateStrValue = [dateFormatter stringFromDate:[NSDate date]];
//
//    NSDate *getEstDateValue = [dateFormatter dateFromString:dateStrValue];
//
//
//
//    NSDateComponents* dateComponents = [[NSCalendar currentCalendar]
//                                        components:NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay
//                                        fromDate:getEstDateValue
//                                        toDate:partBDate
//                                        options:0];
//
//    effectiveDate_year = [dateComponents year];
//    effectiveDate_month = [dateComponents month];
//    effectiveDate_day = [dateComponents day];
    
    //    NSString *birthDate = birthdayView.selectedString;
    //    NSDateFormatter *dateFormat1 = [[NSDateFormatter alloc] init];
    //    [dateFormat1 setDateFormat:@"MM/dd/yyyy"];
    //    NSDate *birthDayDate = [dateFormat1 dateFromString:birthDate];
    //    PRINTLOG(@"Plan date ::%@",birthDayDate);
    //    NSDateComponents *componentsYear = [[NSCalendar currentCalendar] components:NSCalendarUnitDay | NSCalendarUnitMonth | NSCalendarUnitYear fromDate:birthDayDate];
    //    cacheYear = [componentsYear year] + 65;
    //    PRINTLOG(@"birth date add 65 ::%ld",(long)cacheYear);
    
    
    [self buildPlanValidator];
    NSMutableArray *EnrollArray1 =[[NSMutableArray alloc]init];
    for (NSString *item in planEnrollArray) {
        PRINTLOG(@"item:%@", item);
        
        if([[_planValidators objectForKey:item] validate:partBDate])
            [EnrollArray1 addObject:item];
    }
    PRINTLOG(@"Plan array ::%@",EnrollArray1);
    self.planEnrolView.contentArray = EnrollArray1;
    return EnrollArray1;
}

-(float)ageCalculation:(NSString *)selectedString{
    
    float ageValue =0;
    int monthvalue = 0;
    
    NSString *birthDay = selectedString;
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
    [dateFormatter setDateFormat:@"MM/dd/yyyy"];
    [dateFormatter setTimeZone:[NSTimeZone timeZoneWithName:@"EST"]];
    
    NSDate *birthDate=[dateFormatter dateFromString:birthDay];
    
    NSDateComponents *componentsYear = [[NSCalendar currentCalendar] components:NSCalendarUnitDay | NSCalendarUnitMonth | NSCalendarUnitYear fromDate:birthDate];
    cacheYear = [componentsYear year];
    
    attainedYear = cacheYear + 65;
    
    attainMonth = [componentsYear month];
    
    //NSString *dob = [NSString stringWithFormat:@"%ld/%d/%d",(long)[componentsYear month],[componentsYear day],[componentsYear year]+65];
    
//    NSDate  *now = [NSDate date]; // old code because days varing due to EST daytime saving

    //handled DayTime saving for US
    NSString *nowDateStr = [dateFormatter stringFromDate:[NSDate date]];
    NSDate *now= [dateFormatter dateFromString:nowDateStr];
    
 
    
    NSDateComponents* ageComponents = [[NSCalendar currentCalendar]
                                       components:NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay
                                       fromDate:birthDate
                                       toDate:now
                                       options:0];
    ageValue = [ageComponents year];
    monthvalue = [ageComponents month];
    
    NSString *ageOnDecemberString = [NSString stringWithFormat:@"12/31/%@",[AppConfig enrollYear]];
    NSDate *ageDecDate = [dateFormatter dateFromString:ageOnDecemberString];
    
    NSTimeInterval ageOnDecSeconds = [ageDecDate timeIntervalSinceDate:birthDate];
    int decOfDays = ageOnDecSeconds/86400.0;
    
    ageOnDecember = decOfDays/365.25;
    
    
    NSTimeInterval secondsBetween = [now timeIntervalSinceDate:birthDate];
    
    int numberOfDays = secondsBetween / 86400.0;
    
    float yearRoundOFF= (numberOfDays/365.25);
    
    
    //float yearRoundOFF= roundf(numberOfDays/365.25);
    
    ageValue = yearRoundOFF;
    PRINTLOG(@"age VAlue :: %f",ageValue);

    return ageValue;
}


-(void)validateAge:(AgeValidator)validator Data:(id)dataValue parent:(id)parentValue{
    
    validator(dataValue,parentValue);
    
}

+(NSMutableDictionary *)AgeValidatorDictionary {
    
    ageValidatorDict = [NSMutableDictionary dictionaryWithObjectsAndKeys:[self medigapUnder50],@"SupplementUnder50",[self medigap50To64],@"Supplement Plan 50-64",[self medigapAbove65],@"Supplement Plan 65 and over",nil];
    
    return ageValidatorDict;
    
}

-(NSMutableDictionary *)AgeCalculatedPlanDict:(id)planList :(id)planCEffectiveArray :(id)otherPlansEffectiveArray{
    
    [planMonthDictionary setObject:planList forKey:@"PlanList"];
    [planMonthDictionary setObject:planCEffectiveArray forKey:@"MonthForPlanC"];
    [planMonthDictionary setObject:otherPlansEffectiveArray forKey:@"MonthForOtherPlans"];
    
    if(![[planList objectAtIndex:0] isEqualToString:@""] ){
        
        NSMutableDictionary *tempDict = [[NSMutableDictionary alloc]init];
        
        
        [tempDict setObject:planList forKey:@"PlanList"];
        [tempDict setObject:planCEffectiveArray forKey:@"MonthForPlanC"];
        [tempDict setObject:otherPlansEffectiveArray forKey:@"MonthForOtherPlans"];
        
        [AppConfig setmedigapPlanMetaDict:tempDict];
    }
    
    return planMonthDictionary;
}

-(void)setBoolValueForBackAction:(BOOL)isBackAction{
    
    isFromBackAction = isBackAction;
}

+(AgeValidator)medigapUnder50{
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        medigap_Under_50_Validator = ^id(id birthDate, id parent){
            
            [parent setBoolValueForBackAction:NO];
            float agevalue = [parent ageCalculation:birthDate];
            int month = (enrollYear > currentYear)?1:(currentMonth+1);
            
            if(agevalue < 49.0){
                
            }else if(agevalue>49.0 && agevalue <=49.999) {
                
            }else {
                
                return [parent AgeCalculatedPlanDict:emptyArray:emptyArray:emptyArray];
            }
            
//            return [parent AgeCalculatedPlanDict:[parent planTypeArray:PLAN_UNDER_50_MINAGE maxAge:PLAN_UNDER_50_MAXAGE] :[parent effectiveDateForPlanC:month year:enrollYear]:emptyArray];
            
            return [parent AgeCalculatedPlanDict:[parent planTypeArray:PLAN_UNDER_50_MINAGE maxAge:PLAN_UNDER_50_MAXAGE] :[parent effectiveDateForPlanC:month year:enrollYear]:[parent effectiveDateForOtherPlans:month year:enrollYear]];

        };
    });
    return medigap_Under_50_Validator;
}


+(AgeValidator)medigap50To64{
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        medigap_50_64_Validator = ^id(id birthDate, id parent){
            
            [parent setBoolValueForBackAction:NO];
            float agevalue = [parent ageCalculation:birthDate];
            
            int month = (enrollYear > currentYear)?1:(currentMonth+1);
            
             if(agevalue >=50.0 && agevalue <=64.49){//age lesser than 64 years 5 months
                
            }else {
                
                return [parent AgeCalculatedPlanDict:emptyArray:emptyArray:emptyArray];
            }
            
//            return [parent AgeCalculatedPlanDict:[parent planTypeArray:PLAN_50_64_MINAGE maxAge:PLAN_50_64_MAXAGE] :[parent effectiveDateForPlanC:month year:enrollYear]:[NSMutableArray arrayWithObject:@""]];
            
            return [parent AgeCalculatedPlanDict:[parent planTypeArray:PLAN_50_64_MINAGE maxAge:PLAN_50_64_MAXAGE] :[parent effectiveDateForPlanC:month year:enrollYear]:[parent effectiveDateForOtherPlans:month year:enrollYear]];
        };
    });
    return medigap_50_64_Validator;
}


+(AgeValidator)medigapAbove65 {
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        medigap_Above_65_Validator = ^id(id birthDate, id parent){
            
            [parent setBoolValueForBackAction:NO];
            
            float agevalue = [parent ageCalculation:birthDate];
            float minAgeValue = 0.0,maxAgeValue = 0.0;
            
            int planC_month,planC_year,otherPlan_month,otherPlan_year;
            
            [parent calculateAge65Date:birthDate];
            
            if(agevalue>=64.495 && agevalue <=69.999){
                
                minAgeValue = PLAN_ABOVE_65_BETWEEN_64_69_MINAGE;
                maxAgeValue = PLAN_ABOVE_65_BETWEEN_64_69_MAXAGE;
                
            }else if(agevalue>=70.0 && agevalue<=74.999){
                
                minAgeValue = PLAN_ABOVE_65_BETWEEN_70_74_MINAGE;
                maxAgeValue = PLAN_ABOVE_65_BETWEEN_70_74_MAXAGE;
                
            }else if(agevalue>=75.0 && agevalue<=79.999){
                
                minAgeValue = PLAN_ABOVE_65_BETWEEN_75_79_MINAGE;
                maxAgeValue = PLAN_ABOVE_65_BETWEEN_75_79_MAXAGE;
                
                
            }else if(agevalue>=80.0){
                
                minAgeValue = PLAN_ABOVE_65_GREATER_THAN_80_MINAGE;
                maxAgeValue = PLAN_ABOVE_65_GREATER_THAN_80_MAXAGE;
                
            }
            
            if(agevalue >= 64.495){ //age greater than 64 years 6 months
                
                otherPlan_year = enrollYear;
                planC_year = enrollYear;
                
                if(enrollYear>currentYear){//2017 > 2016 future enrollment
                    
                    if(enrollYear > year_of_65){ // scenario when current year is 2016, enrol year is 2017, attain year less than 2017
                        otherPlan_month = 1;
                        planC_month = 1;
                        
                    }else if(year_of_65 == enrollYear){  // 65 completed // scenario when current year is 2016, enrol year is 2017, attain year is 2017
                        
                        if(month_of_65==1){ // if birth month is Jan ,
                            otherPlan_month = 1;
                            planC_month = 1;
                        }else { // if birth month is other that Jan
                            
                            if(day_of_65 == 1){
                                otherPlan_month = month_of_65-1;
                                planC_month = 1;
                            }else if(currentDay !=1 && day_of_65 != 1){
                                otherPlan_month = month_of_65;
                                planC_month = 1;
                            }
                        }
                        
                    }else {
                        
                    }
                    
                }else if(enrollYear == currentYear){
                    
                    if(currentYear == year_of_65){ // scenario when current year is 2016, enrol year is 2016, attain year is equal to 2016
                        if(currentMonth < month_of_65){
                            
                            if(day_of_65==1){
                                otherPlan_month = month_of_65-1;
                                planC_month = currentMonth+1;
                            }else {
                                otherPlan_month = month_of_65;
                                planC_month = currentMonth+1;
                            }
                           
                        }else{
                            
                            if(currentDay== 1 && day_of_65==1) // scnerio 1 1st day of enrol & 1st day of birth date
                            {
                                otherPlan_month = month_of_65-1;
                                planC_month = currentMonth+1;

                                // date = 1
                            }else  {                           // scenerio 2, not 1st day of enrol & 1st day of birth date
                                otherPlan_month = month_of_65;
                                 planC_month = currentMonth+1;
                                // date = day_of_65
                            }
                        }
                        
                    }else if(currentYear > year_of_65) { // scenario when current year is 2016, enrol year is 2016, attain year is less than 2016
                        
                        otherPlan_month = currentMonth+1;
                        planC_month = currentMonth+1;
                        
                    }else { // Scenario when current year is 2016, enroll year is 2016, attain year is 2017
                        
                        if(day_of_65 == 1){
                            if(month_of_65==1){ // january
                                otherPlan_month = 12; // as per excel sheet
                                planC_month = 12;
                            }else {
                                return [parent AgeCalculatedPlanDict:emptyArray:emptyArray:emptyArray];
                            }
   
                        }else { // scenerio 4
                             return [parent AgeCalculatedPlanDict:emptyArray:emptyArray:emptyArray];
                        }
//
                    }
                }else {
                    return [parent AgeCalculatedPlanDict:emptyArray:emptyArray:emptyArray];
                }
            }else { // less than 64.6
                
                return [parent AgeCalculatedPlanDict:emptyArray:emptyArray:emptyArray];
            }
            return [parent AgeCalculatedPlanDict:[parent planTypeArray:minAgeValue maxAge:maxAgeValue] :[parent effectiveDateForPlanC:planC_month year:planC_year]:[parent effectiveDateForOtherPlans:otherPlan_month year:otherPlan_year]];
        };
    });
    return medigap_Above_65_Validator;
}


-(NSMutableArray *)effectiveDateForPlanC:(int)startMonth year:(int)startYear{

    
    NSMutableArray *planCDateArray = [[NSMutableArray alloc]init];
    
    int endMonth = ((startMonth+3)>12)?13:(startMonth+3);
    
    while (startMonth<endMonth ) {
        
        [planCDateArray addObject:[NSString stringWithFormat:@"%02ld/01/%d",(long)startMonth,startYear]];
        startMonth++;
       
        
    }
    
    return planCDateArray;
    
}


-(NSMutableArray *)effectiveDateForOtherPlans:(int)startMonth year:(int)startYear{
    
    
    NSMutableArray *otherPlanDateArray = [[NSMutableArray alloc]init];
    
    int endMonth = ((startMonth+3)>12)?13:(startMonth+3);
    
    while (startMonth<endMonth ) {
        
        [otherPlanDateArray addObject:[NSString stringWithFormat:@"%02ld/01/%d",(long)startMonth,startYear]];
        startMonth++;
        
        
    }

    return otherPlanDateArray;
    
}

-(void)calculateAge65Date :(NSString *)birthDateString{
    
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
    [dateFormatter setDateFormat:@"MM/dd/yyyy"];
    [dateFormatter setTimeZone:[NSTimeZone timeZoneWithName:@"EST"]];
   
    
    //convert string to date
    NSString *birthDay = birthDateString;
    NSDate *birthDate=[dateFormatter dateFromString:birthDay];
    
    //calculate 65 age year & month
    NSDateComponents *futureComponent = [[NSDateComponents alloc]init];
    [futureComponent setYear:65];
    
    NSDate *date_65 = [[NSCalendar currentCalendar]dateByAddingComponents:futureComponent toDate:birthDate options:0];
    
    NSDateComponents* components = [[NSCalendar currentCalendar] components:NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay fromDate:date_65];// Get necessary date components
    
    month_of_65 = [components month];
    year_of_65 = [components year];
    day_of_65 = [components day];
}


+(void)currentDate{
    
    // newly handled for current date
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
    [dateFormatter setDateFormat:@"MM/dd/yyyy"];
    [dateFormatter setTimeZone:[NSTimeZone timeZoneWithName:@"EST"]];
    
    NSString *nowDateStr = [dateFormatter stringFromDate:[NSDate date]];
    NSDate *currentDate = [dateFormatter dateFromString:nowDateStr];
    //
    
    // old code
//    NSDateComponents *components = [[NSCalendar currentCalendar] components:NSCalendarUnitMonth | NSCalendarUnitYear |NSCalendarUnitDay fromDate:[NSDate date]];
    
     NSDateComponents *components = [[NSCalendar currentCalendar] components:NSCalendarUnitMonth | NSCalendarUnitYear |NSCalendarUnitDay fromDate:currentDate];
    
    currentYear = [components year];
    currentMonth = [components month];
   
    currentDay = [components day];
}

+(void)enrollYearValue {
    
    NSString *enrollYearString = [AppConfig enrollYear];
    enrollYear = [enrollYearString intValue];
    
}

#pragma mark Rate WebService

-(void)rateAPIWebService {
    
    __block SupplementPlanViewController *weakSelf = self;
    
    Callback *cacheCallback = [[Callback alloc]initWithCallbacks: ^(id response,id operation,id handler){
        
        PRINTLOG(@"supplement Response :: %@",response);
        NSError *jsonError;
        NSData *objectData = [response dataUsingEncoding:NSUTF8StringEncoding];
        NSMutableArray *jsonData = [NSJSONSerialization JSONObjectWithData:objectData options:NSJSONReadingMutableContainers error:&jsonError];
       
        [handler displayRateText:jsonData];
        
    }:^(id response,id operation,id handler){
         PRINTLOG(@"supplement Response :: %@",response);
        if([response isKindOfClass:[NSDictionary class]]){
            [handler errorMessageAlert:@"Error" message:@""];
        }else {
            [handler errorMessageAlert:@"Error" message:[[AppConfig ErrorResponseJSONSerialization:response]objectAtIndex:0]];
        }
     
        [handler displayRateText:response];
        
        
    }: weakSelf];
    

//    if([self.planEnrolView.contentArray containsObject:self.planEnrolView.selectedString]) {
    if(![self.planEnrolView.selectedString isEqualToString: @""]) {
        NSInteger index = [self.planEnrolView.contentArray indexOfObject: self.planEnrolView.selectedString];
        
        getCurrentPlanArray = [getPlanArray objectAtIndex:index];
        PRINTLOG(@"Index: %u, Plan: %@", index, self.planEnrolView.selectedString);
    }
    
    

    NSString *rateEffectiveDate = [self rateEffectiveDate:1 year:enrollYear];
    
    /*
     Same as 50 , 50-64, 65+
     "eftindicator": false,
     
     "preferredindicator": true,
     
     "tobaccouseindicator": false
     */
    
    
    NSMutableDictionary *rateParamsDict = [NSMutableDictionary dictionaryWithObjectsAndKeys:birthdayView.getValueString,@"dateofbirth",_genderView.getValueString,@"gender",[getCurrentPlanArray objectAtIndex:3],@"coveragecode",effectiveDateView.getValueString,@"coverageeffectivedate",rateEffectiveDate,@"rateeffectivedate",@"false",@"eftindicator",@"true",@"preferredindicator",@"false",@"tobaccouseindicator",nil];
    PRINTLOG(@"rate param%@", rateParamsDict);
    
//     NSMutableDictionary *rateParamsDict = [NSMutableDictionary dictionaryWithObjectsAndKeys:birthdayView.getValueString,@"dateofbirth",_genderView.getValueString,@"gender",@"B2280",@"coveragecode",effectiveDateView.getValueString,@"coverageeffectivedate",effectiveDateView.getValueString,@"rateeffectivedate",@"true",@"eftindicator",@"true",@"preferredindicator",@"false",@"tobaccouseindicator",nil];
    
    
    //local webservice
//    if([[AppConfig currentPlan]isEqualToString:@"SupplementUnder50"]){
//       [rateParamsDict setValue:@"05/17/2006" forKey:@"dateofbirth"];
//    }else if ([[AppConfig currentPlan]isEqualToString:@"Supplement Plan 50-64"]){
//        [rateParamsDict setValue:@"05/20/1967" forKey:@"dateofbirth"];
//   }else{
//        [rateParamsDict setValue:@"Male" forKey:@"gender"];
//        [rateParamsDict setValue:@"05/17/1948" forKey:@"dateofbirth"];
//    }
    ////end
    
    
    
    [AppConfig setRateAPIParams:rateParamsDict];
    
    JsonOperation *jOP = [[JsonOperation alloc]init];
    
    PRINTLOG(@"JSON value ::%@",[jOP getJsonStringByDictionary:rateParamsDict]);
    
//    [AppConfig testWrapper:RATE_URL query:[jOP getJsonStringByDictionary:rateParamsDict] callback:cacheCallback];
    
//    GENERATEDICT();
    //cacheCallback.onSuccess(RATE_URL, nil, self);
    
    
    
    
    GENERATESERVICE(RATE_URL, [jOP getJsonStringByDictionary:rateParamsDict] , cacheCallback);
    
    
    
    
    
    
    
//
//    NSString *filepath = [[NSBundle mainBundle] pathForResource:@"planName1" ofType:@"plist"];
//    NSDictionary *plistHash = [NSDictionary dictionaryWithContentsOfFile:filepath];
////    NSLog(@"Plist Hash Dictonary value:%@", plistHash);
//    NSDictionary *supplementPlandict = [plistHash objectForKey:[AppConfig currentPlan]];
//    NSLog(@"supplementPlandict :: %@",supplementPlandict);
//    for(id keys in supplementPlandict)
//    {
//        [rateParamsDict setValue:[supplementPlandict valueForKey:keys] forKey:keys];
//        NSLog(@"RateParamDict :: %@",rateParamsDict);
//    }
//    NSDictionary *responseDictionary = [plistHash objectForKey:RATE_URL];
//    if([responseDictionary isKindOfClass:[NSDictionary class]]) {
//        cacheCallback.onSuccess([responseDictionary valueForKey:[jOP getJsonStringByDictionary:rateParamsDict]], nil, self);
//
//    } else {
//        cacheCallback.onSuccess(responseDictionary, nil, self);
//
//    }

    
 
    
}




-(void)displayRateText:(id)getRateData {
    
    PRINTLOG(@"Rate response ::%@",getRateData);
    
    if([getRateData isKindOfClass:[NSArray class]]){
        if([getRateData count]>0){
            
            self.rateAmountLabel.text = [NSString stringWithFormat:@"$%.2f",[[getRateData objectAtIndex:0]doubleValue]];
        }else {
            self.rateAmountLabel.text = @"$0.00";
            
        }
    }else {
        self.rateAmountLabel.text = @"$0.00";
    }
    
    [AppConfig setRateAmount:self.rateAmountLabel.text];
    [AppConfig setIsCallRateAPI:YES];
    
    [self stopActivityIndicator];

}



-(NSString *)rateEffectiveDate:(int)startMonth year:(int)startYear{
    
    return [NSString stringWithFormat:@"%02ld/01/%d",(long)startMonth,startYear];
    
}

#pragma mark Error Alert methods
-(void)errorMessageAlert:(NSString *)title message:(NSString *)message {
    
//    [self removeActivityIndicator];
    
    [self stopActivityIndicator];
    NSString *localizeTitle = [LanguageCentral languageSelectedString:title];
    NSString *titleString = (localizeTitle.length>0)?localizeTitle:title;
    
    
    NSString *localizeMessage = [LanguageCentral languageSelectedString:message];
    NSString *msgString = (localizeMessage.length>0)?localizeMessage:message;
    
    
    
    UIAlertController *alertController = [UIAlertController
                                          alertControllerWithTitle:titleString
                                          message:msgString
                                          preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *okAction = [UIAlertAction
                               actionWithTitle:NSLocalizedString(@"OK", @"OK action")
                               style:UIAlertActionStyleDefault
                               handler:^(UIAlertAction *action)
                               {
                                   PRINTLOG(@"ok action");
                               }];
    
    [alertController addAction:okAction];
    
    [self presentViewController:alertController animated:YES completion:nil];
    
}

#pragma mark ActivityIndicator methods

- (void)startActivityIndicator
{
    // disable the user interaction for whole screen or UI
    [[UIApplication sharedApplication] beginIgnoringInteractionEvents];
    
    currentBaseView = [AppConfig getBaseMainView];
        NSString *filePath = [[NSBundle mainBundle] pathForResource: @"HB-loader-fullsquare-final-notext 3" ofType: @"gif"];
        
        NSData *gifData = [NSData dataWithContentsOfFile: filePath];
        
        
        UIImageView *loader = [[UIImageView alloc]initWithImage:[UIImage animatedImageWithAnimatedGIFData:gifData]];
        loader.frame = CGRectMake(0,0, 59,59);
        loader.clipsToBounds = YES;
        [self.view addSubview:loader];
        loader.translatesAutoresizingMaskIntoConstraints = NO;
        
        [loader addConstraint:[NSLayoutConstraint constraintWithItem:loader attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:0 multiplier:1 constant:59]];
        [loader addConstraint:[NSLayoutConstraint constraintWithItem:loader attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:nil attribute:0 multiplier:1 constant:59]];
        
        [self.view addConstraint:[NSLayoutConstraint constraintWithItem:loader attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterY multiplier:1 constant:0]];
        [self.view addConstraint:[NSLayoutConstraint constraintWithItem:loader attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterX multiplier:1 constant:0]];
    
    [self.view updateConstraintsIfNeeded];
        self.view.userInteractionEnabled = NO;
    currentBaseView.userInteractionEnabled = NO;
   
}

- (void)stopActivityIndicator
{
    // enable the user interaction for whole screen or UI
    [[UIApplication sharedApplication] endIgnoringInteractionEvents];
    
    loader = nil;
    [loader removeFromSuperview];
   
    for(id subViewData in self.view.subviews){
        if([subViewData isKindOfClass:[UIImageView class]]){
            [subViewData removeFromSuperview];
        }
    }
    self.view.userInteractionEnabled = YES;
    currentBaseView.userInteractionEnabled = YES;
}

-(void)viewWillDisappear:(BOOL)animated {
    
    [super viewWillDisappear:animated];
    cache = nil;
    loader = nil;
    currentBaseView = nil;
}
@end
