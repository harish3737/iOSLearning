//
//  EmailCollectionViewController.h
//  BCBS Medicare Enrolment App
//
//  Created by CSS Corp on 04/07/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>

@interface EmailCollectionViewController : UIBaseContainerViewController
@property (weak, nonatomic) IBOutlet UIView *firstView;
@property (weak, nonatomic) IBOutlet UIView *secondView;

@end
