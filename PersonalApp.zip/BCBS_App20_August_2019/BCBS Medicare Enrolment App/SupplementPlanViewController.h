//
//  SupplementPlanViewController.h
//  BCBS Medicare Enrolment App
//
//  Created by CSS Corp on 08/06/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>
#import "CustomValidatorLabel.h"

typedef id(^AgeValidator)(id birthDate,id parent);

@interface SupplementPlanViewController : UIBaseContainerViewController<DropDownDelegate>

@property (strong, nonatomic) IBOutlet UIDropDown *birthdayView;
@property (strong, nonatomic) IBOutlet UIDropDown *planEnrolView;
@property (strong, nonatomic) IBOutlet UIDropDown *effectiveDateView;
@property (strong, nonatomic) IBOutlet UIDropDown *genderView;


//svk
@property (strong, nonatomic) IBOutlet UIDropDown *partAView;
@property (strong, nonatomic) IBOutlet UIDropDown *partBView;


//svk added constraint property
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *partALabelTop;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *partAViewTop;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *partBLabelTop;

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *partBViewTop;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *planEnrollLabelTop;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *planEnrollGenderTop;




//svk
@property (strong, nonatomic) IBOutlet ValidatorLabel *partALabel;
@property (strong, nonatomic) IBOutlet ValidatorLabel *partBLabel;

@property (strong, nonatomic) IBOutlet ValidatorLabel *titleString;
@property (strong, nonatomic) IBOutlet ValidatorLabel *effectiveDateLabel;
@property (strong, nonatomic) IBOutlet ValidatorLabel *birthdateLabel;
@property (strong, nonatomic) IBOutlet ValidatorLabel *planEnrollLabel;
@property (weak, nonatomic) IBOutlet ValidatorLabel *genderLabel;


@property (weak, nonatomic) IBOutlet ValidatorLabel *rateLabel;
@property (weak, nonatomic) IBOutlet ValidatorLabel *rateContentLabel;
@property (weak, nonatomic) IBOutlet CustomValidatorLabel *rateAmountLabel;
@property (weak, nonatomic) IBOutlet ValidatorLabel *subtitleLabel;
@property (weak, nonatomic) IBOutlet ValidatorLabel *rateDisclaimerLabel;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *genderVerticalConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *planVerticalConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *genderLabelHeightConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *genderViewHeightConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *rateLabelHeightConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *rateContentHeightConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *rateAmountHeightConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *rateLabelVerticalConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *effectiveDateVerticalConstraint;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *rateDisclaimerVerticalConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *rateDisclaimerHeightConstraint;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *rateContentLeadingConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *rateAmountLeadingConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *rateContentWidthConstraint;




+(AgeValidator)medigapUnder50;
+(AgeValidator)medigap50To64;
+(AgeValidator)medigapAbove65;

+(NSMutableDictionary *)AgeValidatorDictionary;

-(NSMutableDictionary *)AgeCalculatedPlanDict:(id)planList :(id)planCEffectiveArray :(id)otherPlansEffectiveArray;

-(void)setBoolValueForBackAction:(BOOL)isBackAction;

//anitha
-(void) buildPlanValidator;
-(NSMutableArray *)planArray: (NSString *)selectedString;


@end
