//
//  UIHeaderLabelEditButtonView.m
//  CSSUIFramwork
//
//  Created by CSS CORP on 27/06/18.
//  Copyright © 2018 csscorp. All rights reserved.
//

#import "UIHeaderLabelEditButtonView.h"
#import "AppConfig.h"

@implementation UIHeaderLabelEditButtonView
@synthesize actionblock,xPath;

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    
    [super drawRect:rect];
}



-(instancetype)initWithCoder:(NSCoder *)aDecoder {
    
    self = [super initWithCoder:aDecoder];
    
    if(self){
        
        [self loadLabeledButtonXibFile];
        
    }
    
    return self;
    
}

-(instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if(self){
        
        [self loadLabeledButtonXibFile];
        
    }
    return self;
    
}

-(void)loadLabeledButtonXibFile {
    
    //1. Load a Xib file
    [[NSBundle mainBundle]loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
    
    //2adjust bounds
    self.bounds = self.headerEditBtnView.bounds;
   
    //3. Add a subview
    [self addSubview:self.headerEditBtnView];
    
//    [self.editButton addTarget:self action:@selector(editButtonTapped:) forControlEvents:UIControlEventTouchUpInside];
    
    
}

-(void)awakeFromNib {
    
    [self InitiatingValidatorBlock];
  
    [super awakeFromNib];
    
}

-(void)InitiatingValidatorBlock {
    
    actionblock = ^(id sender,id parent){
        
    };
    
    _dataValidator = [Validator NoValidation];
    [self linkChain];
}

-(IBAction)editButtonTapped:(id)sender {
    
//    actionblock(sender,self.parent);
    
//    SEL selector = @selector(buttonSavePressed:);
    
    
    
//    // selector is used over here
//    [self.editButton addTarget:parent action:@selector(editIndexButtonPressed:)
//              forControlEvents:UIControlEventTouchUpInside];
   
}


-(void)setTitleLabel:(NSString *)titleLabel {
    
    self.headerLabel.localizationKey = titleLabel;
}

-(NSString *)titleLabel {
    return self.headerLabel.localizationKey;
}


-(NSString *)xPath {
    return xPath;
}

-(NSString *)getValueString{
    
    return @"-";
}


-(void)linkChain {
    
    if([Validator tailItem]!=nil) {
        
        [[Validator tailItem] setNextField:self];
    }
    [Validator tailItem:self];
}

-(void)setComparator:(NSString *)Comparator {
    
    _comparator = Comparator;
    _dataValidator = [Validator getValidator:_comparator];
}

-(void)setCompareValue:(NSString *)compareValue {
    
    _compareValue = compareValue;
}


@end
