//
//  PlanValidator.h
//  BCBS Medicare Enrolment App
//
//  Created by Dheena on 27/05/19.
//  Copyright © 2019 CSS Corp. All rights reserved.
//

#ifndef PlanValidatorProtocol_h
#define PlanValidatorProtocol_h


@protocol PlanValidatorProtocol <NSObject>
@property (nonatomic, strong) NSDate *compareDate;
@property (nonatomic, strong) NSDate *withDate;
@end

#endif /* PlanValidator_h */


