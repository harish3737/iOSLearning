//
//  ViewController.h
//  autolayout programmatically
//
//  Created by CSS Corp on 03/05/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>

@interface ScopeBaseViewController : UIBaseViewController
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@property (strong, nonatomic) IBOutlet UIView *progressView;
 

typedef void (^LoadXib)(NSString *);
typedef void (^LoadContentViewController) (NSString *);


@property (copy)LoadXib loadXib;
@property (copy)LoadContentViewController loadcontentVC;


@property (weak, nonatomic) IBOutlet UIButton *skipButton;

@property (strong, nonatomic) IBOutlet UIButton *nextButton;
@property (strong, nonatomic) IBOutlet UIButton *backButton;


- (IBAction)logoutAction:(id)sender;

- (IBAction)nextButton:(id)sender;
- (IBAction)backButton:(id)sender;
- (IBAction)skipButtonAction:(id)sender;

+(void)populateCurrentItemValue;

-(void)fillJSONDictionary :(NSString *)xPath value:(id)value;
-(NSString *)getValueFromXpath:(NSDictionary *)requestDict :(NSString *)xPath;

@property (nonatomic, retain) IBOutlet UILabel *welcomeLbl;

@end


