//
//  DashboardBaseViewController.m
//  dashboard flow
//
//  Created by CSS Corp on 04/05/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "DashboardBaseViewController.h"
#import "LanguageViewController.h"
#import "YearViewController.h"
#import "DashboardViewController.h"
#import "AppConfig.h"

#import <CacheLib/CacheLib.h>
#import <CacheLib/WebServiceWrapper.h>
#import <CacheLib/Callback.h>
#import <CacheLib/Global.h>



@interface DashboardBaseViewController ()
{
	UIActivityIndicatorView* activity;
}


@end

@implementation DashboardBaseViewController
@synthesize delegate;

- (void)viewDidLoad {
	


	self.backButton.hidden = YES;
	
	[UINavigationQueue showInitialContainerViewcontroller:self];
	
	 self.currentViewController.willLoadNext(self);
	
	
	NSString * welcomeString = [NSString stringWithFormat:@"WELCOME, %@",[AppConfig getUserName]];
	
	[_welcomeLbl setText:[welcomeString uppercaseString]];
	
	[_welcomeLbl setFont:[UIFont fontWithName:@"AvenirNext-Regular" size:20.0]];
	self.welcomeLbl.textColor=[UIColor colorWithRed:(140/255.f) green:(140/255.f) blue:(140/255.f) alpha:1.0];

	[super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)addSubview:(UIView *)subView toView:(UIView*)parentView {
	[parentView addSubview:subView];
	
	NSDictionary * views = @{@"subView" : subView,};
	NSArray *constraints = [NSLayoutConstraint constraintsWithVisualFormat:@"H:|[subView]|"
																   options:0
																   metrics:0
																	 views:views];
	[parentView addConstraints:constraints];
	constraints = [NSLayoutConstraint constraintsWithVisualFormat:@"V:|[subView]|"
														  options:0
														  metrics:0
															views:views];
	[parentView addConstraints:constraints];
}

- (void)cycleFromViewController:(UIViewController*) currentViewController
			   toViewController:(UIViewController*) nextViewController {
	[currentViewController willMoveToParentViewController:nil];
	[self addChildViewController:nextViewController];
	[self addSubview:nextViewController.view toView:self.containerView];
	[nextViewController.view layoutIfNeeded];
	
	// set starting state of the transition
	nextViewController.view.alpha = 0;
	
	[UIView animateWithDuration:0.5
					 animations:^{
						 nextViewController.view.alpha = 1;
						 currentViewController.view.alpha = 0;
					 }
					 completion:^(BOOL finished) {
						 [currentViewController.view removeFromSuperview];
						 [currentViewController removeFromParentViewController];
						 [nextViewController didMoveToParentViewController:self];
					 }];
}


- (IBAction)backToDashboardPage:(id)sender{
	

	[UINavigationQueue showPrevious:self];
	if ([self.currentViewController isKindOfClass:[DashboardViewController class]]) {
		
		self.backButton.hidden =YES;
		[UINavigationQueue deleteAfter:[DashboardBaseViewController class] container:[DashboardViewController class] xib:nil];
		self.currentViewController.willLoadNext(self);
    }else if([self.currentViewController isKindOfClass:[LanguageViewController class]]) {
        [UINavigationQueue deleteAfter:[DashboardBaseViewController class] container:[LanguageViewController class] xib:nil];
        self.backButton.hidden = NO;
        
    }else if([self.currentViewController isKindOfClass:[YearViewController class]]){
        [UINavigationQueue deleteAfter:[DashboardBaseViewController class] container:[YearViewController class] xib:nil];
        self.backButton.hidden = NO;
    }else {
        self.backButton.hidden = NO;
    }

}

- (IBAction)logoutAction:(id)sender {
    
	
	if([AppConfig getNetworkStatus]){
	
    [self startActivityIndicator];

        __block DashboardBaseViewController *weakSelf = self;
        
        Callback *cacheCallback = [[Callback alloc]initWithCallbacks: ^(id response,id operation,id handler){
            PRINTLOG(@"dashboard Response Success ::\n%@",response);
    
            NSError *jsonError;
            NSData *objectData = [response dataUsingEncoding:NSUTF8StringEncoding];
//            NSMutableDictionary *jsonData = [NSJSONSerialization JSONObjectWithData:objectData
//                                                                            options:NSJSONReadingMutableContainers
//                                                                              error:&jsonError];
            
            NSMutableArray *jsonData = [NSJSONSerialization JSONObjectWithData:objectData
                                                                            options:NSJSONReadingMutableContainers
                                                                              error:&jsonError];
            
            
            [AppConfig setUserLoggedIn:NO];
                
            [handler logoutSuccessAction];
          

        }:^(id response,id operation,id handler){
            PRINTLOG(@"dashboard Response Failed ::\n%@",response);
             [handler errorMessageAlert:@"Error" message:[[AppConfig ErrorResponseJSONSerialization:response]objectAtIndex:0]];
            
            
        }:weakSelf];
        
        Cache *cache = [[Cache alloc]init];
        [cache setService: [[WebServiceWrapper alloc] init]];
        [cache settimeoutInMin:1.0];
        
        [cache registerTask:LOGOUT_URL :@"NoData" :cacheCallback :NO_CACHE];
        [cache setHeaders:LOGOUT_URL  :@"NoData" :[AppConfig headerList]];
        [cache execute : LOGOUT_URL :@"NoData"];
//        [AppConfig testWrapper:LOGOUT_URL query:@"" callback:cacheCallback];
    
	}else{
		
//        [self errorMessageAlert:@"INFO" message:@"The Internet connection appears to be offline."];
        [AppConfig errorMessageAlert:@"INFO" message:@"The Internet connection appears to be offline" class:self];
	}
}

-(void)logoutSuccessAction {
    
//    [self removeActivityIndicator];
    [AppConfig stopAnimatingGif];
    [Validator ValidationDone];
    [AppConfig resetAppConfig];
    [UINavigationQueue clearNavigationQueue:-1];
    
    CATransition* transition = [CATransition animation];
    transition.duration = 0.25f;
    transition.type = kCATransitionFade;
    transition.subtype = kCATransitionFromTop;
    [self.navigationController.view.layer addAnimation:transition
                                                forKey:kCATransition];
    [self.navigationController popToRootViewControllerAnimated:NO];
    
}

//-(void)errorMessageAlert:(NSString *)title message:(NSString *)message {
//
//    [self removeActivityIndicator];
//
//
//    NSString *localizeTitle = [LanguageCentral languageSelectedString:title];
//    NSString *titleString = (localizeTitle.length>0)?localizeTitle:title;
//
//
//    NSString *localizeMessage = [LanguageCentral languageSelectedString:message];
//    NSString *msgString = (localizeMessage.length>0)?localizeMessage:message;
//
//
//
//    UIAlertController *alertController = [UIAlertController
//                                          alertControllerWithTitle:titleString
//                                          message:msgString
//                                          preferredStyle:UIAlertControllerStyleAlert];
//
//    UIAlertAction *okAction = [UIAlertAction
//                               actionWithTitle:NSLocalizedString(@"OK", @"OK action")
//                               style:UIAlertActionStyleDefault
//                               handler:^(UIAlertAction *action)
//                               {
//                                   PRINTLOG(@"ok action");
//                               }];
//
//    [alertController addAction:okAction];
//
//    [self presentViewController:alertController animated:YES completion:nil];
//
//}




#pragma mark Custom methods

- (void)startActivityIndicator
{
	[AppConfig showLoaderGif];
	
//    activity = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
//    [activity setHidesWhenStopped:TRUE];
//    [activity setAlpha:1.0];
//    [activity setFrame:CGRectMake((self.view.frame.origin.x+self.view.frame.size.width)/2.0, ((self.view.frame.origin.y+self.view.frame.size.height)/2.0)-100.0, activity.frame.size.width, activity.frame.size.height)];
//    [self.view addSubview:activity];
//    [activity startAnimating];
    
}

- (void)removeActivityIndicator
{
	[AppConfig stopAnimatingGif];
	
//    [activity stopAnimating];
//    [activity removeFromSuperview];
}



@end
