//
//  UIIndexLabelSubLabelView.h
//  BCBS Medicare Enrolment App
//
//  Created by CSS Admin on 7/19/18.
//  Copyright © 2018 CSS Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CSSUIFramwork/CSSUIFramwork.h>
#import "CustomValidatorLabel.h"

IB_DESIGNABLE
@interface UIIndexLabelSubLabelView : UIView


@property (strong, nonatomic) IBOutlet UIIndexLabelSubLabelView *indexSubLabeledView;

@property (strong, nonatomic) IBOutlet CustomValidatorLabel *leftLabel;
@property (strong, nonatomic) IBOutlet CustomValidatorLabel *rightLabel;
@property (strong, nonatomic) IBOutlet CustomValidatorLabel *indexLabel;

@property (strong,nonatomic) NSString *xPath;

@property (nonatomic,strong) NSString *comparator;
@property (nonatomic,weak) DataValidator dataValidator;
@property (copy) UICallback *callback;

@property(nonatomic,strong) NSString *compareValue;

-(NSString *)getValueString;
-(NSString *)xPath;


@end
