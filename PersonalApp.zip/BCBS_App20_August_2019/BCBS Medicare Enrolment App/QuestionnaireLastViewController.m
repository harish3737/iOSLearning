//
//  QuestionnaireLastViewController.m
//  BCBS Medicare Enrolment App
//
//  Created by CSS Corp on 16/06/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "QuestionnaireLastViewController.h"
#import "AppConfig.h" 
#import "ScopeBaseViewController.h"

@interface QuestionnaireLastViewController ()

@end

@implementation QuestionnaireLastViewController
@synthesize subTitle;

- (void)viewDidLoad {
    [super viewDidLoad];
	
	
	if([[AppConfig currentPlan] isEqualToString:@"DSNP"]){
		
//		subTitle.text=@"Please choose the name and the Provider ID of a Primary Care Physician (PCP) from our provider directory HorizonBlue.com/doctorfinder";
        if(([[AppConfig enrollYear] isEqualToString:@"2019"] ||[[AppConfig enrollYear] isEqualToString:@"2020"])){
            [subTitle setLocalizationKey:@"CHOOSE_NAME_PROVIDER_ID_2019"];
        }else {
            [subTitle setLocalizationKey:@"CHOOSE_NAME_PROVIDER_ID"];
        }
    }else if([[AppConfig currentPlan] isEqualToString:@"MAPD"] ){
          [subTitle setLocalizationKey:@"CHOOSE_THE_NAME_AND_ABJK_2019"];
    }else {
         [subTitle setLocalizationKey:@"CHOOSE_THE_NAME_AND_ABJK"];
        
    }
    // Do any additional setup after loading the view.

	_titleString.text = [NSString stringWithFormat:@"%@ %@ - \n%@",[AppConfig enrollYear],[LanguageCentral languageSelectedString:[[AppConfig currentPlanDictionary] objectForKey:@"PlanTitle"]],[LanguageCentral languageSelectedString:[[[AppConfig currentPlanDictionary] objectForKey:NSStringFromClass([self class])]objectForKey:@"title"]]];
    
    
	[UIRenderer renderPlist:self plist:[NSString stringWithFormat:@"%@PcpQuestionForm%@",[AppConfig currentPlan],[AppConfig enrollYear]]];
	

    if([[AppConfig currentPlan] isEqualToString:@"DSNP"]){
        [self.sharedataObj setForwardNextButtonTitle:@"Continue_to_authorization"];
        [self.sharedataObj setNextProgressIndex:2];
        
        [self.sharedataObj setPreviousNextButtonTitle:@"Next"];
        [self.sharedataObj setBackProgressIndex:2];
    }else {
        [self.sharedataObj setForwardNextButtonTitle:@"continue_to_attestation"];
        [self.sharedataObj setNextProgressIndex:3];
        
        [self.sharedataObj setPreviousNextButtonTitle:@"Next"];
        [self.sharedataObj setBackProgressIndex:3];
    }
	
}


-(void)viewWillAppear:(BOOL)animated{
	
	[ScopeBaseViewController populateCurrentItemValue];
	[self loadBackData];

	
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
