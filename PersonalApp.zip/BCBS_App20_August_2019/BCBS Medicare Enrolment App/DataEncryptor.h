//
//  DataEncryptor.h
//  BCBS Medicare Enrolment App
//
//  Created by CSS Admin on 8/22/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
//#import "RNCryptor/RNCryptor.h"

@interface DataEncryptor : NSObject

//+(void)getEncryptData:(id)dataString;
//
//+(void)getDecryptData:(id)dataString;

@end
