//
//  GuaranteedIssueRightsViewController.m
//  BCBS Medicare Enrolment App
//
//  Created by CSS CORP on 22/06/18.
//  Copyright © 2018 CSS Corp. All rights reserved.
//

#import "GuaranteedIssueRightsViewController.h"
#import "AppConfig.h"
#import "ScopeBaseViewController.h"

@interface GuaranteedIssueRightsViewController ()

@end

@implementation GuaranteedIssueRightsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    _titleString.text = [NSString stringWithFormat:@"%@ %@ - \n%@",[AppConfig enrollYear],[LanguageCentral languageSelectedString:[[AppConfig currentPlanDictionary] objectForKey:@"PlanTitle"]],[LanguageCentral languageSelectedString:[[[AppConfig currentPlanDictionary] objectForKey:NSStringFromClass([self class])]objectForKey:@"title"]]];
    
    [self.sharedataObj setForwardNextButtonTitle:@"Next"];
    [self.sharedataObj setNextProgressIndex:3];
    
    [self.sharedataObj setPreviousNextButtonTitle:@"Next"];
    [self.sharedataObj setBackProgressIndex:3];
    if([[AppConfig enrollYear]isEqualToString:@"2020"])
    {
        self.medicareBlueSupplement.localizationKey = @"MEDICARE_BLUE_SUPPLIMENTS_D";
        self.medicareBlueSupplement1.localizationKey = @"MEDICARE_BLUE_SUPPLIMENTS_1_D";
    }
}

-(void)viewWillAppear:(BOOL)animated {
    
    [ScopeBaseViewController populateCurrentItemValue];
    [self loadBackData];
    [super viewWillAppear:animated];
}

-(void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
}

//-(BOOL)validateVC {
//
//
//}

-(void)loadNextPage {
    
    [self addCustomJsonValue];
}

-(void)addCustomJsonValue {
    
    
}

-(void)loadBackData {
   
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
