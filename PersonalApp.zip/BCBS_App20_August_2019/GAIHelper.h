//
//  GAIHelper.h
//  vBoxDev
//
//  Created by Chunhui on 16/1/14.
//
//

#import <Foundation/Foundation.h>
#import "GAI.h"

@interface GAIHelper : NSObject
+(void) initGAI;
+(void) sendScreenWithName:(NSString *) name;
+ (void) setGAUserId:(NSString *)user;

@end
