//
//  Callback.h
//  CacheLib
//
//  Created by CSS Corp on 05/04/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ServiceCallbackProtocol.h"

@interface Callback : NSObject <ServiceCallbackProtocol>

@property (nonatomic, strong) id handler;

+ (instancetype) getDummyCallback;
- (instancetype) initWithCallbacks : (callbackBlock) successBlock : (callbackBlock) failedBlock : (id) handler;
- (id) handler;

@end
