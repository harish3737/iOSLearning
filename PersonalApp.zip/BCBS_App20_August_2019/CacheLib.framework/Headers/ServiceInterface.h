//
//  ServiceInterface.h
//  CacheLib
//
//  Created by CSS Corp on 05/04/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ServiceProtocol.h"

@interface ServiceInterface : NSObject <ServiceProtocol>

@end
