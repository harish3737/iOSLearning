//
//  Cache.h
//  CacheLib
//
//  Created by CSS Corp on 01/04/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#ifndef Cache_h
#define Cache_h

#import <Foundation/Foundation.h>
#import "Callback.h"
#import "ServiceInterface.h"
#import "Global.h"
#import "InterceptorProtocol.h"

@interface Cache : NSObject

@property (strong) NSMutableDictionary *dictionaryL1;
@property (strong, readonly) id service;
@property (assign) double timeOut;


- (id) put : (NSString*) key1 : (NSString*) key2 : (CacheType) cacheType;
- (id) get: (NSString*) key1 : (NSString*) key2;
- (double) getTimeOut;

- (void) settimeoutInMin: (double) min;


//- (void) setService : (callbackBlock) mySuccessBlock : (callbackBlock) myFailedBlock;
- (void) setService:(id) service;

- (void) setResponse: (NSString*) key1 : (NSString*) key2 : (id) response;

- (void) registerTask: (NSString*) key1 : (NSString*) key2 : (Callback*) callback : (CacheType) cacheType;
- (void) registerTask: (NSString*) key1 : (NSString*) key2 : (Callback*) callback;
- (void) registerTaskAndExecute: (NSString*) key1 : (NSString*) key2 : (Callback*) callback : (CacheType) cacheType;
- (void) registerTaskAndExecute: (NSString*) key1 : (NSString*) key2 : (Callback*) callback;
- (void) unregisterTask: (NSString*) key1 : (NSString*) key2;
- (void) clear;

- (void) execute: (NSString*)key1 : (NSString*) key2;
- (void) updateAndExecute: (NSString*)key1 : (NSString*) key2;

- (NSMutableDictionary *) getHeaders : (NSString *) key1 : (NSString *) key2;
- (void) setHeaders : (NSString *) key1 : (NSString *) key2 : (NSMutableDictionary *) headers ;



@end

#endif
