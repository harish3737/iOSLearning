//
//  ServiceProtocol.h
//  CacheLib
//
//  Created by CSS Corp on 05/04/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#ifndef ServiceProtocol_h
#define ServiceProtocol_h

#import "Callback.h"

@protocol ServiceProtocol <NSObject>

@required
- (void) call:(id)url query:(id)queryString callBack:(Callback *)callback : (id) operation : (NSMutableDictionary *) headers;

@end

#endif /* ServiceProtocol_h */
