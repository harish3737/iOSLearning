//
//  CacheLib.h
//  CacheLib
//
//  Created by CSS Corp on 01/04/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CacheLib.
FOUNDATION_EXPORT double CacheLibVersionNumber;

//! Project version string for CacheLib.
FOUNDATION_EXPORT const unsigned char CacheLibVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CacheLib/PublicHeader.h>

#import <CacheLib/CacheLib.h>
#import <CacheLib/Cache.h>
#import <CacheLib/Global.h>
#import <CacheLib/Callback.h>
#import <CacheLib/WebServiceHelper.h>
#import <CacheLib/WebServiceWrapper.h>
