//
//  GAIHelper.m
//  vBoxDev
//
//  Created by Chunhui on 16/1/14.
//
//

#import "GAIHelper.h"
#import "GAIDictionaryBuilder.h"
#import "GAIFields.h"

@implementation GAIHelper
{

}

static NSString *const kTrackingId = GA_TRACKING_ID; 


+(void)initGAI {
	
	[[GAI sharedInstance] trackerWithTrackingId:kTrackingId];
	 [GAI sharedInstance].dispatchInterval = 10;
	[[GAI sharedInstance] setTrackUncaughtExceptions:YES];
    PRINTLOG(@"Gai Init");
}

+(void)sendScreenWithName:(NSString *)name {
	
	id tracker = [[GAI sharedInstance] defaultTracker];
    [tracker set:kGAIScreenName value:name];
    [tracker send:[[GAIDictionaryBuilder createScreenView] build]];
	
}



+ (void) setGAUserId:(NSString *)user {
	
	id<GAITracker> tracker = [[GAI sharedInstance] defaultTracker];
	
	// You only need to set User ID on a tracker once. By setting it on the tracker, the ID will be
	// sent with all subsequent hits.
	[tracker set:kGAIUserId  value:user];
	[tracker setAllowIDFACollection:YES];
	// This hit will be sent with the User ID value and be visible in User-ID-enabled views (profiles).
	[tracker send:[[GAIDictionaryBuilder createEventWithCategory:@"Medicare"            // Event category (required)
														  action:@"User SignIn"  // Event action (required)
														   label:nil              // Event label
														   value:nil] build]];    // Event value
}



@end
