//
//  FileInterceptor.m
//  FileOperation
//
//  Created by Ganesh on 01/07/16.
//  Copyright (c) 2016 CSS. All rights reserved.
//

#import "QueryProcessor.h"
#import <UIKit/UIKit.h>

@implementation QueryProcessor
{
	NSDictionary *sampleDictionary,*sampleDictionary2,*d3;
	NSMutableArray *testArray;
	NSString *insertQueryTemplate;
//	NSInteger count;
}

-(instancetype)init
{
//	
//	insertQueryTemplate = @"insert into bcbs_pdp_plan values ('@plan@','@csv plan name@','@plan year@','@region@','@monthly premium@','@plan type@','@updated date@')";
//	NSString *planJson = @"[{\"plan\":\"Horizon Medicare Blue Value HMO\",\"csv plan name\":\"Horizon Medicare Blue Value\",\"plan year\":\"2016-01-01 00:00:00\",		\"region\":\"A\",		\"monthly premium\":\"$52.10\",		\"plan type\":\"Medicare Advantage\",		\"updated date\":\"2016-01-14 10:18:35\"},	{\"plan\":\"Horizon Medicare Blue Value w/Rx (HMO)\",		\"csv plan name\":\"Horizon Medicare Blue Value w/Rx\",\"plan year\":\"2016-01-01 00:00:00\",		\"region\":\"A\",		\"monthly premium\":\"$92.60\",		\"plan type\":\"Medicare Advantage\",\"updated date\":\"2016-01-21 09:12:01\"	},	{		\"plan\":\"Horizon Medicare Blue Choice w/Rx (HMO) \",		\"csv plan name\":\"Horizon Medicare Blue Choice w/Rx\",		\"plan year\":\"2016-01-01 00:00:00\",		\"region\":\"B\",		\"monthly premium\":\"$179.10\",\"plan type\":\"Medicare Advantage\",		\"updated date\":\"2016-01-21 09:19:08\"	},	{		\"plan\":\"Horizon Medicare Blue Patient-Centered w/Rx (HMO)\",		\"csv plan name\":\"Horizon Medicare Blue Patient-Centered w/Rx\",		\"plan year\":\"2016-01-01 00:00:00\",\"region\":\"2\",		\"monthly premium\":\"$46.10\",		\"plan type\":\"Medicare Advantage\",		\"updated date\":\"2016-01-21 09:17:20\"},	{		\"plan\":\"Horizon Medicare Blue Patient-Centered w/Rx (HMO)\",		\"csv plan name\":\"Horizon Medicare Blue Patient-Centered w/Rx\",\"plan year\":\"2016-01-01 00:00:00\",		\"region\":\"3\",		\"monthly premium\":\"$71.70\",		\"plan type\":\"Medicare Advantage\",\"updated date\":\"2016-01-21 09:21:52\"	},	{		\"plan\":\"Horizon Medicare Blue Patient-Centered w/Rx (HMO)\",		\"csv plan name\":\"Horizon Medicare Blue Patient-Centered w/Rx\",		\"plan year\":\"2016-01-01 00:00:00\",		\"region\":\"4\",		\"monthly premium\":\"$108.70\",		\"plan type\":\"Medicare Advantage\",		\"updated date\":\"2016-01-21 09:26:15\"	},	{		\"plan\":\"Horizon Medicare Blue Patient-Centered w/Rx (HMO)\",		\"csv plan name\":\"Horizon Medicare Blue Patient-Centered w/Rx\",		\"plan year\":\"2016-01-01 00:00:00\",		\"region\":\"1\",		\"monthly premium\":\"$0.00\",		\"plan type\":\"Medicare Advantage\",\"updated date\":\"2016-01-21 09:10:17\"	}]";
//	
//	
//	[self requestProcessor:planJson :insertQueryTemplate];
	return self;
}


+(void)requestProcessor : (NSString *)jsonString :(NSString *)template
{ 
	
	// Convert to JSON object:
	NSMutableArray *jsonArray = [NSJSONSerialization JSONObjectWithData:[jsonString dataUsingEncoding:NSUTF8StringEncoding]
														  options:0 error:NULL];
	
	if([jsonArray count])
	{
		for (int iteration = 0; iteration < [jsonArray count] ; iteration ++)
		{
			
			[self generateQuery:template :[jsonArray objectAtIndex:iteration]];
		}
	}
	
}





+(NSString *) generateQuery : (NSString *)template :(NSMutableDictionary *)element
{
    
    
	NSArray *keys = [element allKeys];
 	for (int iteration = 0; iteration < [keys count]; iteration++){
		
		NSString *string = [NSString stringWithFormat:@"@%@@",[keys objectAtIndex:iteration]];
		NSRange range = [template rangeOfString:string options:NSCaseInsensitiveSearch];
		//if (NSNotFound != range.location) {
			
			NSString *key = [keys objectAtIndex:iteration];
            
            if([key isEqualToString:@"age range"])
            {
                
               
                if ([element[key] rangeOfString:@"-"].location == NSNotFound) {
                    //NSLog(@"string does not contain -");
                    NSRange minrange = [template rangeOfString:@"@min age range@" options:NSCaseInsensitiveSearch];
                    template = [template stringByReplacingCharactersInRange:minrange  withString:element[key]];
                    
                    NSRange maxrange = [template rangeOfString:@"@max age range@" options:NSCaseInsensitiveSearch];
                    
                    template = [template stringByReplacingCharactersInRange:maxrange  withString:element[key]];
                }
                else {
                         //NSLog(@"string contains -");
                         NSArray *ageArray = [element[key] componentsSeparatedByString:@"-"];
                          NSRange minrange = [template rangeOfString:@"@min age range@" options:NSCaseInsensitiveSearch];
                         template = [template stringByReplacingCharactersInRange:minrange  withString:[ageArray objectAtIndex:0]];
                    
                        NSRange maxrange = [template rangeOfString:@"@max age range@" options:NSCaseInsensitiveSearch];
                         template = [template stringByReplacingCharactersInRange:maxrange  withString:[ageArray objectAtIndex:1]];
                }
                
            }else {
            
			template = [template stringByReplacingCharactersInRange:range  withString:element[key]];
                
            }
//		}
	}
	
//	count+=1;
//	
//	NSMutableString *finalTemplate = [template mutableCopy];
//	
//	[finalTemplate insertString:[NSString stringWithFormat:@"'%ld',",(long)count] atIndex:34];
//	
//	//NSLog(@"Replaced template ...%@",finalTemplate);
    NSLog(@"Returned Template ::%@",template);
	return template;
}


//			if([key isEqualToString:@"plan"]) {
//				template = [template stringByReplacingCharactersInRange:NSMakeRange(35,4)  withString:element[key]];
//			}
//			else{


@end
