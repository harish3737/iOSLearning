//
//  UILabledTextFieldNoOptional.h
//  CustomControl
//
//  Created by CSS Corp on 25/04/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ValidatorLabel.h"
#import "UIConfirmImageView.h"
#import "UICGSizeConstraints.h"
#import "ValidatorTextField.h"
#import "UIMultiLingualButton.h"

IB_DESIGNABLE

@interface UILabledTextFieldNoOptional : UIView

@property (strong, nonatomic) IBOutlet UILabledTextFieldNoOptional *contentView;


@property (strong, nonatomic) IBOutlet ValidatorLabel *titleLabel;
@property (strong, nonatomic) IBOutlet ValidatorTextField *textField;

@property (strong,nonatomic) IBOutlet UIConfirmImageView *confirmImgView;

@property (nonatomic,strong) UICGSizeConstraints *sizeConstraints;

@property (strong,nonatomic) id nextItem;

@property (strong,nonatomic) NSString *xPath;

-(NSString *)getValueString;

-(id)nextItem;

-(NSString *)xPath;


-(void)setEnabled:(BOOL)enabled;
-(void)setUserInteractionEnabled:(BOOL)userInteractionEnabled;





@end
