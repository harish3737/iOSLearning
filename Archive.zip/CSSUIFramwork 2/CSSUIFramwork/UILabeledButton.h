//
//  UILabeledButton.h
//  SampleBCBSPOC
//
//  Created by CSS Admin on 5/10/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIDropDown.h"
#import "ValidatorLabel.h"
#import "UIMultiLingualButton.h"

IB_DESIGNABLE

@interface UILabeledButton : UIView


@property (strong, nonatomic) IBOutlet UILabeledButton *labeledButtonView;

@property (weak,nonatomic) IBOutlet ValidatorLabel *titleLabel;
@property (strong,nonatomic)IBOutlet UIDropDown *dropDownCustomView;

@property (strong,nonatomic) IBOutlet UIMultiLingualButton *optionalButton;

@property (strong,nonatomic) NSString *xPath;

+(BOOL)isDatePicker;
+(void)setBooleanDatePicker:(BOOL)isDatePickerShow;

-(void)enableDropDownView;
-(void)disableDropDownView;

-(NSString *)getValueString;

-(NSString *)xPath;


-(void)setEnabled:(BOOL)enabled;
-(void)setUserInteractionEnabled:(BOOL)userInteractionEnabled;

-(void)resetDropDownTitle;
@end
