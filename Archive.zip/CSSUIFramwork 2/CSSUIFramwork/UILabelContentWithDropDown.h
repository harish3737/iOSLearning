//
//  UILabelContentWithDropDown.h
//  CSSUIFramwork
//
//  Created by CSS Admin on 6/16/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ValidatorLabel.h"
#import "UILabeledButton.h"

@interface UILabelContentWithDropDown : UIView


@property (strong,nonatomic) ValidatorLabel *headingLabel;
@property (strong,nonatomic) UILabeledButton *labelDropDownView;

@property (nonatomic)BOOL disableDropDown;
@property (strong,nonatomic) NSString *xPath;

-(NSString *)xPath;


@end
