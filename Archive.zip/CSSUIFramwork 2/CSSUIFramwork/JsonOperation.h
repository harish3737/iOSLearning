//
//  JsonOperation.h
//  FileOperation
//
//  Created by Ganesh on 11/07/16.
//  Copyright © 2016 CSS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JsonOperation : NSObject





-(id)setValue :(NSDictionary *)requestDict :(NSString *)xPath : (id)value;



-(NSString*)getJsonStringByDictionary:(NSDictionary*)dictionary;

@end
