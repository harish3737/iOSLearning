//
//  UIBaseContainerViewController.m
//  BcBs
//
//  Created by CSS Admin on 6/1/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "UIBaseContainerViewController.h"

@interface UIBaseContainerViewController ()

@end

@implementation UIBaseContainerViewController
@synthesize xibPlaceholderView,willLoadNext,willSkipTouch,willBackPage,sizeConstraints;
@synthesize sharedataObj;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    sizeConstraints = [[UICGSizeConstraints alloc]init];
    willLoadNext = ^(id response){};
    willSkipTouch = ^(id response){};
    willBackPage = ^(id response) {};
    sharedataObj = [[SharedData alloc]init];
    
}


-(void)didFinishContainerVC{
	//NSLog(@"Dummy Finish ContainerVC");
}


-(BOOL)validateVC{
	
	return NO;
}

-(void)loadNextPage{
    
    
}


-(void)loadBackData{
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
