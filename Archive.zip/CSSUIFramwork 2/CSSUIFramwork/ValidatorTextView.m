//
//  ValidatorTextView.m
//  CSSUIFramwork
//
//  Created by CSS Admin on 8/9/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import "ValidatorTextView.h"
#import "LanguageCentral.h"
#import "ValidatorLabel.h"
#import "UIMultiLingualButton.h"


#define REDCOLOR [UIColor colorWithRed:(240.0/255.0) green:(108.0/255.0) blue:(108.0/255.0) alpha:1.0f]
#define TEXTCOLOR [UIColor colorWithRed:(153.0/255.0) green:(153.0/255.0) blue:(153.0/255.0) alpha:1.0f]
#define BORDERCOLOR [UIColor colorWithRed:(204.0/255.0) green:(204.0/255.0) blue:(204.0/255.0) alpha:1.0f].CGColor

@interface ValidatorTextView ()

@property(nonatomic,strong) UIView *currentView;
@property(nonatomic,strong) UIScrollView *currentScrollView;
@property (strong, nonatomic) UITextView *activeField;

- (void) validateNextField;

@end

@implementation ValidatorTextView


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    
    [self setContentOffset:CGPointZero animated : NO];
    [super drawRect:rect];
}

// remove copy,paste,select option for textfield text // added by boobalan
- (BOOL)canPerformAction:(SEL)action withSender:(id)sender
{
    if (action == @selector(paste:) ||
        action == @selector(cut:) ||
        action == @selector(copy:) ||
        action == @selector(select:) ||
        action == @selector(selectAll:) ||
        action == @selector(delete:) ||
        action == @selector(makeTextWritingDirectionLeftToRight:) ||
        action == @selector(makeTextWritingDirectionRightToLeft:) ||
        action == @selector(toggleBoldface:) ||
        action == @selector(toggleItalics:) ||
        action == @selector(toggleUnderline:)
        ) {
        UIPasteboard *pb = [UIPasteboard generalPasteboard];
        [pb setValue:@"" forPasteboardType:UIPasteboardNameGeneral];
        
        return NO;
    }
    return [super canPerformAction:action withSender:sender];
    
}

- (void) validateNextField {
    [self.nextField validate];
}


-(void)setNextField:(id)nextField{
    
    _nextField = nextField;
    //NSLog(@"NextItem ::%@",_nextField);
    
}

-(void)setLocalizationKey:(NSString *)localizationKey {
    
    _localizationKey = localizationKey;
    
    NSString *contentString = [LanguageCentral languageSelectedString:_localizationKey];
    
    self.text = (contentString.length>0)?contentString:_localizationKey;
    
    
    [self sizeToFit];
}


-(BOOL)validate{
    
    return [Validator validate:[self dataValidator] Data:self CallBack: self.callback];
    
    
}

-(void)setSubmitHandler:(callbackBlock)submitHandler{
    
    [self.callback setSuccessBlock:submitHandler];
    
}

- (void)awakeFromNib {
    
    self.layer.borderColor = BORDERCOLOR;
    self.layer.borderWidth = 1.0f;
    
    [self setUPTextView];
}

-(void)setUPTextView {
    
    
    _dataValidator = [Validator NoValidation];
    _callback = [UICallback getDummyUICallback];
    [self getSuperView];
    self.delegate = self;
    [self linkChain];
    self.textContainerInset = UIEdgeInsetsMake(5,0, 0, 0);
    self.text = @"Enter Text here...";
}


-(void)setKeyboardTypeName:(NSInteger)keyboardType{
    
    
    switch (keyboardType) {
        case UIKeyboardTypeDefault:
            self.keyboardType = UIKeyboardTypeDefault;
            break;
            
        case UIKeyboardTypeNumberPad:
            self.keyboardType = UIKeyboardTypeNumberPad;
            break;
            
        case UIKeyboardTypePhonePad:
            self.keyboardType = UIKeyboardTypePhonePad;
            break;
            
        case UIKeyboardTypeEmailAddress:
            self.keyboardType = UIKeyboardTypeEmailAddress;
            break;
            
        default:
            self.keyboardType = UIKeyboardTypeDefault;
            break;
    }
}



-(void)getSuperView {
    
    //    id currentViewcontroller = [self viewController];
    //
    //    //NSLog(@"current view controller ::%@",NSStringFromClass([currentViewcontroller class]));
    
    
    id baseVC= [UIApplication sharedApplication].keyWindow.rootViewController;
    
    //NSLog(@"visible ::%@",[baseVC visibleViewController]);
    
    
    UIViewController *visibleViewcontroller = [baseVC visibleViewController];
    
    _currentView = visibleViewcontroller.view;
    for (id subview in visibleViewcontroller.view.subviews){
        
        if([subview isKindOfClass:[UIScrollView class]]){
            //NSLog(@"subview ::%@",subview);
            _currentScrollView = subview;
        }
    }
}


- (UIView *)viewController {
    UIResponder *responder = self;
    while (![responder isKindOfClass:[UIScrollView class]]) {
        //NSLog(@"Responder ::%@",responder);
        responder = [responder nextResponder];
        if (nil == responder) {
            break;
        }
    }
    return (UIView *)responder;
}

-(void)linkChain{
    
    if([Validator tailItem]!=nil){
        [[Validator tailItem] setNextField:self];
    }
    [Validator tailItem:self];
    
}

-(void)callbackInit{
    
    _callback = [[UICallback alloc]initWithUICallbacks:^(id data){
        //NSLog(@"TextField Callback succes");
        ValidatorTextView *successTextField = data;
        successTextField.layer.borderColor = BORDERCOLOR;
        successTextField.layer.borderWidth = 1.0f;
        
//        if([[successTextField superview] isKindOfClass:[UIView class]]){
//            [successTextField changeLabelFontColor:successTextField color:TEXTCOLOR];
//            
//        }
        
    } :^(id data){
        //NSLog(@"TextField Callback Failed");
        ValidatorTextView *failedTextField = data;
        failedTextField.layer.borderColor = [UIColor colorWithRed:(240.0/255.0) green:(108.0/255.0) blue:(108.0/255.0) alpha:1.0f].CGColor;
        failedTextField.layer.borderWidth = 1.0f;

//        if([[failedTextField superview] isKindOfClass:[UIView class]]){
//            [failedTextField changeLabelFontColor:failedTextField color:REDCOLOR];
//            
//        }
        
    }];
    
}


-(void)changeLabelFontColor:(ValidatorTextView *)textField color:(UIColor *)customColor {
    
    
    NSArray *subviewArray = [textField superview].subviews;
    for (int i=0;i<subviewArray.count;i++){
        
        id subViewItem = [subviewArray objectAtIndex:i];
        ValidatorLabel *validateLabel = nil;
        if([subViewItem isKindOfClass:[ValidatorTextView class]]){
            
            if([[subviewArray objectAtIndex:(i-1)] isKindOfClass:[ValidatorLabel class]]){
                validateLabel = [subviewArray objectAtIndex:(i-1)];
                validateLabel.textColor = customColor;
                
            }else if([subViewItem tag]==100){
                
                if([[subviewArray objectAtIndex:0] isKindOfClass:[ValidatorLabel class]]){
                    validateLabel = [subviewArray objectAtIndex:0];
                    validateLabel.textColor = customColor;
                }
                
            }
        }
        subViewItem = nil;
        
    }
    
}


-(void)setValidatorString:(NSString *)validatorString {
    
    _validatorString = validatorString;
    
    _dataValidator = [Validator getValidator:validatorString];
    
    [self callbackInit];
    
    
}

-(id)getNextField{
    return _nextField;
}


- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if(self != nil) {
        
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        
    }
    return self;
}

-(id)init{
    
    if(self = [super init]){
        
        //NSLog(@"Init");
        [self setUPTextView];
        
    }
    return self;
    
}

-(NSString *)getValueString{
    
    if([self.text isEqualToString:@"Enter Text here..."]){
       self.text = @"";
    }
    return self.text;
}


-(void)setValueString:(NSString *)valueString{
    
    if([self.text isEqualToString:@""]){
        self.text = @"Enter Text here...";
    }else {
        self.text = valueString;
    }
}

-(void)setEnableTextView:(BOOL)isEnable{
    
    if(isEnable){
        self.backgroundColor = [UIColor whiteColor];
    }else {
        self.backgroundColor = [UIColor colorWithRed:239.0/255.0 green:239.0/255.0 blue:239.0/255.0 alpha:1.0];
        self.text=@"";
        
    }
    
    self.layer.borderWidth = 1.0f;
    self.layer.borderColor = BORDERCOLOR;
    
}

-(NSString *)xPath {
    return _xPath;
}

- (BOOL)textViewShouldBeginEditing:(UITextView *)textView{
    //NSLog(@"textViewShouldBeginEditing:");
    return YES;
}

- (void)textViewDidBeginEditing:(UITextView *)textView {
    //NSLog(@"textViewDidBeginEditing:");
    if([textView.text isEqualToString:@"Enter Text here..."]){
        textView.text = @"";
    }
    // hide custom language keyboard letters in keyboard
    if([textView keyboardType]==UIKeyboardTypeNumberPad|| [textView keyboardType]==UIKeyboardTypePhonePad ){
    }else {
        textView.keyboardType = UIKeyboardTypeASCIICapable; // boobalan added
    }
    self.activeField = textView;
    [self registerForKeyboardNotifications];
}


- (BOOL)textViewShouldEndEditing:(UITextView *)textView{
    //NSLog(@"textViewShouldEndEditing:");
    return YES;
}

- (void)textViewDidEndEditing:(UITextView *)textView{
    //NSLog(@"textViewDidEndEditing:");
    self.activeField = nil;
    [self unregisterForKeyboardNotification];
}


- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    
    
    return YES;
}
- (void)textViewDidChange:(UITextView *)textView{
    if([textView.text isEqualToString:@"Enter Text here..."]){
        textView.text = @"";
    }
    
    //NSLog(@"textViewDidChange:");
}


- (void)textViewDidChangeSelection:(UITextView *)textView{
    //NSLog(@"textViewDidChangeSelection:");
}


-(void)registerForKeyboardNotifications{
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardDidShow:)
                                                 name:UIKeyboardDidShowNotification
                                               object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillBeHidden:)
                                                 name:UIKeyboardWillHideNotification
                                               object:nil];
}


-(void)unregisterForKeyboardNotification {
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:UIKeyboardWillShowNotification
                                                  object:nil];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:UIKeyboardWillHideNotification
                                                  object:nil];
    
}


- (void)keyboardDidShow:(NSNotification *)notification
{
    //NSLog(@"Keyboard Show TextView");
    NSDictionary* info = [notification userInfo];
//    CGRect kbRect = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue];
    CGRect kbRect = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue]; // ios 11 keyboard issue fix

    // If you are using Xcode 6 or iOS 7.0, you may need this line of code. There was a bug when you
    // rotated the device to landscape. It reported the keyboard as the wrong size as if it was still in portrait mode.
    //kbRect = [self.view convertRect:kbRect fromView:nil];
    
    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0.0, 0.0, kbRect.size.height, 0.0);
    _currentScrollView.contentInset = contentInsets;
    _currentScrollView.scrollIndicatorInsets = contentInsets;
    
    CGRect aRect = _currentView.frame;
    aRect.size.height -= kbRect.size.height;
    //    if (!CGRectContainsPoint(aRect, self.activeField.frame.origin) ) {
    //        [_currentScrollView scrollRectToVisible:self.activeField.frame animated:YES];
    //    }
    
    UIInterfaceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation;
    if(orientation == UIInterfaceOrientationLandscapeRight || orientation == UIInterfaceOrientationLandscapeLeft){
        if (!CGRectContainsPoint(aRect, self.activeField.frame.origin) ) {
            CGPoint scrollPoint = CGPointMake(0.0, self.activeField.frame.origin.y);
            //        CGPoint moveScrollPoint = CGPointMake(scrollPoint.x, scrollPoint.y+200);
            //        //NSLog(@"move ::%f",moveScrollPoint.y);
            [_currentScrollView setContentOffset:scrollPoint animated:YES];
            //        [_currentScrollView setContentOffset:moveScrollPoint animated:YES];
        }}
    else { //self.activeField.frame.origin
        if (!CGRectContainsPoint(aRect, self.activeField.frame.origin) ) {
            CGPoint scrollPoint = CGPointMake(0.0, self.activeField.frame.origin.y-kbRect.size.height);
            //        CGPoint moveScrollPoint = CGPointMake(scrollPoint.x, scrollPoint.y+200);
            //        //NSLog(@"move ::%f",moveScrollPoint.y);
            [_currentScrollView setContentOffset:scrollPoint animated:YES];
            //        [_currentScrollView setContentOffset:moveScrollPoint animated:YES];
        }
    }
    
}

- (void)keyboardWillBeHidden:(NSNotification *)notification
{
    //NSLog(@"Keyboard hidden TextView");
    UIEdgeInsets contentInsets = UIEdgeInsetsZero;
    _currentScrollView.contentInset = contentInsets;
    _currentScrollView.scrollIndicatorInsets = contentInsets;
}




@end
