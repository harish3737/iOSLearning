//
//  UINavigationQueue.h
//  BcBs
//
//  Created by CSS Admin on 5/31/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//


#import <UIKit/UIKit.h>
#import "UIBaseViewController.h"
#import "UIBaseContainerViewController.h"

@interface UINavigationQueue : NSObject

+(void)push:(NSString *)baseVCString containerVC:(NSString *)containerVCString xibName:(NSString *)xibNameString;

+(void)pushClass:(id)baseVcClass containerVC:(id)containerVcClass xibName:(id)xibNameClass;


+(void)showNext:(UIBaseViewController *)baseVC;
+(void)showPrevious:(UIBaseViewController *)baseVC;
+(void)showCurrentContainerVC:(UIBaseViewController *)baseViewController;
+(void)showXibName:(UIBaseContainerViewController *)containerVC;

+(void)showInitialContainerViewcontroller:(UIBaseViewController *)baseViewController;

+(void)deleteAfter:(id)baseVC container:(id)containerVC xib:(id)xibClass;

+(void)clearNavigationQueue:(NSInteger)index;

+(id)getCurrentVCInfo;
+(id)getNextVCInfo;
+(id)getPreviousVCInfo;

//vrl added
+(void)gotoScreen:(NSInteger)indexValue BaseVC:(UIBaseViewController *)baseVC;
+(void)RemoveClassAtIndex:(NSUInteger)indexValue;
+(void)InsertClass:(Class)baseVcClass containerVC:(Class)containerVcClass xibName:(Class)xibNameClass index:(NSUInteger)indexValue;
+(void)deleteNextScreens:(id)baseVC container:(id)containerVC xib:(id)xibClass;

+(NSUInteger)getCurrentVCIndex;

+(NSMutableArray *)getPushlistArray;

+(void)assignCurrentIndex:(NSInteger)index;

@end
