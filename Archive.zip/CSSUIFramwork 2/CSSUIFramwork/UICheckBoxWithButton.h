//
//  UICheckBoxWithButton.h
//  CSSUIFramwork
//
//  Created by CSS Admin on 7/25/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UICheckBox.h"
#import "ValidatorLabel.h"
#import "Validator.h"
#import "UICGSizeConstraints.h"
#import "UIMultiLingualButton.h"


@interface UICheckBoxWithButton : UIView


@property (strong, nonatomic) IBOutlet UICheckBoxWithButton *checkboxButtonView;

@property (strong, nonatomic) IBOutlet UICheckBox *checkBoxButton;

@property (strong, nonatomic) IBOutlet UIMultiLingualButton *contentButton;

@property (nonatomic,strong) NSString *xPath;



-(NSString *)getValueString;

- (IBAction)contentTapAction:(id)sender;


@end
