//
//  UICheckBoxGrouped.h
//  CSSUIFramwork
//
//  Created by CSS Admin on 12/6/18.
//  Copyright © 2018 csscorp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Validator.h"
#import "UICallback.h"
#import "ValidatorLabel.h"

@protocol UICheckBoxGroupedDelegate <NSObject>

@optional
-(void)changeStateOnButtonTapped:(id)radioButton;

@end

IB_DESIGNABLE

typedef void(^ActionBlock)(id sender, id parent);


@interface UICheckBoxGrouped : UIButton

@property (nonatomic,assign)id<UICheckBoxGroupedDelegate> delegate;

@property (strong,nonatomic) IBInspectable UIImage *selectedImage;
@property (strong,nonatomic) IBInspectable UIImage *unSelectedImage;

@property (strong,nonatomic) IBInspectable NSString *groupName;
@property (nonatomic) IBInspectable NSUInteger optionsIndex;
@property (nonatomic) IBInspectable BOOL isNoneOptions;

@property (nonatomic) BOOL buttonSelected;


@property (nonatomic,strong) NSString *validatorString;
@property (nonatomic,strong) DataValidator dataValidator;
@property (nonatomic,strong) id nextField;

@property (copy) UICallback *callback;
@property (strong,nonatomic) NSString *xPath;

@property (nonatomic,strong)ActionBlock actionblock;
@property (nonatomic, strong) id parent;

@property (nonatomic,strong) NSString *selectorClassBlock;



-(BOOL)isRadioButtonSelected;
-(void)setRadioButtonSelected:(BOOL)checked;

-(id)getNextField;

-(BOOL)validate;

-(NSString *)getValueString;

-(NSString *)xPath;

-(void)redioActionBase :(id)sender;

-(void)reset;

-(void)setValueString:(NSString *)valueString;

-(UICheckBoxGrouped *)getActiveButton;

-(void)resetByGroupName:(NSString *)groupName;

-(UICheckBoxGrouped *)getActiveButtonByGroupName:(NSString *)groupName;

@end
