//
//  UIPopOverContentViewController.h
//  SampleBCBSPOC
//
//  Created by CSS Admin on 5/26/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol UIPopOverDisplayDelegate <NSObject>

@optional
-(void)getSelectedTextString:(NSString *)selectedText;

@end
@interface UIPopOverContentViewController : UIViewController <UITableViewDataSource,UITableViewDelegate,UIPopoverPresentationControllerDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (strong,nonatomic) NSMutableArray *contentListArray;
@property (nonatomic) BOOL isMultipleSelection;
@property (nonatomic) BOOL isDatePicker;
@property (nonatomic,strong) NSString *selectedString;
@property (nonatomic,assign) id <UIPopOverDisplayDelegate> delegate;
@property (nonatomic,strong) UIDatePicker *datePicker;
@property (nonatomic) BOOL isPopOverBirthDate;
@property (nonatomic) BOOL isPlanDropDown;



@end
