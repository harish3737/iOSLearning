//
//  UIDatePickerView.h
//  CSSUIFramwork
//
//  Created by CSS Admin on 5/23/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import <UIKit/UIKit.h>

IB_DESIGNABLE
@interface UIDatePickerView : UIView
@property (weak, nonatomic) IBOutlet UIDatePickerView *datePickerButtonView;

@end
