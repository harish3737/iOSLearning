//
//  LanguageCentral.m
//  CSSUIFramwork
//
//  Created by CSS Admin on 4/6/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import "LanguageCentral.h"

#define ENGLISH @"en"
#define SPANISH @"es"

static NSString *language_english = ENGLISH;
@implementation LanguageCentral


+(NSString *)internalizeString{
    
    return language_english;
}

+(void)setInternalizeString:(NSString*)languageString {
    
    language_english = languageString;
}

+(NSString *)languageSelectedString:(NSString *)key{
    
    NSBundle *languageBundle = [NSBundle bundleWithPath:[self pathForLanguageSelected:[self internalizeString]]];
    NSString *str = [languageBundle localizedStringForKey:key value:@"" table:nil];
    return str;
    
    
}


+(NSString *)pathForLanguageSelected:(NSString*)languageName{
    
    
    // you check in application
    NSBundle *bundle = [NSBundle mainBundle];
    
    // you check in Unit test
//    NSBundle *bundle = [NSBundle bundleForClass:[self class]];
    
    
    NSString *path = [bundle pathForResource:languageName ofType:@"lproj"];
    
    return path;
}


@end
