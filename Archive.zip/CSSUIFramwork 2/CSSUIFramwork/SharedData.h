//
//  SharedData.h
//  CSSUIFramwork
//
//  Created by CSS Admin on 7/12/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SharedData : NSObject
@property (nonatomic,strong) NSString *forwardNextButtonTitle;
@property (nonatomic) NSUInteger nextProgressIndex;

@property (nonatomic,strong) NSString *previousNextButtonTitle;
@property (nonatomic) NSUInteger backProgressIndex;


@end
