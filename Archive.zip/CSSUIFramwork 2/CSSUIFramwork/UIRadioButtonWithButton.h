//
//  UIRadioButtonWithButton.h
//  CSSUIFramwork
//
//  Created by CSS Admin on 7/25/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIRadioButton.h"
#import "UICGSizeConstraints.h"
#import "UIMultiLingualButton.h"


@interface UIRadioButtonWithButton : UIView<UIRadioButtonDelegate>

@property (strong, nonatomic) IBOutlet UIRadioButtonWithButton *radioBtnView;
@property (strong, nonatomic) IBOutlet UIRadioButton *radioButton;

@property (strong, nonatomic) IBOutlet UIMultiLingualButton *contentButton;

@property (nonatomic,strong) NSString *xPath;

- (IBAction)contentTapAction:(id)sender;

@end
