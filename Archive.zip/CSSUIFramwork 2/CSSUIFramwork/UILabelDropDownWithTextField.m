//
//  UILabelDropDownWithTextField.m
//  CSSUIFramwork
//
//  Created by CSS Admin on 6/17/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import "UILabelDropDownWithTextField.h"

#define BORDERCOLOR [UIColor colorWithRed:(204.0/255.0) green:(204.0/255.0) blue:(204.0/255.0) alpha:1.0f].CGColor

@implementation UILabelDropDownWithTextField
@synthesize headingLabel,userTextField,dropDownBtnView,dropDownTextFieldView;
@synthesize xPath,confirmImageView;
@synthesize optionalButton;

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    
   
    [super drawRect:rect];
}

-(instancetype)initWithCoder:(NSCoder *)aDecoder {
    
    self = [super initWithCoder:aDecoder];
    if(self){
        
         [self loadXibFile];
    }
    return self;
}

-(instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if(self){
        [self loadXibFile];
    }
    return self;
}

-(void)loadXibFile  {
    
    [[NSBundle mainBundle]loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
    self.bounds = self.dropDownTextFieldView.bounds;
    [self addSubview:self.dropDownTextFieldView];
    optionalButton.tag = 500;
    confirmImageView.hidden = YES;
    
    [self initializeProperty];
}


-(void)initializeProperty {
    
    //NSLog(@"UILabelDropDownwithTextField");
    
    dropDownBtnView = [[UIDropDown alloc]init];
    dropDownBtnView.isMultipleSelection = NO;
    dropDownBtnView.isDatePickerShow = NO;
    dropDownBtnView.contentArray = [NSMutableArray arrayWithObjects:@"Home",@"Mobile", nil];
    dropDownBtnView.confirmImgView.hidden = YES;
    [self.dropDownTextFieldView addSubview:dropDownBtnView];
    
    [dropDownBtnView setTranslatesAutoresizingMaskIntoConstraints:NO];
    
    
    [dropDownTextFieldView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-10-[dropDownBtnView(125)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(dropDownBtnView)]];
    
    [dropDownTextFieldView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[headingLabel(25)]-5-[dropDownBtnView(50)]->=10-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(dropDownBtnView,headingLabel)]];
    
    [dropDownTextFieldView setNeedsUpdateConstraints];
    [dropDownTextFieldView layoutIfNeeded];


    userTextField = [[ValidatorTextField alloc]init];
    userTextField.layer.borderWidth = 1.0f;
    userTextField.layer.borderColor = BORDERCOLOR;
    userTextField.tag = 100; //for identify textfield
    //vrl
    [userTextField setFont:[UIFont fontWithName:@"Arial" size:20.0]];
    userTextField.textColor=[UIColor colorWithRed:(204/255.f) green:(204/255.f) blue:(204/255.f) alpha:1.0];
    [dropDownTextFieldView addSubview:userTextField];
    
    [userTextField setTranslatesAutoresizingMaskIntoConstraints:NO];
    
    
    [dropDownTextFieldView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:[dropDownBtnView]-30-[userTextField]-25-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(userTextField,dropDownBtnView)]];
    
    [dropDownTextFieldView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[headingLabel(25)]-5-[userTextField(50)]->=10-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(dropDownBtnView,headingLabel,userTextField)]];
    
    [dropDownTextFieldView setNeedsUpdateConstraints];
    [dropDownTextFieldView layoutIfNeeded];
    
    
}

-(void)awakeFromNib {
    
    
    [super awakeFromNib];
}

-(NSString *)getValueString{
	return @"_";
}

-(NSString *)xPath {
	return xPath;
}



-(void)setEnabled:(BOOL)enabled{
	//NSLog(@"UILabelDropDownTextField setEnable ::%d",enabled);
//	dropDownTextFieldView.confirmImageView.hidden = YES;
	confirmImageView.hidden = YES;
	[userTextField setEnableTextField:enabled];
	if(enabled){
		[dropDownBtnView setenabled];
	}else {
		[dropDownBtnView setdisabled];
	}
}

-(void)setUserInteractionEnabled:(BOOL)userInteractionEnabled{
	[userTextField setUserInteractionEnabled:userInteractionEnabled];
	[dropDownBtnView setUserInteractionEnabled:userInteractionEnabled];
}

@end
