//
//  UIRenderer.m
//  CSSUIFramwork
//
//  Created by CSS Admin on 6/9/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import "UIRenderer.h"
#import "UIBaseContainerViewController.h"
#import "Validator.h"
#import "ValidatorTextField.h"
#import "UIDropDown.h"
#import "UICheckBox.h"
#import "UIRadioButton.h"


static id parentClassObj;
@implementation UIRenderer

//vrl added
+(void)renderPlistToView:(id)classObject plist:(NSString *)plistName viewObject:(id)viewObject appConfig:(NSMutableDictionary *)appConfig extraData:(id)extraData{
    
//    NSLog(@"Parent Class ::%@",classObject);
    
    parentClassObj = classObject;
    
    [Validator setAppConfigPlanData:appConfig];
    [Validator setExtraData:extraData];
    
    NSString *plistFileName = [NSString stringWithFormat:@"%@.plist",plistName];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask,YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *path = [documentsDirectory stringByAppendingPathComponent:plistFileName];
    
    if(![[NSFileManager defaultManager] fileExistsAtPath:path]){
                NSLog(@"Plist File Not Exist");
        path = [[NSBundle mainBundle]pathForResource:plistName ofType:@"plist"];
                NSLog(@"Plist path ::%@",path);
    }

    NSMutableDictionary *data = [[NSMutableDictionary alloc]initWithContentsOfFile:path];
    
    if([data valueForKey:@"VCConfiguration"]!=nil){
        NSDictionary *VCConfigDict = [data valueForKey:@"VCConfiguration"];
        if(VCConfigDict!=nil){
            [self loadVCConfiguration:classObject dictionary:VCConfigDict];
        }
    }
    
    [self loadContentToViewObject:classObject subviewObj:viewObject plistData:[data objectForKey:@"view1"]];
}

+(void)renderPlist:(id)classObject plist:(NSString *)plistName {
    
     parentClassObj = classObject;
         NSString *plistFileName = [NSString stringWithFormat:@"%@.plist",plistName];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask,YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *path = [documentsDirectory stringByAppendingPathComponent:plistFileName];
    
    if(![[NSFileManager defaultManager] fileExistsAtPath:path]){
        
//        //NSLog(@"Plist File Not Exist");
        path = [[NSBundle mainBundle]pathForResource:plistName ofType:@"plist"];
//        //NSLog(@"Plist path ::%@",path);
        
    }
NSMutableDictionary *data = [[NSMutableDictionary alloc]initWithContentsOfFile:path];
	
	
    
    if([data valueForKey:@"VCConfiguration"]!=nil){
        NSDictionary *VCConfigDict = [data valueForKey:@"VCConfiguration"];
        if(VCConfigDict!=nil){
            [self loadVCConfiguration:classObject dictionary:VCConfigDict];
        }
    }
    
    for (NSString *objString in data) {
        
        //NSLog(@"objString ::%@",objString);
        
        if([objString isEqualToString:@"VCConfiguration"]){
//            NSDictionary *VCConfigDict = [data valueForKey:@"VCConfiguration"];
//            if(VCConfigDict!=nil){
//                [self loadVCConfiguration:classObject dictionary:VCConfigDict];
//            }
            
        }else if([objString isEqualToString:@"Views"]){
            
            NSMutableDictionary *viewsDict = [data valueForKey:@"Views"];
            if(viewsDict!=nil){
                for(NSString *viewString in viewsDict){
                    
                [self loadSubViewContent:classObject subviewObj:viewString plistData:viewsDict];
                }
            }
            
        }else if([objString isEqualToString:@"objNavigation"]){
            NSDictionary *VCConfigDict = [data valueForKey:@"objNavigation"];
            if(VCConfigDict!=nil){
                [self loadVCConfiguration:classObject dictionary:VCConfigDict];
            }
            
        }
        else {
            
            [self loadSubViewContent:classObject subviewObj:objString plistData:data];
        }
        
    
    }
    
}

//vrl added
+(void)loadContentToViewObject:(id)classObject subviewObj:(id)parentObject plistData:(NSDictionary *)parentDict {
    
//    NSLog(@"new classObject ::%@",classObject);
//    NSLog(@"new parentObject ::%@",parentObject);
//    NSLog(@"new ParentDict ::%@",parentDict);
    
    [self  addChildViewToParentView:parentObject childDictionary:parentDict container:classObject];
}

+(void)loadSubViewContent:(id)classObject subviewObj:(NSString *)objString plistData:(NSMutableDictionary *)data {
    
    NSDictionary *parentDict;
    id parentObject;
    parentObject = [classObject valueForKey:objString]; //multipleView
    //        //NSLog(@"parentObj ::%@",parentObject);
    
    
    parentDict = [data valueForKey:objString];
//    [self addChildViewToParentView:parentObject childDictionary:parentDict container:classObject]; //old code
    
     [self loadContentToViewObject:classObject subviewObj:parentObject plistData:parentDict];//new method for preview mode handling
}

+(void)loadVCConfiguration:(id)viewController dictionary:(NSDictionary *)dictionary{
    
    UIBaseContainerViewController *container = viewController;
    [self renderChildPlist:container plistDictionary:[dictionary copy]];
}

+(void)addChildViewToParentView:(id)parentObject childDictionary:(NSDictionary *)childDict container:(UIBaseContainerViewController *)container{
    
    id tempParentObject = parentObject;
    NSDictionary *subChildDict;
    id childObject;
    
    NSDictionary *metrics =@{@"leading":container.sizeConstraints.leadingSpace,
                             @"trailing":container.sizeConstraints.trailingSpace,
                             @"top":container.sizeConstraints.topSpace,
                             @"bottom":container.sizeConstraints.bottomSpace,
                             @"width":container.sizeConstraints.width,
                             @"height":container.sizeConstraints.height,
                             @"vertical":container.sizeConstraints.verticalSpace,
                             @"horizontal":container.sizeConstraints.horizontalSpace};


    //NSLog(@"Metrics ::%@",metrics);
    
//    for(NSString *numberString in childDict ){
    
    for(int i=1;i<([childDict allKeys].count)+1;i++){
         NSLog(@"numberString ::%d",i);
        
        subChildDict = [childDict valueForKey:[NSNumber numberWithInt:i].stringValue];
        
        
        for(NSString *childstring in subChildDict){
            
            //vrl added new for preview field validation
            if([[subChildDict valueForKey:childstring]valueForKey:@"comparator"]) {
//                NSLog(@"subchildDcit ::%@",[subChildDict valueForKey:childstring]);
                if(![Validator getValidator:[[subChildDict valueForKey:childstring]valueForKey:@"comparator"]]([subChildDict valueForKey:childstring])) {
                    continue;
                }
            }
//              NSLog(@"childString ::%@",childstring);
            childObject = [[NSClassFromString(childstring) alloc] init];
//            NSLog(@"childObject ::%@",childObject);
           
            [childObject setBackgroundColor:[UIColor blueColor]];
            NSLog(@"%@",subChildDict);
            [self renderChildPlist:childObject plistDictionary:[subChildDict valueForKey:childstring]];
            
            
            [parentObject addSubview:childObject];
            
           
            
            [childObject setTranslatesAutoresizingMaskIntoConstraints:NO];
            
            
//            [parentObject addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-100-[childObject]-100-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(childObject)]];
        [parentObject addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-leading-[childObject]-trailing-|" options:0 metrics:metrics views:NSDictionaryOfVariableBindings(childObject)]];
            if(i==1){
                
//                [parentObject addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-20-[childObject(>=95)]->=20-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(childObject)]];
                
        [parentObject addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-top-[childObject(>=height)]->=bottom-|" options:0 metrics:metrics views:NSDictionaryOfVariableBindings(childObject)]];
            }else {
                
//                 [parentObject addConstraints:[NSLayoutConstraint  constraintsWithVisualFormat:@"V:[tempParentObject(>=95)]-20-[childObject(>=95)]->=20-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(childObject,tempParentObject)]];
                
//        [parentObject addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[tempParentObject(>=height)]-20-[childObject(>=height)]->=bottom-|" options:0 metrics:metrics views:NSDictionaryOfVariableBindings(childObject,tempParentObject)]];
            [parentObject addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[tempParentObject(>=height)]-vertical-[childObject(>=height)]->=bottom-|" options:0 metrics:metrics views:NSDictionaryOfVariableBindings(childObject,tempParentObject)]];
            }
            
            [parentObject setNeedsUpdateConstraints];
            [parentObject layoutIfNeeded];
            tempParentObject = childObject;
            
        }

        
    }
    
}





+(void)renderChildPlist:(id)baseObject plistDictionary:(NSMutableDictionary *)plistDict {
    
    NSLog(@"base Object:: %@ ---- \n Dict ::%@",baseObject,plistDict);
    for(NSString *keyString in [plistDict allKeys]){
        NSLog(@"%@",plistDict);
        
        id childObject = [plistDict valueForKey:keyString];
        
//        NSLog(@"Child object ::%@",childObject);
        
        
        if([keyString isEqualToString:@"editButton"]){
            
            if([childObject valueForKey:@"comparator"]) {
                
                if(![Validator getValidator:[childObject valueForKey:@"comparator"]](childObject)) {
                    NSLog(@"working comparator validator");
                    [[baseObject valueForKey:@"editButton"] setHidden:YES];
//                    continue;
                }
            }
        }
        
         if(![childObject isKindOfClass:[NSDictionary class]]){
        
            
            if([keyString isEqualToString:@"selectorClassBlock"]) {
//                NSLog(@"Key String ::%@",keyString);
                [baseObject setValue:parentClassObj forKey:@"parent"];
//                [baseObject setParent:parentClassObj];

            }
            [baseObject setValue:childObject forKey:keyString];

        }else {
            
            [self renderChildPlist:[baseObject valueForKey:keyString]  plistDictionary:childObject];
        }
        
    }
    
    
}


+(id)getComponentAtIndex:(NSUInteger)index{
    
    id currentItem = [Validator headItem];
   
    for (int i=1;i<index;i++){
        NSLog(@"%@:::%@",i,currentItem);
        currentItem = [currentItem getNextField];
    }
    
    return currentItem;
}

+ (void) stretchToSuperView:(UIView*) view {
    view.translatesAutoresizingMaskIntoConstraints = NO;
    view.bounds = view.superview.bounds;
    NSDictionary *bindings = NSDictionaryOfVariableBindings(view);
    NSString *formatTemplate = @"%@:|[view]|";
    for (NSString * axis in @[@"H",@"V"]) {
        NSString * format = [NSString stringWithFormat:formatTemplate,axis];
        NSArray * constraints = [NSLayoutConstraint constraintsWithVisualFormat:format options:0 metrics:nil views:bindings];
        [view.superview addConstraints:constraints];
    }
    
}


@end
