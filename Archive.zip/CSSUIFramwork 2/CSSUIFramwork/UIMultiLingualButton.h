//
//  UIMultiLingualButton.h
//  SampleBCBSPOC
//
//  Created by CSS Admin on 4/5/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Validator.h"

typedef void(^ActionBlock)(id sender, id parent);

@interface UIMultiLingualButton : UIButton

@property(nonatomic) IBInspectable NSString *localizationKey;

@property (nonatomic,strong)ActionBlock actionblock;

@property (nonatomic, strong) id parent;

@property (nonatomic,strong) NSString *selectorClassBlock;

@property (nonatomic,strong) NSString *methodName;

@property (nonatomic,strong) NSString *pageName;

@property (nonatomic,strong) NSString *nextToName;

@property (nonatomic,strong) NSString *xPath;
@property (nonatomic,strong) NSString *comparator;
@property (nonatomic,weak) DataValidator dataValidator;
@property(nonatomic,strong) NSString *compareValue;

-(NSString *)getValueString;
-(NSString *)xPath;



@end
