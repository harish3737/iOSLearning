//
//  UIDropDown.m
//  SampleBCBSPOC
//
//  Created by CSS Admin on 5/20/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import "UIDropDown.h"
#import "ValidatorLabel.h"

#define REDCOLOR [UIColor colorWithRed:(240.0/255.0) green:(108.0/255.0) blue:(108.0/255.0) alpha:1.0f]
#define TEXTCOLOR [UIColor colorWithRed:(153.0/255.0) green:(153.0/255.0) blue:(153.0/255.0) alpha:1.0f]
#define BORDERCOLOR [UIColor colorWithRed:(204.0/255.0) green:(204.0/255.0) blue:(204.0/255.0) alpha:1.0f].CGColor

@implementation UIDropDown
@synthesize dropDownTextLabel,dropDownImageView,dropDownView;
@synthesize isDatePickerShow,isMultipleSelection,contentArray,dropDownButton;
@synthesize delegate,titleString,xPath,confirmImgView,isBirthDate,popoverVC,actionBlock;
@synthesize isPlanDropDown;

@synthesize isAutoEnableWRTData;

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code

    self.dropDownView.layer.borderColor = BORDERCOLOR;
    self.dropDownView.layer.borderWidth = 1.0f;

    [super drawRect:rect];
}

-(void)awakeFromNib {
    
    _dataValidator = [Validator NoValidation];
    _callback = [UICallback getDummyUICallback];

//    actionBlock = ^(id sender,id parent){
//        
//    };
    
    isAutoEnableWRTData = NO;  //vrl newly added  on Dec13,2018
    [self linkChain];
    
    [super awakeFromNib];
    
}

-(void)linkChain {
    
    if([Validator tailItem]!=nil) {
        
        [[Validator tailItem] setNextField:self];
    }
    [Validator tailItem:self];
}

-(void)setValidatorString:(NSString *)validatorString {
    
    _validatorString = validatorString;
    _dataValidator = [Validator getValidator:validatorString];
    //NSLog(@"BlocK ::%@",_dataValidator);
    [self callBackInitialize];
}

-(void)callBackInitialize {
    
    _callback = [[UICallback alloc]initWithUICallbacks:^(id data){
        //NSLog(@"callback sucess dropDown:%@",data);
        UIDropDown *successDropdown = data;
        successDropdown.layer.borderWidth = 1.0f;
        successDropdown.layer.borderColor = BORDERCOLOR;
        successDropdown.confirmImgView.hidden = NO;
        [successDropdown changeFontColor:successDropdown color:TEXTCOLOR];
        
    } :^(id data){
        //NSLog(@"callback failed dropDown:%@",data);
        UIDropDown *failedDropdown = data;
        failedDropdown.layer.borderWidth = 1.0f;
        failedDropdown.layer.borderColor = [UIColor colorWithRed:(240.0/255.0) green:(108.0/255.0) blue:(108.0/255.0) alpha:1.0f].CGColor;
        failedDropdown.confirmImgView.hidden = YES;
        [failedDropdown changeFontColor:failedDropdown color:REDCOLOR];
    }];
    
}


//change font color based on success or failure
-(void)changeFontColor:(UIDropDown *)dropdownObj color:(UIColor *)color {
    NSArray *dropdownSubArray = [dropdownObj superview].subviews;
    for (int i=0;i<dropdownSubArray.count;i++){
        
        if([[dropdownSubArray objectAtIndex:i]isKindOfClass:[UIDropDown class]]){
            
            if([[dropdownSubArray objectAtIndex:(i-1)] isKindOfClass:[ValidatorLabel class]]){
                ValidatorLabel *validateLabel = [dropdownSubArray objectAtIndex:(i-1)];
                validateLabel.textColor = color;
            }
        }
    }
    
}



-(instancetype)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if(self){
    
        [self loadDropDownXib];

    }
    return self;
    
}

-(instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if(self){
        [self loadDropDownXib];
    }
    return self;
    
}

-(void)loadDropDownXib {
    
    //1.Load a Xib file
    [[NSBundle mainBundle]loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
    
    //2. Adjust a bounds
    self.bounds = self.dropDownView.bounds;
    
    //3. Add subview
    [self addSubview:self.dropDownView];
    
    titleString = [NSString stringWithFormat:@"%@",@"Select"];
    confirmImgView.hidden = YES;

     isAutoEnableWRTData = NO; //vrl newly added Dec13,2018
    
    actionBlock = ^(id sender,id parent){
        
    };
}


-(void)setdisabled{
    
	self.dropDownView.userInteractionEnabled = NO;
	self.dropDownView.alpha = 1.0f;
	self.dropDownView.backgroundColor =  [UIColor colorWithRed:239.0/255.0 green:239.0/255.0 blue:239.0/255.0 alpha:1.0];
	self.dropDownView.layer.borderWidth = 1.0f;
	self.dropDownView.layer.borderColor = BORDERCOLOR;
	[self.dropDownView setNeedsDisplay];
	[self.dropDownView setNeedsLayout];
	[self.dropDownView layoutIfNeeded];
//	self.dropDownView.confirmImgView.hidden = YES;
    [self changeFontColor:self color:TEXTCOLOR];
    
    //NSLog(@"contentArray ::%@",self.contentArray);
    
    self.layer.borderColor = BORDERCOLOR;
    self.layer.borderWidth = 1.0f;
    
    if(self.contentArray.count==0){
        [self setTitleString:@"Select"];
        self.selectedString = @"";
        
    }
	
}
-(void)setenabled {
    
    self.dropDownView.userInteractionEnabled = YES;
    self.dropDownView.alpha = 1.0f;
    self.dropDownView.backgroundColor = [UIColor whiteColor];
    self.dropDownView.layer.borderWidth = 1.0f;
    self.dropDownView.layer.borderColor = BORDERCOLOR;
    [self.dropDownView setNeedsDisplay];
    [self.dropDownView setNeedsLayout];
    [self.dropDownView layoutIfNeeded];
    [self changeFontColor:self color:TEXTCOLOR]; //vrl12
    
    self.layer.borderColor = BORDERCOLOR;
    self.layer.borderWidth = 1.0f;
    
}

-(void)resetTitle;{
    
    titleString = @"Select";
    [dropDownTextLabel setText:@"Select"];
    _selectedString = @"";
}


- (IBAction)DropDownAction:(id)sender {
    
    
    //NSLog(@"clicked DropDown Action");
	
	UIViewController *getCurrentVC = [self getCurrentViewController];
	//NSLog(@"CurrentViewController ::%@",getCurrentVC);
	[getCurrentVC.view endEditing:YES];
	
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    
    //Load popover content
    popoverVC = [storyboard instantiateViewControllerWithIdentifier:@"UIPopOverContentViewController"];
    popoverVC.isDatePicker = isDatePickerShow;
	
    popoverVC.isPopOverBirthDate = isBirthDate;
    popoverVC.isPlanDropDown = isPlanDropDown;
    popoverVC.selectedString = self.dropDownTextLabel.text;
    popoverVC.contentListArray = contentArray;
    popoverVC.isMultipleSelection = isMultipleSelection;
    popoverVC.delegate = self;
//	popoverVC.preferredContentSize = CGSizeMake(300,300);
    //present the controller
    popoverVC.modalPresentationStyle = UIModalPresentationPopover;
	
    [getCurrentVC presentViewController:popoverVC animated:YES completion:nil];
    
    //configure popover presentation controller
    UIPopoverPresentationController *presentController = [popoverVC popoverPresentationController];
    
    //    presentController.delegate = self;
    presentController.permittedArrowDirections = UIPopoverArrowDirectionUp;
    
    presentController.sourceView = sender;
    presentController.sourceRect = CGRectMake((self.dropDownView.frame.size.width/2.0),(self.dropDownView.frame.size.height - 5), 5, 5);
    
    
}
// delegate method for UIPopOverContentViewController
-(void)getSelectedTextString:(NSString *)selectedText {
    _selectedString = selectedText;
    dropDownTextLabel.text = selectedText;
    [self.delegate dropDownLabelText:dropDownTextLabel.text tag:self.tag];
    actionBlock(selectedText,self.parent);
}

-(UIViewController *)getCurrentViewController {
    
    id rootViewController = [UIApplication sharedApplication].keyWindow.rootViewController;
    
    if(rootViewController){
    UIViewController *currentViewController = rootViewController;
    
    while( currentViewController.presentedViewController != nil ) {
        currentViewController = currentViewController.presentedViewController;
    }
    return currentViewController;
    }
    return nil;
}


-(id)getNextField{
    return _nextField;
}


-(void)setTitleString:(NSString *)title {
    
    [dropDownTextLabel setText:title];
}

-(BOOL)validate{
    //NSLog(@"validate DropDown");
    //NSLog(@"_selectedString ::%@",_selectedString);
    if(_selectedString!=nil && _selectedString.length>0){
        return YES;
    }
    return NO;
}

-(NSString *)getValueString{
	
    return _selectedString;
}

-(void)setValueString:(NSString *)valueString{
    
    NSLog(@"DropDown backData::%@",valueString);
    dropDownTextLabel.text = valueString;
    if(![valueString containsString:@"Select"]){
        _selectedString = valueString;
        
        if(isAutoEnableWRTData && valueString.length>0) { //vrl newly added on Dec13, 2018
            [self setenabled];
        }
    }
}

-(NSString *)xPath {
	return xPath;
}


@end
