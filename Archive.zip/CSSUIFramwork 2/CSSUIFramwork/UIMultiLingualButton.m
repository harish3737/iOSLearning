//
//  UIMultiLingualButton.m
//  SampleBCBSPOC
//
//  Created by CSS Admin on 4/5/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import "UIMultiLingualButton.h"
#import "LanguageCentral.h"

@implementation UIMultiLingualButton
@synthesize actionblock,parent,xPath;


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    //     //NSLog(@"ValidateTextbutton::%@",self.titleLabel.text);
    [super drawRect:rect];
    
}

- (id)initWithCoder:(NSCoder *)aDecoder {
     self = [super initWithCoder:aDecoder];
    if(self != nil) {
        self.titleLabel.numberOfLines = 0;
        self.titleLabel.lineBreakMode = NSLineBreakByWordWrapping;
        self.titleLabel.textAlignment = NSTextAlignmentLeft;
//        self.titleLabel.adjustsFontSizeToFitWidth = YES;
        
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        
    }
    return self;
}


-(CGSize)intrinsicContentSize {
    return [self.titleLabel sizeThatFits:CGSizeMake(self.titleLabel.preferredMaxLayoutWidth, CGFLOAT_MAX)];;
}
-(void)layoutSubviews {
    self.titleLabel.preferredMaxLayoutWidth = self.frame.size.width;
      [super layoutSubviews];
}

-(void)setLocalizationKey:(NSString *)localizationKey {
     _localizationKey = localizationKey;
      NSString *contentString = [LanguageCentral languageSelectedString:_localizationKey];
      NSString *titleText = (contentString.length>0)?contentString:_localizationKey;
      [self setTitle:titleText forState:UIControlStateNormal];
      [self sizeToFit];
}


-(void)setMethodName:(NSString *)methodName {
   
    _methodName = methodName;
    NSLog(@"***** Method Name :: %@ ********",_methodName);
   NSLog(@"***** button Parent ::: %@ *****",parent);
   
//    [self removeTarget:nil action:NULL forControlEvents:UIControlEventTouchUpInside];
    NSString *selName = [NSString stringWithFormat:@"%@",_methodName];
    SEL selector = NSSelectorFromString(selName);

//    [self addTarget:parent action:@selector(editIndexButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
    
     [self addTarget:parent action:selector forControlEvents:UIControlEventTouchUpInside];
}



-(void)awakeFromNib {
    
//     NSLog(@"text 4::%@",self.text);
    [super awakeFromNib];
    
    actionblock = ^(id sender,id parent){
        
    };
    
    _dataValidator = [Validator NoValidation];
}

-(NSString *)xPath {
    return xPath;
}

-(NSString *)getValueString{
    
    return @"-";
}


-(void)setComparator:(NSString *)Comparator {
    
    _comparator = Comparator;
    _dataValidator = [Validator getValidator:_comparator];                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
}

-(void)setCompareValue:(NSString *)compareValue {
    
    _compareValue = compareValue;
}


@end
