//
//  UILabelTitleDropDownView.m
//  SampleBCBSPOC
//
//  Created by CSS Admin on 5/10/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import "UILabelTitleDropDownView.h"
#import "UIDropDown.h"


static BOOL isDatePicker = NO;

@implementation UILabelTitleDropDownView
@synthesize titleLabel,dropDownCustomView,xPath;


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    
    [super drawRect:rect];
}



-(instancetype)initWithCoder:(NSCoder *)aDecoder {
    
    self = [super initWithCoder:aDecoder];
    
    if(self){
        
       [self loadLabeledButtonXibFile];
        
    }
    
    return self;
    
}

-(instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if(self){
        
        [self loadLabeledButtonXibFile];
        
    }
    return self;
    
}

-(void)loadLabeledButtonXibFile {
    
    //1. Load a Xib file
    [[NSBundle mainBundle]loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
    
    //2adjust bounds
    self.bounds = self.labeledButtonView.bounds;

    //3. Add a subview
    [self addSubview:self.labeledButtonView];
    
}


+(BOOL)isDatePicker{
   
    return isDatePicker;
}

+(void)setBooleanDatePicker:(BOOL)isDatePickerShow {
    
    isDatePicker = isDatePickerShow;
}


-(void)enableDropDownView{
    
    [dropDownCustomView setenabled];
}
-(void)disableDropDownView {


    [dropDownCustomView setdisabled];
}

-(void)resetDropDownTitle{
    
    [dropDownCustomView resetTitle];
}

-(NSString *)getValueString{
	
	return @"_";
}


-(NSString *)xPath {
	return xPath;
}


-(void)setEnabled:(BOOL)enabled{
	//NSLog(@"UILabeledButton setEnable ::%d",enabled);
	if(enabled){
		[dropDownCustomView setenabled];
	}else {
		[dropDownCustomView setdisabled];
	}
}

-(void)setUserInteractionEnabled:(BOOL)userInteractionEnabled {
	[dropDownCustomView setUserInteractionEnabled:userInteractionEnabled];
}

@end
