//
//  JsonOperation.m
//  FileOperation
//
//  Created by Ganesh on 11/07/16.
//  Copyright © 2016 CSS. All rights reserved.
//

#import "JsonOperation.h"

@implementation JsonOperation
{
	NSMutableDictionary *dict;

}

-(instancetype)init
{
//	NSString *path = [[NSBundle mainBundle] pathForResource:@"medigap_65_enroll" ofType:@"plist"];
//	dict = [[NSMutableDictionary alloc] initWithContentsOfFile:path];
////	[self setValue:@"data:email_confirmation:email_address" : @"boobalan@css.com"];
////	[self setValue:@"data:notice:options" : @"options 123"];
////	[self setValue:@"data:personal_info:age" : @"25"];
////	[self setValue:@"data:personal_info:sex" : @"Male"];
////	[self setValue:@"data:plan_details:plan_year" : @"2016"];
//	
//	
//	NSString *jsonString = [self getJsonStringByDictionary:dict];
//	//NSLog(@"jsonString ::%@",jsonString);
	
	return self;
}



-(id)setValue :(NSDictionary *)requestDict :(NSString *)xPath : (id)value
{
    
    
	NSDictionary *tmpDict = requestDict;
	NSArray *keysArray = [xPath componentsSeparatedByString:@":"];
   
	for(int i=0; i<[keysArray count]-1; i++)
	{
		tmpDict = [tmpDict objectForKey:[keysArray objectAtIndex:i]];
        NSLog(@"%@",tmpDict);
	}
    
    if([value isKindOfClass:[NSString class]]){
        value = [value stringByTrimmingCharactersInSet:
                 [NSCharacterSet whitespaceCharacterSet]];
    }
	
	[tmpDict setValue:value forKey:[keysArray objectAtIndex:[keysArray count]-1]];
    NSLog(@"Temp Dict ::%@",tmpDict);
	return requestDict;
}



-(NSString*)getJsonStringByDictionary:(NSDictionary*)dictionary{
	NSError *error;
	NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dictionary
													   options:NSJSONWritingPrettyPrinted
														 error:&error];
	return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
}




//-(id)assignValues : (NSString *)firstKey :(NSString *)secondKey :(NSString *)thirdKey :(NSString *)value{
//
//	dict[firstKey][secondKey][thirdKey] = value;
//	//NSLog(@"%@",dict);
//	return  dict;
//}


@end
