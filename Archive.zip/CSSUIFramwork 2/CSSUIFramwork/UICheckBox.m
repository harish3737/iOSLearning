//
//  UICheckBox.m
//  SampleBCBSPOC
//
//  Created by CSS Admin on 5/20/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import "UICheckBox.h"

#define REDCOLOR [UIColor colorWithRed:(240.0/255.0) green:(108.0/255.0) blue:(108.0/255.0) alpha:1.0f]
#define TEXTCOLOR [UIColor colorWithRed:(153.0/255.0) green:(153.0/255.0) blue:(153.0/255.0) alpha:1.0f]
#define DETAILTEXTCOLOR [UIColor colorWithRed:(102.0/255.0) green:(102.0/255.0) blue:(102.0/255.0) alpha:1.0f] //vrl13

@implementation UICheckBox
@synthesize actionblock,parent,unCheckedImage,checkedImage;


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    //NSLog(@"checkbox drawRect");
    [super drawRect:rect];

}

-(instancetype)initWithCoder:(NSCoder *)aDecoder {
    
    self = [super initWithCoder:aDecoder];
    if(self){
        
        [self setUp];
    }
    return self;
    
}

-(instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if(self){
        
        [self setUp];
       
    }
    return self;
}


-(void)setUp{
    
    //NSLog(@"checkbox setup");
    _checkboxState = NO;
    
    [self addTarget:self action:@selector(buttonTapped:) forControlEvents:UIControlEventTouchUpInside];
}



-(void)buttonTapped:(id)sender{
    [self updateUI];
	actionblock(sender,self.parent);
	
	
	
}


-(void)awakeFromNib {
     
 [self setImage:self.unCheckedImage forState:UIControlStateNormal];
	
	_dataValidator = [Validator NoValidation];
	_callback = [UICallback getDummyUICallback];
	
	actionblock = ^(id sender,id parent){
		
	};
	[self linkChain];
	
	[super awakeFromNib];
}


-(BOOL)validate{
	
    //NSLog(@"Validate checkBox::%d",_checkboxState);
    return _checkboxState;
    
}



-(BOOL)ischecked {
    
    return _checkboxState;
}

-(void)setChecked:(BOOL)checked {
    

    _checkboxState = !checked;
    
	[self updateUI];
	
}

-(void)updateUI{
	
	if (!_checkboxState) { //NO
		
		[self setImage:self.checkedImage forState:UIControlStateNormal];
		_checkboxState = YES;
		
	} else { // YES
		[self setImage:self.unCheckedImage forState:UIControlStateNormal];
		_checkboxState = NO;
		
	}
	
	
}

-(void)setNextField:(id)nextField {
	
    _nextField = nextField;
}

-(void)setValidatorString:(NSString *)validatorString {
    
    _validatorString = validatorString;

    _dataValidator = [Validator getValidator:validatorString];

    [self callBackInitialize];

}

-(void)linkChain {
    
    if([Validator tailItem]!=nil){
        
        [[Validator tailItem] setNextField:self];
    }
    [Validator tailItem:self];
}

-(void)callBackInitialize {
    
    _callback = [[UICallback alloc]initWithUICallbacks:^(id data){
        //NSLog(@"callback sucess CheckBox:%@",data);
        UICheckBox *successCheckBox = data;
        successCheckBox.layer.borderColor = [UIColor clearColor].CGColor;
        successCheckBox.layer.borderWidth = 1.0f;
        [successCheckBox changeLabelFontColor:successCheckBox color:DETAILTEXTCOLOR];
       
    } :^(id data){
        //NSLog(@"callback failed CheckBox:%@",data);
        UICheckBox *failedCheckBox = data;
       failedCheckBox.layer.borderColor =[UIColor colorWithRed:(240.0/255.0) green:(108.0/255.0) blue:(108.0/255.0) alpha:1.0f].CGColor;
        failedCheckBox.layer.borderWidth = 1.0f;
        [failedCheckBox changeLabelFontColor:failedCheckBox color:REDCOLOR];
    }];

}

-(void)changeLabelFontColor:(id)checkboxButton color:(UIColor *)customColor {
    
    
    NSArray *subviewArray = [checkboxButton superview].subviews;
    //NSLog(@"radioButton superview ::%@",[checkboxButton superview]);
    //NSLog(@"Array ::%@",subviewArray);
    
    for (int i=0;i<subviewArray.count;i++){
        
        id subViewItem = [subviewArray objectAtIndex:i];
        UIButton *contentButton = nil;
        if([subViewItem isKindOfClass:[UICheckBox class]]){
            
            if([[subviewArray objectAtIndex:(i+1)] isKindOfClass:[UIButton class]]){
                contentButton = [subviewArray objectAtIndex:(i+1)];
                [contentButton setTitleColor:customColor forState:UIControlStateNormal];
            }
        }
        subViewItem = nil;
        
    }
    
}


-(id)getNextField{
    return _nextField;
}

-(NSString *)getValueString{
	
    if(_checkboxState){
        return @"Yes";
    }else {
        return @"No";
    }
}

-(void)setValueString:(NSString *)valueString{
    
    if([valueString isEqualToString:@"Yes"]){
        [self setChecked:YES];
    }else {
        [self setChecked:NO];
    }
    
}

-(NSString *)xPath {
	return _xPath;
}

@end
