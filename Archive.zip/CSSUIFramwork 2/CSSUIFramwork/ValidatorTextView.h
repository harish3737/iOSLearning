//
//  ValidatorTextView.h
//  CSSUIFramwork
//
//  Created by CSS Admin on 8/9/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Validator.h"
#import "UICallback.h"

@interface ValidatorTextView : UITextView <UITextViewDelegate>

@property(nonatomic) IBInspectable NSString *localizationKey;

@property (strong, nonatomic) id nextField;
@property(nonatomic,strong)DataValidator dataValidator;
@property(nonatomic,strong) NSString *validatorString;

@property (nonatomic,strong) NSString *xPath;
@property (nonatomic) NSInteger keyboardTypeName;

@property(copy)UICallback *callback;

-(void)setSubmitHandler:(callbackBlock)submitHandler;
-(BOOL)validate;
-(void)linkChain;

-(id)getNextField;

-(NSString *)getValueString;
-(NSString *)xPath;

-(void)setValueString:(NSString *)valueString;
-(void)setEnableTextView:(BOOL)isEnable;
@end
