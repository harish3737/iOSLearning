//
//  UICheckBoxGrouped.m
//  CSSUIFramwork
//
//  Created by CSS Admin on 12/6/18.
//  Copyright © 2018 csscorp. All rights reserved.
//

#import "UICheckBoxGrouped.h"


#define REDCOLOR [UIColor colorWithRed:(240.0/255.0) green:(108.0/255.0) blue:(108.0/255.0) alpha:1.0f]
#define TEXTCOLOR [UIColor colorWithRed:(153.0/255.0) green:(153.0/255.0) blue:(153.0/255.0) alpha:1.0f]
#define DETAILTEXTCOLOR [UIColor colorWithRed:(102.0/255.0) green:(102.0/255.0) blue:(102.0/255.0) alpha:1.0f]


static NSMutableDictionary *activeRadioButtons;
static NSMutableArray *activeRadioBtnArray;

@implementation UICheckBoxGrouped
@synthesize delegate,xPath;
@synthesize actionblock,parent;

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    
    [super drawRect:rect];
}

-(instancetype)initWithCoder:(NSCoder *)aDecoder {
    
    self = [super initWithCoder:aDecoder];
    if(self){
        [self setUpActiveButton];
    }
    return self;
}

-(instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if(self){
        
        [self setUpActiveButton];
        
    }
    return self;
    
}

-(void)setUpActiveButton{
    
    activeRadioButtons = [[NSMutableDictionary alloc]init];
    activeRadioBtnArray = [[NSMutableArray alloc]init];
 
    _buttonSelected = NO;
    
    [self addTarget:self action:@selector(radioButtonTapped:) forControlEvents:UIControlEventTouchUpInside];
    
}


-(void)awakeFromNib {
    
    [self InitiatingValidatorBlock];
    
    [super awakeFromNib];
    
}

-(void)InitiatingValidatorBlock {

    [self setImage:_unSelectedImage forState:UIControlStateNormal];
    _dataValidator = [Validator NoValidation];
    _callback = [UICallback getDummyUICallback];
    
    actionblock = ^(id sender,id parent){
        
    };
    
    [self linkchain];
}

-(instancetype)init {
    
    self = [super init];
    if(self){
        
        [self InitiatingValidatorBlock];
    }
    return self;
}

-(void)linkchain {
    
    if ([Validator tailItem]!=nil){
        
        [[Validator tailItem] setNextField:self];
    }
    [Validator tailItem:self];
}

-(void)setValidatorString:(NSString *)validatorString {
    
//    NSLog(@"grouped ValidatorString ::%@",validatorString);
    _validatorString = validatorString;
    _dataValidator = [Validator getValidator:validatorString];
    //NSLog(@"Block ::%@",_dataValidator);
    [self callBackInitialize];
    
}


-(void)callBackInitialize {
    
    //vrl6
    _callback = [[UICallback alloc]initWithUICallbacks:^(id data){
        //NSLog(@"callback sucess radioButton:%@",data);
        UICheckBoxGrouped *successRadioButton = data;
        successRadioButton.layer.borderColor = [UIColor clearColor].CGColor;
        successRadioButton.layer.borderWidth = 1.0f;
        [successRadioButton changeLabelFontColor:successRadioButton color:DETAILTEXTCOLOR];
        
    } :^(id data){
        //NSLog(@"callback failed radiobutton:%@",data);
        UICheckBoxGrouped *failedRadioButton = data;
        failedRadioButton.layer.borderColor =[UIColor colorWithRed:(240.0/255.0) green:(108.0/255.0) blue:(108.0/255.0) alpha:1.0f].CGColor;
        failedRadioButton.layer.borderWidth = 1.0f;
        [failedRadioButton changeLabelFontColor:failedRadioButton color:REDCOLOR]; //vrl13
    }];
    
}


-(void)changeLabelFontColor:(UICheckBoxGrouped *)radiobutton color:(UIColor *)customColor {
    
    
    NSArray *subviewArray = [radiobutton superview].subviews;
    
    for (int i=0;i<subviewArray.count;i++){
        
        id subViewItem = [subviewArray objectAtIndex:i];
        UIButton *contentButton = nil;
        ValidatorLabel *contentLabel = nil;
        if([subViewItem isKindOfClass:[UICheckBoxGrouped class]]){
            
            if((i+1)<subviewArray.count){
                if([[subviewArray objectAtIndex:(i+1)] isKindOfClass:[UIButton class]]){
                    contentButton = [subviewArray objectAtIndex:(i+1)];
                    [contentButton setTitleColor:customColor forState:UIControlStateNormal];
                }
            }else {
                //                NSLog(@"No subview array");
            }
        }else if([subViewItem isKindOfClass:[ValidatorLabel class]]){
            contentLabel = [subviewArray objectAtIndex:i];
            [contentLabel setTextColor:customColor];
        }
        subViewItem = nil;
        
    }
    
}


-(void)setNextField:(id)nextField {
    
    _nextField = nextField;
}

-(IBAction)radioButtonTapped:(id)sender {
    
    [self redioActionBase:sender];
}

-(void)redioActionBase :(id)sender {
    
    //fetch the UICheckBoxGrouped class objects from Parent class
    [self getGroupedItemsDict:self.groupName];
    
    self.layer.borderColor = [UIColor clearColor].CGColor;
    self.layer.borderWidth = 1.0f;
    
    [self noneOptionsSelectedLogic];
    
    [activeRadioButtons setObject:self forKey:_groupName];
    
    actionblock(sender,self.parent);

}

-(void)updateCheckBoxUI {
    
    if(!_buttonSelected){ //NO
        
        [self setImage:_selectedImage forState:UIControlStateNormal];
        _buttonSelected = YES;
    }else { // YES
        [self setImage:_unSelectedImage forState:UIControlStateNormal];
        _buttonSelected = NO;
    }
    
    // delegate -> to disable / enable dropdown view and change the content button color
//     [delegate changeStateOnButtonTapped:self]; // old code need to remove for view loaded slowly
    
   
}
-(void)noneOptionsSelectedLogic {
    
    if (self.isNoneOptions) {

        // unchecked the all buttons other than none button
        [activeRadioBtnArray enumerateObjectsWithOptions:NSEnumerationReverse usingBlock:^(id obj, NSUInteger idx, BOOL *stop) {

            UICheckBoxGrouped *items = [obj valueForKey:@"checkBoxButton"];

            if(!items.isNoneOptions){
                [items setRadioButtonSelected:NO];
                 [items.delegate changeStateOnButtonTapped:items]; //vrl newly added on Dec13,2018
            }else {
                [items setRadioButtonSelected:YES];
            }
        }];
        
       
        
    }else {
        // unchecked the none options button
        UICheckBoxGrouped *lastitems = [[activeRadioBtnArray lastObject] valueForKey:@"checkBoxButton"];
        [lastitems setRadioButtonSelected:NO];
        
        //other than None Button , selected the checkbox
        [self updateCheckBoxUI];
        [self.delegate changeStateOnButtonTapped:self]; //vrl newly added on Dec13,2018
    }
    
}
-(BOOL)isRadioButtonSelected {
    
    return _buttonSelected;
}

-(void)setRadioButtonSelected:(BOOL)checked{
    
    _buttonSelected = !checked;

    [self updateCheckBoxUI];
    
}

-(UICheckBoxGrouped *)getActiveButton{
    
    return [activeRadioButtons objectForKey:_groupName];
}

-(id)getNextField{
    return _nextField;
}

-(BOOL)validate{
    
    return [self isRadioButtonSelected];
}

-(NSString *)getValueString{
    
    if(_buttonSelected){
        return @"Yes";
    }else {
        return @"No";
    }
    
}


-(void)setValueString:(NSString *)valueString{

    if([valueString isEqualToString:@"Yes"]){
        [self setRadioButtonSelected:YES];
    }else {
         [self setRadioButtonSelected:NO]; //new code
    }
}

-(NSString *)xPath {
    return xPath;
}

-(void)reset{
    
    [[activeRadioButtons objectForKey:_groupName] setRadioButtonSelected:NO];
    [activeRadioButtons removeObjectForKey: _groupName];
    
}

-(UICheckBoxGrouped *)getActiveButtonByGroupName:(NSString *)groupName{
    
    return [activeRadioButtons objectForKey:_groupName];
    
}

-(void)resetByGroupName:(NSString *)groupName{
    
    [[activeRadioButtons objectForKey:groupName] setRadioButtonSelected:NO];
    [activeRadioButtons removeObjectForKey: groupName];
    
}


-(void)getGroupedItemsDict:(NSString *)groupNameString {

    
    if (parent!=nil && activeRadioBtnArray.count==0) {
        
        // predicate using identifier   // IN is sames as "EqualToString" method
//        NSPredicate *groupNamePredicate = [NSPredicate predicateWithFormat:@"SELF.checkBoxButton.groupName IN %@",groupNameString];
        
       // Predicate using KeyPath
        // %K - K refer to keypath like [self valueForKeyPath:@"checkBoxButton"]
        NSPredicate *groupNameKeyPathPredicate = [NSPredicate predicateWithFormat:@"SELF.%K.%K IN %@",@"checkBoxButton",@"groupName",groupNameString];
        
        activeRadioBtnArray = [NSMutableArray arrayWithArray:[[parent valueForKey:@"groupedItemsArray"] filteredArrayUsingPredicate:groupNameKeyPathPredicate]];
    
    }
    
}



@end
