//
//  UICallback.m
//  CSSUIFramwork
//
//  Created by CSS Corp on 05/04/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "UICallback.h"

@implementation UICallback

@synthesize onSuccess;
@synthesize onFailed;

static UICallback* dummyCallback = nil;

+ (instancetype) getDummyUICallback {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        dummyCallback = [[UICallback alloc] initWithUICallbacks:^(id response) {
            //NSLog(@"Dummy CallBack True");
        } :^(id response) {
            //NSLog(@"Dummy CallBack False");
        }];
    });
    
    return dummyCallback;
}

- (instancetype) initWithUICallbacks:(callbackBlock)successBlock :(callbackBlock)failedBlock {
    self = [super init];
    if(self) {
        onSuccess = successBlock;
        onFailed = failedBlock;
    }
    return self;
}

- (void) setSuccessBlock:(callbackBlock) mySuccessBlock {
    onSuccess = mySuccessBlock;
}

- (void) setFailedBlock:(callbackBlock) myFailedBlock {
    onFailed = myFailedBlock;
}

@end
