//
//  UICheckBoxWithLabel.m
//  CSSUIFramwork
//
//  Created by CSS Admin on 6/15/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import "UICheckBoxWithLabel.h"

@implementation UICheckBoxWithLabel
@synthesize xPath;

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    [super drawRect:rect];
}



-(instancetype)initWithCoder:(NSCoder *)aDecoder {
    
    
    self = [super initWithCoder:aDecoder];
    if(self){
        
        [self setUpXibFile];
        
    }
    return self;
}

-(instancetype)initWithFrame:(CGRect)frame {
    
    
    self = [super initWithFrame:frame];
    if(self){
        
        [self setUpXibFile];
    }
    return self;
    
}

-(void)setUpXibFile {
    
    //1. Load a Xib
    [[NSBundle mainBundle]loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
    
    self.bounds = self.checkBoxLabelView.bounds;
    //3.Add as a subviw
    [self addSubview:self.checkBoxLabelView];
    
    [_checkBoxButton setChecked:NO];
    
}


@end
