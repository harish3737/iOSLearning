//
//  UILabledTextFielddemo.m
//  CSSUIFramwork
//
//  Created by CSSCORP on 3/20/19.
//  Copyright © 2019 csscorp. All rights reserved.
//

#import "UILabledTextFielddemo.h"

@implementation UILabledTextFielddemo
@synthesize textField,titleLabel,confirmImgView,optionalButton,xPath;


- (void)drawRect:(CGRect)rect {
    // Drawing code
    
    
    
    [super drawRect:rect];
}




- (id)initWithCoder:(NSCoder *)aDecoder{
    self = [super initWithCoder:aDecoder];
    if (self) {
        
        [self loadLabledTextFieldXibFile];
        
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if(self){
        
        [self loadLabledTextFieldXibFile];
        
        
    }
    return self;
}

-(void)loadLabledTextFieldXibFile {
    
    [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
    //adjust bounds
    self.bounds = self.contentView.bounds;
    [self addSubview:self.contentView];
    optionalButton.tag = 500;
    confirmImgView.hidden = YES;
    
}


-(id)nextItem {
    
    return _nextItem;
}

-(NSString *)getValueString{
    
    return @"-";
}


-(NSString *)xPath {
    return xPath;
}



-(void)setEnabled:(BOOL)enabled{
    //NSLog(@"UILabledTextField setEnable ::%d",enabled);
    [textField setEnableTextField:enabled];
    confirmImgView.hidden = YES;
}

-(void)setUserInteractionEnabled:(BOOL)userInteractionEnabled{
    
    [textField setUserInteractionEnabled:userInteractionEnabled];
}

@end
