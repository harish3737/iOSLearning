//
//  UIRadioButton.m
//  CSSUIFramwork
//
//  Created by CSS Admin on 6/3/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import "UIRadioButton.h"

#define REDCOLOR [UIColor colorWithRed:(240.0/255.0) green:(108.0/255.0) blue:(108.0/255.0) alpha:1.0f]
#define TEXTCOLOR [UIColor colorWithRed:(153.0/255.0) green:(153.0/255.0) blue:(153.0/255.0) alpha:1.0f]
#define DETAILTEXTCOLOR [UIColor colorWithRed:(102.0/255.0) green:(102.0/255.0) blue:(102.0/255.0) alpha:1.0f]

static NSMutableDictionary *activeRadioButtons;
static NSMutableDictionary *activeUnSelectedButtons;
@implementation UIRadioButton
@synthesize delegate,xPath;
@synthesize actionblock,parent;


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code

    [super drawRect:rect];
}


-(instancetype)initWithCoder:(NSCoder *)aDecoder {
    
    self = [super initWithCoder:aDecoder];
    if(self){
        [self setUpActiveButton];
    }
    return self;
}
-(instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if(self){
        
        [self setUpActiveButton];
        
    }
    return self;
    
}

-(void)setUpActiveButton{
    
    activeRadioButtons = [NSMutableDictionary new];
    activeUnSelectedButtons = [NSMutableDictionary new];
    _buttonSelected = NO;
    _valueChanged = NO;
    
    [self addTarget:self action:@selector(radioButtonTapped:) forControlEvents:UIControlEventTouchUpInside];
   
}

-(void)awakeFromNib {
    
    [self InitiatingValidatorBlock];
    [super awakeFromNib];
    
    
}

-(void)InitiatingValidatorBlock {
    
    [self setImage:_unSelectedImage forState:UIControlStateNormal];
    _dataValidator = [Validator NoValidation];
    _callback = [UICallback getDummyUICallback];
    
    actionblock = ^(id sender,id parent){
        
    };
    
    [self linkchain];
}

-(instancetype)init {
    
    self = [super init];
    if(self){
        
        [self InitiatingValidatorBlock];
    }
    return self;
}

-(void)linkchain {
    
    if ([Validator tailItem]!=nil){
        
        [[Validator tailItem] setNextField:self];
    }
    [Validator tailItem:self];
}

-(void)setValidatorString:(NSString *)validatorString {
    
    //NSLog(@"ValidatorString ::%@",validatorString);
    _validatorString = validatorString;
    _dataValidator = [Validator getValidator:validatorString];
     //NSLog(@"Block ::%@",_dataValidator);
    [self callBackInitialize];

}

-(void)callBackInitialize {
    
    //vrl6
    _callback = [[UICallback alloc]initWithUICallbacks:^(id data){
        //NSLog(@"callback sucess radioButton:%@",data);
        UIRadioButton *successRadioButton = data;
        successRadioButton.layer.borderColor = [UIColor clearColor].CGColor;
        successRadioButton.layer.borderWidth = 1.0f;
         [successRadioButton changeLabelFontColor:successRadioButton color:DETAILTEXTCOLOR];
		
    } :^(id data){
        //NSLog(@"callback failed radiobutton:%@",data);
        UIRadioButton *failedRadioButton = data;
//        failedRadioButton.layer.borderColor =[UIColor colorWithRed:(240.0/255.0) green:(108.0/255.0) blue:(108.0/255.0) alpha:1.0f].CGColor;
//        failedRadioButton.layer.borderWidth = 1.0f;
          [failedRadioButton changeLabelFontColor:failedRadioButton color:REDCOLOR]; //vrl13
    }];

}

-(void)changeLabelFontColor:(UIRadioButton *)radiobutton color:(UIColor *)customColor {
    
    
    NSArray *subviewArray = [radiobutton superview].subviews;
//    NSLog(@"radioButton superview ::%@",[radiobutton superview]);
//    NSLog(@"Array ::%@",subviewArray);
    
    for (int i=0;i<subviewArray.count;i++){
        
        id subViewItem = [subviewArray objectAtIndex:i];
        UIButton *contentButton = nil;
        ValidatorLabel *contentLabel = nil;
        if([subViewItem isKindOfClass:[UIRadioButton class]]){
            
            if((i+1)<subviewArray.count){
                if([[subviewArray objectAtIndex:(i+1)] isKindOfClass:[UIButton class]]){
                    contentButton = [subviewArray objectAtIndex:(i+1)];
                    [contentButton setTitleColor:customColor forState:UIControlStateNormal];
                }
            }else {
//                NSLog(@"No subview array");
            }
        }else if([subViewItem isKindOfClass:[ValidatorLabel class]]){
          contentLabel = [subviewArray objectAtIndex:i];
            [contentLabel setTextColor:customColor];
        }
        subViewItem = nil;
        
    }
    
}


-(void)setNextField:(id)nextField {
    
    _nextField = nextField;
}

-(IBAction)radioButtonTapped:(id)sender {
	
	[self redioActionBase:sender];
}

-(void) redioActionBase :(id)sender {
    _valueChanged = YES;
    NSLog(@"Buttontapped ::%@",_groupName);

	
	if(!_buttonSelected){ //NO
		
		[self setImage:_selectedImage forState:UIControlStateNormal];
		_buttonSelected = YES;
		self.userInteractionEnabled = NO;
	}else { // YES
		[self setImage:_unSelectedImage forState:UIControlStateNormal];
		
		_buttonSelected = NO;
		self.userInteractionEnabled = YES;
	}
	
	[delegate changeStateOnButtonTapped:self];
	
	self.layer.borderColor = [UIColor clearColor].CGColor;
	self.layer.borderWidth = 1.0f;
    
	UIRadioButton  *activeButton = [activeRadioButtons objectForKey:_groupName];
	if(activeButton != nil){
		

		[activeButton setImage:[activeUnSelectedButtons objectForKey:_groupName] forState:UIControlStateNormal];
		activeButton.buttonSelected = NO;
		activeButton.userInteractionEnabled = YES;
		
	}
	[activeRadioButtons setObject:self forKey:_groupName];
	[activeUnSelectedButtons setObject:_unSelectedImage forKey:_groupName];
	//    [self setImage:_selectedImage forState:UIControlStateNormal];
	//    self.buttonSelected = YES;
	
    actionblock(sender,self.parent);
}



-(void)setRadioButtonSelected:(BOOL)checked{

    _buttonSelected = !checked;
    [self radioButtonTapped:nil];
    
}

-(BOOL)isRadioButtonSelected {
    
    return _buttonSelected;
}

-(UIRadioButton *)getActiveButton{
    
    return [activeRadioButtons objectForKey:_groupName];
}


-(id)getNextField{
    return _nextField;
}

-(BOOL)validate{
    
    NSLog(@"_groupName ::%@",_groupName);
    NSLog(@"Validate Radiobutton");
    return ([activeRadioButtons valueForKey:_groupName]!=nil);
}

-(NSString *)getValueString{
	
    UIRadioButton *getActiveBtn = [activeRadioButtons valueForKey:_groupName];
    if(_valueChanged == YES)
    {
        if(getActiveBtn.tag==1&&getActiveBtn.buttonSelected){
            return @"No";
        
        }else {
            if(getActiveBtn.buttonSelected){
                return @"Yes";
            }else {
                return @"No";
                }
            }

        }
    return @"";
}

-(void)setValueString:(NSString *)valueString{
    
    
    if(self.tag==1 && [valueString isEqualToString:@"No"]){
        [self setRadioButtonSelected:YES];
    }else if(self.tag==0 && [valueString isEqualToString:@"Yes"]){
        [self setRadioButtonSelected:YES];
    }else {
        
    }
}

-(NSString *)xPath {
	return xPath;
}


-(void)setBtnSelectedImage:(UIImage *)image{
    _selectedImage = image;
}
-(void)setBtnUnSelectedImage:(UIImage *)image{
    _unSelectedImage = image;
}
-(void)loadImage:(UIImage *)image{
    
    [self setImage:image forState:UIControlStateNormal];
}

-(void)reset{
	
//	[[activeUnSelectedButtons objectForKey:_groupName] setRadioButtonSelected:NO];
//	[activeUnSelectedButtons removeObjectForKey: _groupName];
	
    [[activeRadioButtons objectForKey:_groupName] setRadioButtonSelected:NO];
    [activeRadioButtons removeObjectForKey: _groupName];
	
}

-(UIRadioButton *)getActiveButtonByGroupName:(NSString *)groupName{
    
    return [activeRadioButtons objectForKey:_groupName];
    
}

-(void)resetByGroupName:(NSString *)groupName{
    
    [[activeRadioButtons objectForKey:groupName] setRadioButtonSelected:NO];
    [activeRadioButtons removeObjectForKey: groupName];
    
}

@end
