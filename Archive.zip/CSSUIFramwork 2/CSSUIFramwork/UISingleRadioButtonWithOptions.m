//
//  UISingleRadioButtonWithOptions.m
//  SampleBCBSPOC
//
//  Created by CSS Admin on 6/2/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import "UISingleRadioButtonWithOptions.h"


@implementation UISingleRadioButtonWithOptions

@synthesize contentView,xPath;


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code

    [super drawRect:rect];
}


-(instancetype)initWithCoder:(NSCoder *)aDecoder {
    
    self = [super initWithCoder:aDecoder];
    if(self){
        
        [self loadRadioButtonXibFile];
    }
    return self;
    
}

-(instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if(self)
    {
        
        [self loadRadioButtonXibFile];
    }
    return self;
    
}



-(void)loadRadioButtonXibFile {
    
    [[NSBundle mainBundle]loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
    self.bounds = self.radioButtonView.bounds;
    [self addSubview:self.radioButtonView];
    _radioButton.delegate = self;
    [contentView.labelDropDownView disableDropDownView];
    
}


-(void)changeStateOnButtonTapped:(id)radioButton {
    
    UIView* activeRadioButtonSuperView =  [[radioButton getActiveButton] superview];
    NSArray *superviewArray = [activeRadioButtonSuperView subviews];
    
    //    //NSLog(@"Array ::%@",superviewArray);
    
    UIView *insideContentView = [superviewArray objectAtIndex:1];
    NSArray *contentViewArray = [insideContentView subviews];
    //    //NSLog(@"contentArray ::%@",contentViewArray);
    
    
    if([contentViewArray count]!=0){
        UILabeledButton *labeledButtonView = [contentViewArray objectAtIndex:1];
//        NSArray *labeledButtonViewArray = [labeledButtonView subviews];
        [labeledButtonView disableDropDownView];
        [labeledButtonView resetDropDownTitle];
    }

    
    /*
    UILabeledButton *labeledButtonView = [contentViewArray objectAtIndex:1];
    NSArray *labeledButtonViewArray = [labeledButtonView subviews];
    
    UIView *buttonContentView = [labeledButtonViewArray objectAtIndex:0];
    NSArray *buttonContentViewArray = [buttonContentView subviews];
    //NSLog(@"dropDownView ::%@",buttonContentViewArray);
    
    if([contentViewArray count]!=0){
        UILabeledButton *activeDropDownView = [contentViewArray objectAtIndex:1];
        [activeDropDownView disableDropDownView];
    }
     */
    
    [contentView.labelDropDownView enableDropDownView];
    
    
    
    
    
    
    /* // dropdownview enable / disable called
     
     
     if([buttonContentViewArray count]!=0){
     UIDropDown *activeDropDownView = [buttonContentViewArray objectAtIndex:1];
     [activeDropDownView setDisabled];
     }
     
     [self.labelDropDownView.dropDownCustomView setEnabled];
     
     */
}

////vrl
//-(void)awakeFromNib {
//    
//    [_radioButton setButtonSelected:YES]; //vrl
//    [super awakeFromNib];
//}


-(void)layoutSubviews {
    
    [super layoutSubviews];
    
    
}

-(NSString *)getValueString{
	
	return @"_";
}

-(NSString *)xPath {
	return xPath;
}



@end
