//
//  UILabledTextFieldNoOptional.m
//  CustomControl
//
//  Created by CSS Corp on 25/04/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "UILabledTextFieldNoOptional.h"


@implementation UILabledTextFieldNoOptional
@synthesize textField,titleLabel,confirmImgView,xPath;

//@synthesize contentView;


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    
   
    
    [super drawRect:rect];
}




- (id)initWithCoder:(NSCoder *)aDecoder{
    self = [super initWithCoder:aDecoder];
    if (self) {
       
         [self loadLabledTextFieldXibFile];
        
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if(self){
        
        [self loadLabledTextFieldXibFile];
    
        
    }
    return self;
}

-(void)loadLabledTextFieldXibFile {
    
    [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
    //adjust bounds
    self.bounds = self.contentView.bounds;
    [self addSubview:self.contentView];

    confirmImgView.hidden = YES;
    
}


-(id)nextItem {
	
    return _nextItem;
}

-(NSString *)getValueString{
	
	return @"-";
}


-(NSString *)xPath {
	return xPath;
}



-(void)setEnabled:(BOOL)enabled{
	//NSLog(@"UILabledTextField setEnable ::%d",enabled);
	[textField setEnableTextField:enabled];
	confirmImgView.hidden = YES;
}

-(void)setUserInteractionEnabled:(BOOL)userInteractionEnabled{
	
	[textField setUserInteractionEnabled:userInteractionEnabled];
}

@end
