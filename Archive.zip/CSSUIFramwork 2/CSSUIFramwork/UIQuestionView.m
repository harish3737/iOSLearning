//
//  UIQuestionView.m
//  SampleBCBSPOC
//
//  Created by CSS Admin on 5/30/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import "UIQuestionView.h"
#import "UISingleLabelView.h"
#import "UILabeledButton.h"




@implementation UIQuestionView
@synthesize xPath;


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code

    [super drawRect:rect];
}


-(instancetype)initWithCoder:(NSCoder *)aDecoder {
    
    self = [super initWithCoder:aDecoder];
    
    if(self){
        [self loadXibFile];
    }
    return self;
}

-(instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if(self){
        [self loadXibFile];
    
    }
    return self;
}


-(void)loadXibFile {
    
    //1. Load a Xib
    [[NSBundle mainBundle]loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
    
    self.bounds = self.questionView.bounds;
    //3.Add as a subviw
    [self addSubview:self.questionView];
	_yesButton.delegate = self;
	_noButton.delegate = self;
    
}


-(void)setChildViewString:(NSString *)childViewString {
	
	
	_childViewString = childViewString;
	
	
}


-(void)changeStateOnButtonTapped:(id)radioButton{
	
	
    NSArray *superview = [radioButton superview].subviews;
    
    for (id subViews in superview){
        
        if([subViews isKindOfClass:[ValidatorLabel class]]){
            
            ValidatorLabel *getLabel = subViews;
            if(getLabel.tag==200){
                getLabel.textColor = [UIColor colorWithRed:50.0/255.0 green:50.0/255.0 blue:50.0/255.0 alpha:1.0];
            }else if(getLabel.tag==210){
                getLabel.textColor = [UIColor colorWithRed:50.0/255.0 green:50.0/255.0 blue:50.0/255.0 alpha:1.0];
            }else {
                getLabel.textColor = [UIColor colorWithRed:102.0/255.0 green:102.0/255.0 blue:102.0/255.0 alpha:1.0];
            }
            
        }
    }
    
	//NSLog(@"childViewString ::%@",_childViewString);
	
	UIRadioButton *radioBtn = radioButton;
	//NSLog(@"Button Tag ::%ld",(long)radioBtn.tag);
	
	
	if(_childViewString!=nil){
            if(radioBtn.tag==1){
                [self enableSecondView:([radioBtn isRadioButtonSelected])?NO:YES];
            }else {
                [self enableSecondView:YES];
            }
	}
	
}


-(void)enableSecondView :(BOOL)enable{
	
//    NSLog(@"Enable SecondView ::%d",enable);
	
	if(_childViewString!=nil){
		id childObject = [[self viewController] valueForKey:_childViewString];
		
		[childObject setUserInteractionEnabled:enable];
//        NSLog(@"child Object ::%@\n",childObject);
		for (id subviewcontent in [childObject subviews]){
//            NSLog(@"subviews ::%@\n",subviewcontent);
            
            if([subviewcontent isKindOfClass:[UISingleLabelView class]]) {
                
                [subviewcontent setBackgroundColor:[UIColor whiteColor]];
            }
            
            if(_disableChildView){
                
                if([subviewcontent isKindOfClass:[UILabeledButton class]]) {
                    [subviewcontent setEnabled:YES];
                    [subviewcontent setUserInteractionEnabled:enable];
                }else {
                    [subviewcontent setEnabled:enable];
                    [subviewcontent setUserInteractionEnabled:enable];
                }
                
            }else {
                [subviewcontent setEnabled:enable];
                [subviewcontent setUserInteractionEnabled:enable];
            }
		}
	}
	
	
}



- (UIViewController *)viewController {
	UIResponder *responder = self;
	while (![responder isKindOfClass:[UIViewController class]]) {
		responder = [responder nextResponder];
		if (nil == responder) {
			break;
		}
	}
	return (UIViewController *)responder;
}




//-(void)setHeadingLabelText:(NSString *)headingText {
//    self.headingLabel.localizationKey = headingText;
//
//}
//-(void)setDetailLabelText:(NSString *)detailText
//{
//    self.detailLabel.localizationKey = detailText;
//
//}
//-(NSString *)headingLabelText{
//    return _headingLabel.text;
//    
//}
//-(NSString *)detailLabelText{
//    return _detailLabel.text;
//}
//-(void)setHiddenDetailLabel:(BOOL)isHidden{
//    
//    _detailLabel.hidden = isHidden;
//    
//}
//-(BOOL)isHiddenDetailLabel{
//    return _detailLabel.hidden;
//}

- (IBAction)YesActionClicked:(id)sender {
    
    [self changeborderColor];
   

}

- (IBAction)NoActionClicked:(id)sender {
    [self changeborderColor];
}

-(void)changeborderColor {
    
    _yesButton.layer.borderColor = [UIColor clearColor].CGColor;
    _yesButton.layer.borderWidth =1.0f;
    
    _noButton.layer.borderColor = [UIColor clearColor].CGColor;
    _noButton.layer.borderWidth =1.0f;
    
}


//-(void)layoutSubviews {
//
//    [self.questionView setNeedsDisplay];
//    
//}

@end
