//
//  Validator.h
//  CSSUIFramwork
//
//  Created by CSS Admin on 4/8/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "UICallback.h"



typedef enum {
    
    EMAIL_VALIDATOR,
    PASSWORD_VALIDATOR,
    NUMBER_VALIDATOR,
    PHONE_NUMBER_VALIDATOR,
    NUMBER_ONLY_VALIDATOR,
    ALPHANUMERIC_VALIDATOR,
    ALPHABET_VALIDATOR

}ValidatorType;



@class ValidatorTextField;

typedef bool(^DataValidator)(id);

static NSMutableDictionary *appconfigPlanData;
static id appconfigExtraData;

@interface Validator : NSObject

+(BOOL)validate:(DataValidator)validate Data:(id)dataValue CallBack:(UICallback *)callback;

+ (DataValidator) EmailValidator;
+ (DataValidator) PhoneNumberValidator;
+ (DataValidator) PasswordValidator;
+ (DataValidator) AlphabetValidator;
+ (DataValidator) NumberValidator;
+ (DataValidator) NoValidation;
+ (DataValidator) AlphaNumericSpecialCharacterValidator;
+ (DataValidator) MandatoryValidator;
+ (DataValidator) EmptyValidator;
+ (DataValidator) ZipcodeValidator;
+ (DataValidator) OptionalEmailValidator;
+ (DataValidator) OptionalAlphabetValidator;
+ (DataValidator) OptionalNumberValidator;
+ (DataValidator) AlphaNumericValidator;
+ (DataValidator) AddressValidator;
+ (DataValidator) OptionalAlphaNumericValidator;
+ (DataValidator) SingleAlphapetValidator;
+ (DataValidator) OptionalSingleAlphapetValidator;
+ (DataValidator) OptionalAlphabetWithSpaceValidator;
+ (DataValidator) OptionalZipcodeValidator;
+ (DataValidator) OptionalAddressValidator;
+ (DataValidator) OptionalPhoneNumberValidator;

+ (DataValidator) MedicareBeneficiaryIDValidator;
    
+(DataValidator) MedicareNumberValidator;

+(DataValidator)EqualStringValidator;
+(DataValidator)NotEqualStringValidator;

+ (id) tailItem;
+ (void) tailItem:(id)newitem;

+(void)headItem:(id)itemValue;
+(id)headItem;


+(DataValidator)getValidator:(NSString *)keyString;
+(NSMutableDictionary *)ValidatorDictionary;
+(BOOL)Validate;
+(void)ValidationDone;


+(void)setAppConfigPlanData:(NSMutableDictionary *)planData;
+(void)setExtraData:(id)extraData;

@end
