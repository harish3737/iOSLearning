//
//  UIBaseContainerViewController.h
//  BcBs
//
//  Created by CSS Admin on 6/1/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UICGSizeConstraints.h"
#import "SharedData.h"

@interface UIBaseContainerViewController : UIViewController

typedef void(^WillLoadNextBlock)(id);

@property (strong, nonatomic) IBOutlet UIView *xibPlaceholderView;
@property (strong,nonatomic) UICGSizeConstraints *sizeConstraints;

@property (strong,nonatomic) WillLoadNextBlock willLoadNext;
@property (strong,nonatomic) WillLoadNextBlock willSkipTouch;
@property (strong,nonatomic) WillLoadNextBlock willBackPage;

@property (strong,nonatomic) SharedData *sharedataObj;

-(void)didFinishContainerVC;

-(BOOL)validateVC;
-(void)loadNextPage;
-(void)loadBackData;

@end
