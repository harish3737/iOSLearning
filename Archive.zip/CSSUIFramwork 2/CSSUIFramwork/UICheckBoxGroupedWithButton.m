//
//  UICheckBoxGroupedWithButton.m
//  CSSUIFramwork
//
//  Created by CSS Admin on 12/10/18.
//  Copyright © 2018 csscorp. All rights reserved.
//

#import "UICheckBoxGroupedWithButton.h"
#define DETAILTEXTCOLOR [UIColor colorWithRed:(102.0/255.0) green:(102.0/255.0) blue:(102.0/255.0) alpha:1.0f]


@implementation UICheckBoxGroupedWithButton

@synthesize xPath;

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    [super drawRect:rect];
}


-(instancetype)initWithCoder:(NSCoder *)aDecoder {
    
    
    self = [super initWithCoder:aDecoder];
    if(self){
        
        [self setUpXibFile];
        
    }
    return self;
}

-(instancetype)initWithFrame:(CGRect)frame {
    
    
    self = [super initWithFrame:frame];
    if(self){
        
        [self setUpXibFile];
    }
    return self;
    
}

-(void)setUpXibFile {
    
    //1. Load a Xib
    [[NSBundle mainBundle]loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
    
    self.bounds = self.checkBoxGroupBtnView.bounds;
    //3.Add as a subviw
    [self addSubview:self.checkBoxGroupBtnView];
    
    _checkBoxButton.delegate = self;
    
}

- (IBAction)cotentAction:(id)sender {
    
    [_checkBoxButton redioActionBase:nil];
    
}

-(NSString *)getValueString{
    
    return @"-";
}

-(void)changeStateOnButtonTapped:(id)radioButton; {
    
    [radioButton layer].borderColor = [UIColor clearColor].CGColor;
    [radioButton layer].borderWidth = 1.0f;
    
    if([self.checkBoxButton isRadioButtonSelected]) {
        
        self.contentButton.userInteractionEnabled = YES;
        [self.contentButton setTitleColor:DETAILTEXTCOLOR forState:UIControlStateNormal];
    }
    
    [self layoutSubviews];

}

@end
