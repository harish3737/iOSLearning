//
//  UIConfirmImageView.m
//  CSSUIFramwork
//
//  Created by CSS Admin on 7/8/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import "UIConfirmImageView.h"

@implementation UIConfirmImageView


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    [super drawRect:rect];
}

-(id)init{
    
    self = [super init];
    if(self){
        
        [self setInitialize];
    }
    return self;
}

-(id)initWithCoder:(NSCoder *)aDecoder {
    
    self = [super initWithCoder:aDecoder];
    if(self){
        
    }
    return self;
}

-(id)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if(self){
        
    }
    return self;
    
}

-(void)awakeFromNib {
    
    
    [super awakeFromNib];
}

-(void)setInitialize {
    
    _imageViewIdentifier = [NSString stringWithFormat:@"%@",@"ConfirmImage"];
}

@end
