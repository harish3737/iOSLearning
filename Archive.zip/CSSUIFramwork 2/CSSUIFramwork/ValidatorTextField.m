//
//  ValidatorTextField.m
//  SampleBCBSPOC
//
//  Created by CSS Admin on 4/4/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import "validatorTextField.h"
#import "LanguageCentral.h"
#import "UILabledTextField.h"
#import "UILabelDropDownWithTextField.h"


//callbackBlock onSuccessBlock;
//callbackBlock onFailedBlock;

#define kOFFSET_FOR_KEYBOARD 150.0
#define REDCOLOR [UIColor colorWithRed:(240.0/255.0) green:(108.0/255.0) blue:(108.0/255.0) alpha:1.0f]
#define TEXTCOLOR [UIColor colorWithRed:(153.0/255.0) green:(153.0/255.0) blue:(153.0/255.0) alpha:1.0f]
#define BORDERCOLOR [UIColor colorWithRed:(204.0/255.0) green:(204.0/255.0) blue:(204.0/255.0) alpha:1.0f].CGColor

@interface ValidatorTextField (){
    
    
}

@property(nonatomic,strong) UIView *currentView;
@property(nonatomic,strong) UIScrollView *currentScrollView;
@property (strong, nonatomic) UITextField *activeField;
- (void) validateNextField;

@end


@implementation ValidatorTextField

//@synthesize callback;

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    
    

    [self makeTextFieldLength];

//    [LanguageCentral setInternalizeString:@"es"];
    
//    self.text = [LanguageCentral languageSelectedString:_localizationKey];
    [self addPaddingView]; //Boobalan changed 20/07/2016
    [super drawRect:rect];
    
}

// remove copy,paste,select option for textfield text // added by boobalan
- (BOOL)canPerformAction:(SEL)action withSender:(id)sender
{
    if (action == @selector(paste:))
    {
        return false;
    }else if (action == @selector(cut:))
    {
        return false;
    }
    
    return false;
}

- (void) validateNextField {
    [self.nextField validate];
}


-(void)setNextField:(id)nextField{

    _nextField = nextField;
    //NSLog(@"NextItem ::%@",_nextField);

}

-(void)setLocalizationKey:(NSString *)localizationKey {
    
    _localizationKey = localizationKey;
    
    NSString *contentString = [LanguageCentral languageSelectedString:_localizationKey];
    
    self.text = (contentString.length>0)?contentString:_localizationKey;
    
}

-(BOOL)validate{

   return [Validator validate:[self dataValidator] Data:self CallBack: self.callback];
}

-(void)setSubmitHandler:(callbackBlock)submitHandler{
    
    [self.callback setSuccessBlock:submitHandler];
    
}

- (void)awakeFromNib {
    
    self.layer.borderColor = BORDERCOLOR;
    self.layer.borderWidth = 1.0f;
    
     [self getSuperView];
    self.delegate = self;
    _dataValidator = [Validator NoValidation];
    _callback = [UICallback getDummyUICallback];
    
    [self linkChain];
}

//Boobalan changed 20/07/2016
-(void)addPaddingView {
    
    UIView *paddingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 10, 20)];
    self.leftView = paddingView;
    self.leftViewMode = UITextFieldViewModeAlways;
}

//Boobalan changed 20/07/2016
-(void)setKeyboardTypeName:(NSInteger)keyboardType{

    
    switch (keyboardType) {
        case UIKeyboardTypeDefault:
            self.keyboardType = UIKeyboardTypeDefault;
            break;
            
        case UIKeyboardTypeNumberPad:
            self.keyboardType = UIKeyboardTypeNumberPad;
            break;
            
        case UIKeyboardTypePhonePad:
            self.keyboardType = UIKeyboardTypePhonePad;
            break;
            
        case UIKeyboardTypeEmailAddress:
            self.keyboardType = UIKeyboardTypeEmailAddress;
            break;
            
        default:
             self.keyboardType = UIKeyboardTypeDefault;
            break;
    }
}



-(void)getSuperView {
	
	//    id currentViewcontroller = [self viewController];
	//
	//    //NSLog(@"current view controller ::%@",NSStringFromClass([currentViewcontroller class]));
	
	
            	id baseVC= [UIApplication sharedApplication].keyWindow.rootViewController;
	
    NSLog(@"visible ::%@",[baseVC visibleViewController]);
	
	
	UIViewController *visibleViewcontroller = [baseVC visibleViewController];
	
	_currentView = visibleViewcontroller.view;
	for (id subview in visibleViewcontroller.view.subviews){
		
		if([subview isKindOfClass:[UIScrollView class]]){
			//NSLog(@"subview ::%@",subview);
			_currentScrollView = subview;
		}
	}
}




- (UIView *)viewController {
	UIResponder *responder = self;
	while (![responder isKindOfClass:[UIScrollView class]]) {
		//NSLog(@"Responder ::%@",responder);
		responder = [responder nextResponder];
		if (nil == responder) {
			break;
		}
	}
	return (UIView *)responder;
}

-(void)linkChain{
	
    if([Validator tailItem]!=nil){
        [[Validator tailItem] setNextField:self];
    }
    [Validator tailItem:self];
    
}

-(void)callbackInit{
    
    _callback = [[UICallback alloc]initWithUICallbacks:^(id data){
        //NSLog(@"TextField Callback succes");
        ValidatorTextField *successTextField = data;
        successTextField.layer.borderColor = BORDERCOLOR;
        successTextField.layer.borderWidth = 1.0f;
        
        ValidatorLabel *titleLabel = [successTextField getTitleLabel:successTextField];
        
        if(successTextField.tag==100){
            
            if([titleLabel.textColor isEqual:REDCOLOR]){
                [successTextField showConfirmImage:successTextField hidden:NO];
            }else {
                if(successTextField.text.length!=0){
                    [successTextField showConfirmImage:successTextField hidden:NO];
                }else {
                [successTextField showConfirmImage:successTextField hidden:YES];
                }
                
            }
        }else {
            [successTextField showConfirmImage:successTextField hidden:NO];
        }
        
//         [successTextField showConfirmImage:successTextField hidden:NO];
//        if([[successTextField superview] isKindOfClass:[UIView class]]){
//                    [successTextField changeLabelFontColor:successTextField color:TEXTCOLOR];
//        
//        }
       
        [titleLabel setTextColor:TEXTCOLOR];
        
    } :^(id data){
        //NSLog(@"TextField Callback Failed");
        ValidatorTextField *failedTextField = data;
          failedTextField.layer.borderColor = [UIColor colorWithRed:(240.0/255.0) green:(108.0/255.0) blue:(108.0/255.0) alpha:1.0f].CGColor;
        failedTextField.layer.borderWidth = 1.0f;
        [failedTextField showConfirmImage:failedTextField hidden:YES];
        if([[failedTextField superview] isKindOfClass:[UIView class]]){
            [failedTextField changeLabelFontColor:failedTextField color:REDCOLOR];
            
        }
        
    }];
    
}

-(id)getTitleLabel:(id)view {
    
    NSArray *subviewArray = [view superview].subviews;
    for (int i=0;i<subviewArray.count;i++){
        
        id subViewItem = [subviewArray objectAtIndex:i];
        
        if([subViewItem isKindOfClass:[ValidatorTextField class]]){
            
            if([[subviewArray objectAtIndex:(i-1)] isKindOfClass:[ValidatorLabel class]]){
                return [subviewArray objectAtIndex:(i-1)];
                
                
            }else if([subViewItem tag]==100){
                
                if([[subviewArray objectAtIndex:0] isKindOfClass:[ValidatorLabel class]]){
                    return [subviewArray objectAtIndex:0];
                }
                
            }
        }
        subViewItem = nil;
        
    }
    return nil;
    
}


//[UIColor colorWithRed:(204.0/255.0) green:(204.0/255.0) blue:(204.0/255.0) alpha:1.0f]  //graycolor
//[UIColor colorWithRed:(240.0/255.0) green:(108.0/255.0) blue:(108.0/255.0) alpha:1.0f] //redcolor
-(void)changeLabelFontColor:(ValidatorTextField *)textField color:(UIColor *)customColor {
    
    
    NSArray *subviewArray = [textField superview].subviews;
    for (int i=0;i<subviewArray.count;i++){
        
        id subViewItem = [subviewArray objectAtIndex:i];
        ValidatorLabel *validateLabel = nil;
        if([subViewItem isKindOfClass:[ValidatorTextField class]]){
            
            if([[subviewArray objectAtIndex:(i-1)] isKindOfClass:[ValidatorLabel class]]){
                validateLabel = [subviewArray objectAtIndex:(i-1)];
                validateLabel.textColor = customColor;
                
            }else if([subViewItem tag]==100){
                
                if([[subviewArray objectAtIndex:0] isKindOfClass:[ValidatorLabel class]]){
                    validateLabel = [subviewArray objectAtIndex:0];
                    validateLabel.textColor = customColor;
                }
                
            }
        }
        subViewItem = nil;
        
    }
    
}



-(void)showConfirmImage:(ValidatorTextField *)textField hidden:(BOOL)isHiddenConfirmImage {

    BOOL isOptionalButton = NO;
    for (id viewcontent in [textField superview].subviews){
        
        if([NSStringFromClass([viewcontent class]) isEqualToString:@"UIMultiLingualButton"] && [viewcontent tag]==500){
            if(![viewcontent isHidden]){
                isOptionalButton = YES;
            }
        }
        if([NSStringFromClass([viewcontent class]) isEqualToString:@"UIConfirmImageView"]){
            if(isOptionalButton){
                if(textField.text.length!=0 && !isHiddenConfirmImage){
                    [viewcontent setHidden:NO];
                }else {
                    [viewcontent setHidden:YES];
                }

                isOptionalButton = NO;
            }else {
                [viewcontent setHidden:isHiddenConfirmImage];
            }
        }
        
    }
    
}


-(void)setValidatorString:(NSString *)validatorString {
    
    _validatorString = validatorString;
    
    _dataValidator = [Validator getValidator:validatorString];

    [self callbackInit];
    
    
}

-(id)getNextField{
    return _nextField;
}


- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if(self != nil) {
        
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        
    }
    return self;
}

-(id)init{
    
    if(self = [super init]){
        
        //NSLog(@"Init");
        _dataValidator = [Validator NoValidation];
        _callback = [UICallback getDummyUICallback];
        [self getSuperView];
		self.delegate = self;
        [self linkChain];
       
    }
    return self;
    
}



-(void)makeTextFieldLength {
    
//    _maxLength = 10;
    _minLength = 5;
}


-(NSString *)getValueString{
	
	return self.text;
}

-(void)setValueString:(NSString *)valueString{
    
    self.text = valueString;
}

-(NSString *)xPath {
	return _xPath;
}

-(void)setEnableTextField:(BOOL)isEnable{
	
	if(isEnable){
		self.backgroundColor = [UIColor whiteColor];
	}else {
		self.backgroundColor = [UIColor colorWithRed:239.0/255.0 green:239.0/255.0 blue:239.0/255.0 alpha:1.0];
         self.text=@"";
    
	}
    self.layer.borderWidth = 1.0f;
    self.layer.borderColor = BORDERCOLOR;
    
    //vrl12
    if([[self superview] isKindOfClass:[UIView class]]){
        [self changeLabelFontColor:self color:TEXTCOLOR];
        
    }
}


-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
	
	
	
	[self registerForKeyboardNotifications];
	return YES;
}

-(BOOL)textFieldShouldEndEditing:(UITextField *)textField {
	
	
	return YES;
}

-(void)textFieldDidBeginEditing:(UITextField *)sender
{
    // hide custom language keyboard letters in keyboard
    if([sender keyboardType]==UIKeyboardTypeNumberPad|| [sender keyboardType]==UIKeyboardTypePhonePad ){
    }else {
        sender.keyboardType = UIKeyboardTypeASCIICapable; // boobalan added
    }

    
	self.activeField = sender;
	
}

-(void)textFieldDidEndEditing:(UITextField *)sender {
	
	[self unregisterForKeyboardNotification];
	self.activeField = nil;
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
	[textField resignFirstResponder];
	
	return YES;
}

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    // Always allow a backspace
    if ([string isEqualToString:@""]) {
        return YES;
    }
    
    if(range.length + range.location > textField.text.length)
    {
        return NO;
    }
    
    if(!self.maxLength)
        self.maxLength = 100;
    if(textField.text.length < self.maxLength)
        return YES;
    else
        return NO;
}

-(void)registerForKeyboardNotifications{
	
	
	[[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(keyboardDidShow:)
												 name:UIKeyboardDidShowNotification
											   object:nil];
	
	[[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(keyboardWillBeHidden:)
												 name:UIKeyboardWillHideNotification
											   object:nil];
}


-(void)unregisterForKeyboardNotification {
	[[NSNotificationCenter defaultCenter] removeObserver:self
													name:UIKeyboardWillShowNotification
												  object:nil];
	
	[[NSNotificationCenter defaultCenter] removeObserver:self
													name:UIKeyboardWillHideNotification
												  object:nil];
	
}


- (void)keyboardDidShow:(NSNotification *)notification
{
	NSDictionary* info = [notification userInfo];
//    CGRect kbRect = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue];
    CGRect kbRect = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue]; // ios 11 keyboard issue fix

	// If you are using Xcode 6 or iOS 7.0, you may need this line of code. There was a bug when you
	// rotated the device to landscape. It reported the keyboard as the wrong size as if it was still in portrait mode.
	//kbRect = [self.view convertRect:kbRect fromView:nil];
	
	UIEdgeInsets contentInsets = UIEdgeInsetsMake(0.0, 0.0, kbRect.size.height+20, 0.0);
	_currentScrollView.contentInset = contentInsets;
	_currentScrollView.scrollIndicatorInsets = contentInsets;
	
	CGRect aRect = _currentView.frame;
	aRect.size.height -= kbRect.size.height;
	//    if (!CGRectContainsPoint(aRect, self.activeField.frame.origin) ) {
	//        [_currentScrollView scrollRectToVisible:self.activeField.frame animated:YES];
	//    }
	
	if (!CGRectContainsPoint(aRect, self.activeField.frame.origin) ) {
		CGPoint scrollPoint = CGPointMake(0.0, self.activeField.frame.origin.y-kbRect.size.height);
		//        CGPoint moveScrollPoint = CGPointMake(scrollPoint.x, scrollPoint.y+200);
		//        //NSLog(@"move ::%f",moveScrollPoint.y);
		[_currentScrollView setContentOffset:scrollPoint animated:YES];
		//        [_currentScrollView setContentOffset:moveScrollPoint animated:YES];
	}
}

- (void)keyboardWillBeHidden:(NSNotification *)notification
{
	UIEdgeInsets contentInsets = UIEdgeInsetsZero;
	_currentScrollView.contentInset = contentInsets;
	_currentScrollView.scrollIndicatorInsets = contentInsets;
}


@end
