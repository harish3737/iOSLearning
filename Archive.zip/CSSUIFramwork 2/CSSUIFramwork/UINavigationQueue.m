
//  UINavigationQueue.m
//  BcBs
//
//  Created by CSS Admin on 5/31/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "UINavigationQueue.h"
#import "UIRenderer.h"



static NSMutableArray *mutableArray = nil;
static NSInteger currentIndex = -1;

@implementation UINavigationQueue
{
    
}


+(void)push:(NSString *)baseVCString containerVC:(NSString *)containerVCString xibName:(NSString *)xibNameString{
    
   
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        mutableArray = [[NSMutableArray alloc]init];
    });
    
//    [mutableArray addObject:[NSArray arrayWithObjects:baseVCString,containerVCString,xibNameString, nil]];
    //NSLog(@"MutableArray ::%@",mutableArray);
}

+(void)pushClass:(Class)baseVcClass containerVC:(Class)containerVcClass xibName:(Class)xibNameClass{
    
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        mutableArray = [[NSMutableArray alloc]init];
    });
    
    [mutableArray addObject:[NSArray arrayWithObjects:baseVcClass,containerVcClass,xibNameClass, nil]];
    NSLog(@"MutableArray ::%@",mutableArray);

    
}

//vrl added
+(void)InsertClass:(Class)baseVcClass containerVC:(Class)containerVcClass xibName:(Class)xibNameClass index:(NSUInteger)indexValue {
    
    // NSLog(@"MutableArray count  ::%ld",mutableArray.count);
    
    [mutableArray insertObject:[NSArray arrayWithObjects:baseVcClass,containerVcClass,xibNameClass, nil] atIndex:indexValue];
//    NSLog(@"MutableArray ::%@",mutableArray);
//    NSLog(@"after MutableArray count  ::%ld",mutableArray.count);
}


+(void)RemoveClassAtIndex:(NSUInteger)indexValue {
//    NSLog(@"remove class At Index ::%d",indexValue);
    //     NSLog(@"before count MutableArray ::%ld",mutableArray.count);
    [mutableArray removeObjectAtIndex:indexValue];
//          NSLog(@"after remove at index MutableArray ::%@",mutableArray);
}


+(void)showNext:(UIBaseViewController *)baseVC{
    
    if(currentIndex == mutableArray.count){
        return;
    }
    currentIndex = currentIndex+1;
    
    [self loadBaseViewController:baseVC];
}

+(void)showPrevious:(UIBaseViewController *)baseVC{
    
    if(currentIndex == 0){
        return;
    }
//    --currentIndex;
    currentIndex = currentIndex-1;
    [self loadBaseViewController:baseVC];
}

//vrl added
+(void)gotoScreen:(NSInteger)indexValue BaseVC:(UIBaseViewController *)baseVC{
    
    currentIndex = indexValue;
//    NSLog(@"Go To Screen Index ::%ld",currentIndex);
    //    [self loadBaseViewController:baseVC];
    
}


+(void)loadBaseViewController:(UIBaseViewController *)baseViewController {
    
    NSLog(@"CurrentVC Index ::%ld",(long)currentIndex);
    
    NSLog(@"Array base :%@",[[mutableArray objectAtIndex:currentIndex]objectAtIndex:0]);
    NSLog(@"Array container :%@",[[mutableArray objectAtIndex:currentIndex]objectAtIndex:1]);
//    NSLog(@"Array container :%@",[[mutableArray objectAtIndex:currentIndex]objectAtIndex:2]);
    
    
    NSLog(@"current Root ::%@",NSStringFromClass([baseViewController class]));
    
    if([[[mutableArray objectAtIndex:currentIndex]objectAtIndex:0]isEqual:[baseViewController class]]){
        
        NSLog(@"Same base name ::%@",[baseViewController class]);
        [self showCurrentContainerVC:baseViewController];
        
        
    }else {
        NSLog(@"Not same Base class");
//        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
//        
//        UIBaseViewController *nextBaseVC = [storyboard instantiateViewControllerWithIdentifier:NSStringFromClass([[mutableArray objectAtIndex:currentIndex]objectAtIndex:0])];
//        
//        [baseViewController.navigationController pushViewController:nextBaseVC animated:YES];
        
        
         BOOL hasDashboard = [[NSUserDefaults standardUserDefaults]boolForKey:@"DashboardView"];
        
        if(hasDashboard){
            
            NSArray *viewControllerArray = baseViewController.navigationController.viewControllers;
            CATransition* transition = [CATransition animation];
            transition.duration = 0.25f;
            transition.type = kCATransitionFade;
            transition.subtype = kCATransitionFromTop;
            [baseViewController.navigationController.view.layer addAnimation:transition
                                                                      forKey:kCATransition];
            [baseViewController.navigationController popToViewController:[viewControllerArray objectAtIndex:1] animated:NO];
        }else {
            
            UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            
            UIBaseViewController *nextBaseVC = [storyboard instantiateViewControllerWithIdentifier:NSStringFromClass([[mutableArray objectAtIndex:currentIndex]objectAtIndex:0])];
            
//            [baseViewController.navigationController pushViewController:nextBaseVC animated:YES];
            CATransition* transition = [CATransition animation];
            transition.duration = 0.25f;
            transition.type = kCATransitionFade;
            transition.subtype = kCATransitionFromTop;
            
            [baseViewController.navigationController.view.layer addAnimation:transition forKey:kCATransition];
            [baseViewController.navigationController pushViewController:nextBaseVC animated:NO];
        }

    }

}

+(void)showCurrentContainerVC:(UIBaseViewController *)baseViewController{
    
    
    if([[[mutableArray objectAtIndex:currentIndex]objectAtIndex:1] isEqual:[baseViewController.currentViewController class]]){
        
        NSLog(@"Same ContentVC ::%@",NSStringFromClass([baseViewController.currentViewController class]));
        
        [self showXibName:baseViewController.currentViewController];
        
    }else {
        NSLog(@"different ContentVC ::%@",NSStringFromClass([baseViewController.currentViewController class]));
        
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        
        UIBaseContainerViewController *nextViewcontroller = [storyboard instantiateViewControllerWithIdentifier:NSStringFromClass([[mutableArray objectAtIndex:currentIndex]objectAtIndex:1])];
        
        nextViewcontroller.view.translatesAutoresizingMaskIntoConstraints = NO;
        
        [baseViewController cycleFromViewController:baseViewController.currentViewController toViewController:nextViewcontroller];
        baseViewController.currentViewController = nextViewcontroller;
      
    }
}


+(void)showInitialContainerViewcontroller:(UIBaseViewController *)baseViewController {
    
    
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
  UIBaseContainerViewController *currentViewController = [storyboard instantiateViewControllerWithIdentifier:NSStringFromClass([[mutableArray objectAtIndex:currentIndex]objectAtIndex:1])];
    currentViewController.view.translatesAutoresizingMaskIntoConstraints = NO;
    [baseViewController addChildViewController:currentViewController];
    [baseViewController addSubview:currentViewController.view toView:baseViewController.containerView];
    baseViewController.currentViewController = currentViewController;
    
}

+(void)showXibName:(UIBaseContainerViewController *)containerVC{
    
    
    //NSLog(@"BaseContainer ::%@",containerVC);
    
    //NSLog(@"XibName ::%@",[[mutableArray objectAtIndex:currentIndex]objectAtIndex:2]);
    
    
    if([[[mutableArray objectAtIndex:currentIndex]objectAtIndex:2] isKindOfClass:[NSString class]]){
         
        //NSLog(@"Not XIb View class");
        [self removePreviousXibView:containerVC];
        [UIRenderer renderPlist:containerVC plist:[[mutableArray objectAtIndex:currentIndex]objectAtIndex:2]];
		 [containerVC didFinishContainerVC];
    }else {
        [self removePreviousXibView:containerVC];
        
        NSString *className = NSStringFromClass([[mutableArray objectAtIndex:currentIndex]objectAtIndex:2]);
        UIView *viewXib =  [[NSClassFromString(className) alloc]init];
        
        [UIRenderer stretchToSuperView: containerVC.xibPlaceholderView];
        [containerVC.xibPlaceholderView addSubview:viewXib];
        [UIRenderer stretchToSuperView: viewXib];
        
        
        NSLog(@"After Add ::%@",[containerVC.xibPlaceholderView subviews]);
    }

    
}

+(void)removePreviousXibView:(UIBaseContainerViewController *)containerVC{
    

    NSString *classString = NSStringFromClass([containerVC class]);
   
    if([classString isEqualToString:@"QuestionnaireViewController"]){
        NSArray *questionArray = [containerVC.view subviews];
        
        
        for (UIView *contentView in questionArray){
            
            //remove firstView & secondview content in QuestionnaireViewcontroller
            if ([contentView isMemberOfClass:[UIView class]]){
                
                NSArray *subContentArray = [contentView subviews];
                
                for (id subcontent in subContentArray) {
                    [subcontent removeFromSuperview];
                }
            }
        }
        
        
    }else {
    
    NSArray *viewsToRemove = [containerVC.xibPlaceholderView subviews];
   

    for (UIView *v in viewsToRemove) {
        [v removeFromSuperview];
    }

    }
    NSLog(@"final ::%@",[containerVC.xibPlaceholderView subviews]);
    
}


+(void)deleteAfter:(id)baseVC container:(id)containerVC xib:(id)xibClass {
    
    
    NSArray *compareArray =  [NSArray arrayWithObjects:baseVC,containerVC,xibClass, nil];
    
    for (int i=(mutableArray.count-1);i>0;i--){
        
        NSArray *childArray = [mutableArray objectAtIndex:i];
        
        if([childArray isEqualToArray:compareArray]){
            break;
        }else {
            [mutableArray removeObjectAtIndex:i];
        }
        
        
    }
    NSLog(@"Final Array ::%@",mutableArray);
}

//vrl added
+(void)deleteNextScreens:(id)baseVC container:(id)containerVC xib:(id)xibClass {
    
    
    NSArray *compareArray =  [NSArray arrayWithObjects:baseVC,containerVC,xibClass, nil];
    int j=0;
    for (int i=0;i<mutableArray.count;i++){
        
        NSArray *childArray = [mutableArray objectAtIndex:i];
        
        if([childArray isEqualToArray:compareArray]){
            [mutableArray removeObjectAtIndex:i];
            j=j+1;
        }else {
            if(j>0){
                [mutableArray removeObjectAtIndex:i];
            }
        }
    }
        NSLog(@"new Final Array ::%@",mutableArray);
}


+(void)assignCurrentIndex:(NSInteger)index {
    
    currentIndex = index;
}

+(id)getCurrentVCInfo{
    
    return [mutableArray objectAtIndex:currentIndex];
}

+(id)getNextVCInfo {
    if (mutableArray.count > (currentIndex + 1))
        return [mutableArray objectAtIndex:currentIndex + 1];
    return [mutableArray objectAtIndex:currentIndex];
}


+(id)getPreviousVCInfo {
    if (mutableArray.count > (currentIndex + 1)){
        return [mutableArray objectAtIndex:currentIndex - 1];
    }
    
    return [mutableArray objectAtIndex:currentIndex];
}

+(void)clearNavigationQueue:(NSInteger)index{
	
    NSLog(@"Clear Navigation Queue");
	[mutableArray removeAllObjects];
    NSLog(@"After clear Navigation Array ::%@",mutableArray);
 currentIndex = index;
}

//vrl added
+(NSUInteger)getCurrentVCIndex {
    return currentIndex;
}

+(NSMutableArray *)getPushlistArray {
    return mutableArray;
}

@end
