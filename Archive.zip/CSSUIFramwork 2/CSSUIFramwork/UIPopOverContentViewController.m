//
//  UIPopOverContentViewController.m
//  SampleBCBSPOC
//
//  Created by CSS Admin on 5/26/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import "UIPopOverContentViewController.h"
#import "LanguageCentral.h"


 NSString *const contentCellIdentifier = @"PopOverContentCell";
NSString *const checkMarkUnicodeString = @"\u2713";
NSUInteger selectedrow = 0;

@interface UIPopOverContentViewController (){
    UIView *popoverView;
    NSDateFormatter *dateFormatter;
}

@end

@implementation UIPopOverContentViewController
@synthesize contentListArray,isMultipleSelection,isDatePicker,selectedString,delegate;
@synthesize datePicker,isPopOverBirthDate,isPlanDropDown;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //Register our custom subclass
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:contentCellIdentifier];
    
    dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"MM/dd/yyyy"];
    
    //self-sizing magic
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.estimatedRowHeight = 44; //set this to any value that works for you

    
    // This will remove extra separators from tableview
    self.tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    
    isMultipleSelection = NO;
    //multiplerow selection
    self.tableView.allowsMultipleSelection = isMultipleSelection;
    
    if (isDatePicker){
        
        self.tableView.hidden = YES;
        [self datePickerShow];
        
    }else {
        self.tableView.hidden = NO;
    }
    

}


-(void)datePickerShow{
    
    
    popoverView = [[UIView alloc] initWithFrame:CGRectMake(0,20,320,250)];   //view
    popoverView.backgroundColor = [UIColor clearColor];
    
    datePicker = [[UIDatePicker alloc]init];//Date picker
    datePicker.frame= CGRectMake(0,20,320, 216);
    datePicker.datePickerMode = UIDatePickerModeDate;
    [datePicker addTarget:self action:@selector(dateResult:) forControlEvents:UIControlEventValueChanged];//need to implement this method in same class
    
	if(isPopOverBirthDate){
		datePicker.maximumDate = [NSDate date];
		isPopOverBirthDate = NO;
	}
    
    if(selectedString.length > 0 && ![selectedString isEqualToString:@"Select"]){
        NSDate *date = [dateFormatter dateFromString:selectedString];
        self.datePicker.date = date;
    }
    
	[popoverView addSubview:datePicker];
    self.view = popoverView;
   

}

-(void)dateResult:(UIDatePicker *)datePicker {
    

    NSString *strDate = [dateFormatter stringFromDate:datePicker.date];
    selectedString = strDate;
    //NSLog(@"Selected DateString ::%@",selectedString);
    [delegate getSelectedTextString:selectedString];
   
    
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [contentListArray count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = (UITableViewCell *)[tableView dequeueReusableCellWithIdentifier:contentCellIdentifier];
    if(cell == nil ){
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:contentCellIdentifier];
    }
    // Add tick mark as unicode in tableview content
    NSArray *indexPaths = [tableView indexPathsForSelectedRows];
    if(isMultipleSelection){
        if([indexPaths containsObject:indexPath]){
            
            NSString *contentString = [LanguageCentral languageSelectedString:[contentListArray objectAtIndex:indexPath.row]];
            NSString *localizeString = (contentString.length>0)?contentString:[contentListArray objectAtIndex:indexPath.row];
            
            NSString *strFinalText = [NSString stringWithFormat:@"%@ %@",checkMarkUnicodeString,localizeString];
            NSMutableAttributedString *strAttributedText = [[NSMutableAttributedString alloc]initWithString:strFinalText];
            NSRange range=[strFinalText rangeOfString:checkMarkUnicodeString];
            [strAttributedText addAttribute:NSForegroundColorAttributeName
                                      value:[UIColor blueColor]
                                      range:range];
            cell.textLabel.attributedText = strAttributedText;
        }else if(indexPath.row == 0){
            
            NSString *contentString = [LanguageCentral languageSelectedString:[contentListArray objectAtIndex:indexPath.row]];
            NSString *localizeString = (contentString.length>0)?contentString:[contentListArray objectAtIndex:indexPath.row];
            
            NSString *strFinalText = [NSString stringWithFormat:@"    %@",localizeString];
            NSMutableAttributedString *strAttributedText = [[NSMutableAttributedString alloc]initWithString:strFinalText];
            NSRange range=[strFinalText rangeOfString:checkMarkUnicodeString];
            [strAttributedText addAttribute:NSForegroundColorAttributeName
                                      value:[UIColor blueColor]
                                      range:range];
            cell.textLabel.attributedText = strAttributedText;
        }else {
            
            NSString *contentString = [LanguageCentral languageSelectedString:[contentListArray objectAtIndex:indexPath.row]];
            NSString *localizeString = (contentString.length>0)?contentString:[contentListArray objectAtIndex:indexPath.row];
            
            cell.textLabel.text = [NSString stringWithFormat:@"    %@",localizeString];
        }
    }else {
        if(indexPath.row == selectedrow && [selectedString isEqualToString:[contentListArray objectAtIndex:indexPath.row]] && [selectedString rangeOfString:@"Select"].location == NSNotFound) {
            
            NSString *contentString = [LanguageCentral languageSelectedString:[contentListArray objectAtIndex:indexPath.row]];
            NSString *localizeString = (contentString.length>0)?contentString:[contentListArray objectAtIndex:indexPath.row];
            
            NSString *strFinalText = [NSString stringWithFormat:@"%@ %@",checkMarkUnicodeString,localizeString];
            NSMutableAttributedString *strAttributedText = [[NSMutableAttributedString alloc]initWithString:strFinalText];
            NSRange range=[strFinalText rangeOfString:checkMarkUnicodeString];
            [strAttributedText addAttribute:NSForegroundColorAttributeName
                                      value:[UIColor blueColor]
                                      range:range];
            cell.textLabel.attributedText = strAttributedText;
        }else {
            
            NSString *contentString = [LanguageCentral languageSelectedString:[contentListArray objectAtIndex:indexPath.row]];
            NSString *localizeString = (contentString.length>0)?contentString:[contentListArray objectAtIndex:indexPath.row];
            
            cell.textLabel.text = [NSString stringWithFormat:@"    %@",localizeString];
        }
    }
    return cell;
}




-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
//    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    
    selectedrow = indexPath.row;
    
    if(isMultipleSelection){
        
        NSString *contentString = [LanguageCentral languageSelectedString:[contentListArray objectAtIndex:indexPath.row]];
        NSString *localizeString = (contentString.length>0)?contentString:[contentListArray objectAtIndex:indexPath.row];
        
        NSString *strFinalText = [NSString stringWithFormat:@"%@ %@",checkMarkUnicodeString,localizeString];
        NSMutableAttributedString *strAttributedText = [[NSMutableAttributedString alloc]initWithString:strFinalText];
        NSRange range=[strFinalText rangeOfString:checkMarkUnicodeString];
        
        [strAttributedText addAttribute:NSForegroundColorAttributeName
                                  value:[UIColor blueColor]
                                  range:range];
        
        cell.textLabel.attributedText = strAttributedText;
    }else {
        [tableView reloadData];
    }
    
    NSString *contentString = [LanguageCentral languageSelectedString:[contentListArray objectAtIndex:indexPath.row]];
    NSString *localizeString = (contentString.length>0)?contentString:[contentListArray objectAtIndex:indexPath.row];
    
    selectedString = localizeString;
    
    //NSLog(@"Selected String ::%@",selectedString);
    
    [delegate getSelectedTextString:selectedString];
    
    [self dismissViewControllerAnimated:YES completion:nil];
    

}


-(void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if(isMultipleSelection){
        UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
        
        NSString *contentString = [LanguageCentral languageSelectedString:[contentListArray objectAtIndex:indexPath.row]];
        NSString *localizeString = (contentString.length>0)?contentString:[contentListArray objectAtIndex:indexPath.row];
        
        cell.textLabel.text = [NSString stringWithFormat:@"    %@",localizeString];
    }
}


- (CGSize)preferredContentSize {
    if(isDatePicker){
        
       return popoverView.frame.size;
    }else if(isPlanDropDown){
        return CGSizeMake(self.tableView.contentSize.width-75, self.tableView.contentSize.height);
    }
    else {
        return CGSizeMake(self.tableView.contentSize.width/2.0, self.tableView.contentSize.height);
    }
}

-(void)popoverPresentationControllerDidDismissPopover:(UIPopoverPresentationController *)popoverPresentationController{
    
    //NSLog(@"Dismiss popover");
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
