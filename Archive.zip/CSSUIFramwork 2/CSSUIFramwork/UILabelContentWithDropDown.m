//
//  UILabelContentWithDropDown.m
//  CSSUIFramwork
//
//  Created by CSS Admin on 6/16/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import "UILabelContentWithDropDown.h"

@implementation UILabelContentWithDropDown
@synthesize headingLabel,labelDropDownView;
@synthesize xPath;


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    
    [super drawRect:rect];
}


-(instancetype)initWithCoder:(NSCoder *)aDecoder {
    
    self = [super initWithCoder:aDecoder];
    if(self){
        
        
        [self loadContentView];
        
    }
    return self;
    
}

-(instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if(self){
      
        [self loadContentView];
    }
    return self;
    
}


-(void)loadContentView {

    headingLabel = [[ValidatorLabel alloc]init];
    headingLabel.numberOfLines = 0;
    [headingLabel setFont:[UIFont fontWithName:@"Arial" size:18.0]]; 
    headingLabel.textColor = [UIColor colorWithRed:102.0/255.0 green:102.0/255.0 blue:102.0/255.0 alpha:1.0];
    headingLabel.textAlignment = NSTextAlignmentLeft;
    headingLabel.lineBreakMode = NSLineBreakByWordWrapping;
    headingLabel.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight ;

    [self addSubview:headingLabel];
    [headingLabel setTranslatesAutoresizingMaskIntoConstraints:NO];

    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-10-[headingLabel]-10-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(headingLabel)]];



    labelDropDownView = [[UILabeledButton alloc]init];

    labelDropDownView.backgroundColor = [UIColor whiteColor];
    labelDropDownView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight ;

    //    labelTextView.textView.text = [ NSString stringWithFormat:@"%@",@"Hello world"];
    
    [self addSubview:labelDropDownView];


    [labelDropDownView setTranslatesAutoresizingMaskIntoConstraints:NO];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-5-[labelDropDownView]-5-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(labelDropDownView)]];

    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-5-[headingLabel(>=21)]-5-[labelDropDownView(>=95)]->=5-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(labelDropDownView,headingLabel)]];

    [self setNeedsUpdateConstraints];
    [self layoutIfNeeded];


}


-(void)setDisableDropDown:(BOOL)disableDropDown {
    
   
    _disableDropDown = disableDropDown;
    
    if(!disableDropDown){
        [labelDropDownView enableDropDownView];
    }else { 
        [labelDropDownView disableDropDownView];
    }
    
}

-(NSString *)xPath {
	return xPath;
}


@end
