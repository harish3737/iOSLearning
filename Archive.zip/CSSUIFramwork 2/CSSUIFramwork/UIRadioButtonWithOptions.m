//
//  UIRadioButtonWithOptions.m
//  CSSUIFramwork
//
//  Created by CSS Admin on 7/26/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import "UIRadioButtonWithOptions.h"

#define DETAILTEXTCOLOR [UIColor colorWithRed:(102.0/255.0) green:(102.0/255.0) blue:(102.0/255.0) alpha:1.0f]

@implementation UIRadioButtonWithOptions

@synthesize xPath;


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    
    [super drawRect:rect];
}


-(instancetype)initWithCoder:(NSCoder *)aDecoder {
    
    self = [super initWithCoder:aDecoder];
    if(self){
        
        [self loadRadioButtonXibFile];
    }
    return self;
    
}

-(instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if(self)
    {
        
        [self loadRadioButtonXibFile];
    }
    return self;
    
}



-(void)loadRadioButtonXibFile {
    
    [[NSBundle mainBundle]loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
    self.bounds = self.radioBtnOptionsView.bounds;
    [self addSubview:self.radioBtnOptionsView];
    _radioButton.delegate = self;

    [_labelDropDownView disableDropDownView];
    
}

////vrl
//-(void)awakeFromNib {
//
//    [_radioButton setButtonSelected:YES]; //vrl
//    [super awakeFromNib];
//}


-(void)layoutSubviews {
    
    [super layoutSubviews];
    
    
}

-(NSString *)getValueString{
    
    return @"_";
}

-(NSString *)xPath {
    return xPath;
}

- (IBAction)contentTapAction:(id)sender {
    
     [_radioButton redioActionBase:nil];
    
}

-(void)changeStateOnButtonTapped:(id)radioButton {
    
    UIView* activeRadioButtonSuperView =  [[radioButton getActiveButton] superview];
    NSArray *superviewArray = [activeRadioButtonSuperView subviews];
    [self.contentButton setUserInteractionEnabled:[radioButton isUserInteractionEnabled]];
    
    if(superviewArray.count>2){
        
        NSString *labeledBtnClassName = NSStringFromClass([[superviewArray objectAtIndex:2] class]);
        
        if([labeledBtnClassName isEqualToString:@"UILabeledButton"]){
            UILabeledButton *labeledButtonView = [superviewArray objectAtIndex:2];
            [labeledButtonView disableDropDownView];
            [labeledButtonView resetDropDownTitle];
            
        }
    }
    NSString *multilingualBtn = NSStringFromClass([[superviewArray objectAtIndex:1] class]);
    if([multilingualBtn isEqualToString:@"UIMultiLingualButton"]){
        UIMultiLingualButton *subcontentBtn = [superviewArray objectAtIndex:1];
        subcontentBtn.userInteractionEnabled = YES;
    }
    
    if(activeRadioButtonSuperView==nil){
        
        UIView* btnSuperView =  [radioButton superview];
        NSArray *viewArray = [btnSuperView subviews];
        //NSLog(@"array ::%@",superviewArray);
        
        NSString *multilingualBtn = NSStringFromClass([[viewArray objectAtIndex:1] class]);
        if([multilingualBtn isEqualToString:@"UIMultiLingualButton"]){
            UIMultiLingualButton *subcontentBtn = [viewArray objectAtIndex:1];
            [subcontentBtn setTitleColor:DETAILTEXTCOLOR forState:UIControlStateNormal];
            
        }
        
    }
    [_labelDropDownView enableDropDownView];
}

@end
