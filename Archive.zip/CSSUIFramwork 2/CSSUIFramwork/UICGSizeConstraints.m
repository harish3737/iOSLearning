//
//  UICGSizeConstraints.m
//  BcBs
//
//  Created by CSS Admin on 6/17/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "UICGSizeConstraints.h"

@implementation UICGSizeConstraints


-(void)setWidth:(NSNumber *)width {
    
    _width = width;
    
}

-(void)setHeight:(NSNumber *)height {
    
    _height = height;
    
}

-(void)setTopSpace:(NSNumber *)topSpace {
    _topSpace = topSpace;
}

-(void)setBottomSpace:(NSNumber *)bottomSpace {
    
    _bottomSpace = bottomSpace;
}

-(void)setLeadingSpace:(NSNumber *)leadingSpace {
    
    _leadingSpace = leadingSpace;
}

-(void)setTrailingSpace:(NSNumber *)trailingSpace {
    
    _trailingSpace = trailingSpace;
}

-(void)setVerticalSpace:(NSNumber *)verticalSpace{
    _verticalSpace = verticalSpace;
}

-(void)setHorizontalSpace:(NSNumber *)horizontalSpace{
    _horizontalSpace = horizontalSpace;
}



-(id)init {
    
    self = [super init];
    
    if(self)
    {
        
        _height = [NSNumber numberWithInt:95];
        _width = [NSNumber numberWithInt:100];
        _topSpace = [NSNumber numberWithInt:20];
        _bottomSpace = [NSNumber numberWithInt:20];
        _leadingSpace = [NSNumber numberWithInt:100];
        _trailingSpace = [NSNumber numberWithInt:100];
        _verticalSpace = [NSNumber numberWithInt:20];
        _horizontalSpace = [NSNumber numberWithInt:8];

        

    }
    
    return self;
    
}

@end
