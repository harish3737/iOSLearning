//
//  SharedData.m
//  CSSUIFramwork
//
//  Created by CSS Admin on 7/12/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import "SharedData.h"

@implementation SharedData


-(id)init {
    
    self = [super init];
    if(self){
        
    }
    return self;
}

-(void)setForwardNextButtonTitle:(NSString *)forwardNextButtonTitle {
    
    _forwardNextButtonTitle = forwardNextButtonTitle;
    NSLog(@"Set nextButtonTitle ::%@",_forwardNextButtonTitle);
}

-(void)setNextProgressIndex:(NSUInteger)nextProgressIndex {
    _nextProgressIndex = nextProgressIndex;
    NSLog(@"Set progressIndex::%lu",(unsigned long)_nextProgressIndex);
}



@end
