//
//  FileInterceptor.h
//  FileOperation
//
//  Created by Ganesh on 01/07/16.
//  Copyright (c) 2016 CSS. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface QueryProcessor : NSObject 



+(NSString *) generateQuery : (NSString *)template :(NSDictionary *)element;
+(void)requestProcessor : (NSString *)jsonString :(NSString *)template;

@end
