//
//  UIDatePickerView.m
//  CSSUIFramwork
//
//  Created by CSS Admin on 5/23/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import "UIDatePickerView.h"

@implementation UIDatePickerView


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    //NSLog(@"Draw Rect ");

    // Important when add xib in framework and load in another project
//    NSString *const frameworkBundleID = @"com.csscorp.CSSUIFramwork";
//    NSBundle *bundle = [NSBundle bundleWithIdentifier:frameworkBundleID];
//    [bundle loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
    
  
     // Important notes when add xib in framework and load in another project
//    NSBundle *bundle = [NSBundle bundleForClass:[self class]];
//    [bundle loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
    
    
    [[NSBundle mainBundle]loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
    
    self.bounds = self.datePickerButtonView.bounds;
    
    [self addSubview:self.datePickerButtonView];

    [super drawRect:rect];
}


-(instancetype)initWithCoder:(NSCoder *)aDecoder {
    
    
    self = [super initWithCoder:aDecoder];
    if(self){
        
        //NSLog(@"loadXib datePicker");
        [[NSBundle mainBundle]loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
        
        self.bounds = self.datePickerButtonView.bounds;
        
        [self addSubview:self.datePickerButtonView];
        
    }
    return self;
    
}

@end
