//
//  ValidatorLabel.h
//  SampleBCBSPOC
//
//  Created by CSS Admin on 4/5/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Validator.h"


@interface ValidatorLabel : UILabel

@property(nonatomic) IBInspectable NSString *localizationKey;

@property(nonatomic) IBInspectable NSString *customTextKey;

@property(nonatomic,strong) NSString *customFontSize;
@property(nonatomic,strong) NSString *customFontName;


@end
