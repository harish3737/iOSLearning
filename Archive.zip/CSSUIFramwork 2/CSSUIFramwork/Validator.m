//
//  Validator.m
//  CSSUIFramwork
//
//  Created by CSS Admin on 4/8/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import "Validator.h"
#import "ValidatorTextField.h"
#import "UILabledTextField.h"
#import "UIRadioButton.h"


@implementation Validator


static DataValidator emailValidator;
static DataValidator passwordValidator;
static DataValidator numberValidator;
static DataValidator phonenumberValidator;
static DataValidator alphabetValidator;
static DataValidator noValidator;
static DataValidator alphaNumericSpecialCharValidator;
static DataValidator mandatoryValidator;
static DataValidator emptyValidator;
static DataValidator zipcodeValidator;
static DataValidator optionalEmailValidator;
static DataValidator optionalAlphabetValidator;
static DataValidator optionalNumberValidator;
static DataValidator alphaNumericValidator;
static DataValidator addressValidator;
static DataValidator optionalAlphaNumericValidator;
static DataValidator singleAlphabetValidator;
static DataValidator optionalSingleAlphabetValidator;
static DataValidator optionalAlphabetWithSpaceValidator;
static DataValidator optionalAddressValidator;
static DataValidator optionalZipcodeValidator;
static DataValidator optionalPhonenumberValidator;

static DataValidator medicareBeneficiaryIDValidator;
    
static DataValidator medicareNumberValidator;

static DataValidator equalStringValidator;
static DataValidator notequalStringValidator;

static NSMutableDictionary *validatorDict;
static id tailItem;
static id headItem;
static UICallback* dummyCallback = nil;

#define EMAILREGEX @"^[A-Z0-9a-z\\._%+-]+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}$"

#define PHONENUMBERREGEX @"(?:7(?:0(?:2[2-9]|[3-8]\\d|9[0-8])|2(?:0[024-9]|19|2[012]|5[09]|7[5-8]|9[389])|3(?:0[1-9]|[58]\\d|7[3679]|9[689])|4(?:0[1-9]|1[15-9]|[29][89]|39|8[389])|5(?:[034678]\\d|2[03-9]|5[017-9]|9[7-9])|6(?:0[0127]|1[0-257-9]|2[0-4]|3[19]|5[4589]|[6-9]\\d)|7(?:0[2-9]|[1-79]\\d|8[1-9])|8(?:[0-7]\\d|9[013-9]))|8(?:0(?:[01589]\\d|6[67])|1(?:[02-589]\\d|1[0135-9]|7[0-79])|2(?:[236-9]\\d|5[1-9])|3(?:[0357-9]\\d|4[1-9])|[45]\\d{2}|6[02457-9]\\d|7[1-69]\\d|8(?:[0-26-9]\\d|44|5[2-9])|9(?:[035-9]\\d|2[2-9]|4[0-8]))|9\\d{3})\\d{6}"

#define PASSWORDREGEX @"[A-Za-z]+" //matches one or more letters

//#define ALPHABETSONLYREGEX @"^[a-zA-Z]+$" //matches only strings that consist of one or more letters only (^ and $ mark the begin and end of a string respectively).

#define ALPHABETSONLYREGEX @"^[a-zA-Z_]+( [a-zA-Z_]+)*$" //matches only strings that consist of one or more letters only (^ and $ mark the begin and end of a string respectively).

//#define NUMBERSONLYREGEX @"^[0-9]+$" // matches one or more numbers only

#define NUMBERSONLYREGEX @"^[0-9_]+( [0-9_]+)*$" // matches one or more numbers only

#define ALPHANUMERICSPECIALCHARACTERREGX @"^(?=.*[0-9. ])(?=.*[a-zA-Z. ])(?=.*[$@$!%*#?&^'()+,-/:;<=>_`{|}~\\[\\]\\\\. ])([A-Za-z0-9$@$!%*#?&^'()+,-/:;<=>_`{|}~\\[\\]\\\\. ]+)$"

//#define ZIPCODEREGEX @"^(\\d{5}(-\\d{4})?|[a-z]\\d[a-z][- ]*\\d[a-z]\\d)$" // for canada & US
#define ZIPCODEREGEX @"(^[0-9]{5}(-[0-9]{4})?$)"

#define ALPHANUMERICREGEX @"[A-Za-z0-9]*$"

#define ADDRESSREGEX @"[A-Za-z0-9 #,/.-]+$"

#define ALPHABETWITHSPACE_REGEX @"^[a-zA-Z]+( [a-zA-Z]+)*$"

#define MEDICARE_BENEFICIARY_ID_REGEX @"^[1-9]((?![SLOIBZ])[A-Z])((?![SLOIBZ])[A-Z0-9])[0-9]((?![SLOIBZ])[A-Z])((?![SLOIBZ])[A-Z0-9])[0-9]((?![SLOIBZ])[A-Z]){2}[0-9]{2}$"

+ (DataValidator)EmailValidator {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        emailValidator = ^bool(id data){
            ValidatorTextField *emailTextField = data;
            NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",EMAILREGEX];
            return ([emailTest evaluateWithObject:emailTextField.text]&&(emailTextField.text.length>0))?1:0;
            
        };
    });
    return emailValidator;
}


+ (DataValidator)AlphaNumericSpecialCharacterValidator{
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        alphaNumericSpecialCharValidator = ^bool(id data){
            ValidatorTextField *emailTextField = data;
            NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",ALPHANUMERICSPECIALCHARACTERREGX];
            return ([emailTest evaluateWithObject:emailTextField.text]&&(emailTextField.text.length>0))?1:0;
            
        };
    });
    return alphaNumericSpecialCharValidator;
    
}

+ (DataValidator)PhoneNumberValidator{
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        phonenumberValidator = ^bool(id data){
            
            ValidatorTextField *numbertextField = data;
            
            NSPredicate *numberTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",NUMBERSONLYREGEX];
            
            if(numbertextField.text.length==10){
                return ([numberTest evaluateWithObject:numbertextField.text]&&(numbertextField.text.length>0))?1:0;
            }else {
                return 0;
            }
        };

    });
    return phonenumberValidator;
}
 
 

+(DataValidator)PasswordValidator{
    
    static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken, ^{
        passwordValidator = ^bool(id data){
            ValidatorTextField *pwdTextField = data;
            
            NSPredicate *passwordTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",ALPHABETSONLYREGEX];
            return ([passwordTest evaluateWithObject:pwdTextField.text]&&(pwdTextField.text.length>0))?1:0;
            
        };
        
    });
    return passwordValidator;
    
}

+(DataValidator)AlphabetValidator{
    
    static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken, ^{
        alphabetValidator = ^bool(id data){
            ValidatorTextField *textField = data;
            
            NSPredicate *stringTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",ALPHABETSONLYREGEX];
            return ([stringTest evaluateWithObject:textField.text]&&(textField.text.length>0))?1:0;
            
        };
        
    });
    return alphabetValidator;
    
}



+(DataValidator)NumberValidator{
    
    static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken, ^{
        numberValidator = ^bool(id data){
            ValidatorTextField *textField = data;
            
            NSPredicate *stringTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",NUMBERSONLYREGEX];
            return ([stringTest evaluateWithObject:textField.text]&&(textField.text.length>0))?1:0;
            
        };
        
    });
    return numberValidator;
    
}


+ (DataValidator) EmptyValidator {
    
    static dispatch_once_t onceToken;

    
    dispatch_once(&onceToken, ^{
        emptyValidator = ^bool(id data){
            ValidatorTextField *textField = data;
            return (textField.text.length>0)?1:0;
        };
        
    });
    return emptyValidator;

}
+(DataValidator)NoValidation{
    
    static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken, ^{
        noValidator = ^bool(id data){
            
            return YES;
        };
        
    });
    return noValidator;
    
}


+(DataValidator)MandatoryValidator{
    
    
    static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken, ^{
        mandatoryValidator = ^bool(id data){
            
            return [data validate];
        };
        
    });
    return mandatoryValidator;

}


+(DataValidator) ZipcodeValidator{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        zipcodeValidator = ^bool(id data){
            ValidatorTextField *zipcodeTextField = data;
            NSPredicate *zipcodeTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",ZIPCODEREGEX];
            if(zipcodeTextField.text.length==5){
                return ([zipcodeTest evaluateWithObject:zipcodeTextField.text])?1:0;
            }else {
                return 0;
            }
        };
    });
    return zipcodeValidator;
}

+ (DataValidator) OptionalEmailValidator {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        optionalEmailValidator = ^bool(id data){
            ValidatorTextField *emailTextField = data;
            if(emailTextField.text.length > 0){
                NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",EMAILREGEX];
                return ([emailTest evaluateWithObject:emailTextField.text]&&(emailTextField.text.length>0))?1:0;
            }
            else{
                return 1;
            }
        };
    });
    return optionalEmailValidator;
}


+ (DataValidator) OptionalAlphabetValidator{
    
    static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken, ^{
        optionalAlphabetValidator = ^bool(id data){
            ValidatorTextField *textField = data;
            
            if(textField.text.length > 0){
                NSPredicate *stringTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",ALPHABETSONLYREGEX];
                return ([stringTest evaluateWithObject:textField.text]&&(textField.text.length>0))?1:0;
            }
            else{
                return 1;
            }
        };
        
    });
    return optionalAlphabetValidator;
}
+ (DataValidator) OptionalNumberValidator{
    
    static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken, ^{
        optionalNumberValidator = ^bool(id data){
            ValidatorTextField *textField = data;
            if(textField.text.length > 0){
                NSPredicate *stringTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",NUMBERSONLYREGEX];
                return ([stringTest evaluateWithObject:textField.text]&&(textField.text.length>0))?1:0;
            }
            else{
                return 1;
            }
        };
        
    });
    return optionalNumberValidator;
}

+ (DataValidator) OptionalAlphaNumericValidator{
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        optionalAlphaNumericValidator = ^bool(id data){
            ValidatorTextField *textField = data;
            if(textField.text.length > 0){
                NSPredicate *stringTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",ALPHANUMERICREGEX];
                return ([stringTest evaluateWithObject:textField.text]&&(textField.text.length>0))?1:0;
            }
            else{
                return 1;
            }
        };
    });
    return optionalAlphaNumericValidator;
    
}


+ (DataValidator) AlphaNumericValidator{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        alphaNumericValidator = ^bool(id data){
            ValidatorTextField *textField = data;
            NSPredicate *stringTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",ALPHANUMERICREGEX];
            return ([stringTest evaluateWithObject:textField.text]&&(textField.text.length>0))?1:0;
        };
    });
    return alphaNumericValidator;
}


+ (DataValidator) AddressValidator{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        addressValidator = ^bool(id data){
            ValidatorTextField *textField = data;
            NSPredicate *stringTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",ADDRESSREGEX];
            return ([stringTest evaluateWithObject:textField.text]&&(textField.text.length>0))?1:0;
        };
    });
    return addressValidator;
}


+ (DataValidator)SingleAlphapetValidator{
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        singleAlphabetValidator = ^bool(id data){
            ValidatorTextField *textField = data;
            NSPredicate *stringTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",ALPHABETSONLYREGEX];
            
            if(textField.text.length==1){
                return ([stringTest evaluateWithObject:textField.text])?1:0;
            }else {
                return 0;
            }
        };
    });
    return singleAlphabetValidator;
}

+ (DataValidator) OptionalSingleAlphapetValidator{
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        optionalSingleAlphabetValidator = ^bool(id data){
            ValidatorTextField *textField = data;
            if(textField.text.length > 0){
                NSPredicate *stringTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",ALPHABETSONLYREGEX];
                if(textField.text.length==1){
                    return ([stringTest evaluateWithObject:textField.text])?1:0;
                }else {
                    return 0;
                }
            }
            else{
                return 1;
            }
        };
    });
    return optionalSingleAlphabetValidator;
}

+ (DataValidator) OptionalAlphabetWithSpaceValidator{
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        optionalAlphabetWithSpaceValidator = ^bool(id data){
            ValidatorTextField *textField = data;
            if(textField.text.length > 0){
                NSPredicate *stringTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",ALPHABETWITHSPACE_REGEX];
                return ([stringTest evaluateWithObject:textField.text]&&(textField.text.length>0))?1:0;
            }
            else{
                return 1;
            }
        };
    });
    return optionalAlphabetWithSpaceValidator;
}

+ (DataValidator) OptionalZipcodeValidator{
 
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        optionalZipcodeValidator = ^bool(id data){
            ValidatorTextField *zipcodeTextField = data;
            if(zipcodeTextField.text.length > 0){
                NSPredicate *zipcodeTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",ZIPCODEREGEX];
                if(zipcodeTextField.text.length==5){
                    return ([zipcodeTest evaluateWithObject:zipcodeTextField.text])?1:0;
                }else {
                    return 0;
                }
            }
            else{
                return 1;
            }
        };
    });
    return optionalZipcodeValidator;
}



+ (DataValidator) OptionalAddressValidator{
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        optionalAddressValidator = ^bool(id data){
            ValidatorTextField *textField = data;
            if(textField.text.length > 0){
                NSPredicate *stringTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",ADDRESSREGEX];
                return ([stringTest evaluateWithObject:textField.text]&&(textField.text.length>0))?1:0;
            }
            else{
                return 1;
            }
        };
    });
    return optionalAddressValidator;
    
}


//NSLog(@"Number ::%d",[numberTest evaluateWithObject:numbertextField.text]);


+ (DataValidator) OptionalPhoneNumberValidator{
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        optionalPhonenumberValidator = ^bool(id data){
            ValidatorTextField *numbertextField = data;
            if(numbertextField.text.length > 0){
                NSPredicate *numberTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",NUMBERSONLYREGEX];
                if(numbertextField.text.length==10){
                   return ([numberTest evaluateWithObject:numbertextField.text]&&(numbertextField.text.length>0))?1:0;
                }else {
                    return 0;
                }
            }
            else{
                return 1;
            }
        };
    });
    return optionalPhonenumberValidator;
    
    
}


+ (DataValidator) MedicareBeneficiaryIDValidator{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        medicareBeneficiaryIDValidator = ^bool(id data){
            ValidatorTextField *textField = data;
            NSPredicate *stringTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",MEDICARE_BENEFICIARY_ID_REGEX];
            return ([stringTest evaluateWithObject:textField.text]&&(textField.text.length==11))?1:0;
        };
    });
    return medicareBeneficiaryIDValidator;
}
    
    
+(DataValidator) MedicareNumberValidator{
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        medicareNumberValidator = ^bool(id data){
            ValidatorTextField *textField = data;
            NSPredicate *stringTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",ALPHANUMERICREGEX];
            return ([stringTest evaluateWithObject:textField.text]&&(textField.text.length==textField.maxLength))?1:0;
        };
    });
    return medicareNumberValidator;
    
}

+(DataValidator)EqualStringValidator{
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        equalStringValidator = ^bool(id data){
            NSDictionary *dataDict = data;
//            NSLog(@"appconfig render ::%@",[self getValueFromXpath:appconfigPlanData :[dataDict valueForKey:@"xPath"]]);
//            NSLog(@"compareValue ::%@",[dataDict valueForKey:@"compareValue"]);
            //            NSLog(@"current Plan Dict ::%@",appconfigPlanData);
            
            if([[dataDict valueForKey:@"xPath"] containsString:@"tempJSON"]){
//                NSLog(@"working TEMPJSON EqualStringValidator");
                 return [[self getValueFromXpath:appconfigExtraData :[dataDict valueForKey:@"xPath"]] isEqualToString:[dataDict valueForKey:@"compareValue"]];
            }else {
                 return [[self getValueFromXpath:appconfigPlanData :[dataDict valueForKey:@"xPath"]] isEqualToString:[dataDict valueForKey:@"compareValue"]];
            }
            
//            return [[self getValueFromXpath:appconfigPlanData :[dataDict valueForKey:@"xPath"]] isEqualToString:[dataDict valueForKey:@"compareValue"]];
        };
    });
    return equalStringValidator;
    
}

+(DataValidator)NotEqualStringValidator{
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        notequalStringValidator = ^bool(id data){
            NSDictionary *dataDict = data;
//            NSLog(@"appconfig render ::%@",[self getValueFromXpath:appconfigPlanData :[dataDict valueForKey:@"xPath"]]);
//            NSLog(@"compareValue ::%@",[dataDict valueForKey:@"compareValue"]);
            //            NSLog(@"current Plan Dict ::%@",appconfigPlanData);
            
            if([[dataDict valueForKey:@"xPath"] containsString:@"tempJSON"]){
//                NSLog(@"working TEMPJSON NotEqualStringValidator");
               return ![[self getValueFromXpath:appconfigExtraData :[dataDict valueForKey:@"xPath"]] isEqualToString:[dataDict valueForKey:@"compareValue"]];
            }else {
                return ![[self getValueFromXpath:appconfigPlanData :[dataDict valueForKey:@"xPath"]] isEqualToString:[dataDict valueForKey:@"compareValue"]];
            }
        };
    });
    return notequalStringValidator;
}

-(id)init {
    
    if (self = [super init]) {
    
//        [Validator OnSuccess];
//        [Validator OnFailed];
    }
    return self;

}



+(BOOL)validate:(DataValidator)validate Data:(id)dataValue CallBack:(UICallback *)callback; {
    
    if(validate(dataValue)){
        callback.onSuccess(dataValue);
        return YES;
    }else {
        callback.onFailed(dataValue);
        return NO;
    }
    
}


+ (NSMutableDictionary *)ValidatorDictionary{
    
    static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken, ^{
        
        validatorDict = [NSMutableDictionary dictionaryWithObjectsAndKeys:[Validator EmailValidator],@"EmailValidator",[Validator PasswordValidator],@"PasswordValidator",[Validator NumberValidator],@"NumberValidator",[Validator AlphabetValidator],@"AlphabetValidator",[Validator PhoneNumberValidator],@"PhoneNumberValidator",[Validator NoValidation],@"NoValidation",[Validator AlphaNumericSpecialCharacterValidator],@"AlphaNumericSpecialCharacterValidator",[Validator MandatoryValidator],@"MandatoryValidator",[Validator EmptyValidator],@"EmptyValidator",[Validator ZipcodeValidator],@"ZipcodeValidator",[Validator OptionalEmailValidator],@"OptionalEmailValidator",[Validator AlphaNumericValidator],@"AlphaNumericValidator",[Validator OptionalAlphabetValidator],@"OptionalAlphabetValidator",[Validator OptionalNumberValidator],@"OptionalNumberValidator",[Validator AddressValidator],@"AddressValidator",[Validator OptionalAlphaNumericValidator],@"OptionalAlphaNumericValidator",[Validator SingleAlphapetValidator],@"SingleAlphapetValidator",[Validator OptionalSingleAlphapetValidator],@"OptionalSingleAlphapetValidator",[Validator OptionalAlphabetWithSpaceValidator],@"OptionalAlphabetWithSpaceValidator",[Validator OptionalZipcodeValidator],@"OptionalZipcodeValidator",[Validator OptionalAddressValidator],@"OptionalAddressValidator",[Validator OptionalPhoneNumberValidator],@"OptionalPhoneNumberValidator",[Validator MedicareBeneficiaryIDValidator],@"MedicareBeneficiaryIDValidator",[Validator MedicareNumberValidator],@"MedicareNumberValidator",[Validator EqualStringValidator],@"EqualStringValidator",[Validator NotEqualStringValidator],@"NotEqualStringValidator",nil];
        
    });
    return validatorDict;
}

+ (id)tailItem{
    
    //NSLog(@"Get TailItem ::%@",tailItem);
    return tailItem;
}

+ (void) tailItem:(id)newitem{
    
    tailItem = newitem;
     //NSLog(@"set TailItem ::%@",tailItem);
    [self headItem:tailItem];
    
}

+(DataValidator)getValidator:(NSString *)keyString{
//    NSLog(@"GET Validator String ::%@",keyString);
    NSMutableDictionary *validatorBlockDict = [self ValidatorDictionary];
//    //NSLog(@"Validator Dict ::%@",validatorBlockDict);
   
    return [validatorBlockDict valueForKey:keyString];
}


+(void)headItem:(id)itemValue {
    
    if(headItem==nil){
        
        headItem = itemValue;
        //NSLog(@"HeadItem ::%@",headItem);
    }
}

+(id)headItem{
    return headItem;
}

+(BOOL)Validate {
    
//    return [self recursiveValiate:headItem];
    return [self validateALL:headItem];
}

+(BOOL)recursiveValiate:(id)currentItem {
    
    if(currentItem !=nil){
        
//        if(![currentItem validate]){
//            return NO;
//        }
        if(![self validate:[currentItem dataValidator] Data:currentItem CallBack:[currentItem callback]]){
            return NO;
        }
    }else {
        return YES;
    }
    return [self recursiveValiate:[currentItem getNextField]];
}

+(BOOL)validateALL:(id)currentItem {
    
	BOOL success = YES;
	
	while (currentItem!=nil) {
		
		if(![currentItem isUserInteractionEnabled]){
			
			currentItem = [currentItem getNextField];
			continue;
		}
		
		if(![self validate:[currentItem dataValidator] Data:currentItem CallBack:[currentItem callback]]){
			success = NO;
		}
		currentItem = [currentItem getNextField];
		
	}
	return success;
}


+(void)ValidationDone{
	
    headItem = nil;
    tailItem = nil;

}


+(NSString *)getValueFromXpath:(NSDictionary *)requestDict :(NSString *)xPath{
    
    NSDictionary *tmpDict = requestDict;
    NSMutableArray *keysArray = [NSMutableArray arrayWithArray:[xPath componentsSeparatedByString:@":"]];
    
    if([keysArray containsObject:@"tempJSON"]){
        [keysArray removeObjectAtIndex:0];
    }
    
    for(int iteration=0; iteration<[keysArray count]-1; iteration++)
    {
        tmpDict = [tmpDict objectForKey:[keysArray objectAtIndex:iteration]];
    }
    
    //NSLog(@"getXpathValue ::%@",[tmpDict valueForKey:[keysArray objectAtIndex:[keysArray count]-1]]);
    return [tmpDict valueForKey:[keysArray objectAtIndex:[keysArray count]-1]];
    
}

+(void)setAppConfigPlanData:(NSMutableDictionary *)planData{
    
    appconfigPlanData = planData;
}

+(void)setExtraData:(id)extraData {
    
    appconfigExtraData = extraData;
}
@end
