//
//  UIRadioButtonWithTextViewOptions.m
//  CSSUIFramwork
//
//  Created by Ganesh on 08/08/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import "UIRadioButtonWithTextViewOptions.h"
#import "UILabeledButton.h"


#define DETAILTEXTCOLOR [UIColor colorWithRed:(102.0/255.0) green:(102.0/255.0) blue:(102.0/255.0) alpha:1.0f]

@implementation UIRadioButtonWithTextViewOptions



- (void)drawRect:(CGRect)rect {
	// Drawing code
	[super drawRect:rect];
}

-(instancetype)initWithCoder:(NSCoder *)aDecoder {
	
	
	self = [super initWithCoder:aDecoder];
	if(self){
		[self setUpXibFile];
		
	}
	return self;
}

-(instancetype)initWithFrame:(CGRect)frame {
	
	
	self = [super initWithFrame:frame];
	if(self){
		[self setUpXibFile];
		
	}
	return self;
	
}

-(void)setUpXibFile {
	
	//1. Load a Xib
	[[NSBundle mainBundle]loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
	
	self.bounds = self.radioBtnView.bounds;
	//3.Add as a subview
	[self addSubview:self.radioBtnView];
	
	_radioButton.delegate = self;
    
    [_contentButton setTitleEdgeInsets:UIEdgeInsetsMake(-5,0,0,0)];
 

	
}

- (IBAction)contentTapAction:(id)sender {
	
	//NSLog(@"Radio Button Tapped ");
	
	[_radioButton redioActionBase:nil];
	
	
}

-(void)changeStateOnButtonTapped:(id)radioButton {
	
	UIView* activeRadioButtonSuperView =  [[radioButton getActiveButton] superview];
	NSArray *superviewArray = [activeRadioButtonSuperView subviews];
	
	[self.contentButton setUserInteractionEnabled:[radioButton isUserInteractionEnabled]];
	
	if(superviewArray.count>2){
		
		NSString *labeledBtnClassName = NSStringFromClass([[superviewArray objectAtIndex:2] class]);
		
		if([labeledBtnClassName isEqualToString:@"UILabeledButton"]){
			UILabeledButton *labeledButtonView = [superviewArray objectAtIndex:2];
			[labeledButtonView disableDropDownView];
            [labeledButtonView resetDropDownTitle];
			
		}
	}
	NSString *multilingualBtn = NSStringFromClass([[superviewArray objectAtIndex:1] class]);
	if([multilingualBtn isEqualToString:@"UIMultiLingualButton"]){
		UIMultiLingualButton *subcontentBtn = [superviewArray objectAtIndex:1];
        [subcontentBtn setTitleColor:DETAILTEXTCOLOR forState:UIControlStateNormal];
		subcontentBtn.userInteractionEnabled = YES;
	}
    
    if(activeRadioButtonSuperView==nil){
        
        UIView* btnSuperView =  [radioButton superview];
        NSArray *viewArray = [btnSuperView subviews];
        //NSLog(@"array ::%@",superviewArray);
        
        NSString *multilingualBtn = NSStringFromClass([[viewArray objectAtIndex:1] class]);
        if([multilingualBtn isEqualToString:@"UIMultiLingualButton"]){
            UIMultiLingualButton *subcontentBtn = [viewArray objectAtIndex:1];
            [subcontentBtn setTitleColor:DETAILTEXTCOLOR forState:UIControlStateNormal];
            
        }
        
    }
    
     [self.contentButton setTitleColor:DETAILTEXTCOLOR forState:UIControlStateNormal];
	
}



/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
