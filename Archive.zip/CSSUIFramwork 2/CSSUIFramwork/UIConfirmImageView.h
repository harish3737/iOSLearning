//
//  UIConfirmImageView.h
//  CSSUIFramwork
//
//  Created by CSS Admin on 7/8/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIConfirmImageView : UIImageView

@property (nonatomic,strong) NSString *imageViewIdentifier;
@end
