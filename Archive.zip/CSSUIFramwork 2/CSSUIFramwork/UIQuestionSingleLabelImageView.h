//
//  UIQuestionSingleLabelImageView.h
//  CSSUIFramwork
//
//  Created by CSS Admin on 6/22/18.
//  Copyright © 2018 csscorp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ValidatorLabel.h"
#import "UIRadioButton.h"


IB_DESIGNABLE

@interface UIQuestionSingleLabelImageView : UIView<UIRadioButtonDelegate>

@property (strong, nonatomic) IBOutlet UIQuestionSingleLabelImageView *questionContentImageView;

@property (weak, nonatomic) IBOutlet UIImageView *leftImageView;

@property (strong, nonatomic) IBOutlet ValidatorLabel *contentLabel;
@property (strong, nonatomic) IBOutlet UIRadioButton *yesButton;
@property (strong, nonatomic) IBOutlet UIRadioButton *noButton;

@property (strong,nonatomic) NSString *xPath;
@property (strong,nonatomic) NSString *childViewString;
@property (strong,nonatomic) UIView *childView;

- (IBAction)YesActionClicked:(id)sender;

- (IBAction)NoActionClicked:(id)sender;

- (void)enableSecondView :(BOOL)enable;


@end
