//
//  UICheckBoxGroupedWithButton.h
//  CSSUIFramwork
//
//  Created by CSS Admin on 12/10/18.
//  Copyright © 2018 csscorp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UILabeledButton.h"
#import "UIMultiLingualButton.h"
#import "UICheckBoxGrouped.h"

@interface UICheckBoxGroupedWithButton : UIView<UICheckBoxGroupedDelegate>

@property (strong, nonatomic) IBOutlet UICheckBoxGroupedWithButton *checkBoxGroupBtnView;
@property (strong, nonatomic) IBOutlet UICheckBoxGrouped *checkBoxButton;
@property (strong, nonatomic) IBOutlet UIMultiLingualButton *contentButton;

@property (nonatomic,strong) NSString *xPath;

-(NSString *)getValueString;


- (IBAction)cotentAction:(id)sender;

@end
