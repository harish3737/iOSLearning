//
//  UICheckBoxWithLabel.h
//  CSSUIFramwork
//
//  Created by CSS Admin on 6/15/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UICheckBox.h"
#import "ValidatorLabel.h"

@interface UICheckBoxWithLabel : UIView
@property (strong, nonatomic) IBOutlet UICheckBoxWithLabel *checkBoxLabelView;
@property (strong, nonatomic) IBOutlet UICheckBox *checkBoxButton;
@property (strong, nonatomic) IBOutlet ValidatorLabel *contentLabel;

@property (nonatomic,strong) NSString *xPath;
@end
