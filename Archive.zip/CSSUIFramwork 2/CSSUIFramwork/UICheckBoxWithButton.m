//
//  UICheckBoxWithButton.m
//  CSSUIFramwork
//
//  Created by CSS Admin on 7/25/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import "UICheckBoxWithButton.h"

#define DETAILTEXTCOLOR [UIColor colorWithRed:(102.0/255.0) green:(102.0/255.0) blue:(102.0/255.0) alpha:1.0f]
@implementation UICheckBoxWithButton

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/


@synthesize xPath;

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    [super drawRect:rect];
}



-(instancetype)initWithCoder:(NSCoder *)aDecoder {
    
    
    self = [super initWithCoder:aDecoder];
    if(self){
        
        [self setUpXibFile];
        
    }
    return self;
}

-(instancetype)initWithFrame:(CGRect)frame {
    
    
    self = [super initWithFrame:frame];
    if(self){
        
        [self setUpXibFile];
    }
    return self;
    
}

-(void)setUpXibFile {
    
    //1. Load a Xib
    [[NSBundle mainBundle]loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
    
    self.bounds = self.checkboxButtonView.bounds;
    //3.Add as a subviw
    [self addSubview:self.checkboxButtonView];
    
    [_checkBoxButton setChecked:NO];
    
    _contentButton.actionblock = ^(id sender,id parent){
        
    };

}



-(NSString *)getValueString{
    
    return @"-";
}


- (IBAction)contentTapAction:(id)sender {
    
    //NSLog(@"checkbox tapped");
    [_checkBoxButton updateUI];
     _contentButton.actionblock(sender,_contentButton.parent);
}
@end
