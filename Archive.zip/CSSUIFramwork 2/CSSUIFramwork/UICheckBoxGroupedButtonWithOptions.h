//
//  UICheckBoxGroupedButtonWithOptions.h
//  CSSUIFramwork
//
//  Created by CSS Admin on 12/4/18.
//  Copyright © 2018 csscorp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UICheckBox.h"
#import "UILabeledButton.h"
#import "UIMultiLingualButton.h"
#import "UICheckBoxGrouped.h"

@interface UICheckBoxGroupedButtonWithOptions : UIView <UICheckBoxGroupedDelegate>

@property (strong, nonatomic) IBOutlet UICheckBoxGroupedButtonWithOptions *checkBoxBtnOptionsView;

@property (strong, nonatomic) IBOutlet UICheckBoxGrouped *checkBoxButton;
@property (strong, nonatomic) IBOutlet UIMultiLingualButton *contentButton;
@property (strong, nonatomic) IBOutlet UILabeledButton *labelDropDownView;

@property (strong,nonatomic) NSString *xPath;

-(NSString *)getValueString;

- (IBAction)contentTapAction:(id)sender;

@end
