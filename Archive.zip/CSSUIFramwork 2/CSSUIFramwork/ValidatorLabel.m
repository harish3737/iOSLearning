//
//  ValidatorLabel.m
//  SampleBCBSPOC
//
//  Created by CSS Admin on 4/5/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import "ValidatorLabel.h"
#import "LanguageCentral.h"

@implementation ValidatorLabel


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    

//    
//    NSString *contentString = [LanguageCentral languageSelectedString:_localizationKey];
//    
//    self.text = (contentString.length>0)?contentString:self.text;

//     //NSLog(@"ValidateTextlabel::%@",self.text);
    
    [super drawRect:rect];
    

}

-(void)setLocalizationKey:(NSString *)localizationKey {
    
    _localizationKey = localizationKey;
    
     NSString *contentString = [LanguageCentral languageSelectedString:_localizationKey];
    NSLog(@"%@",_localizationKey);
    
    self.text = (contentString.length>0)?contentString:_localizationKey;
    
    
}

-(void)setCustomFontSize:(NSString *)customFontSize {
    
    //self.font = 46[UIFont fontWithName:@"Arial" size:[customFontSize floatValue]];
    //NSLog(@"font size ::%f",self.font.pointSize);
    
    self.font = [self.font fontWithSize:[customFontSize floatValue]];
    
}

-(void)setCustomFontName:(NSString *)customFontName {
    
     NSLog(@"updated font size ::%f",self.font.pointSize);
    
    
   // http://iphonedevwiki.net/index.php/UIFont  //-- refer link for font names
    
    self.font = [UIFont fontWithName:customFontName size:self.font.pointSize];
    
    NSLog(@"updated font name ::%@",self.font.fontName); //Arial-BoldMT
}

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if(self != nil) {
        NSLog(@"Intialized Validator Label Class with decoder");
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        
        NSLog(@"Intialized Validator Label Class initwith frame");
     
    }
    return self;
}

//- (instancetype)init
//{
//    self = [super init];
//    if (self) {
//        NSLog(@"Intialized Validator Label Class");
//    }
//    return self;
//}

//-(void)awakeFromNib {
//    
//    
//
//     //NSLog(@"text 4::%@",self.text);
//}

@end
