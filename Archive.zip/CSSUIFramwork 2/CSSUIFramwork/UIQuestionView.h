//
//  UIQuestionView.h
//  SampleBCBSPOC
//
//  Created by CSS Admin on 5/30/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ValidatorLabel.h"
#import "UICheckBox.h"
#import "UIRadioButton.h"



IB_DESIGNABLE

@interface UIQuestionView : UIView<UIRadioButtonDelegate>

@property (strong, nonatomic) IBOutlet UIQuestionView *questionView;

@property (strong, nonatomic) IBOutlet ValidatorLabel *headingLabel;
@property (strong, nonatomic) IBOutlet ValidatorLabel *detailLabel;
@property (strong, nonatomic) IBOutlet UIRadioButton *yesButton;
@property (strong, nonatomic) IBOutlet UIRadioButton *noButton;

@property (strong, nonatomic) IBOutlet ValidatorLabel *topHeadingLabel;

@property (strong,nonatomic) NSString *childViewString;
@property (strong,nonatomic) UIView *childView;

@property (strong,nonatomic) NSString *xPath;

@property(nonatomic)BOOL disableChildView;

- (IBAction)YesActionClicked:(id)sender;

- (IBAction)NoActionClicked:(id)sender;

- (void)enableSecondView :(BOOL)enable;

//-(void)setHeadingLabelText:(NSString *)headingText;
//-(void)setDetailLabelText:(NSString *)detailText;
//-(NSString *)headingLabelText;
//-(NSString *)detailLabelText;
//-(void)setHiddenDetailLabel:(BOOL)isHidden;
//-(BOOL)isHiddenDetailLabel;

@end
