//
//  CSSUIFramworkTests.m
//  CSSUIFramworkTests
//
//  Created by CSS Admin on 4/6/16.
//  Copyright © 2016 csscorp. All rights reserved.
//

#import <XCTest/XCTest.h>
#import "LanguageCentral.h"

@interface CSSUIFramworkTests : XCTestCase

@end

@implementation CSSUIFramworkTests

- (void)setUp {
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
    
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.

//    XCTAssertTrue([[LanguageCentral languageSelectedString:@"CONFIRMATION"] isEqualToString:@"Confirmation"],
//                  @"Strings are not equal %@ ",[LanguageCentral languageSelectedString:@"CONFIRMATION"]);
    

    
    [LanguageCentral setInternalizeString:@"en"];
    NSString *internalisationString = [LanguageCentral languageSelectedString:@"CONFIRMATION"];
    
    XCTAssertNotNil(internalisationString);
    XCTAssertEqual(internalisationString,@"Confirmation"); 
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}


@end
