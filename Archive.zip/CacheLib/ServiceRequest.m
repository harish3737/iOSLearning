//
//  ServiceRequest.m
//  CacheLib
//
//  Created by CSS Admin on 7/6/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "ServiceRequest.h"
#import "Operation.h"


@interface ServiceRequest ()


@property (nonatomic,strong) Callback *callback;
@property (nonatomic,strong) Callback *uiCallback;
@property (nonatomic, strong) Operation* operation;

@property (nonatomic,strong) NSMutableData *responseData;  //vrl newly added
@end

@implementation ServiceRequest


-(id)initWithCallBack:(Callback *)callback :(Operation *)operation {
    
    self = [super init];
    if(self){
//        NSLog(@"Call back init \n");
        _callback = callback;
        _operation = operation;
        _uiCallback = [operation callback];
        _responseData = nil; //vrl added
        _responseData = [[NSMutableData alloc]init]; //vrl added
//        [_operation callback].onSuccess (@"Hello", nil, [[_operation callback] handler]);
    }
    return self;
}



-(void)URLSession:(NSURLSession *)session dataTask:(NSURLSessionDataTask *)dataTask didReceiveResponse:(NSURLResponse *)response completionHandler:(void (^)(NSURLSessionResponseDisposition))completionHandler{
    
    
    NSLog(@"### handler 1");
    NSLog(@"Response ::%@",response);
    completionHandler(NSURLSessionResponseAllow);
    
}

-(void)URLSession:(NSURLSession *)session dataTask:(NSURLSessionDataTask *)dataTask didReceiveData:(NSData *)data {
    
    /* //old code commented by vrl
    NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)dataTask.response;
    NSLog(@"Status Code ::%ld",(long)httpResponse.statusCode);

    NSString *str = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
    NSLog(@"Received String ::%@",str);

    [_operation setCallback: _uiCallback];

    if(httpResponse.statusCode == 200){ //success

        self.callback.onSuccess(str, _operation, self.callback.handler);

    }else { //failure
        self.callback.onFailed(str,_operation,self.callback.handler);
    }
     */
    //vrl added
//    NSLog(@"Receive Data");
    [_responseData appendData:data];  // to add this line for handling response have more data , so we appened the data in variable
    
    //_uiCallback.onSuccess (str, _operation, [_uiCallback handler]);
    ////NSLog(@"%@", [_operation response] );
    
}

-(void)URLSession:(NSURLSession *)session task:(NSURLSessionTask *)task didCompleteWithError:(NSError *)error {
    
    if(error == nil){
        
//        NSLog(@"Download successful");
        
        NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)task.response;
        
//        NSLog(@"HTTP response ::%@\n",httpResponse);
        
//        NSLog(@"Status Code ::%ld",(long)httpResponse.statusCode);
        
        if(_responseData!=nil){
            
            NSString *str = [[NSString alloc]initWithData:_responseData encoding:NSUTF8StringEncoding];
            
            //        NSLog(@"Received String ::%@",str);
            
            [_operation setCallback: _uiCallback];
            
            if(httpResponse.statusCode == 200){ //success
                
            self.callback.onSuccess(str, _operation, self.callback.handler);
                
                
            }else { //failure
                self.callback.onFailed(str,_operation,self.callback.handler);
            }
        }else {
            // failure for no response data
              self.callback.onFailed(@"",_operation,self.callback.handler);
        }
        
    }else {
        NSLog(@"Error %@",[error userInfo]);
        _callback.onFailed([error userInfo], _operation, [[_operation callback] handler]);
    }
}


// delegate method for access self-signed certificate server
- (void)URLSession:(NSURLSession *)session didReceiveChallenge:(NSURLAuthenticationChallenge *)challenge completionHandler:(void (^)(NSURLSessionAuthChallengeDisposition, NSURLCredential *))completionHandler
{

    
//    if ([Cache SSLValidationValue] == 0) {
        //NSLog(@"SSL Validation access");
//        NSURLCredential *credential = [NSURLCredential credentialForTrust:challenge.protectionSpace.serverTrust];
//        completionHandler(NSURLSessionAuthChallengeUseCredential,credential);
    
//    }
    
    /*
    //for sit & uat //old code
    NSURLCredential *credential = [NSURLCredential credentialForTrust:challenge.protectionSpace.serverTrust];
    completionHandler(NSURLSessionAuthChallengeUseCredential,credential);
     */

  
     // Please enable this code when build frameworks for SIT & UAT
    // for Sit & uat new code // ganesh code
    NSURLCredential *credential = [NSURLCredential credentialForTrust:challenge.protectionSpace.serverTrust];
    if ([challenge previousFailureCount] == 0)
    {
        completionHandler(NSURLSessionAuthChallengeUseCredential,credential);
    } else
    {
        completionHandler(NSURLSessionAuthChallengeCancelAuthenticationChallenge,credential);
    }

    

    /*

    // Please enable below code when build frameworks for production
    // For Production SSL validation
    // Get remote certificate
    SecTrustRef serverTrust = challenge.protectionSpace.serverTrust;
    SecCertificateRef certificate = SecTrustGetCertificateAtIndex(serverTrust, 0);
    
    // Set SSL policies for domain name check
    NSMutableArray *policies = [NSMutableArray array];
    [policies addObject:(__bridge_transfer id)SecPolicyCreateSSL(true, (__bridge CFStringRef)challenge.protectionSpace.host)];
    SecTrustSetPolicies(serverTrust, (__bridge CFArrayRef)policies);
    
    // Evaluate server certificate
    SecTrustResultType result;
    SecTrustEvaluate(serverTrust, &result);
    BOOL certificateIsValid = (result == kSecTrustResultUnspecified || result == kSecTrustResultProceed);
    
    // Get local and remote cert data
    NSData *remoteCertificateData = CFBridgingRelease(SecCertificateCopyData(certificate));
    
    NSString *pathToCert = [[NSBundle mainBundle]pathForResource:@"medicare.horizonblue" ofType:@"der"];
    NSData *localCertificate = [NSData dataWithContentsOfFile:pathToCert];
    
    // The pinnning check
    if ([remoteCertificateData isEqualToData:localCertificate] && certificateIsValid) {
        
        NSURLCredential *credential = [NSURLCredential credentialForTrust:serverTrust];
        completionHandler(NSURLSessionAuthChallengeUseCredential, credential);
    } else {
        
        completionHandler(NSURLSessionAuthChallengeCancelAuthenticationChallenge, NULL);
    }

    */
}


@end
