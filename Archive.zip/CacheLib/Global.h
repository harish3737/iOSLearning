//
//  Global.h
//  CacheLib
//
//  Created by CSS Corp on 11/04/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#ifndef Global_h
#define Global_h

typedef enum {
    VOLATILE,
    NON_VOLATILE,
    NO_CACHE
} CacheType;

#endif /* Global_h */
