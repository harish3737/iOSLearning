//
//  ServiceRequest.h
//  CacheLib
//
//  Created by CSS Admin on 7/6/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ServiceProtocol.h"

@interface ServiceRequest : NSObject <NSURLSessionDataDelegate>


-(id)initWithCallBack:(Callback *)callback : (id) operation;

@end
