//
//  CacheLibTests.m
//  CacheLibTests
//
//  Created by CSS Corp on 01/04/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <XCTest/XCTest.h>
#import "Cache.h"
#import "TestBackgroundProcess.h"
#import "WebServiceWrapper.h"
#import "WebServiceHelper.h"

@interface CacheLibTests : XCTestCase

@end

@implementation CacheLibTests

Cache *cache;

- (void)setUp {
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
    //NSLog(@"setUp");
    
    cache = [[Cache alloc] init];
    //[cache setService: [[ServiceInterface alloc] init]];
    [cache setService: [[WebServiceWrapper alloc] init]];
    
    
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    //NSLog(@"tearDown");
    
    [super tearDown];
}

- (void)testExample {
    //NSLog(@"Test Cases");

}

- (void) testWebService {
    Callback *cb = [[Callback alloc] initWithCallbacks: ^(id response) {
        //NSLog(@"Response - %@", response);
    } : ^(id response) {
        //NSLog(@"Response - %@", response);
    }];
    [cache setTimeOut: 2];
    
    [cache registerTaskAndExecute: @"medicareuat.horizonbluestaging.com/restapi/v1/views/plans_pdp" :@" " : cb ];
    //[cache registerTask:@"http://medicareuat.horizonbluestaging.com/restapi/v1/views/plans_pdp" :@" " :cb];

}

- (void) testWebserviceHelper {
    Callback *cb = [[Callback alloc] initWithCallbacks: ^(id response) {
        //NSLog(@"Response - %@", response);
    } : ^(id response) {
        //NSLog(@"Response - %@", response);
    }];
    
    WebServiceWrapper *wr = [[WebServiceWrapper alloc] init];
    //WebServiceHelper
    [wr call:@"http://medicareuat.horizonbluestaging.com/restapi/v1/views/plans_pdp" query:@"2" callBack : cb];
}

- (void) testPutAndGet {
    Cache* cache = [[Cache alloc] init];
    NSString* testResponse;
    testResponse = @"Hello";
    
    Callback *cb = [[Callback alloc] initWithCallbacks: ^(id response) {
        //NSLog(@"Response - %@", response);
    } : ^(id response) {
        //NSLog(@"Response - %@", response);
    }];
    
    
    [cache registerTask: @"k" :@"1" : cb ];
    [cache registerTask:@"k" :@"2" : cb ];
    [cache registerTask:@"u" :@"1" : cb ];
    XCTAssertNotNil([cache get:@"k" :@"1"], @"k1 Not available");
    
//    XCTAssertEqual([cache get:@"k" :@"1"], testResponse, "k1 - Success");
    XCTAssertNotNil([cache get:@"k" :@"2"], @"k2 Not available");
//    XCTAssertEqual([cache get:@"k" :@"2"], @"Data1");
    XCTAssertNotNil([cache get:@"u" :@"1"], @"u1 Not available");
//    XCTAssertEqual([cache get:@"u" :@"1"], @"Data2");
}

- (void) testPlan {
    //NSLog(@"Test Function");
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

- (void) testRegisterCallback {
    Callback *cb = [[Callback alloc] initWithCallbacks: ^(id response) {
        //NSLog(@"UI - Success Response - %@", response);
    } : ^(id response) {
        //NSLog(@"UI - Failed Response - %@", response);
    }];
    [cache registerTask: @"k" :@"1" : cb ];
}

- (void) testSetService {
    Callback *cb = [[Callback alloc] initWithCallbacks: ^(id response) {
        //NSLog(@"UI - Success Response - %@", response);
    } : ^(id response) {
        //NSLog(@"UI - Failed Response - %@", response);
    }];
    [cache registerTask: @"k" :@"1" : cb ];
    [cache setTimeOut: 2];
    [cache setResponse:@"k" :@"1" :@"Service Response1"];
    [cache execute:@"k" :@"1"];

}

- (void) testTimeout {
    Callback *cb = [[Callback alloc] initWithCallbacks: ^(id response) {
        //NSLog(@"UI - Success Response - %@", response);
    } : ^(id response) {
        //NSLog(@"UI - Failed Response - %@", response);
    }];
    [cache registerTask: @"k" :@"1" : cb ];
    [cache settimeoutInMin: 1];
    //[cache setResponse:@"k" :@"1" :@"Service Response1"];
    for (int i=0; i<60; i++) {
        sleep(1);
        //NSLog(@"Seconds - %d", i);
        [cache execute:@"k" :@"1" ];
    }
    
    
    [cache unregisterTask: @"k" :@"1"];
    [cache execute:@"k" :@"1" ];
}

- (void) testVolatile {
    Callback *cb = [[Callback alloc] initWithCallbacks: ^(id response) {
        //NSLog(@"UI - Success Response - %@", response);
    } : ^(id response) {
        //NSLog(@"UI - Failed Response - %@", response);
    }];
    [cache registerTask: @"k" :@"1" : cb ];
    [cache setTimeOut: 2];
    [cache setResponse:@"k" :@"1" :@"Service Response1"];
    sleep(1);
    [cache execute:@"k" :@"1" ];
    sleep(1);
    [cache updateAndExecute:@"k" :@"1" ];
    sleep(1);
    [cache execute:@"k" :@"1" ];
    
    [cache unregisterTask: @"k" :@"1"];
    [cache execute:@"k" :@"1" ];
}

- (void) testNonVolatile {
    Callback *cb = [[Callback alloc] initWithCallbacks: ^(id response) {
        //NSLog(@"UI - Success Response - %@", response);
    } : ^(id response) {
        //NSLog(@"UI - Failed Response - %@", response);
    }];
    [cache registerTask: @"k" :@"1" : cb : NON_VOLATILE ];
    [cache setTimeOut: 2];
    //[cache setResponse:@"k" :@"1" :@"Service Response1"];
    sleep(1);
    [cache execute:@"k" :@"1" ];
    sleep(1);
    [cache execute:@"k" :@"1" ];
    sleep(1);
    [cache updateAndExecute :@"k" :@"1" ];
    
    [cache unregisterTask: @"k" :@"1"];
    [cache execute:@"k" :@"1" ];
}

- (void) testNoCache {
    TestBackgroundProcess *tbProcess = [[TestBackgroundProcess alloc] initWithCache:cache];
    //[tbProcess testNo
}

- (void) testFun {
    //NSLog(@"Hello iOS");
}

@end
