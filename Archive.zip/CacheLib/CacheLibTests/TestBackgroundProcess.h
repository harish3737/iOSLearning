//
//  TestBackgroundProcess.h
//  CacheLib
//
//  Created by CSS Corp on 21/04/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Cache.h"

@interface TestBackgroundProcess : NSObject

@property (nonatomic) Cache *cache;

- (instancetype) initWithCache: (Cache*) cache;

- (void) testNoCache;

@end
