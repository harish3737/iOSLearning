//
//  TestBackgroundProcess.m
//  CacheLib
//
//  Created by CSS Corp on 21/04/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "TestBackgroundProcess.h"

@interface TestBackgroundProcess ()

@property (assign) NSInteger testIntData;


@end

@implementation TestBackgroundProcess

- (instancetype) initWithCache: (Cache*) cache {
    self = [super init];
    
    if (self) {
        _cache = cache;
        _testIntData = 100;
    }
    return self;
}

- (void) testNoCache {
    TestBackgroundProcess *weakTbProcess = self;
    Callback *cb = [[Callback alloc] initWithCallbacks: ^(id response) {
        //NSLog(@"UI - Success Response - %@", response);
        [weakTbProcess testInstanceMethod];
        
    } : ^(id response) {
        //NSLog(@"UI - Failed Response - %@", response);
    }];
    [_cache registerTask: @"k" :@"1" : cb : NO_CACHE ];
    [_cache setTimeOut: 2];
    //[cache setResponse:@"k" :@"1" :@"Service Response1"];
    sleep(1);
    [_cache execute:@"k" :@"1" ];
    sleep(1);
    [_cache execute:@"k" :@"1" ];
    sleep(1);
    [_cache updateAndExecute :@"k" :@"1" ];
    
    [_cache unregisterTask: @"k" :@"1"];
    [_cache execute:@"k" :@"1" ];
}

- (void) testInstanceMethod {
    //NSLog(@"instance data %ld", _testIntData);
}

@end
