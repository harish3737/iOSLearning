//
//  CacheTypeProtocol.h
//  CacheLib
//
//  Created by CSS Corp on 13/04/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#ifndef CacheTypeProtocol_h
#define CacheTypeProtocol_h

@protocol CacheTypeProtocol <NSObject>

@required
- (void) setResponse

@end

#endif /* CacheTypeProtocol_h */
