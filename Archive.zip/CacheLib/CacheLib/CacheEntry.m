//
//  CacheEntry.m
//  CacheLib
//
//  Created by CSS Corp on 05/04/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "CacheEntry.h"
#import "Operation.h"
#import "Cache.h"

@interface CacheEntry ()

@property (weak,nonatomic) NSString *key1;
@property (weak,nonatomic) NSString *key2;
@property (strong) Operation *entryOperation;
@property (weak) Cache* cache;

@end

@implementation CacheEntry

- (instancetype)initWithData: (NSString*) key1 : (NSString*) key2 : (Cache*) cacheInstance : (CacheType) cacheType {
    self = [super init];
    if (self) {
        _key1 = key1;
        _key2 = key2;
        _cache = cacheInstance;
        _entryOperation = [[Operation alloc] initWithCacheEntry: self : cacheType];
    
        
    }
    return self;
}

- (id) key1 {
    return _key1;
}
- (id) key2{
    return _key2;
}

-(Cache*) getCache {
    return _cache;
}

- (void) setCallback:(Callback*)callback {
    [[ self entryOperation] setCallback: callback];
}

- (Callback*) getCallback {
    return [[self entryOperation] callback];
}

- (void) updateResponse:(id)response {
    [[self entryOperation] updateResponse: response];
}

- (void) execute:(ServiceInterface *)service {
    //NSLog(@"Cache execution start - CacheEntry - %@ - %@", _key1, _key2);
    [[self entryOperation] execute: service : [[[self entryOperation] callback] handler]];
    
}

- (void) updateAndExecute:(ServiceInterface *)service {
    [[self entryOperation] updateAndExecute: service : [[[self entryOperation] callback] handler]];
}

- (NSMutableDictionary *) getHeaders {
    return _headers;
}

- (void) setHeaders : (NSMutableDictionary *) headers {
    _headers = headers;
}

@end
