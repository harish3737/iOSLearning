//
//  WebServiceWrapper.h
//  CacheLib
//
//  Created by CSS Corp on 06/07/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ServiceProtocol.h"

@interface WebServiceWrapper : NSObject<ServiceProtocol>


@end
