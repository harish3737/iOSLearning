//
//  InterceptorProtocol.h
//  CacheLib
//
//  Created by CSS Corp on 22/06/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#ifndef InterceptorProtocol_h
#define InterceptorProtocol_h

@protocol InterceptorProtocol <NSObject>

@required
- (void) willRegister;
- (void) didRegister;
- (void) willCallService;
- (void) didCallService;

@end


#endif /* InterceptorProtocol_h */
