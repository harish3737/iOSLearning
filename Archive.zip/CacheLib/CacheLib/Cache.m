//
//  Cache.m
//  CacheLib
//
//  Created by CSS Corp on 01/04/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "CacheEntry.h"
#import "WebServiceWrapper.h"
#import "Cache.h"
@interface Cache ()



@end

@implementation Cache

//@synthesize timeOut;

- (id) init {
    self = [super init];
    if(self) {
        _dictionaryL1 = [[NSMutableDictionary alloc] init];
        _service = [[WebServiceWrapper alloc]init];
        _timeOut = 1;
    }
    return self;
}


- (double) getTimeOut {
    return _timeOut;
}

- (void) settimeoutInMin:(double)min {
    _timeOut = min * 60;
}

- (void) setService:(id) service {
    _service = service;
}

- (void) setResponse:(NSString *)key1 :(NSString *)key2 :(id)response {
    [[self get:key1 :key2] updateResponse: response];
}

- (id)put:(NSString *)key1 :(NSString *)key2 : (CacheType) cacheType {
    if ([_dictionaryL1 valueForKey:key1] == nil) {
        [_dictionaryL1 setObject: [[NSMutableDictionary alloc] init] forKey: key1];
    }
    CacheEntry *entry = [[CacheEntry alloc] initWithData:key1 :key2 : self : cacheType];
    [((NSMutableDictionary*) [_dictionaryL1 valueForKey:key1]) setObject: entry forKey:key2];
    return entry;
}

- (id) get:(NSString *) key1 : (NSString *) key2 {
    
    if ([_dictionaryL1 valueForKey: key1] != nil) {
        if ([[_dictionaryL1 valueForKey: key1] valueForKey: key2] != nil) {
            return [[_dictionaryL1 valueForKey: key1] valueForKey: key2];
        }
    }
    
    return nil;
}

- (void) registerTask:(NSString *)key1 :(NSString *)key2 :(Callback *)callback : (CacheType) cacheType {
    [[self put:key1 :key2 : cacheType] setCallback: callback];
}

- (void) registerTask:(NSString *)key1 :(NSString *)key2 :(Callback *)callback {
    [[self put:key1 :key2 : VOLATILE] setCallback: callback];
    
}

- (void) registerTaskAndExecute:(NSString *)key1 :(NSString *)key2 :(Callback *)callback :(CacheType)cacheType {
    [self registerTask:key1 :key2 :callback : cacheType];
    [self execute:key1 :key2];
}

- (void) registerTaskAndExecute:(NSString *)key1 :(NSString *)key2 :(Callback *)callback {
    [self registerTaskAndExecute:key1 :key2 :callback :VOLATILE];
}

- (void) unregisterTask:(NSString *) key1 :(NSString *) key2 {
    [[[_dictionaryL1 valueForKey: key1] valueForKey: key2] setCallback: [Callback getDummyCallback]];
    [[_dictionaryL1 valueForKey: key1] removeObjectForKey: key2];
    if ([_dictionaryL1 count] == 0)
        [_dictionaryL1 removeObjectForKey: key1];
}

- (void) clear {
    [_dictionaryL1 enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull subDictionary, BOOL * _Nonnull stop) {
        [subDictionary enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull cacheEntry, BOOL * _Nonnull stop) {
            [cacheEntry setCallback: [Callback getDummyCallback]];
        }];
        [subDictionary removeAllObjects];
    }];
    [_dictionaryL1 removeAllObjects];
}

- (void) execute:(NSString *)key1 :(NSString *)key2 {
//    if ([self get:key1 :key2] != nil) {
    @try {
        [[self get: key1 : key2]  execute: _service];
    } @catch (NSException *exception) {
        //NSLog(@"Task %@%@ not found!", key1, key2);
        [NSException raise: @"Task not found" format: @"Task %@%@ not found!", key1, key2];
    } @finally {
        
    }
    
//    }
}

- (void) updateAndExecute:(NSString *) key1 :(NSString *) key2 {
    @try {
        [[self get: key1 : key2] updateAndExecute: _service];
    } @catch (NSException *exception) {
        //NSLog(@"Task %@%@ not found!", key1, key2);
        [NSException raise: @"Task not found" format: @"Task %@%@ not found!", key1, key2];
    } @finally {
        
    }
    
 
}

- (NSMutableDictionary *) getHeaders : (NSString *) key1 : (NSString *) key2 {
    return [[self get:key1 :key2] getHeaders];
}

- (void) setHeaders : (NSString *) key1 : (NSString *) key2 : (NSMutableDictionary *) headers  {
    [[self get :key1 :key2] setHeaders : headers];
}


@end
