//
//  WebServiceHelper.m
//  BcBs
//
//  Created by CSS Admin on 6/23/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "WebServiceHelper.h"
#import "ServiceRequest.h"

@interface WebServiceHelper ()

@property (nonatomic,strong) ServiceRequest *serviceRequest;
@end

@implementation WebServiceHelper


-(instancetype)init{
    self = [super init];
    if (self) {
        
        _serviceRequest = [[ServiceRequest alloc]init];
    }
    return self;
}


-(void)sendHTTPGet:(NSString *)urlString identifier:(NSString *)identifier delegate:(id)delegate headerList:(NSMutableDictionary *)headers{
    
    
    NSString *authStr = @"staging:m5Q5ccWX4M";
    NSData *authData = [authStr dataUsingEncoding:NSUTF8StringEncoding];
    NSString *authValue = [NSString stringWithFormat: @"Basic %@",[authData base64EncodedStringWithOptions:0]];

    NSURLSessionConfiguration *defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];

    defaultConfigObject.timeoutIntervalForRequest = 30.0;
    defaultConfigObject.timeoutIntervalForResource = 120.0; //vrl added old time is 60.0
    defaultConfigObject.HTTPAdditionalHeaders = @{@"Authorization": authValue};
    
//    NSURLSession *defaultSession = [NSURLSession sessionWithConfiguration: defaultConfigObject delegate: self delegateQueue: [NSOperationQueue mainQueue]];
    
    NSURLSession *defaultSession = [NSURLSession sessionWithConfiguration: defaultConfigObject delegate:delegate  delegateQueue: [NSOperationQueue mainQueue]];
    
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:urlString]];

    if(headers!=nil){
        [request setValue:[headers objectForKey:@"sessid"] forHTTPHeaderField:@"Cookie"];
        [request setValue:[headers objectForKey:@"token"] forHTTPHeaderField:@"X-csrf-token"];
        [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
        
    }
    
    NSURLSessionDataTask *task = [defaultSession dataTaskWithRequest:request];
    [task resume];
    
}


-(void) httpPostWithCustomDelegate:(NSString *)urlString params:(id)paramData identifier:(NSString *)identifier delegate:(id)delegate headerList:(NSMutableDictionary *)headers
{
    
    
    NSString *authStr = @"staging:m5Q5ccWX4M";
    NSData *authData = [authStr dataUsingEncoding:NSUTF8StringEncoding];
    NSString *authValue = [NSString stringWithFormat: @"Basic %@",[authData base64EncodedStringWithOptions:0]];
    
    NSURLSessionConfiguration *defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    defaultConfigObject.HTTPAdditionalHeaders = @{@"Authorization": authValue};
    
    NSURLSession *defaultSession = [NSURLSession sessionWithConfiguration: defaultConfigObject delegate:delegate delegateQueue: [NSOperationQueue mainQueue]];
    
    
    NSURL * url = [NSURL URLWithString:urlString];
    NSMutableURLRequest * urlRequest = [NSMutableURLRequest requestWithURL:url];
	
	
	
	//NSLog(@"ParamsData ::%@",paramData);
    NSData *jsonData;
    if ([paramData hasPrefix: @"NoData"]) {
        jsonData =[[NSData alloc]init];
    } else {
        jsonData = [paramData dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    }
//	NSError *error;
//	NSData *jsonData = [NSJSONSerialization dataWithJSONObject:paramData options:NSJSONWritingPrettyPrinted error:&error];
	
    [urlRequest setValue:@"application/json" forHTTPHeaderField:@"Content-type"];
    [urlRequest setValue:@"application/json" forHTTPHeaderField:@"Accept"];
    
    
    if(headers!=nil){
        
        for (NSString *keyString in [headers allKeys]) {
        [urlRequest setValue:[headers objectForKey:keyString] forHTTPHeaderField:keyString];
        }
    }
    [urlRequest setHTTPMethod:@"POST"];
    [urlRequest setValue:[NSString stringWithFormat:@"%lu",(unsigned long)[jsonData length]] forHTTPHeaderField:@"Content-Length"];
    [urlRequest setHTTPBody:jsonData];
    
    NSURLSessionDataTask *dataTask = [defaultSession dataTaskWithRequest:urlRequest];
    
    [dataTask resume];
    
}


@end
