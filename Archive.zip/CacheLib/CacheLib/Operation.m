//
//  Operation.m
//  CacheLib
//
//  Created by CSS Corp on 05/04/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "Operation.h"
#import "Cache.h"
#import "CacheEntry.h"

@interface Operation ()

typedef void (^SetResponseBlock) (Operation*, id);
typedef void (^updateAndExecuteBlock) (Operation *operation);


@property (assign) double timestamp;
@property (nonatomic, weak) id response;
@property (strong) timeoutValidator validate;
@property (nonatomic, strong) CacheEntry* cacheEntry;
@property (nonatomic, strong) SetResponseBlock setResponseBlock;
@property (nonatomic, strong) updateAndExecuteBlock updateAndExecuteBlock;
@property (nonatomic, strong) Callback *updateCacheBlock;
//@property (nonatomic, assign) CacheType cacheType;


- (void) updateTimeStamp;
- (void) setVolatile;
- (void) setNonVolatile;
- (void) setNoCache;

@end

@implementation Operation
@synthesize callback;

static timeoutValidator tm;

+ (timeoutValidator) Validate {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        tm = ^bool {
            return false;
        };
    });
    return tm;
}

- (id) initWithCacheEntry:(CacheEntry *) cacheEntry : (CacheType) cacheType {
    self = [super init];
    if(self) {
        _cacheEntry = cacheEntry;
        
        _timestamp = 0 - [[cacheEntry getCache] getTimeOut];
        [self setCacheType: cacheType];
        
    }
    return self;
}

- (void) setUp {
    [self setVolatile];
    
}

- (CacheEntry*) cacheEntry {
    return _cacheEntry;
}

- (void) setVolatile {
    Operation *weakSelf = self;
    _validate = ^bool {
        //NSLog(@"Volatile Validate");
        return ([[NSDate date] timeIntervalSince1970] - [weakSelf timestamp] >= [[_cacheEntry getCache] getTimeOut]);
    };
    
    _setResponseBlock = ^(Operation *operation, id response) {
        //NSLog(@"Volatile setResponse");
        operation.response = response;
    };
    
    _updateAndExecuteBlock = ^(Operation *operation){
        //NSLog(@"update");
        operation.timestamp = 0 - [[[operation cacheEntry] getCache] getTimeOut];
    };
}

- (void) setNonVolatile {
    self.validate = ^bool {
        return (self.response == nil);
    };
    
    self.setResponseBlock = ^(Operation *operation, id response) {
        //NSLog(@"Non-Volatile setResponse");
        operation.response = response;
    };
    
    self.updateAndExecuteBlock = ^(Operation *operation){
        //NSLog(@"Non-Volatile updateAndExecuteBlock");
        [operation updateResponse: nil];
    };
}

- (void) setNoCache {
    _validate = ^bool {
        return true;
    };
    
    _setResponseBlock = ^(Operation *operation, id response) {
        operation.response = response;
    };
    
    _updateAndExecuteBlock = ^(Operation *operation) {

    };
}

- (void) setCacheType: (CacheType) cacheType {
    
    switch (cacheType) {
        case VOLATILE:
            [self setVolatile];
            break;
            
        case NON_VOLATILE:
            //NSLog(@"Non-Volatile");
            [self setNonVolatile];
            break;
            
        case NO_CACHE:
            [self setNoCache];
            break;
            
        default:
            break;
    }
}

- (void) updateResponse:(id)response {
//    NSLog(@"Updating %@", response);
    _setResponseBlock(self, response);
}

- (id) response {
    return _response;
}

-(void) updateTimeStamp {
    _timestamp = [[NSDate date] timeIntervalSince1970];
}

- (void) updateAndExecute:(ServiceInterface *)service : (id) handler {
    _updateAndExecuteBlock(self);
    [self execute: service : handler];
}

- (void) execute:(ServiceInterface *)service : (id) handler {
    __block typeof(self) weakSelf = self;
    
    if (self.validate()) {
        
        self.updateCacheBlock = [[Callback alloc] initWithCallbacks: ^(id response, id operation, id handler) {
            //NSLog(@"Cache response received - Success - %@", response);
            [operation updateResponse: response];
            [operation updateTimeStamp];
//            [operation processResponse];
            [operation callback].onSuccess(response, operation, [[operation callback] handler]);
            //NSLog(@"%@ - %@", [[operation cacheEntry] key1], [[operation cacheEntry] key2]);
            
        } : ^(id response, id operation, id handler) {
            //NSLog(@"Cache response received - Failed - %@", response);
            
//            [operation callback].onFailed(response, operation, handler); //old code
            [operation callback].onFailed(response, operation, [[operation callback] handler]);
            
        } : handler];
        
        [service call:[_cacheEntry key1] query:[_cacheEntry key2] callBack:_updateCacheBlock : self : [_cacheEntry getHeaders]];
        
//        [service call:[_cacheEntry key1] query:[_cacheEntry key2] callBack:[[Callback alloc] initWithCallbacks: ^(id response, id operation, id handler) {
//            //NSLog(@"Cache response received - Success - %@", response);
//            [weakSelf updateResponse: response];
//            [operation updateTimeStamp];
//            [operation processResponse];
//            [operation callback].onSuccess(response, operation, [[operation callback] handler]);
//            //NSLog(@"%@ - %@", [[operation cacheEntry] key1], [[operation cacheEntry] key2]);
//            
//        } : ^(id response, id operation, id handler) {
//            //NSLog(@"Cache response received - Failed - %@", response);
//            [operation callback].onFailed(response, operation, handler);
//        } : handler] : self];
    } else {
        //NSLog(@"Return Existing");
        [weakSelf callback].onSuccess([weakSelf response], self, handler);
    }
    
}



@end
