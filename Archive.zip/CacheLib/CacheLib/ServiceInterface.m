//
//  ServiceInterface.m
//  CacheLib
//
//  Created by CSS Corp on 05/04/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "ServiceInterface.h"

@implementation ServiceInterface

- (void) call:(id)url query:(id)queryString callBack:(Callback *)callback :(id)operation : (NSMutableDictionary *) headers {
    //NSLog(@"Service not configured");
    NSString *response = @"Please configure service! - ";
    //response = [response stringByAppendingFormat: @"%f", [[NSDate date] timeIntervalSince1970]];
//    serviceCallback.onFailed([response stringByAppendingFormat: @"%f", [[NSDate date] timeIntervalSince1970]]);
    callback.onSuccess([response stringByAppendingFormat: @"%f", [[NSDate date] timeIntervalSince1970]], operation, nil);
}

@end
