//
//  WebServiceWrapper.m
//  CacheLib
//
//  Created by CSS Corp on 06/07/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "WebServiceWrapper.h"
#import "WebServiceHelper.h"
#import "ServiceRequest.h"


@interface WebServiceWrapper ()


@end
@implementation WebServiceWrapper

-(id)init{
    
    self = [super init];
    if(self){
        
    }
    return self;
}

- (void) call:(id)url query:(id)queryString callBack:(Callback *)callback :(id)operation : (NSMutableDictionary *) headers {
 
    
    ServiceRequest *serviceReq = [[ServiceRequest alloc]initWithCallBack:callback : operation];
    WebServiceHelper *webserviceHelper = [[WebServiceHelper alloc]init];

    NSLog(@"url::%@",url);
    NSLog(@"QueryString ::%@",queryString);
    
	if(![queryString isEqualToString:@""]){
		//NSLog(@"POST URL");
		 [webserviceHelper httpPostWithCustomDelegate:url params:queryString identifier:nil delegate:serviceReq headerList:headers];
	}else {
		//NSLog(@"GET URL");
		 [webserviceHelper sendHTTPGet:url identifier:@"" delegate:serviceReq headerList:headers];
	}
}



@end
