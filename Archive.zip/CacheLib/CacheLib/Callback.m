//
//  Callback.m
//  CacheLib
//
//  Created by CSS Corp on 05/04/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import "Callback.h"

@implementation Callback

@synthesize onSuccess;
@synthesize onFailed;

static Callback* dummyCallback = nil;

+ (instancetype) getDummyCallback {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        dummyCallback = [[Callback alloc] initWithCallbacks:^(id response, id obj, id handler) {
            
        } :^(id response, id obj, id handler) {
            
        } : nil];
    });
    
    return dummyCallback;
}

- (instancetype) initWithCallbacks:(callbackBlock) successBlock :(callbackBlock) failedBlock :(id)handler {

    self = [super init];
    if(self) {
        onSuccess = successBlock;
        onFailed = failedBlock;
        _handler = handler;
    }
    return self;
}

- (void) setSuccessBlock:(callbackBlock) mySuccessBlock {
    self.onSuccess = mySuccessBlock;
}

- (void) setFailiedBlock:(callbackBlock) myFaliedBlock {
    self.onFailed = myFaliedBlock;
}

- (id) handler {
    return _handler;
}

@end
