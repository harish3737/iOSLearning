//
//  Operation.h
//  CacheLib
//
//  Created by CSS Corp on 05/04/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#ifndef Operation_h
#define Operation_h

#import <Foundation/Foundation.h>
#import "Callback.h"
#import "ServiceInterface.h"
#import "Global.h"
@class CacheEntry;

@interface Operation : NSObject

@property (nonatomic, strong) Callback* callback;

typedef bool (^timeoutValidator) (void);


+ (timeoutValidator) Validate;
- (CacheEntry *) cacheEntry;
- (id) initWithCacheEntry: (CacheEntry*) cacheEntry : (CacheType) cacheType;
- (id) response;
- (void) updateResponse: (id) response;
- (void) setCacheType: (CacheType) cacheType;
- (void) updateAndExecute: (ServiceInterface*) service : (id) handler;
- (void) execute: (ServiceInterface*) service : (id) handler;

@end

#endif