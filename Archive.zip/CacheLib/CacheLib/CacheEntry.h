//
//  ClassEntry.h
//  CacheLib
//
//  Created by CSS Corp on 05/04/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#ifndef CacheEntry_h
#define CacheEntry_h

#import <Foundation/Foundation.h>
#import "Callback.h"
#import "ServiceInterface.h"
#import "Global.h"
@class Cache;



@interface CacheEntry : NSObject

@property (nonatomic, strong) NSMutableDictionary *headers;


- (instancetype)initWithData: (NSString*) key1 : (NSString*) key2 : (Cache*) cacheInstance : (CacheType) cacheType;
- (Cache*) getCache;
- (void) setCallback: (Callback*) callback;
- (Callback*) getCallback;
- (void) updateResponse: (id) response;
- (void) execute: (ServiceInterface*) service;
- (void) updateAndExecute: (ServiceInterface*) service;
- (id) key1;
- (id) key2;

- (NSMutableDictionary *) getHeaders;
- (void) setHeaders : (NSMutableDictionary *) headers;

@end


#endif