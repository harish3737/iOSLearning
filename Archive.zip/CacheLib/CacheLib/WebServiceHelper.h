//
//  WebServiceHelper.h
//  BcBs
//
//  Created by CSS Admin on 6/23/16.
//  Copyright © 2016 CSS Corp. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>



@interface WebServiceHelper : NSObject{
    
    NSMutableData *responseData; // hold the response data

}

//urlSession
-(void)httpPostWithCustomDelegate:(NSString *)urlString params:(id)paramData identifier:(NSString *)identifier delegate:(id)delegate headerList:(NSMutableDictionary *)headers;
-(void)sendHTTPGet :(NSString *)urlString identifier:(NSString *)identifier delegate:(id)delegate headerList:(NSMutableDictionary *)headers;



@end
