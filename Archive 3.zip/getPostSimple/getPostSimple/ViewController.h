//
//  ViewController.h
//  getPostSimple
//
//  Created by CSSCORP on 12/28/18.
//  Copyright © 2018 CSSCORP. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
- (IBAction)clickOn:(id)sender;
- (IBAction)updateClick:(id)sender;




@end

