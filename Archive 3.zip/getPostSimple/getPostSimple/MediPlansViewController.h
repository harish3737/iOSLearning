//
//  MediPlansViewController.h
//  getPostSimple
//
//  Created by CSSCORP on 1/2/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import "ViewController.h"



@interface MediPlansViewController : ViewController
- (IBAction)Pdp:(id)sender;
- (IBAction)ma:(id)sender;
- (IBAction)MediGap:(id)sender;
- (IBAction)Dsnp:(id)sender;
- (IBAction)Zipcode:(id)sender;
- (IBAction)Agent:(id)sender;

@end


