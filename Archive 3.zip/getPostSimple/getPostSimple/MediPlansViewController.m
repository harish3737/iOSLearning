//
//  MediPlansViewController.m
//  getPostSimple
//
//  Created by CSSCORP on 1/2/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import "MediPlansViewController.h"

@interface MediPlansViewController ()
{
    NSString *username;
    NSString *password;
    NSString *authStr;
    NSData *authData;
    NSString *authValue;
    
}
//username="hello";

@end

@implementation MediPlansViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)Pdp:(id)sender {
    [self pdpclickJson];
}

- (IBAction)ma:(id)sender {
    [self maclickJson];
}

- (IBAction)MediGap:(id)sender {
    [self medigapclickJson];
}

- (IBAction)Dsnp:(id)sender {
    [self dsnpClickJson];
}

- (IBAction)Zipcode:(id)sender {
    [self ZipcodeclickJson];    
}

- (IBAction)Agent:(id)sender {
    [self AgentLogin];
}

-(void)pdpclickJson
{
    username= @"staging" ;
    password= @"m5Q5ccWX4M";
    authStr = [NSString stringWithFormat:@"%@:%@", username, password];
    authData = [authStr dataUsingEncoding:NSUTF8StringEncoding];
    authValue = [NSString stringWithFormat:@"Basic %@", [authData base64EncodedStringWithOptions:0]];
    
    NSString *url1 = @"https://medicaresit.horizonbluestaging.com/restapi/v1/views/plans_pdp";
    //    NSDictionary *getValue = dictonaryResponse;
    NSURLSession *session = [NSURLSession sharedSession];
    NSURL *url = [NSURL URLWithString:url1];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    request.HTTPMethod=@"GET";
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request setValue:authValue forHTTPHeaderField:@"Authorization"];
    
    [[session dataTaskWithRequest:request
                completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
                    if (!error) {
                        
                        id response=[NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
                        
                        if ([response isKindOfClass:[NSString class]])
                        {
                            NSString *responseString = [NSString stringWithFormat:@"%@",response];
                            NSLog(@"%@",responseString);
                        }
                        else if([response isKindOfClass:[NSDictionary class]])
                        {
                            NSDictionary *responseDictonary = response;
                            NSLog(@"%@",responseDictonary);
                        }
                        else if([response isKindOfClass:[NSArray class]])
                        {
                            NSArray *arrayResponse = response;
                            NSLog(@"%@",arrayResponse);
                        }
                        
                    }
                }] resume];
}
-(void)maclickJson
{
    
     NSString *url1=@"https://medicaresit.horizonbluestaging.com/restapi/v1/views/plans_ma";
    
    //    NSDictionary *getValue = dictonaryResponse;
    NSURLSession *session = [NSURLSession sharedSession];
    NSURL *url = [NSURL URLWithString:url1];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    request.HTTPMethod=@"GET";
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request setValue:authValue forHTTPHeaderField:@"Authorization"];
    
    [[session dataTaskWithRequest:request
                completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
                    if (!error) {
                        
                        id response=[NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
                        if ([response isKindOfClass:[NSString class]])
                        {
                            NSString *responseString = [NSString stringWithFormat:@"%@",response];
                            NSLog(@"%@",responseString);
                        }
                        else if([response isKindOfClass:[NSDictionary class]])
                        {
                            NSDictionary *responseDictonary = response;
                            NSLog(@"%@",responseDictonary);
                        }
                        else if([response isKindOfClass:[NSArray class]])
                        {
                            NSArray *arrayResponse = response;
                            NSLog(@"%@",arrayResponse);
                        }
                        
                    }
                }] resume];
}



-(void)medigapclickJson
{
    
       NSString *url1=@"https://medicaresit.horizonbluestaging.com/restapi/v1/views/plans_medigap";
    //    NSDictionary *getValue = dictonaryResponse;
    NSURLSession *session = [NSURLSession sharedSession];
    NSURL *url = [NSURL URLWithString:url1];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    request.HTTPMethod=@"GET";
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request setValue:authValue forHTTPHeaderField:@"Authorization"];
    [[session dataTaskWithRequest:request
                completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
                    if (!error) {
                        
                        id response=[NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
                        if ([response isKindOfClass:[NSString class]])
                        {
                            NSString *responseString = [NSString stringWithFormat:@"%@",response];
                            NSLog(@"%@",responseString);
                        }
                        else if([response isKindOfClass:[NSDictionary class]])
                        {
                            NSDictionary *responseDictonary = response;
                            NSLog(@"%@",responseDictonary);
                        }
                        else if([response isKindOfClass:[NSArray class]])
                        {
                            NSArray *arrayResponse = response;
                            NSLog(@"%@",arrayResponse);
                        }
                        
                    }
                }] resume];
}
-(void)dsnpClickJson
{
    NSString *url1=@"https://medicaresit.horizonbluestaging.com/restapi/v1/views/plans_dsnp";
    //    NSDictionary *getValue = dictonaryResponse;
    NSURLSession *session = [NSURLSession sharedSession];
    NSURL *url = [NSURL URLWithString:url1];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    request.HTTPMethod=@"GET";
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request setValue:authValue forHTTPHeaderField:@"Authorization"];
    [[session dataTaskWithRequest:request
                completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
                    if (!error) {
                        
                        id response=[NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
                        if ([response isKindOfClass:[NSString class]])
                        {
                            NSString *responseString = [NSString stringWithFormat:@"%@",response];
                            NSLog(@"%@",responseString);
                        }
                        else if([response isKindOfClass:[NSDictionary class]])
                        {
                            NSDictionary *responseDictonary = response;
                            NSLog(@"%@",responseDictonary);
                        }
                        else if([response isKindOfClass:[NSArray class]])
                        {
                            NSArray *arrayResponse = response;
                            NSLog(@"%@",arrayResponse);
                        }
                        
                    }
                }] resume];
}
-(void)ZipcodeclickJson
{
    
   NSString *url1=@"https://medicare.horizonblue.com/restapi/v1/zipcodes/retrieve";
    
    //    NSDictionary *getValue = dictonaryResponse;
    NSURLSession *session = [NSURLSession sharedSession];
    NSURL *url = [NSURL URLWithString:url1];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    request.HTTPMethod=@"GET";
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request setValue:authValue forHTTPHeaderField:@"Authorization"];
    
    [[session dataTaskWithRequest:request
                completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
                    if (!error) {
                        
                        id response=[NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
                        if ([response isKindOfClass:[NSString class]])
                        {
                            NSString *responseString = [NSString stringWithFormat:@"%@",response];
                            NSLog(@"%@",responseString);
                        }
                        else if([response isKindOfClass:[NSDictionary class]])
                        {
                            NSDictionary *responseDictonary = response;
                            NSLog(@"%@",responseDictonary);
                        }
                        else if([response isKindOfClass:[NSArray class]])
                        {
                            NSArray *arrayResponse = response;
                            NSLog(@"%@",arrayResponse);
                        }
                        
                    }
                }] resume];
}

-(void)AgentLogin
{
    NSString *queryParams = @"agent1";
    NSString *url1=[NSString stringWithFormat:@"https://medicaresit.horizonbluestaging.com/restapi/v1/views/agent_profile?args[0]=%@",queryParams];
    
    //    NSDictionary *getValue = dictonaryResponse;
    NSURLSession *session = [NSURLSession sharedSession];
    NSURL *url = [NSURL URLWithString:url1];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    request.HTTPMethod=@"GET";
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    NSString *authStr = [NSString stringWithFormat:@"%@:%@", username, password];
    NSData *authData = [authStr dataUsingEncoding:NSUTF8StringEncoding];
    NSString *authValue = [NSString stringWithFormat:@"Basic %@", [authData base64EncodedStringWithOptions:0]];
    [request setValue:authValue forHTTPHeaderField:@"Authorization"];
    
    [[session dataTaskWithRequest:request
                completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
                    if (!error) {
                        
                        id response=[NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
                        if ([response isKindOfClass:[NSString class]])
                        {
                            NSString *responseString = [NSString stringWithFormat:@"%@",response];
                            NSLog(@"%@",responseString);
                        }
                        else if([response isKindOfClass:[NSDictionary class]])
                        {
                            NSDictionary *responseDictonary = response;
                            NSLog(@"%@",responseDictonary);
                        }
                        else if([response isKindOfClass:[NSArray class]])
                        {
                            NSArray *arrayResponse = response;
                            NSLog(@"%@",arrayResponse);
                        }
                        
                    }
                }] resume];
}

@end
