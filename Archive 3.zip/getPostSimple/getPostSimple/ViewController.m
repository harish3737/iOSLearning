//
//  ViewController.m
//  getPostSimple
//
//  Created by CSSCORP on 12/28/18.
//  Copyright © 2018 CSSCORP. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    NSString *username;
    NSString *password;
    NSDictionary *dictonaryResponse;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (IBAction)clickOn:(id)sender {
    [self loginView];

}

- (IBAction)updateClick:(id)sender {
    [self updateView];
}
-(void)loginView
{
    username= @"staging" ;
    password= @"m5Q5ccWX4M123";
    NSString *url1=@"https://medicaresit.horizonbluestaging.com/restapi/v1/user/login";
    NSMutableDictionary *value = [[NSMutableDictionary alloc]init];
    [value setValue:@"agent1" forKey:@"username"];
    [value setValue:@"P@ssw0rd!@#" forKey:@"password"];
    NSURLSession *session = [NSURLSession sharedSession];
    NSURL *url = [NSURL URLWithString:url1];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    request.HTTPMethod=@"Post";
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    NSString *authStr = [NSString stringWithFormat:@"%@:%@", username, password];
    NSData *authData = [authStr dataUsingEncoding:NSUTF8StringEncoding];
    NSString *authValue = [NSString stringWithFormat:@"Basic %@", [authData base64EncodedStringWithOptions:0]];
    [request setValue:authValue forHTTPHeaderField:@"Authorization"];
     NSData *getParams =[NSJSONSerialization dataWithJSONObject:value options:NSJSONWritingPrettyPrinted error:0];
    request.HTTPBody = getParams;
    [[session dataTaskWithRequest:request
                completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
                    if (!error) {
                        
                        id response=[NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
                        if ([response isKindOfClass:[NSString class]])
                        {
                            NSString *responseString = [NSString stringWithFormat:@"%@",response];
                            NSLog(@"%@",responseString);
                        }
                        else if([response isKindOfClass:[NSDictionary class]])
                        {
                            NSDictionary *responseDictonary = response;
                            self -> dictonaryResponse = responseDictonary;
                            NSLog(@"%@",responseDictonary);
                        }
                        else if([response isKindOfClass:[NSArray class]])
                        {
                            NSArray *arrayResponse = response;
                            NSLog(@"%@",arrayResponse);
                        }
                        
                    }
                }] resume];}




-(void)updateView
{
    username= @"staging" ;
    password= @"m5Q5ccWX4M";
    NSString *url1=@"https://medicaresit.horizonbluestaging.com/restapi/v1/checkforupdates/retrieve";
//    NSDictionary *getValue = dictonaryResponse;
     NSString *SessionName =[dictonaryResponse valueForKey:@"session_name"];
    NSString *sessid=[dictonaryResponse valueForKey:@"sessid"];
    NSString *token=[dictonaryResponse valueForKey:@"token"];
    NSString *cookie=[NSString stringWithFormat:@"%@=%@",SessionName,sessid];
    NSURLSession *session = [NSURLSession sharedSession];
    NSURL *url = [NSURL URLWithString:url1];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    request.HTTPMethod=@"GET";
    [request setValue:cookie forHTTPHeaderField:@"Cookie"];
    [request setValue:token forHTTPHeaderField:@"X-csrf-token"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    NSString *authStr = [NSString stringWithFormat:@"%@:%@", username, password];
    NSData *authData = [authStr dataUsingEncoding:NSUTF8StringEncoding];
    NSString *authValue = [NSString stringWithFormat:@"Basic %@", [authData base64EncodedStringWithOptions:0]];
    [request setValue:authValue forHTTPHeaderField:@"Authorization"];
    [[session dataTaskWithRequest:request
                completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
                    if (!error) {
                        
                        id response=[NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
                        if ([response isKindOfClass:[NSString class]])
                        {
                            NSString *responseString = [NSString stringWithFormat:@"%@",response];
                            NSLog(@"%@",responseString);
                        }
                        else if([response isKindOfClass:[NSDictionary class]])
                        {
                            NSDictionary *responseDictonary = response;
                            NSLog(@"%@",responseDictonary);
                        }
                        else if([response isKindOfClass:[NSArray class]])
                        {
                            NSArray *arrayResponse = response;
                            NSLog(@"%@",arrayResponse);
                        }
                        
                    }
                }] resume];
}

@end
