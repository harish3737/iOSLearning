//
//  ViewController.h
//  Delgate_Example
//
//  Created by CSSCORP on 3/26/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol textDelegate <NSObject>

-(void)sendTextToViewController:(NSString *)string;

@end

@interface ViewController : UIViewController
@property (strong, nonatomic) IBOutlet UITextField *nameTextField;

@property (weak,nonatomic) id<textDelegate>delegate;

- (IBAction)nameTransfer:(id)sender;

//@property (strong,nonatomic)recieveTextViewController *secondVC;

@end

