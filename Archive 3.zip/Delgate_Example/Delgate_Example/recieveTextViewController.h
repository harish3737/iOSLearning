//
//  recieveTextViewController.h
//  Delgate_Example
//
//  Created by CSSCORP on 3/26/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface recieveTextViewController : UIViewController <textDelegate>
@property (strong, nonatomic) IBOutlet UITextField *recieveText;

@end

NS_ASSUME_NONNULL_END
