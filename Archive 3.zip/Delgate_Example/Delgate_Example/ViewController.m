//
//  ViewController.m
//  Delgate_Example
//
//  Created by CSSCORP on 3/26/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import "ViewController.h"
#import "recieveTextViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize nameTextField;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


- (IBAction)nameTransfer:(id)sender {
    [self.delegate sendTextToViewController:self.nameTextField.text];
//    [self presentViewController:recieveTextViewController animated:YES completion:nil];

}


@end
