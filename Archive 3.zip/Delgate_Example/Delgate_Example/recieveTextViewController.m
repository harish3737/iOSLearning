//
//  recieveTextViewController.m
//  Delgate_Example
//
//  Created by CSSCORP on 3/26/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import "recieveTextViewController.h"

@interface recieveTextViewController ()

@end

@implementation recieveTextViewController
@synthesize recieveText;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
//    recieveTextViewController *FVC = [[recieveTextViewController alloc]init];

//    [recieveTextViewController setDelegate:self];
 }


- (void)sendTextToViewController:(NSString *)string {
   self.recieveText.text=string;
}



@end
