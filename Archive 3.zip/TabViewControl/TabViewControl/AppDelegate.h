//
//  AppDelegate.h
//  TabViewControl
//
//  Created by CSSCORP on 12/10/18.
//  Copyright © 2018 CSSCORP. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

