//
//  main.m
//  Dummy
//
//  Created by CSSCORP on 12/17/18.
//  Copyright © 2018 CSSCORP. All rights reserved.
//

#import <Foundation/Foundation.h>
void convertString(NSDictionary *y)
{
    NSDictionary *z = y ;
    NSData * recieved = [NSJSONSerialization dataWithJSONObject:z options:NSJSONWritingPrettyPrinted error:0];
    NSString *print = [NSString stringWithFormat:@"%@",recieved];
    NSLog(@"%@",print);
}

int main(int argc, const char * argv[]) {
    @autoreleasepool {
         NSDictionary *value1 = [[NSDictionary alloc]init];
        [value set:@"hello" forKey:@"number"];
        convertString(value);
        
        
        // insert code here...
//        NSDictionary *codeme=@{@"John":@"firstName"};//[[NSDictionary alloc]initWithObjectsAndKeys:firstName,@"john", nil];
//        NSDictionary *codeme1=@{@"watson":@"secondName"};//[[NSDictionary alloc]initWithObjectsAndKeys:SecondName,@"watson", nil];
//        NSMutableArray *firstName=[[NSMutableArray alloc] ini:@"codeme"];
//        NSMutableDictionary *resume=[[NSMutableDictionary alloc]initWithObjectsAndKeys:firstName,@"firstName",nil];
        
//        //Dictonary
//        NSMutableDictionary *dictonary =[[NSMutableDictionary alloc]init];
//        [dictonary setValue:@"John" forKey:@"name"];
//        [dictonary setValue:@"Watson" forKey:@"surname"];
//
//        NSMutableDictionary *dictonary1 =[[NSMutableDictionary alloc]init];
//        [dictonary1 setValue:@"Detective" forKey:@"Profession"];
//        [dictonary1 setValue:@"35" forKey:@"age"];
//
//        NSMutableDictionary *dictonary2 =[[NSMutableDictionary alloc]init];
//        [dictonary2 setValue:@"Sherlock" forKey:@"friend"];
//        [dictonary2 setValue:@"Moriarity" forKey:@"enemy"];
//
//        //array
//        NSMutableArray *keyvalue = [[NSMutableArray alloc]init ];
//        [keyvalue setObject:dictonary atIndexedSubscript:0];
//        [keyvalue setObject:dictonary1 atIndexedSubscript:1];
//        [keyvalue setObject:dictonary2 atIndexedSubscript:2];
//
////        NSMutableArray *keyvalue1 = [[NSMutableArray alloc]init ];
////        [keyvalue1 setObject:dictonary1 atIndexedSubscript:0];
////
////        NSMutableArray *keyvalue2 = [[NSMutableArray alloc]init ];
////        [keyvalue2 setObject:dictonary2 atIndexedSubscript:0];
////
//        //Dictonary
//        NSMutableDictionary *resume=[[NSMutableDictionary alloc]init];
//        [resume setObject:keyvalue forKey:@"About"];
////        [resume setObject:keyvalue forKey:@"details"];
//       NSMutableString *string =[keyvalue valueAtIndex:0 inPropertyWithKey:@"surname"] ;
////        for items in
////        [resume setObject:keyvalue2 forKey:@"history"];
//        NSLog(@"%@",resume);
//        NSLog(@"%@",string);
        
//        -(String)convertString
    }
    return 0;
}
