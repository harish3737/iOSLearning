//
//  ViewController.m
//  multithreading
//
//  Created by CSSCORP on 4/22/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
//    [self getName];
    _Name = @"newValue";
    NSLog(@"%@",_Name);
    [self getAddrs];
}
- (void)viewWillAppear:(BOOL)animated
{
//    [self getName];
}
-(void)getName
{
//    int i;
//    dispatch_as
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_BACKGROUND,0),^{
       
        self->_Name = @"hello";
        NSLog(@"%@",self->_Name);
        self->_Name = @"Fire";
        NSLog(@"%@",self->_Name );
            dispatch_async(dispatch_get_main_queue(), ^{
//            NSLog(@"%@",_Name);
                self->_Name = @"new thread";
                NSLog(@"%@",self->_Name);
          });
//        self->_Name = @"getName";
//        NSLog(@"%@",self->_Name);
//        self->_Name = @"NewName";
//        NSLog(@"%@",self->_Name);
//        self->_Name = @"newVariable";
//        NSLog(@"%@",self->_Name);
//
            });
    _Name = @"newValue";
    NSLog(@"%@",self->_Name);
    _Name = @"getName";
    NSLog(@"%@",self->_Name);
    _Name = @"NewName";
    NSLog(@"%@",self->_Name);
    _Name = @"newVariable";
    NSLog(@"%@",self->_Name);
    
}
- (void)getAddrs
{
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_BACKGROUND,0),^{
        
        self->_Addrs = @"1";
        NSLog(@"%@",self->_Addrs);
        self->_Addrs = @"2";
        NSLog(@"%@",self->_Addrs);
        dispatch_async(dispatch_get_main_queue(), ^{
            //            NSLog(@"%@",_Name);
            self->_Addrs = @"3";
            NSLog(@"%@",self->_Addrs);
        });
        //        self->_Name = @"getName";
        //        NSLog(@"%@",self->_Name);
        //        self->_Name = @"NewName";
        //        NSLog(@"%@",self->_Name);
        //        self->_Name = @"newVariable";
        //        NSLog(@"%@",self->_Name);
        //
    });
    _Addrs = @"4";
    NSLog(@"%@",self->_Addrs);
    _Addrs = @"5";
    NSLog(@"%@",self->_Addrs);
    _Addrs = @"6";
    NSLog(@"%@",self->_Addrs);
    _Addrs = @"7";
    NSLog(@"%@",self->_Addrs);
    
}


@end
