//
//  AppDelegate.h
//  multithreading
//
//  Created by CSSCORP on 4/22/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

