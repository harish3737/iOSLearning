//
//  ViewController.h
//  multithreading
//
//  Created by CSSCORP on 4/22/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property(atomic,weak)NSString *Name;
@property(nonatomic,weak)NSString *Addrs;

-(void)getName;
-(void)getAddrs;

@end

