//
//  ViewController.m
//  Core Data
//
//  Created by CSSCORP on 1/3/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import "ViewController.h"
#import "AppDelegate.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize Name;
@synthesize phoneno;
@synthesize Address;
@synthesize status;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.


}
- (IBAction)saveData:(id)sender {
    
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    
    
    NSManagedObjectContext *context = [[appDelegate persistentContainer]viewContext];
    NSManagedObject *newContact;
//    newContact = [NSEntityDescription
//                  insertNewObjectForEntityForName:@"Contact"
//                  inManagedObjectContext:context];
    
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Contact" inManagedObjectContext:context];
    newContact = [[NSManagedObject alloc]initWithEntity:entity insertIntoManagedObjectContext:context];
    [newContact setValue: Name.text forKey:@"name"];
    [newContact setValue: Address.text forKey:@"address"];
    [newContact setValue: phoneno.text forKey:@"phone"];
    Name.text = @"";
    Address.text = @"";
    phoneno.text = @"";
    NSError *error;
    [context save:&error];
    status.text = @"Contact saved";
}

- (IBAction)findContact:(id)sender {
    AppDelegate *appDelegate =
    [[UIApplication sharedApplication] delegate];
    
    NSManagedObjectContext *context =
    [appDelegate managedObjectContext];
    
    NSEntityDescription *entityDesc =
    [NSEntityDescription entityForName:@"Contacts"
                inManagedObjectContext:context];
    
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    [request setEntity:entityDesc];
    
    NSPredicate *pred =
    [NSPredicate predicateWithFormat:@"(name = %@)",
     Name.text];
    [request setPredicate:pred];
    NSManagedObject *matches = nil;
    
    NSError *error;
    NSArray *objects = [context executeFetchRequest:request
                                              error:&error];
    
    if ([objects count] == 0) {
        status.text = @"No matches";
    } else {
        matches = objects[0];
        Address.text = [matches valueForKey:@"address"];
        phoneno.text = [matches valueForKey:@"phone"];
        status.text = [NSString stringWithFormat:
                        @"%lu matches found", (unsigned long)[objects count]];
    }
}


@end
