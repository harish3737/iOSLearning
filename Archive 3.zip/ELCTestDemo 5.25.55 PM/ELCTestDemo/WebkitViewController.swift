//
//  WebkitViewController.swift
//  ELCTestDemo
//
//  Created by CSSCORP on 2/12/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

import UIKit
import WebKit

class WebkitViewController: UIViewController, WKUIDelegate, UIApplicationDelegate, WKNavigationDelegate {
    
    
    @IBOutlet weak var webViewContainer: UIView!
    
    let requestURLString = "https://iosdevcenters.blogspot.com/"
    
    var webView: WKWebView!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        let webView = WKWebView(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: self.view.frame.size.height))
        self.view.addSubview(webView)
        let url = URL(string: "https://stackoverflow.com/questions/50189878/swift-4-webkit-webview-does-not-load-url-with-added-parameter")
        webView.load(URLRequest(url: url!))
        NSLog("INSIDE VIEW DID LOAD")
    }
   
    
    override func viewWillAppear(_ animated: Bool) {

        let webView = WKWebView(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: self.view.frame.size.height))
        self.view.addSubview(webView)
        let url = URL(string: "https://iosdevcenters.blogspot.com")
        webView.load(URLRequest(url: url!))
        NSLog("INSIDE VIEW DID APPEARS")
    }
    
    func webView(_: WKWebView, didFinish: WKNavigation!)
 {
    webView.stopLoading()
}
   }



  
