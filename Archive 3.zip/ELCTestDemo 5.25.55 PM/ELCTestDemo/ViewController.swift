//
//  ViewController.swift
//  ELCTestDemo
//
//  Created by CSSCORP on 2/12/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
       
    }

    @IBAction func webPageSignIn(_ sender: Any) {
           
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "WebkitViewController") as! WebkitViewController
        self.navigationController?.pushViewController(nextViewController, animated: true)
    
}
}
