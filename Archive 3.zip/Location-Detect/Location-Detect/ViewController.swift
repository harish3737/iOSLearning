//
//  ViewController.swift
//  Location-Detect
//
//  Created by CSSCORP on 3/12/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

import UIKit
import CoreLocation


class ViewController: UIViewController, CLLocationManagerDelegate {
@IBOutlet var latitudeLabe: UILabel!
@IBOutlet var longitudeLabel: UILabel!
var locationManager:CLLocationManager!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a snib.
   self.latitudeLabe.isHidden = true
    self.longitudeLabel.isHidden = true
    
    }
   @IBAction func seeLocation(_ sender: Any) {
        self.latitudeLabe.isHidden=false
        self.longitudeLabel.isHidden = false
        self.determineMyCurrentLocation()
    
    
    
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func determineMyCurrentLocation() {
        locationManager = CLLocationManager()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestAlwaysAuthorization()
        
        if CLLocationManager.locationServicesEnabled() {
            locationManager.startUpdatingLocation()
            //locationManager.startUpdatingHeading()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let userLocation:CLLocation = locations[0] as CLLocation
        
        // Call stopUpdatingLocation() to stop listening for location updates,
        // other wise this function will be called every time when user location changes.
        
        
        
        print("user latitude = \(userLocation.coordinate.latitude)")
        print("user longitude = \(userLocation.coordinate.longitude)")
        let latitude = String(userLocation.coordinate.latitude)
        let logitude = String(userLocation.coordinate.longitude)
//        self.latitudeLabe.backgroundColor=UIColor.red
        self.latitudeLabe.text = latitude
        self.longitudeLabel.text = logitude
    ViewController.runThisAfterDelay(seconds: 10){
            //write your code here
        print("after 10 sec")
        manager.stopUpdatingLocation()
        print("user latitude = \(userLocation.coordinate.latitude)")
                print("user longitude = \(userLocation.coordinate.longitude)")
                self.latitudeLabe.text = latitude
                self.longitudeLabel.text = logitude
//        mas
        }
        
        
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error)
    {
        print("Error \(error)")
    }
    
    //This is used in delaying the getting of lat and longitude
    public static func runThisAfterDelay(seconds: Double, after: @escaping () -> Void) {
        runThisAfterDelay(seconds: seconds, queue: DispatchQueue.main, after: after)
    }
    
    public static func runThisAfterDelay(seconds: Double, queue: DispatchQueue, after: @escaping () -> Void) {
        let time = DispatchTime.now() + Double(Int64(seconds * Double(NSEC_PER_SEC))) / Double(NSEC_PER_SEC)
        queue.asyncAfter(deadline: time, execute: after)
    }
}
    


