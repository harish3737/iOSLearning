//
//  ViewController.h
//  sampleview
//
//  Created by CSSCORP on 11/26/18.
//  Copyright © 2018 CSSCORP. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction)changeColor:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *colorChange;
@property (strong, nonatomic) IBOutlet UIView *changeView;
@property (nonatomic, assign) BOOL *click;



@end

