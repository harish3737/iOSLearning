//
//  ViewController.m
//  sampleview
//
//  Created by CSSCORP on 11/26/18.
//  Copyright © 2018 CSSCORP. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize colorChange;
@synthesize changeView;
@synthesize click;


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (IBAction)changeColor:(id)sender {
//
//            changeView.backgroundColor = [UIColor redColor];

   if(self.click==0)
    {
        changeView.backgroundColor = [UIColor colorWithRed:35/255.0 green:70/255.0 blue:137/255.0 alpha:0.7];
        click+=1;
        NSLog(@"inside if");

    }
    else{
        changeView.backgroundColor=[UIColor colorWithRed:137/255.0 green:35/255.0 blue:70/255.0 alpha:1.0];
        click = 0;
        NSLog(@"inside else");
    }

}

@end
