//
//  callClass.h
//  classCall
//
//  Created by CSSCORP on 3/28/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface callClass : NSObject
@property (nonatomic,strong)NSString *value;
-(void)valueforProperty;

@end


