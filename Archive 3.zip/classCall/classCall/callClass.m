//
//  callClass.m
//  classCall
//
//  Created by CSSCORP on 3/28/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import "callClass.h"

@implementation callClass

- (instancetype)init

{
    [self valueforProperty];

    return self;

}


- (void)valueforProperty
{
    NSLog(@"%@",_value);
}

@end
