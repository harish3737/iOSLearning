//
//  UICustomButton.m
//  classCall
//
//  Created by CSSCORP on 3/29/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import "UICustomButton.h"

@implementation UICustomButton

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
- (instancetype)init
{
    self = [super init];
    if (self) {
        NSLog(@"intialized");
    }
    return self;
}
-(void)setLabelText:(NSString *)labelText //method for setting value for title by passing the value for the title as string
{
    [self setTitle:labelText forState:UIControlStateNormal];
    
}
- (void)setFrameValue:(NSString *)frameValue
{
    CGRect frameValue1 = CGRectFromString(frameValue);
    self.frame =  frameValue1;
    
}
//- (void)setCustomColor:(NSString *)customColor
//{
//    self.backgroundColor = [NSString stringWithFormat:@"UIColor %@",customColor];
//
//}


-(NSString *)labelText
{
    return self.labelText;
}
//-(NSString *)customColor
//{
//    
//}
-(NSString *)frameValue
{
    return self.frameValue;
    
}


@end
