//
//  UICustomButton.h
//  classCall
//
//  Created by CSSCORP on 3/29/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UICustomButton : UIButton
@property (nonatomic,strong)NSString *labelText;
@property(nonatomic,strong)NSString *frameValue;
-(void)setLabelText:(NSString * _Nonnull)labelText;
-(void)setFrameValue:(NSString * _Nonnull)frameValue;




@end

NS_ASSUME_NONNULL_END
