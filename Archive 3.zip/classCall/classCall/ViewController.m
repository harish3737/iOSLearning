//
//  ViewController.m
//  classCall
//
//  Created by CSSCORP on 3/28/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import "ViewController.h"
#import <CSSUIFramwork/CSSUIFramwork.h>

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
//    id buttonClass = [[NSClassFromString(buttonName)alloc]init];
//    [buttonClass setValue:@"clickFunction" forKey:nameProperty];
//    [buttonClass setValue:@"UIButtonTypeRoundedRect" forKey:@"buttonWithType"];
//    [buttonClass setValue:@"CGRectMake(80.0, 210.0, 160.0, 40.0)" forKey:@"frame"];
//    [buttonClass setValue:<#(nullable id)#> forKey:<#(nonnull NSString *)#>]
//    [self.view addSubview:buttonClass];
    
//    NSString *buttonNameString =@"buttonNameString";
//
//    id buttonClick = [UIButton buttonWithType:UIButtonTypeRoundedRect];
//    [buttonClick setTitle:nameProperty forState:UIControlStateNormal];
//    buttonClick.frame = CGRectMake(80.0, 210.0, 160.0, 40.0);
//    buttonClick.backgroundColor=[UIColor redColor];
//    [buttonClick setValue:@"CGRectMake(80.0, 210.0, 160.0, 40.0)" forKey:@"frame"];
//    [buttonClick setValue:@"[UIColor redColor]" forKey:@"backgroundColor"];
//    [self.view addSubview:buttonClick];
    
//    id buttonNameString = [[NSClassFromString(buttonName)alloc]initWithFrame:CGRectMake(80.0, 210.0, 160.0, 40.0)];
////    [buttonNameString setValue:@"UIButtonTypeRoundedRect" forKey:@"buttonWithType"];
////    [buttonNameString setValue:@"UIColor redColor" forKey:@"backgroundColor"];
//    [buttonName setValue:nameProperty forKey:@"setTitle"];
//    [self.view addSubview:buttonNameString];

//    NSString *rectValue = @"{{80.0,210.0},{160.0,40.0}}";
    
   
//  testLabel
//     UILabel *testLabel = [[UILabel alloc] initWithFrame: CGRectMake(30.0f,100.0f,250.0f,40.0f)];
   
//    [self callButton];
    
//    [self callButton];
//    [self callCheckBoxwithLabel];
//    [self callValidatorlabel];
    [self calldropdown];
//    [self calldropDown];


}

- (void)testdata{
    UIButton *button = [[NSClassFromString(@"UIButton") alloc] init];
    button.frame = CGRectMake(10, 25, 150, 75);
    [button setValue:[UIColor blackColor] forKey:@"backgroundColor"];
    
    [button setBackgroundColor:[UIColor blackColor]];
    [self.view addSubview:button];
    
}

-(void)callButton
{
    NSDictionary *buttonPropertynew =@{
                                       @"labelText":@"TitleforButton",
                                       @"frameValue":@"{{80,210},{160,40}}"
                                       
                                    };
    id buttonName = [[NSClassFromString(@"UICustomButton")alloc]init];
    for(NSString *keyValue in[buttonPropertynew allKeys])
    {
        id propertyValue = [buttonPropertynew valueForKey:keyValue];
    
        [buttonName setValue:propertyValue forKey:keyValue];
        
    }
    [buttonName setBackgroundColor:[UIColor blackColor]];
    [self.view addSubview:buttonName];
}


-(void)callValidatorlabel
{
    ValidatorLabel *detailLabel = [[NSClassFromString(@"ValidatorLabel") alloc] init];
    detailLabel.frame = CGRectMake(10, 25, 150, 75);
     [detailLabel setValue:[UIColor blueColor] forKey:@"backgroundColor"];
//    detailLabel.localizationKey = @"detailText";
//    detailLabel.textColor = [UIColor colorWithRed:102.0/255.0 green:102.0/255.0 blue:102.0/255.0 alpha:1.0];
//    detailLabel.font = [UIFont fontWithName:@"Arial-Regular" size:14.0];
//    detailLabel.textAlignment = NSTextAlignmentLeft;
//    detailLabel.numberOfLines = 1;
    [self.view addSubview:detailLabel];

}



-(void)dataForValidator
{
    NSDictionary *validatorLabelproperties =@{
                                       @"localizationKey":@"TitleforLabel",
                                       @"customTextKey":@"TitleforLabel",
                                       @"customFontSize":@"15",
                                       @"customFontName":@"Helvetica",
                                       @"frameValue":@"{{80,210},{160,40}}"
                                            };
    id validatorlabel = [[NSClassFromString(@"UICheckBoxWithButton")alloc]init];
    for(NSString *keyValue in[validatorLabelproperties allKeys])
    {
        id propertyValue = [validatorLabelproperties valueForKey:keyValue];
           [validatorlabel setValue:propertyValue forKey:keyValue];
        
    }
//    validatorlabel.frame = CGRectMake(80,210, 160, 40);
    [validatorlabel setBackgroundColor:[UIColor blueColor]];
    [self.view addSubview:validatorlabel];
}

//-(void)callCheckBox
//{
//
//    NSDictionary *UICheckBoxWithLabel =@{@"checkBoxButton":
//                                    @{@"localizationKey":@"HelloWorld",
//                                        },
//                                @"contentLabel":
//                                    @{
//                                                 @"localizationKey":@"HelloWorld"
////                                           @"xPath":@"tempJSON"
//                                        }
//                                };
//    NSLog(@"%@",UICheckBoxWithLabel);
//    id ParentObject = [[NSClassFromString(@"UICheckBoxWithLabel")alloc]init];
//    for(NSString *keyString in [UICheckBoxWithLabel allKeys])
//    {
////        id propertyName = keyString;
//
//        NSDictionary *childDict = [UICheckBoxWithLabel valueForKey:keyString];
//        NSLog(@"%@",childDict);
//        for(NSString *key in [childDict allKeys])
//        {
//            NSLog(@"%@",childDict);
//        id childObject = [childDict valueForKey:key];
//           [ParentObject setValue:childObject forKey:key];
////         [parentObject1 setValue:UICheckBoxWithLabel forKey:keyString];
//            [ParentObject setFrame:CGRectMake(120, 140, 50,80)];
//            [ParentObject setBackgroundColor:[UIColor blueColor]];
//
//        }
////        [ParentObject setValue:UICheckBoxWithLabel forKey:keyString];
//
//
//    }
//    [ParentObject setBackgroundColor:[UIColor blueColor]];
//    [ParentObject setFrame:CGRectMake(120, 80, 30, 160)];
//    [self.view addSubview:ParentObject];
//
//}
-(void)callCheckBoxwithLabel
{
    NSDictionary *UICheckBoxWithLabel =@{@"UICheckBoxWithLabel"
                                         :@{@"checkBoxButton":
                                             @{ @"xPath":@"tempJSON"
                                               },
                                         @"contentLabel":
                                             @{
                                                 @"localizationKey":@"Hello"
                                                                                               }
                                            }};
    id parentObject;
    for(NSString *childString in UICheckBoxWithLabel)
    {
        parentObject = [[NSClassFromString(childString)alloc]init];
        [parentObject setFrame:CGRectMake(80, 210, 160, 40)];
        [parentObject setBackgroundColor:[UIColor redColor]];
        [self Child:parentObject valueDictionary:[UICheckBoxWithLabel valueForKey:childString]];
        [self.view addSubview:parentObject];
    }
  
}


-(void)directCallforCheckbox
{
    UICheckBoxWithLabel *newCheckBox = [[UICheckBoxWithLabel alloc]init];
    newCheckBox.frame = CGRectMake(120, 60, 120, 60);
    [newCheckBox setBackgroundColor:[UIColor blueColor]];
    [newCheckBox setValue:@"title" forKey:@"contentLabel"];
    [self.view addSubview:newCheckBox];
}
-(void)calldropdown
{
    NSDictionary *uilabeldropdown =@{ @"UILabelDropDownWithTextField":@{
                                              @"headingLabel":@{
                                                      @"localizationKey":@"Number"
                                                      },
                                              @"dropDownBtnView":@{
                                                      @"contentArray":@[
                                                      @"Home",
                                                      @"New",
                                                      @"ground"
                                                      ]
                                                      }
                                              }
                                            };
    NSLog(@"%@",uilabeldropdown);
    id parentObject;
    for(NSString *childString in uilabeldropdown)
    {
        parentObject = [[NSClassFromString(childString)alloc]init];
        [parentObject setFrame:CGRectMake(80, 210, 160, 40)];
        [parentObject setBackgroundColor:[UIColor redColor]];
        [self Child:parentObject valueDictionary:[uilabeldropdown valueForKey:childString]];
        [self.view addSubview:parentObject];
    }
}
-(void)Child:(id)baseObject valueDictionary:(NSMutableDictionary *)listDict{
    for(NSString *keyvalue in [listDict allKeys])
    {
        id childObject = [listDict valueForKey:keyvalue];
        if(![childObject isKindOfClass:[NSDictionary class]])
        {
            [baseObject setValue:childObject forKey:keyvalue];
//            [baseObject setFrame:CGRectMake(120, 240, 120, 240)];
//             [baseObject setBackgroundColor:[UIColor blueColor]];
        }
        else
        {
            [self Child:[baseObject valueForKey:keyvalue] valueDictionary:childObject];
        }
    }
    
}
-(void)calldropDownwithlabel
{
    NSDictionary *dropDownData =@{ @"UILabelDropDownWithTextField":@{
                                              @"headingLabel":@{
                                                      @"localizationKey":@"Number"
                                                      },
                                              @"dropDownBtnView":@{
                                                      @"contentArray":@[
                                                              @"Home",
                                                              @"New",
                                                              @"ground"
                                                              ]
                                                      }
                                              }
                                      };
//    NSString *getdata = [dropDownData objectForKey:@"UILabelDropDownWithTextField"];
    NSArray *keyData = [dropDownData allKeys];
    NSString *valueforKey = [keyData objectAtIndex:0];
    NSLog(@"%@",valueforKey);
    id parentObject;
    parentObject = [[NSClassFromString(valueforKey)alloc]init];
    [parentObject setFrame:CGRectMake(80, 210, 160, 40)];
    [parentObject setBackgroundColor:[UIColor redColor]];
    for(NSString *keyValue in [dropDownData allKeys])
    {
        id childObject = [dropDownData objectForKey:keyValue];
        for(NSString *childKey in childObject)
        {
            id childData = [childObject objectForKey:childKey];
            id childNew = [childData valueForKey:childKey];
            NSLog(@"%@",childNew);
            for(NSString *keyData in childData)
            {
                id datatosend =[childData objectForKey:keyData];
                id baseObject = [datatosend objectForKey:keyData];
                NSLog(@"%@",baseObject);
                [childNew setValue:datatosend forKey:keyData];
                
            }
        }
    }
    [self.view addSubview:parentObject];
    
}

-(void)directCallDropdown{
    UILabelDropDownWithTextField *dropDown = [[NSClassFromString(@"UILabelDropDownWithTextField")alloc]init];
    dropDown.frame= CGRectMake(10, 25, 150, 75);
    dropDown.backgroundColor=[UIColor blueColor];
    [self.view addSubview:dropDown];
  
}




@end

