//
//  Queue.h
//  Queue
//
//  Created by CSSCORP on 4/29/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Queue : NSObject

-(void)enqueue:(id)anObject;
-(id)dequeue;
@property (strong) NSMutableArray *data;
@end

NS_ASSUME_NONNULL_END
