//
//  Queue.m
//  Queue
//
//  Created by CSSCORP on 4/29/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import "Queue.h"

@implementation Queue
-(instancetype)init{
    if (self = [super init]){
        _data = [[NSMutableArray alloc] init];
    }
    return self;
}

-(void)enqueue:(id)anObject{
    [self.data addObject:anObject];
}

-(id)dequeue{
    id headObject = [self.data objectAtIndex:0];
    if (headObject != nil) {
        [self.data removeObjectAtIndex:0];
    }
    return headObject;
}


@end
