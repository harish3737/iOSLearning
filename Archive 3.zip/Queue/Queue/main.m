//
//  main.m
//  Queue
//
//  Created by CSSCORP on 4/29/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Queue.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
         Queue *queue = [[Queue alloc] init];
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
           
            [queue enqueue:@"Jim"];
            [queue enqueue:@"Moriarity"];
            [queue enqueue:@"John"];
            [queue enqueue:@"Cena"];
            [queue enqueue:@"Mary"];
            [queue enqueue:@"Watson"];
        });
        dispatch_async(dispatch_get_main_queue(), ^{
            
            NSLog(@"%@",queue.dequeue);
            NSLog(@"%@",queue.dequeue);
            NSLog(@"%@",queue.dequeue);
            NSLog(@"%@",queue.dequeue);
            NSLog(@"%@",queue.dequeue);
            NSLog(@"%@",queue.dequeue);
        });
       

        //Follows First In First Out
        
    }
    return 0;
   
        
    
}



