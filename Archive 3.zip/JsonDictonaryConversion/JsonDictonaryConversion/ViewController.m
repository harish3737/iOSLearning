//
//  ViewController.m
//  JsonDictonaryConversion
//
//  Created by CSSCORP on 3/27/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()


@end

@implementation ViewController

@synthesize changeText, labelChange;
NSString *new;
- (void)viewDidLoad {
    [super viewDidLoad];
//    [self UrlChange];
    [self urlChange1];
    // Do any additional setup after loading the view.
}

//-(void)UrlChange{
//
//       NSURLSession *session = [NSURLSession sharedSession];//creating a url session for connection
//    NSURLSessionDataTask *dataTask = [session dataTaskWithURL:[NSURL URLWithString:@"https://maps.googleapis.com/maps/api/geocode/json?address=1600+Amphitheatre+Parkway,+Mountain+View,+CA&key=AIzaSyAAKb5lBsDLrS-JxQn9Z38G2bEpF69MuPE"] completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
//        id json = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
////                NSDictionary *json = [NSJSONSerialization isValidJSONObject:data];
//
//        if ([json isKindOfClass:[NSArray class]]){
//            NSArray *jsonArray = json;
//            NSLog(@"%@",jsonArray);
//
//
//        }else if([json isKindOfClass:[NSString class]]){
//                        NSString *jsonString = [NSString stringWithFormat:@"%@",json];
//            NSLog(@"%@",jsonString);
//
//        }else {
//                        NSMutableDictionary *jsonDict = json;
//            NSLog(@"%@",jsonDict);
////            [[self valueforDict = [jsonDict objectForKey:@"results"]] ];
//            NSLog(@"RESULTS  ::::%@",[jsonDict objectForKey:@"results"]);
//
//        }
////        NSDictionary *getValue = //        changeText.text = [getValue objectForKey:@""];
//
//        NSArray *getValue = [json objectForKey:@"results"];
//        NSLog(@"RESULTS 1 ::::%@",getValue);
//        NSDictionary *Value1 = [getValue objectAtIndex:0];
//        NSLog(@"%@",Value1);
////        NSArray *new = [getValue setValue:new forKey:@""];
//        new = [Value1 valueForKey:@"formatted_address"];
//        NSLog(@"%@",new);
//    }];
//    [dataTask resume];
//
//
//
//
//
//
//}
//- (void)viewWillAppear:(BOOL)animated{
//
//}

- (IBAction)clickHere:(id)sender {
    
     [labelChange setText:@"formatted_address"];
    changeText.text = new;
//
}
-(void)urlChange1
{
    
    NSURLSession *session = [NSURLSession sharedSession];//creating a url session for connection
    NSURLSessionDataTask *dataTask = [session dataTaskWithURL:[NSURL URLWithString:@"https://maps.googleapis.com/maps/api/geocode/json?address=1600+Amphitheatre+Parkway,+Mountain+View,+CA&key=AIzaSyAAKb5lBsDLrS-JxQn9Z38G2bEpF69MuPE"] completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        id json = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
        if([json isKindOfClass:[NSDictionary class]])
        {
            NSDictionary *dict1 = json;
            for (id key in dict1)
            {
                NSArray *Value = [dict1 objectForKey:key];
                int i;
                for(i=0;i<[Value count];i++ )
                {
                    NSDictionary *value1 =[Value objectAtIndex:i];
                    new = [value1 objectForKey:@"formatted_address"];
//                    break;
                }
                break;
            }
        }
            
                                      }];
    [dataTask resume];
}
@end



