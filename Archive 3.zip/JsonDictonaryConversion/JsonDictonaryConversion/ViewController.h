//
//  ViewController.h
//  JsonDictonaryConversion
//
//  Created by CSSCORP on 3/27/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (strong, nonatomic) IBOutlet UILabel *labelChange;
@property (strong, nonatomic) IBOutlet UITextField *changeText;
- (IBAction)clickHere:(id)sender;

@end

