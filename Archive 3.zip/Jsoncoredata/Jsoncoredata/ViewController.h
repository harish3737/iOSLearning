//
//  ViewController.h
//  Jsoncoredata
//
//  Created by CSSCORP on 1/7/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
- (IBAction)Add:(id)sender;
- (IBAction)Fetch:(id)sender;



@end

