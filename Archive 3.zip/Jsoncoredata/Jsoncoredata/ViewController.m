//
//  ViewController.m
//  Jsoncoredata
//
//  Created by CSSCORP on 1/7/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import "ViewController.h"
#import "AppDelegate.h"

@interface ViewController ()
{
    NSString *username;
    NSString *password;
    NSString *authStr;
    NSData *authData;
    NSString *authValue;
    NSManagedObjectContext *context;
    NSManagedObject *value;
    NSEntityDescription *entity;
    NSArray *response1;
    
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (IBAction)Add:(id)sender {
    [self pdpclickJson];
}

- (IBAction)Fetch:(id)sender {
    [self fetchdata];
}


-(void)pdpclickJson
{
    username= @"staging" ;
    password= @"m5Q5ccWX4M";
    authStr = [NSString stringWithFormat:@"%@:%@", username, password];
    authData = [authStr dataUsingEncoding:NSUTF8StringEncoding];
    authValue = [NSString stringWithFormat:@"Basic %@", [authData base64EncodedStringWithOptions:0]];
    
    NSString *url1 = @"https://medicaresit.horizonbluestaging.com/restapi/v1/views/plans_pdp";
    //    NSDictionary *getValue = dictonaryResponse;
    NSURLSession *session = [NSURLSession sharedSession];
    NSURL *url = [NSURL URLWithString:url1];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    request.HTTPMethod=@"GET";
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request setValue:authValue forHTTPHeaderField:@"Authorization"];
    
    [[session dataTaskWithRequest:request
                completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
                    if (!error) {
                        
                        id response=[NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
                        
                        if ([response isKindOfClass:[NSString class]])
                        {
                            NSString *responseString = [NSString stringWithFormat:@"%@",response];
                            NSLog(@"%@",responseString);
                        }
                        else if([response isKindOfClass:[NSDictionary class]])
                        {
                            NSDictionary *responseDictonary = response;
                            NSLog(@"%@",responseDictonary);
                            id appDelegate = [[UIApplication sharedApplication] delegate];
                            NSManagedObjectContext *context = [[appDelegate persistentContainer]viewContext];
                            NSEntityDescription *entity = [NSEntityDescription entityForName:@"Pdp" inManagedObjectContext:context];
//                            NSManagedObject *value = [[NSManagedObject a]];
                            NSManagedObject *value;
                            value = [[NSManagedObject alloc]initWithEntity:entity insertIntoManagedObjectContext:context];
                            [value setValuesForKeysWithDictionary:responseDictonary];
                            
                        }
                        else if([response isKindOfClass:[NSArray class]])
                        {
                            NSArray *arrayResponse = response;
                            
                            NSLog(@"%@",arrayResponse);
                            self->response1=arrayResponse;
                            [self arrayResponse];
                        }
                    }
 
                }] resume];
    
}
-(void)fetchdata
{
    id appDelegate =
    [[UIApplication sharedApplication] delegate];
    NSManagedObjectContext *context =
    [[appDelegate persistentContainer]viewContext];
    NSEntityDescription *entityDesc =
    [NSEntityDescription entityForName:@"Pdp"
                inManagedObjectContext:context];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    [request setEntity:entityDesc];
//    NSPredicate *predi = [NSPredicate predicateWithFormat:@"plan=%@", @"Horizon Medicare Blue Rx Standard (PDP)"];
//    [request setPredicate:predi];
    NSError *error;
    NSArray *objects = [context executeFetchRequest:request
                    
                                              error:&error];
   // objects=[[NSManagedObjectContext valueForKeyPath:objects]
//    NSString *new=
    
    for (int i=0; i<objects.count; i++) {
        
    
//    NSArray *new = [objects objectAtIndex:i];
//    NSLog(@"plan=%@",[new valueForKey:@"plan"]);
//    NSLog(@"csv plan name=%@",[new valueForKey:@"csvplanname"]);
//    NSLog(@"plan year=%@",[new valueForKey:@"planyear"]);
//    NSLog(@"monthly premium=%@",[new valueForKey:@"monthlypremium"]);
        
        NSManagedObject *content = [objects objectAtIndex:i];
        NSLog(@"value :: %@",[content valueForKey:@"plan"]);
         NSLog(@"csv plan name :: %@",[content valueForKey:@"csvplanname"]);
        NSLog(@"plan year :: %@",[content valueForKey:@"planyear"]);
        NSLog(@"monthly premium :: %@",[content valueForKey:@"monthlypremium"]);
    }
}
-(void)arrayResponse
{
    NSDictionary *response;
    for (int i =0;i<[response1 count]; i++) {
        response = [response1 objectAtIndex:i];
        AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
        self->context = [[appDelegate persistentContainer]viewContext];
        entity = [NSEntityDescription entityForName:@"Pdp" inManagedObjectContext:context];
        //                            NSManagedObject *value = [[NSManagedObject a]];
        value = [[NSManagedObject alloc]initWithEntity:entity insertIntoManagedObjectContext:context];
        [value setValue:[response valueForKey:@"plan"] forKey:@"plan"];
        [value setValue:[response valueForKey:@"csv plan name"] forKey:@"csvplanname"];
        [value setValue:[response valueForKey:@"plan year"] forKey:@"planyear"];
        [value setValue:[response valueForKey:@"monthly premium"] forKey:@"monthlypremium"];
        NSError *error;
        [context save:&error];
        NSLog(@"saved");
    }
    
}
@end
