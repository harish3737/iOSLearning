//
//  Person.h
//  strongweak
//
//  Created by CSSCORP on 4/12/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import <Foundation/Foundation.h>
@class Marks;


@interface Person : NSObject
@property(nonatomic,strong)Marks *studentMarks;
-(void)initwithdata;
@end

//NS_ASSUME_NONNULL_END
