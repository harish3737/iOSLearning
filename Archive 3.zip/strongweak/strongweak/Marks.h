//
//  Marks.h
//  strongweak
//
//  Created by CSSCORP on 4/12/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import <Foundation/Foundation.h>
@class Person;

@interface Marks : NSObject

@property(nonatomic,strong)Person *marksPerson;

@end


