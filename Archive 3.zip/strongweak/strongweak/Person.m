//
//  Person.m
//  strongweak
//
//  Created by CSSCORP on 4/12/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import "Person.h"
#import "Marks.h"
@implementation Person



-(void)initwithdata
{
    self.studentMarks = [[Marks alloc]init];
    self.studentMarks.marksPerson =self;
}

@end
