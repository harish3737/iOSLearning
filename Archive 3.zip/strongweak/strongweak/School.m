//
//  School.m
//  strongweak
//
//  Created by CSSCORP on 4/12/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import "School.h"
#import "Person.h"
@implementation School

-(void)initData
{
    self.student =[[Person alloc]init];
    [self.student initwithdata];
    
    self.student = nil;
}

@end


