//
//  SecondViewController.m
//  propertyDemo
//
//  Created by CSSCORP on 4/10/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import "SecondViewController.h"

@interface SecondViewController ()

@end

@implementation SecondViewController
@synthesize setValue;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
setValue = @"newvalue";

}
- (IBAction)backtofirstView:(id)sender {
    [self.dataproperty setString:setValue];
    [self.navigationController popViewControllerAnimated:YES];
}

@end
