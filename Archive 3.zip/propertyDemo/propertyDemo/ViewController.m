//
//  ViewController.m
//  propertyDemo
//
//  Created by CSSCORP on 4/10/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
//    _dataValue = @"setValue"
    
       
    
    
    
}
- (void)viewWillAppear:(BOOL)animated
{
    NSLog(@"%@",_dataget);
}

- (void)setString:(NSString *)dataValue {
     _dataget = dataValue;
    NSLog(@"%@",_dataget);
}
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    SecondViewController *sec = [segue destinationViewController];
    sec.dataproperty = self;
}
@end
