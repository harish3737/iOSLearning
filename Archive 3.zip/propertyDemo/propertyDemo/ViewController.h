//
//  ViewController.h
//  propertyDemo
//
//  Created by CSSCORP on 4/10/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SecondViewController.h"

@interface ViewController : UIViewController<setValue>
@property(nonatomic,strong)NSString *dataget;

@end

