//
//  SecondViewController.h
//  propertyDemo
//
//  Created by CSSCORP on 4/10/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol setValue <NSObject>

-(void)setString:(NSString *)dataValue;

@end

@interface SecondViewController : UIViewController
@property(nonatomic,weak)NSString *setValue;
- (IBAction)backtofirstView:(id)sender;
@property(nonatomic,retain)id<setValue> dataproperty;

@end

//NS_ASSUME_NONNULL_END
