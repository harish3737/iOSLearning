//
//  ViewController.m
//  SignUp
//
//  Created by CSSCORP on 12/26/18.
//  Copyright © 2018 CSSCORP. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    NSString *username;
    NSString *password;
    
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
     username= @"staging" ;
     password= @"m5Q5ccWX4M";
    NSString *url1=@"https://medicaresit.horizonbluestaging.com/restapi/v1/user/login";
    NSMutableDictionary *value = [[NSMutableDictionary alloc]init];
    [value setValue:@"agent1" forKey:@"username"];
    [value setValue:@"P@ssw0rd!@#" forKey:@"password"];
    [self changeValue:value];
//     __block ViewController *weakself = self;
    NSURLSession *session = [NSURLSession sharedSession];
    NSURL *url = [NSURL URLWithString:url1];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    request.HTTPMethod=@"Post";
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    NSString *authStr = [NSString stringWithFormat:@"%@:%@", username, password];
    NSData *authData = [authStr dataUsingEncoding:NSUTF8StringEncoding];
    NSString *authValue = [NSString stringWithFormat:@"Basic %@", [authData base64EncodedStringWithOptions:0]];
    [request setValue:authValue forHTTPHeaderField:@"Authorization"];
//    NSString *post = [NSString stringWithFormat:@"Username=%@&Password=%@",@"agent1",@"P@ssw0rd!@#"];
//    NSData *myData = [NSKeyedArchiver archivedDataWithRootObject:post];
//    NSString *postLength = [NSString stringWithFormat:@"%d",[postData length]];
//   NSData *postData = [post dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
//    NSData *myData = [NSKeyedArchiver archivedDataWithRootObject:value];
//    NSLog(@"%@",my)
//    NSMutableString *getParams = [NSJSONSerialization dataWithJSONObject:value options:kNilOptions error:0];
//    NSLog(@"%@",getParams);
    NSData *getParams =[NSJSONSerialization dataWithJSONObject:value options:NSJSONWritingPrettyPrinted error:0];
    
//  NSData *getData = [getParams dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    request.HTTPBody = getParams;
    [[session dataTaskWithRequest:request
                completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
                    if (!error) {
//                        NSDictionary *responseDictionary = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
//                        NSLog(@"%@",responseDictionary);
                        id response=[NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
                         if ([response isKindOfClass:[NSString class]])
                        {
                            NSString *responseString = [NSString stringWithFormat:@"%@",response];
                            NSLog(@"%@",responseString);
                        }
                        else if([response isKindOfClass:[NSDictionary class]])
                        {
                            NSDictionary *responseDictonary = response;
                            NSLog(@"%@",responseDictonary);
                        }
                       else if([response isKindOfClass:[NSArray class]])
                       {
                           NSArray *arrayResponse = response;
                           NSLog(@"%@",arrayResponse);
                       }
                        
                    }
                }] resume];
    
    
}
-(void)changeValue:(NSDictionary *)recieve
{

    NSData *Given=[NSJSONSerialization dataWithJSONObject:recieve options:NSJSONWritingPrettyPrinted error:0];
    NSString *print =[[NSString alloc]initWithData:Given encoding:NSUTF8StringEncoding];
    NSLog(@"%@",print);
}


// Write a seperate method for the calling method(Change from dict to data or string)
//get the data from response input as id and segregate according to the datatype(array or dictonary)
@end
