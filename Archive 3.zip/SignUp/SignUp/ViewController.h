//
//  ViewController.h
//  SignUp
//
//  Created by CSSCORP on 12/26/18.
//  Copyright © 2018 CSSCORP. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (strong, nonatomic) IBOutlet UITextView *viewText;




@end

