//
//  AppDelegate.h
//  StringSearchOptimized
//
//  Created by CSSCORP on 8/27/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

