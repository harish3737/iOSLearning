//
//  ViewController.m
//  StringSearchOptimized
//
//  Created by CSSCORP on 8/27/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self numberOfOccurrencesOfString:@"Sethuram" inString:@"xyxzxnSethuramuyyuyadsjbaksdhjadsSethuramfjsdlkjafskjhafkSethuram"];
    
}
-(void) numberOfOccurrencesOfString:(NSString *)subString inString:(NSString *)userString {
    const char * rawSubString = [subString UTF8String];
    NSUInteger subStringLength = strlen(rawSubString);
    
    const char * rawUserString = [userString UTF8String];
    NSUInteger userStringLength = strlen(rawUserString);
    
    NSUInteger subStringCount = 0;
    NSUInteger subStringIndex = 0;
    for (NSUInteger index = 0; index < userStringLength; ++index) {
        const char thisCharacter = rawUserString[index];
        if (thisCharacter != rawSubString[subStringIndex]) {
            subStringIndex = 0;
        }
        
        
        if (thisCharacter == rawSubString[subStringIndex]) {
            subStringIndex++;
            if (subStringIndex >= subStringLength) {
                subStringCount++;
                subStringIndex = 0;
            }
        }
    }
    NSLog(@"Number of Times String has occured ::: %lu",(unsigned long)subStringCount);
    
}

@end
