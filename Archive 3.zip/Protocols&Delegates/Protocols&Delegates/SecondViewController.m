//
//  SecondViewController.m
//  Protocols&Delegates
//
//  Created by CSSCORP on 3/26/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import "SecondViewController.h"

@interface SecondViewController ()
@property (nonatomic,readwrite)NSString *myString;

@end

@implementation SecondViewController
@synthesize txtLastName,delegate;
- (void)viewDidLoad {
    [super viewDidLoad];
    [self.navigationController setNavigationBarHidden:YES];
}
- (void)viewDidAppear:(BOOL)animated
{
    [txtLastName resignFirstResponder];
    [self.delegate setLastName:txtLastName.text]; //This is used to move the contents from the second VC to first VC
    [self.delegate setTextColor:[UIColor redColor]];
}


- (IBAction)btnDone:(id)sender {
    [txtLastName resignFirstResponder];
    [self.delegate setLastName:txtLastName.text];   //text field value is assigned to object
    [self.delegate setTextColor:[UIColor redColor]];
    [self.navigationController popViewControllerAnimated:YES];
    self.myString = @"newValue";
    NSLog(@"%@",_myString);
        }

@end
