//
//  ViewController.m
//  Protocols&Delegates
//
//  Created by CSSCORP on 3/26/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()


@end

@implementation ViewController
//@synthesize txtFullName,txtFirstName;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    _txtFullName.enabled = NO;
    
}

- (void)viewWillAppear:(BOOL)animated
{
    [_txtFirstName resignFirstResponder];
    
}
- (void)setLastName:(NSString *)lastname
{
    NSString *mainStr = [NSString stringWithFormat:@"%@ %@",_txtFirstName.text,lastname];
     [mainStr stringByAppendingString:@"new"];
    _txtFullName.text = mainStr;
   
    
}
-(void)setTextColor:(UIColor *)txtcolor
{
    _txtFullName.backgroundColor=txtcolor;
    
}
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    SecondViewController *sec = [segue destinationViewController];
    sec.delegate = self;  //using the second VC object to current VC object
//    sec.myString = @"value";
    NSMutableString *newString = [[NSMutableString alloc]initWithString:@"newVariable"];
    sec.myValue = newString;
    NSLog(@"%@",sec.myValue);
    [newString appendString:@"addedValue"];
    NSLog(@"%@",sec.myValue);

}




@end
