//
//  SecondViewController.h
//  Protocols&Delegates
//
//  Created by CSSCORP on 3/26/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol setText <NSObject> //Protocol Method Declaration
@required
-(void)setLastName:(NSString *)lastname;

@optional
-(void)setBackgroundColor:(UIColor *)bgcolor;
-(void)setTextColor:(UIColor *)txtcolor;

@end

@class ViewController;

@interface SecondViewController : UIViewController
@property (weak, atomic) IBOutlet UITextField *txtLastName;
- (IBAction)btnDone:(id)sender;
@property(weak,atomic) id<setText> delegate; //protocol object
@property(nonatomic,readonly)NSString *myString;
@property(nonatomic,copy)NSString *myValue;
@end


