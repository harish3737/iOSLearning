//
//  ViewController.h
//  Protocols&Delegates
//
//  Created by CSSCORP on 3/26/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SecondViewController.h"

@interface ViewController : UIViewController<setText> //assigning object to main vc
@property (nonatomic, retain) IBOutlet UITextField *txtFirstName;
@property (weak, atomic) IBOutlet UITextField *txtFullName;
@property(nonatomic,copy)NSString *myValue;
//@property(nonatomic,strong)SecondViewController *sec;

@end

