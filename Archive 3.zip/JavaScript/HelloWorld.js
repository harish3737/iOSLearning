// alert ("I am JavaScript")
// let admin;
// let name;
// name = 'john';
// admin = name;
// alert(admin);

// using a backstik(`) will help to concatinate/embed a result
// alert(`This is a result ${1+3}`)


// let name = "Vasu"
// alert(`Name is ${1}`)
// alert(`Name is ${"name"}`)
// alert(`Name is ${name}`)


// alert(""+1+0)
// alert(""-1+0)
// alert(true+false);
// alert(6/"3")
// alert("2"*"3")
// if string comes first then the addition is used as concatination 
// alert("$" + 4 + 5)
// if string comes at the end of addition with numbers then additon happens with concatination
// alert(4+5+"px")
// converted as number
// alert("4" - 2)
// NAN
// alert("4px" - 2)
// Infinity
// alert(7 / 0)
// if added the concatination happens as it considers the number as string
// alert( "-9"  + 5)
// if any operation other than addition is performed then the operation gets performed
// alert("  -9  " - 5)
// null is considered as 0
// alert(null + 1);
//NAN 
alert(undefined + 1)
