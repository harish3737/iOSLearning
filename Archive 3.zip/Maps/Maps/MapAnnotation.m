//
//  MapAnnotation.m
//  Maps
//
//  Created by CSSCORP on 1/2/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import "MapAnnotation.h"

@implementation MapAnnotation
-(id)initWithTitle:(NSString *)title andCoordinate:
(CLLocationCoordinate2D)coordinate2d {
    
    self.title = title;
    self.coordinate =coordinate2d;
    return self;
}
@end
