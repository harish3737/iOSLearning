//
//  ViewController.h
//  Maps
//
//  Created by CSSCORP on 1/2/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>

@interface ViewController : UIViewController
@property (strong, nonatomic) IBOutlet MKMapView *mapView;


@end

