//
//  Details_ViewController.m
//  LoginExample
//
//  Created by CSSCORP on 12/7/18.
//  Copyright © 2018 CSSCORP. All rights reserved.
//

#import "Details_ViewController.h"

@interface Details_ViewController ()

@end

@implementation Details_ViewController


@synthesize imageRecipe;
@synthesize recipeName;
@synthesize prepTime;
@synthesize getDataDict;

- (void)viewDidLoad {
    [super viewDidLoad];
//    imageRecipe.image=[UIImage imageNamed:@"FirstName.jpg"];
    // Do any additional setup after loading the view.
}

-(void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
    
    recipeName.text= [getDataDict objectForKey:@"receipe"];//[tableData objectAtIndex:indexPath.row];
    imageRecipe.image=[UIImage imageNamed:[getDataDict objectForKey:@"image"]];//[UIImage imageNamed:[thumbnails objectAtIndex:indexPath.row]];
    prepTime.text=[getDataDict objectForKey:@"time"];  //[prepTime objectAtIndex:indexPath.row];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
