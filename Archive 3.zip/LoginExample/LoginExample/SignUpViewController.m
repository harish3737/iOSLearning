//
//  SignUpViewController.m
//  LoginExample
//
//  Created by CSSCORP on 12/24/18.
//  Copyright © 2018 CSSCORP. All rights reserved.
//

#import "SignUpViewController.h"

@interface SignUpViewController ()


@end

@implementation SignUpViewController
@synthesize firstName;
@synthesize lastName;
@synthesize emailId;
@synthesize phoneNumber;
@synthesize userName;
@synthesize password;
@synthesize confirmPassword;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    firstName.tag=1;
    lastName.tag=2;
    emailId.tag=3;
    phoneNumber.tag=4;
    userName.tag=5;
    password.tag=6;
    confirmPassword.tag=7;
    //delegate
    firstName.delegate=self;
    lastName.delegate=self;
    phoneNumber.delegate=self;
    userName.delegate=self;
    password.delegate=self;
    confirmPassword.delegate=self;
}
- (void)viewWillAppear:(BOOL)animated
{
    BOOL bEmailValid = [self validEmailAddress:emailId.text];
    if(bEmailValid)
    {
        // email valid, other validations in the form
    }
    else
    {
        emailId.tintColor= [UIColor redColor];
    }

    
}
-(BOOL) validEmailAddress:(NSString*) emailStr {
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailValidation = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    if (![emailValidation evaluateWithObject:emailStr]) {
        return FALSE;
    }
    return TRUE;
}
//-(BOOL)validateEmail:(NSString *)email
//{
//    NSString *emailRegex = @"[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?";
//
//    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
//
//    return [emailTest evaluateWithObject:email];
//}

- (void)textFieldDidBeginEditing:(UITextField *)textField{
    [textField becomeFirstResponder];
}
-(BOOL)textFieldShouldReturn:(UITextField*)textField
{
    NSInteger nextTag = textField.tag + 1;
    // Try to find next responder
    UIResponder* nextResponder = [textField.superview viewWithTag:nextTag];
    if (nextResponder) {
        // Found next responder, so set it.
        [nextResponder becomeFirstResponder];
    } else {
        // Not found, so remove keyboard.
        [textField resignFirstResponder];
    }
    return NO; // We do not want UITextField to insert line-breaks.
}
- (BOOL)textFieldShouldEndEditing:(UITextField *)textField
{
    if(firstName.text.length!=0)
    {
        NSLog(@"Empty");
    }
       return YES;
}
-(void)textFieldDidEndEditing:(UITextField *)textField{
    [textField resignFirstResponder];
}
-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if(textField == firstName || textField == lastName)
    {
        NSCharacterSet *invalidCharSet = [[NSCharacterSet characterSetWithCharactersInString:@"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"] invertedSet];
        NSString *filtered = [[string componentsSeparatedByCharactersInSet:invalidCharSet] componentsJoinedByString:@""];
        return [string isEqualToString:filtered];
    }
    BOOL bEmailValid = [self validEmailAddress:emailId.text];
    if(bEmailValid)
    {
        // email valid, other validations in the form
    }
    else
    {
        emailId.backgroundColor= [UIColor redColor];
    }

    return YES;
}




@end
