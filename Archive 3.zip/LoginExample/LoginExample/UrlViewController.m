//
//  UrlViewController.m
//  LoginExample
//
//  Created by CSSCORP on 12/11/18.
//  Copyright © 2018 CSSCORP. All rights reserved.
//

#import "UrlViewController.h"
#import "Reachability.h"

@interface UrlViewController (){
    NSArray *rowCount;
    NSDictionary *totalcount;
}

@end

@implementation UrlViewController
@synthesize viewLoad;

- (void)viewDidLoad {
    [super viewDidLoad];
    viewLoad = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    viewLoad.center = CGPointMake(150, 150);
    viewLoad.color=[UIColor blackColor];
      [self.view addSubview:viewLoad];
    
    self.displayTable.delegate = self;
    self.displayTable.dataSource = self;
    
    self.displayTable.hidden = YES;
    
//
//    //URL Session to get the json file which is being used
//    NSURLSession *session = [NSURLSession sharedSession];//creating a url session for connection
//    NSURLSessionDataTask *dataTask = [session dataTaskWithURL:[NSURL URLWithString:@"https://restcountries.eu/rest/v2/all"] completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
//       id json = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
////        NSDictionary *json = [NSJSONSerialization isValidJSONObject:data];
//
//        if ([json isKindOfClass:[NSArray class]]){
//            NSMutableArray *jsonArray = json;
//
//
//        }else if([json isKindOfClass:[NSString class]]){
//            NSString *jsonString = [NSString stringWithFormat:@"%@",json];
//
//        }else {
//            NSMutableDictionary *jsonDict = json;
//
//        }
//
//        NSDictionary *getFirstDict = [json objectAtIndex:0];
//        rowCount=json;
//        NSLog(@"%@", [getFirstDict objectForKey:@"area"]);//Opening a session with the specified url and returning the json value
////        NSInteger area=[json objectForKey:@"area"];
////        NSLog(@"%d", area);
//    }];
//     [dataTask resume];//once session gets over it closes the tunnel this is used to resume the tunnel and open a new session
    
    
}
- (BOOL)connected
{
    Reachability *reachability = [Reachability reachabilityForInternetConnection];
    NetworkStatus networkStatus = [reachability currentReachabilityStatus];
    return networkStatus != NotReachable;
    
}
-(void)viewDidAppear:(BOOL)animated{
    if (![self connected]) {
        NSLog(@"connect to internet");
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Name" message:@"Switch ON Wifi or Data" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction *ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action)
                             {
                                 //BUTTON OK CLICK EVENT
                             }];
        UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil];
        [alert addAction:cancel];
        [alert addAction:ok];
        [self presentViewController:alert animated:YES completion:nil];
    } else {
        NSLog(@"Network connected");
    

    
    __block UrlViewController *weakself = self;
    [viewLoad startAnimating];
      NSURLSession *session = [NSURLSession sharedSession];//creating a url session for connection
    NSURLSessionDataTask *dataTask = [session dataTaskWithURL:[NSURL URLWithString:@"https://restcountries.eu/rest/v2/all"] completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        id json = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
        //        NSDictionary *json = [NSJSONSerialization isValidJSONObject:data];
       
        if ([json isKindOfClass:[NSArray class]]){
            
            [weakself getArrayFromResponse:json];
//            [self->viewLoad stopAnimating];
            self.viewLoad.hidden=YES;
            
        }else if([json isKindOfClass:[NSString class]]){
//            NSString *jsonString = [NSString stringWithFormat:@"%@",json];
            
        }else {
//      sc      NSMutableDictionary *jsonDict = json;
            
        }
    }];
      [dataTask resume];
  
//    [tableView reloadData];
    }
}



-(void)getArrayFromResponse:(id)json {
    
    
    rowCount = [NSArray arrayWithArray:json];
  
   
        self.displayTable.hidden = NO;
     [self.displayTable reloadData];
    
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    
    return [rowCount count];
    
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *simpleTableIdentifier = @"cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdentifier];
    }
    NSDictionary *getValue = [rowCount objectAtIndex:indexPath.row];
     NSLog(@"%@", getValue);
    cell.textLabel.text = [NSString stringWithFormat:@"%@",[getValue objectForKey:@"capital"]];
   
    
    return cell;
  }


//URL SESSION CONFIGURATION TO DOWNLOAD A FILE
//    NSURLSessionConfiguration *sessionConfiguration = [NSURLSessionConfiguration defaultSessionConfiguration];//Session configuration is used instead of shared session
//
//
//    NSURLSession *session = [NSURLSession sessionWithConfiguration:sessionConfiguration delegate:self delegateQueue:nil];//session configuration
//
//    NSURLSessionDownloadTask *downloadTask = [session downloadTaskWithURL:[NSURL URLWithString:@"http://cdn.tutsplus.com/mobile/uploads/2013/12/sample.jpg"]];//download image template from given website
//
//    [downloadTask resume];
//
//    }
//Function used to provide location for downloading
//- (void)URLSession:(NSURLSession *)session downloadTask:(NSURLSessionDownloadTask *)downloadTask didFinishDownloadingToURL:(NSURL *)location {
//    NSData *data = [NSData dataWithContentsOfURL:location];
//
//    dispatch_async(dispatch_get_main_queue(), ^{
//        [self.progressView setHidden:YES];//progress view being invoked
//        [self.imageView setImage:[UIImage imageWithData:data]];
//    });
//}
//
////Resume function
//- (void)URLSession:(NSURLSession *)session downloadTask:(NSURLSessionDownloadTask *)downloadTask didResumeAtOffset:(int64_t)fileOffset expectedTotalBytes:(int64_t)expectedTotalBytes {
//
//}
//
//- (void)URLSession:(NSURLSession *)session downloadTask:(NSURLSessionDownloadTask *)downloadTask didWriteData:(int64_t)bytesWritten totalBytesWritten:(int64_t)totalBytesWritten totalBytesExpectedToWrite:(int64_t)totalBytesExpectedToWrite {
//    float progress = (double)totalBytesWritten / (double)totalBytesExpectedToWrite;
////    NSLog(progress);
//    dispatch_async(dispatch_get_main_queue(), ^{
//        [self.progressView setProgress:progress];
//        NSLog(@"%f",progress);
//    });
//}




@end
