//
//  Web_ViewController.h
//  LoginExample
//
//  Created by CSSCORP on 12/10/18.
//  Copyright © 2018 CSSCORP. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Web_ViewController : UIViewController<UITextViewDelegate>
@property (strong, nonatomic) IBOutlet UIWebView *webView;
@property (strong, nonatomic) IBOutlet UITextView *textView;

@end


