//
//  Table_ViewController.m
//  LoginExample
//
//  Created by CSSCORP on 12/5/18.
//  Copyright © 2018 CSSCORP. All rights reserved.
//

#import "Table_ViewController.h"
#import "SimpleTableCell.h"
#import "Details_ViewController.h"
@interface Table_ViewController ()

@end

@implementation Table_ViewController
 NSArray *tableData;
NSArray *thumbnails;
NSArray *prepTime;

- (void)viewDidLoad {
    
    
    [super viewDidLoad];
    tableData = [NSArray arrayWithObjects:@"Egg Benedict", @"Mushroom Risotto", @"Full Breakfast", @"Hamburger", nil];
    thumbnails = [NSArray arrayWithObjects:@"FirstName.jpg", @"LastName.jpg", @"Email ID.png", @"phone.png", nil];
    prepTime =[NSArray arrayWithObjects:@"30mins", @"20mins", @"10mins", @"15mins", nil];
//    NSLog(getDataDict);

    
    }

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 4.0;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [tableData count];
}






//CELL FOR ROW
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"SimpleTableCell";
    
    SimpleTableCell *cell = (SimpleTableCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"SimpleTableCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    
    cell.nameLabel.text = [tableData objectAtIndex:indexPath.row];
    cell.thumbnailImageView.image = [UIImage imageNamed:[thumbnails objectAtIndex:indexPath.row]];
    cell.prepTimeLabel.text = [prepTime objectAtIndex:indexPath.row];
   
    return cell;
}


//HEADER
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.frame.size.width, 18)];
      UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 5, tableView.frame.size.width, 18)];
    [label setFont:[UIFont boldSystemFontOfSize:12]];
    NSString *string =@"Header";
    
    [label setText:string];
    [view addSubview:label];
    [view setBackgroundColor:[UIColor colorWithRed:166/255.0 green:177/255.0 blue:186/255.0 alpha:1.0]];
    return view;
}



//FOOTER
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.frame.size.width, 18)];
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 5, tableView.frame.size.width, 18)];
    [label setFont:[UIFont boldSystemFontOfSize:12]];
    NSString *string =@"Footer";
    
    [label setText:string];
    [view addSubview:label];
    [view setBackgroundColor:[UIColor colorWithRed:166/255.0 green:177/255.0 blue:186/255.0 alpha:1.0]]; 
    return view;
    
}
//NEW VIEW ON ROW SELECT
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
//    NSString *new = [tableData objectAtIndex:indexPath.row];
//    UIAlertView *messageAlert = [[UIAlertView alloc]
//                                 initWithTitle:@"Row Selected" message:new delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    
//    // Display Alert Message
//    [messageAlert show];
    NSString * storyboardName = @"Main";
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
    Details_ViewController *vc = [storyboard instantiateViewControllerWithIdentifier:@"Details_ViewController"];
//    vc.recipeName.text=[tableData objectAtIndex:indexPath.row];
//    vc.imageRecipe.image=[UIImage imageNamed:[thumbnails objectAtIndex:indexPath.row]];
//    vc.prepTime.text=[prepTime objectAtIndex:indexPath.row];
    
//    vc.getDataDict = [[alloc]initWithObjectsAndKeys:@"Hello",@"receipe",@"FirstName.jpg",@"image",@"10mins",@"time",nil];
  
//    vc.getDataDict = [[NSMutableDictionary alloc]mutableDict setObject:tableData forkey:@"receipe",@"FirstName.jpg",@"image",@"10mins",@"time",nil];
     // [self presentViewController:vc animated:YES completion:nil];
    NSMutableDictionary *dictionary = [NSMutableDictionary dictionary];
    [dictionary setObject:[tableData objectAtIndex:indexPath.row]  forKey: @"receipe"];
    [dictionary setObject:[thumbnails objectAtIndex:indexPath.row] forKey: @"image"];
    [dictionary setObject:[prepTime objectAtIndex:indexPath.row] forKey: @"time"];
    
    vc.getDataDict=dictionary;
                      
   [self.navigationController pushViewController:vc animated:YES];
    

}

//CUSTOMHEIGHTFORROW
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 78;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
