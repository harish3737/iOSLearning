//
//  ViewController.m
//  LoginExample
//
//  Created by CSSCORP on 11/28/18.
//  Copyright © 2018 CSSCORP. All rights reserved.
//

#import "ViewController.h"
#import "Table_ViewController.h"

@interface ViewController ()

@property (nonatomic, weak) IBOutlet UIView *referencedView;
@end

@implementation ViewController
@synthesize loginButton;
@synthesize userName;
@synthesize userPassword;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.

loginButton.layer.cornerRadius = 10;
loginButton.clipsToBounds=true;
userName.tag=1;
userPassword.tag=2;
//    userName.placeholder=@"UserName";
//    userPassword.placeholder=@"password";
    
userName.delegate = self;
userPassword.delegate=self;
    
//
////    userName.textColor
////    - (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
////        NSLog(@"touchesBegan:withEvent:");
////        [self.view endEditing:YES];
////        [super touchesBegan:touches withEvent:event];
////    }
//
//
//}
//
//-(void)textViewDidBeginEditing:(UITextView *)textView {
//    NSLog(@"Start Editing");
//}
//-(void)textViewDidEndEditing:(UITextView *)textView{
//    NSLog(@"End edit");
    
//}
}
- (void)viewDidAppear:(BOOL)animated
{}
- (void)textFieldDidBeginEditing:(UITextField *)textField{
    [textField becomeFirstResponder];
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    
    
    [self.view endEditing:YES];
    
    [super touchesBegan:touches withEvent:event];
    
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    NSLog(@"textFieldShouldReturn:");
    if (textField.tag == 1) {
        UITextField *passwordTextField = (UITextField *)[self.view viewWithTag:2];
        [passwordTextField becomeFirstResponder];
    }
    else {
        [textField resignFirstResponder];
    }
    return YES;
}
-(void)textFieldDidEndEditing:(UITextField *)textField{
    [textField resignFirstResponder];
}

- (IBAction)loginView:(id)sender {
//    // Instantiate a referenced view (assuming outlet has hooked up in XIB).
//    [[NSBundle mainBundle] loadNibNamed:@"Table_ViewController" owner:self options:nil];
//    // Controller's outlet has been bound during nib loading, so we can access view trough the outlet.
//    [self.view addSubview:self.referencedView];
  
    }


@end
