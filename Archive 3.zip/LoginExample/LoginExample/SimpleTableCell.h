//
//  SimpleTableCell.h
//  LoginExample
//
//  Created by CSSCORP on 12/6/18.
//  Copyright © 2018 CSSCORP. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface SimpleTableCell : UITableViewCell

@property (nonatomic, weak) IBOutlet UILabel *nameLabel;
@property (nonatomic, weak) IBOutlet UILabel *prepTimeLabel;
@property (nonatomic, weak) IBOutlet UIImageView *thumbnailImageView;

@end

