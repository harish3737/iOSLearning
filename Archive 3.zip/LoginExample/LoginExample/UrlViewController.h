//
//  UrlViewController.h
//  LoginExample
//
//  Created by CSSCORP on 12/11/18.
//  Copyright © 2018 CSSCORP. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"
#import <SystemConfiguration/SystemConfiguration.h>
#import "Reachability.h"




@interface UrlViewController : UIViewController<UITableViewDelegate, UITableViewDataSource>  {
    
    
}
//@property (weak, nonatomic) IBOutlet UIImageView *imageView;
//@property (weak, nonatomic) IBOutlet UIProgressView *progressView;
@property (strong, nonatomic) IBOutlet UITableView *displayTable;
@property(nonatomic, weak) id<UITableViewDataSourcePrefetching> prefetchDataSource;
@property (strong, nonatomic) IBOutlet UIActivityIndicatorView *viewLoad;
- (BOOL)connected;
@end


