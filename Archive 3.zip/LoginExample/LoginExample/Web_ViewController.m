//
//  Web_ViewController.m
//  LoginExample
//
//  Created by CSSCORP on 12/10/18.
//  Copyright © 2018 CSSCORP. All rights reserved.
//

#import "Web_ViewController.h"
#import "Reachability.h"

@interface Web_ViewController ()
{
    NSMutableString *new;
}
@end

@implementation Web_ViewController
@synthesize webView;
@synthesize textView;

- (BOOL)connected
{
    Reachability *reachability = [Reachability reachabilityForInternetConnection];
    NetworkStatus networkStatus = [reachability currentReachabilityStatus];
    return networkStatus != NotReachable;
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
//    NSURL *url = [NSURL fileURLWithPath:[[NSBundle mainBundle]pathForResource:@"about.html" ofType:nil]];
//    NSURL *url = [NSURL URLWithString:@"http://192.168.2.5:9002"];
////    NSURL *url = [NSURL URLWithString:@"http://8.8.8.8"];
//    NSURLRequest *request = [NSURLRequest requestWithURL:url];
//    [webView loadRequest:request];
//}
//    NSLog(webView);
//    NSLog(request);
    if (![self connected]) {
        NSLog(@"connect to internet");
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Name" message:@"Switch ON Wifi or Data" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction *ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action)
                             {
                                 //BUTTON OK CLICK EVENT
                             }];
         [alert addAction:ok];
        [self presentViewController:alert animated:YES completion:nil];
    } else {
        NSLog(@"Network connected");
        
    
    textView.delegate = self;
    // Create NSURLSession object.
    NSURLSession *session = [NSURLSession sharedSession];

    // Create a NSURL object.
    NSURL *url = [NSURL URLWithString:@"http://www.yahoo.com/regist"];

    // Create post request object with the url.
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    // Set request method to POST.
    request.HTTPMethod = @"POST";
    // Set post username and password data.
    request.HTTPBody = [@"username=Richard&pwd=888888" dataUsingEncoding:NSUTF8StringEncoding];

    // Create the NSURLSessionDataTask post task object.
    NSURLSessionDataTask *task = [session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {

        self->new=[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];

        // Print out the result JSON format data.
       NSDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
        NSLog(@"%@",json);
    }];

    // Execute th e task
    [task resume];
    }
}
- (BOOL)textViewShouldBeginEditing:(UITextView *)textView{
    NSLog(@"textViewShouldBeginEditing:");
    [textView setText:new];
     return YES;
}
- (void)textViewDidBeginEditing:(UITextView *)textView {
    NSLog(@"textViewDidBeginEditing:");
 //   textView.backgroundColor = [UIColor greenColor];
    
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    NSLog(@"touchesBegan:withEvent:");
    [self.view endEditing:YES];
    [super touchesBegan:touches withEvent:event];
}
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    NSCharacterSet *doneButtonCharacterSet = [NSCharacterSet newlineCharacterSet];
    NSRange replacementTextRange = [text rangeOfCharacterFromSet:doneButtonCharacterSet];
    NSUInteger location = replacementTextRange.location;
    
    if (textView.text.length + text.length > 140){
        if (location != NSNotFound){
            [textView resignFirstResponder];
        }
        return NO;
    }
    else if (location != NSNotFound){
        [textView resignFirstResponder];
        return NO;
    }
    return YES;
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
