//
//  Details_ViewController.h
//  LoginExample
//
//  Created by CSSCORP on 12/7/18.
//  Copyright © 2018 CSSCORP. All rights reserved.
//

#import <UIKit/UIKit.h>



@interface Details_ViewController : UIViewController
@property (strong, nonatomic) IBOutlet UILabel *recipeName;
@property (strong, nonatomic) IBOutlet UIImageView *imageRecipe;
@property (strong, nonatomic) IBOutlet UILabel *prepTime;

@property (strong,nonatomic) NSMutableDictionary *getDataDict;
@end


