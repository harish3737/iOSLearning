//
//  ViewController.h
//  LoginExample
//
//  Created by CSSCORP on 11/28/18.
//  Copyright © 2018 CSSCORP. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"
#import "SignUpViewController.h"

@interface ViewController : UIViewController<UITextFieldDelegate>
@property (strong, nonatomic) IBOutlet UITextField *userName;
@property (strong, nonatomic) IBOutlet UITextField *userPassword;
@property (weak, nonatomic) IBOutlet UIButton *loginButton;
- (IBAction)loginView:(id)sender;


@end

