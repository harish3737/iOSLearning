//
//  EditInfoViewController.h
//  SqLite3DBManager
//
//  Created by CSSCORP on 1/9/19.
//  Copyright © 2019 CSSCORP. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "DBManager.h"

NS_ASSUME_NONNULL_BEGIN
@protocol EditInfoViewControllerDelegate

-(void)editingInfoWasFinished;

@end

@interface EditInfoViewController : UIViewController <UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITextField *txtFirstname;

@property (weak, nonatomic) IBOutlet UITextField *txtLastname;

@property (weak, nonatomic) IBOutlet UITextField *txtAge;

@property (nonatomic, strong) DBManager *dbManager;

@property (nonatomic, strong) id<EditInfoViewControllerDelegate> delegate;

@property (nonatomic) int recordIDToEdit;

- (IBAction)saveInfo:(id)sender;

-(void)loadInfoToEdit;

@end



NS_ASSUME_NONNULL_END
